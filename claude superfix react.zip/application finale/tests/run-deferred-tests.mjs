/**
 * Tests de non-régression de l'envoi différé (frontend React).
 *
 * Le module frontend/src/state/deferredQueue.ts est compilé à la volée avec
 * esbuild (fourni par Vite) en remplaçant ses dépendances par des doublures
 * contrôlées, puis les garanties de la v2 historique sont rejouées :
 * mémoire volatile, isolation par installation/environnement/compte,
 * expiration, nettoyage du stockage persistant et statuts à réessayer.
 *
 * Exécution :  node tests/run-deferred-tests.mjs
 * Prérequis :  npm install dans frontend/ (esbuild est une dépendance de Vite).
 */
import { createRequire } from "node:module";
import { mkdtempSync, rmSync, writeFileSync } from "node:fs";
import { tmpdir } from "node:os";
import path from "node:path";
import { pathToFileURL, fileURLToPath } from "node:url";

const testsDirectory = path.dirname(fileURLToPath(import.meta.url));
const frontendDirectory = path.join(testsDirectory, "..", "frontend");
const require = createRequire(path.join(frontendDirectory, "package.json"));

let esbuild;
try {
  esbuild = require("esbuild");
} catch {
  console.error("esbuild introuvable : lancer « npm install » dans frontend/ avant ce test.");
  process.exit(2);
}

/* ——— Environnement navigateur minimal ——— */
const values = new Map();
globalThis.localStorage = {
  get length() { return values.size; },
  key(index) { return [...values.keys()][index] ?? null; },
  getItem(key) { return values.has(key) ? values.get(key) : null; },
  setItem(key, value) { values.set(String(key), String(value)); },
  removeItem(key) { values.delete(String(key)); },
};
let reloadCount = 0;
globalThis.window = { location: { reload() { reloadCount++; } } };

/* ——— Doublures des dépendances du module ——— */
const harness = {
  session: null,
  api: async () => { throw new Error("network disabled in test"); },
};
globalThis.__deferredTestHarness = harness;

const stubs = {
  react: `export function useSyncExternalStore(subscribe, getSnapshot) { return getSnapshot(); }`,
  "api-client": `export function api(...args) { return globalThis.__deferredTestHarness.api(...args); }`,
  appStore: `
    const harness = globalThis.__deferredTestHarness;
    export function getSession() { return harness.session; }
    export function patchSession(patch) { if (harness.session) harness.session = { ...harness.session, ...patch }; }
    export function refreshNavigationCounts() { return Promise.resolve(); }
    export function setCsrfToken() {}
    export function showLogin() {}
    export function synchroniseServerClock() {}
  `,
  toast: `export function showToast() {}`,
};

const stubPlugin = {
  name: "test-stubs",
  setup(build) {
    build.onResolve({ filter: /^react$/ }, () => ({ path: "react", namespace: "stub" }));
    build.onResolve({ filter: /api\/client$/ }, () => ({ path: "api-client", namespace: "stub" }));
    build.onResolve({ filter: /appStore$/ }, () => ({ path: "appStore", namespace: "stub" }));
    build.onResolve({ filter: /toast$/ }, () => ({ path: "toast", namespace: "stub" }));
    build.onLoad({ filter: /.*/, namespace: "stub" }, (args) => ({
      contents: stubs[args.path],
      loader: "js",
    }));
  },
};

const bundle = await esbuild.build({
  entryPoints: [path.join(frontendDirectory, "src", "state", "deferredQueue.ts")],
  bundle: true,
  format: "esm",
  write: false,
  plugins: [stubPlugin],
});

const workDirectory = mkdtempSync(path.join(tmpdir(), "deferred-test-"));
const bundlePath = path.join(workDirectory, "deferredQueue.mjs");
writeFileSync(bundlePath, bundle.outputFiles[0].text);
const queue = await import(pathToFileURL(bundlePath).href);
rmSync(workDirectory, { recursive: true, force: true });

/* ——— Assertions ——— */
function assert(condition, message) {
  if (!condition) {
    console.error(`✗ ${message}`);
    process.exit(1);
  }
}

const scopeTest = "a".repeat(64);
const scopeOther = "b".repeat(64);
const baseSession = () => ({
  authenticated: true,
  environment: "test",
  installation_scope: scopeTest,
  school_year: "2026-2027",
  deferred_submissions: { enabled: true },
  user: { id: 1, uid: "r.elguimar" },
});
const sampleBody = (key, details = "") => ({
  student_ids: [12],
  location: "1er étage",
  reason: "Présence prolongée",
  details,
  occurred_offset_minutes: 0,
  submission_key: key,
});

// 1. Mémoire volatile : rien ne touche jamais le stockage persistant.
harness.session = baseSession();
assert(queue.enqueueDeferredObservation(sampleBody("obs-test", "détail de test"), 1), "insertion en file échouée");
assert(queue.loadDeferredQueue().length === 1, "file de test absente");
assert(values.size === 0, "la file ne doit jamais être persistée dans localStorage");
assert(![...values.values()].some((value) => value.includes("détail de test")), "détail d'observation fuité vers le stockage persistant");

// 2. Isolation par environnement puis par installation.
harness.session.environment = "production";
assert(queue.loadDeferredQueue().length === 0, "la file de test a fui vers la production");
harness.session.environment = "test";
harness.session.installation_scope = scopeOther;
assert(queue.loadDeferredQueue().length === 0, "la file a fui vers une autre installation");
harness.session.installation_scope = scopeTest;
assert(queue.loadDeferredQueue().length === 0, "la file a survécu à un changement d'environnement");

// 3. Expiration après 12 heures.
assert(queue.enqueueDeferredObservation(sampleBody("obs-expired"), 1), "seconde insertion échouée");
queue.loadDeferredQueue()[0].captured_at = Date.now() - 13 * 60 * 60 * 1000;
assert(queue.loadDeferredQueue().length === 0, "entrée expirée non retirée");

// 4. Nettoyage des files persistées par d'anciennes versions.
values.set("suivi:offline-queue:v1:1", "[]");
values.set(`suivi:deferred:v2:${scopeTest}:test:1:r.elguimar`, "[]");
queue.discardUnsafeLegacyQueues();
assert(values.get("suivi:offline-queue:v1:1") === undefined, "ancienne file v1 non supprimée");
assert(![...values.keys()].some((key) => key.startsWith("suivi:deferred:v2:")), "file v2 persistée non supprimée");

// 5. Isolation par compte connecté.
assert(queue.enqueueDeferredObservation(sampleBody("obs-owner"), 1), "insertion propriétaire échouée");
harness.session.user = { id: 2, uid: "autre.compte" };
assert(queue.loadDeferredQueue().length === 0, "la file a survécu à un changement de compte");

// 6. Rafraîchissement CSRF : jamais de reprise sous une autre identité.
harness.session = baseSession();
harness.session.user = { id: 1, uid: "alice" };
assert(queue.enqueueDeferredObservation(sampleBody("obs-csrf-owner"), 1), "insertion pour test CSRF échouée");
harness.api = async () => ({ authenticated: true, csrf_token: "new-token", user: { id: 2, uid: "bob" } });
assert(await queue.refreshDeferredCsrf() === false, "le rafraîchissement CSRF a accepté un autre compte");
assert(queue.loadDeferredQueue().length === 0, "la file d'un autre compte a été conservée après CSRF");
assert(reloadCount === 1, "le changement d'identité doit recharger la page");

// 7. Relève de session : la maintenance purge après un changement de compte.
harness.session = baseSession();
harness.session.user = { id: 1, uid: "alice" };
assert(queue.enqueueDeferredObservation(sampleBody("obs-navigation-owner"), 1), "insertion pour test de relève échouée");
harness.session.user = { id: 3, uid: "carol" };
queue.maintainDeferredQueues();
assert(queue.loadDeferredQueue().length === 0, "la relève de session a conservé la file d'un autre compte");

// 8. Statuts « à réessayer » contre statuts demandant une vérification.
for (const status of [0, 401, 408, 419, 425, 429, 500, 503]) {
  assert(queue.isDeferredRetryableStatus(status) === true, `statut ${status} devrait rester à réessayer`);
}
for (const status of [400, 403, 409, 422]) {
  assert(queue.isDeferredRetryableStatus(status) === false, `statut ${status} devrait demander une vérification`);
}

console.log("Envoi différé (React) : mémoire volatile, isolation, expiration et nettoyage — OK");
