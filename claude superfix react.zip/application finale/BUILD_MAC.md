# Construire le frontend sur Mac

Le frontend est désormais une application **Vite + React + TypeScript + Tailwind CSS**.
Son code source vit dans `frontend/` ; le build produit `index.html`, `assets/`,
`icons/`, `manifest.webmanifest` et `service-worker.js` **directement dans le
dossier applicatif**, à côté de `api.php`. Le backend PHP n'est jamais touché :
c'est lui qui garantit la compatibilité Kwartz.

## 1. Installer Node.js (une seule fois)

Dans le Terminal :

```sh
node --version
```

- Si une version **20 ou plus** s'affiche : rien à faire.
- Sinon, installe Node avec [Homebrew](https://brew.sh) :

```sh
brew install node
```

## 2. Installer les dépendances (une seule fois, puis après chaque mise à jour du zip)

```sh
cd "chemin/vers/application finale/frontend"
npm install
```

(~80 paquets, moins d'une minute. Le dossier `node_modules/` créé reste sur ton
Mac : ne l'envoie jamais sur le serveur.)

## 3. Construire

```sh
npm run build
```

Cette commande enchaîne trois étapes et s'arrête à la première erreur :

1. `tsc` — vérification TypeScript complète ;
2. `vite build` — compilation optimisée (CSP stricte respectée : aucun script
   inline, chemins relatifs pour `/suivi2/` comme `/suivi/`) ;
3. `scripts/deploy.mjs` — copie du build dans le dossier applicatif parent,
   suppression des anciens fichiers frontend et injection du numéro de
   `VERSION` dans le service worker (le cache PWA se renouvelle tout seul).

## 4. Déployer sur Kwartz

Téléverse dans le dossier web (Nextcloud ou autre) :

- `index.html`
- `assets/` (tout le dossier — les noms de fichiers changent à chaque build,
  c'est normal : supprime l'ancien dossier `assets/` du serveur d'abord)
- `icons/`
- `manifest.webmanifest`
- `service-worker.js`
- `VERSION`

**Ne touche pas** à `var/settings.php` ni aux dossiers `src/`, `database/`,
`tools/`, `tests/` déjà en place. Le dossier `frontend/` n'a pas besoin d'être
sur le serveur (s'il y est, son `.htaccess` le protège).

À l'ouverture suivante, la PWA affichera « Une nouvelle version est prête —
Actualiser ».

## 5. Vérifier (recommandé)

```sh
node tests/run-deferred-tests.mjs      # garanties de l'envoi différé (React)
php tests/run-tests.php                # calculs critiques du backend
php tools/verifier-deploiement.php https://serveur/suivi2/ --insecure
```

## Développement en direct (facultatif)

`npm run dev` lance Vite sur http://localhost:5173 avec rechargement à chaud.
Les appels `api.php` sont relayés vers la cible configurée dans
`frontend/vite.config.ts` (bloc `server.proxy`) : adapte-la si tu veux pointer
vers ton serveur de test.
