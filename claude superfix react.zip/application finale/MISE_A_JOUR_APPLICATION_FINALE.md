# Mise à jour de Suivi des circulations

La version courante de ce dossier est **1.0.0-rc.4**.

Suivre le guide [MISE_A_JOUR_v1.0.0-rc.4.md](MISE_A_JOUR_v1.0.0-rc.4.md).
Il contient la liste exacte des fichiers modifiés et les contrôles à effectuer.

Règles essentielles :

1. tester d’abord dans `suivi-test` avec sa propre base MySQL ;
2. créer un point de récupération manuel ;
3. conserver le dossier `var` déjà présent sur le serveur ;
4. ne jamais remplacer `var/settings.php` entre test et production.
