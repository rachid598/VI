/**
 * Copie le build Vite (dist/) dans le dossier applicatif parent, celui qui est
 * déposé sur le serveur Kwartz à côté de api.php et src/.
 *
 * - remplace index.html, assets/, icons/, manifest.webmanifest, service-worker.js ;
 * - supprime les fichiers de l'ancien frontend s'ils traînent encore ;
 * - injecte la version applicative dans le service worker (nom de cache).
 *
 * Ne touche jamais à : api.php, install.php, src/, var/, database/, donnees/,
 * tools/, tests/, ni aux .htaccess.
 */
import { cpSync, existsSync, mkdirSync, readFileSync, rmSync, writeFileSync } from "node:fs";
import { resolve, dirname } from "node:path";
import { fileURLToPath } from "node:url";

const here = dirname(fileURLToPath(import.meta.url));
const frontendDir = resolve(here, "..");
const distDir = resolve(frontendDir, "dist");
const appDir = resolve(frontendDir, "..");

if (!existsSync(resolve(distDir, "index.html"))) {
  console.error("dist/index.html introuvable : lancer « npm run build » (vite build doit précéder ce script).");
  process.exit(1);
}
if (!existsSync(resolve(appDir, "api.php"))) {
  console.error("Sécurité : api.php introuvable dans le dossier parent — déploiement annulé.");
  process.exit(1);
}

const appVersion = readFileSync(resolve(appDir, "VERSION"), "utf8").trim() || "0.0.0-dev";

// 1. Nettoyer les artefacts remplacés (anciens builds et ancien frontend).
const obsolete = [
  "assets",
  "icons",
  "index.html",
  "service-worker.js",
  "manifest.webmanifest",
  "manifest.json",
];
for (const name of obsolete) {
  rmSync(resolve(appDir, name), { recursive: true, force: true });
}

// 2. Copier le build.
cpSync(distDir, appDir, { recursive: true });

// 3. Injecter la version dans le service worker (nom de cache unique par version).
const swPath = resolve(appDir, "service-worker.js");
if (existsSync(swPath)) {
  const sw = readFileSync(swPath, "utf8").replaceAll("__APP_VERSION__", appVersion);
  writeFileSync(swPath, sw);
}

// 4. S'assurer que le dossier frontend/ n'est pas servi par Apache.
mkdirSync(resolve(frontendDir), { recursive: true });
writeFileSync(resolve(frontendDir, ".htaccess"), "Require all denied\n");

console.log(`Build v${appVersion} déployé dans : ${appDir}`);
console.log("Fichiers publiés : index.html, assets/, icons/, manifest.webmanifest, service-worker.js");
console.log("Backend PHP intact (api.php, src/, var/, .htaccess…).");
