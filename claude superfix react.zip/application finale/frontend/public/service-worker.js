"use strict";

/*
 * Service worker du frontend React.
 *
 * Les fichiers du build Vite portent des noms hachés : plutôt qu'une liste
 * précalculée, le shell est mis en cache à la volée. Le nom du cache inclut la
 * version applicative (__APP_VERSION__, injectée au déploiement) : chaque
 * livraison invalide proprement le cache précédent, sans toucher à celui d'une
 * autre installation grâce à l'empreinte de portée.
 */

function scopeFingerprint(value) {
  let hash = 2166136261;
  for (let index = 0; index < value.length; index++) {
    hash ^= value.charCodeAt(index);
    hash = Math.imul(hash, 16777619);
  }
  return (hash >>> 0).toString(36);
}

const CACHE_PREFIX = `suivi-circulations-${scopeFingerprint(self.registration.scope)}-`;
const CACHE_NAME = `${CACHE_PREFIX}shell-__APP_VERSION__`;

self.addEventListener("install", (event) => {
  event.waitUntil(
    caches.open(CACHE_NAME).then((cache) => cache.addAll(["./", "./index.html"]).catch(() => undefined)),
  );
});

self.addEventListener("activate", (event) => {
  event.waitUntil(
    caches.keys()
      .then((names) => Promise.all(
        names.filter((name) => name.startsWith(CACHE_PREFIX) && name !== CACHE_NAME).map((name) => caches.delete(name)),
      ))
      .then(() => self.clients.claim()),
  );
});

self.addEventListener("message", (event) => {
  if (event.data && event.data.type === "SKIP_WAITING") {
    self.skipWaiting();
  }
});

self.addEventListener("fetch", (event) => {
  const request = event.request;
  if (request.method !== "GET") return;

  const url = new URL(request.url);
  if (url.origin !== self.location.origin) return;
  if (!url.href.startsWith(self.registration.scope)) return;

  // L'API et les dossiers serveur ne passent jamais par le cache : aucune
  // donnée personnelle ne doit être conservée dans la PWA.
  const sensitivePath = /\/(api\.php|install\.php)(?:$|\?)/.test(url.pathname)
    || /\/(var|database|src|tools|tests|donnees|frontend)(?:\/|$)/.test(url.pathname);
  if (sensitivePath) {
    event.respondWith(fetch(request, { cache: "no-store", credentials: "same-origin" }));
    return;
  }

  // Navigation : réseau d'abord, secours sur le shell en cache.
  if (request.mode === "navigate") {
    event.respondWith(
      fetch(request, { cache: "no-store", credentials: "same-origin" })
        .then((response) => {
          if (response.ok) {
            const copy = response.clone();
            event.waitUntil(caches.open(CACHE_NAME).then((cache) => cache.put("./index.html", copy)));
          }
          return response;
        })
        .catch(() => caches.open(CACHE_NAME).then((cache) => cache.match("./index.html"))),
    );
    return;
  }

  // Fichiers statiques du build (hachés, donc immuables) : cache d'abord,
  // réseau en complément.
  const staticDestination = ["style", "script", "image", "manifest", "font"].includes(request.destination)
    || url.pathname.endsWith(".webmanifest");
  if (staticDestination) {
    event.respondWith(
      caches.open(CACHE_NAME).then(async (cache) => {
        const cached = await cache.match(request);
        if (cached) return cached;
        const response = await fetch(request);
        if (response.ok) {
          await cache.put(request, response.clone());
        }
        return response;
      }),
    );
  }
});
