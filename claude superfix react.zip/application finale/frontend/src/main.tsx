import { StrictMode } from "react";
import { createRoot } from "react-dom/client";
import "./styles.css";
import { App } from "./App";
import { initialiseTheme } from "./state/appStore";
import { initialisePwa } from "./pwa/registerServiceWorker";

initialiseTheme();
initialisePwa();

createRoot(document.getElementById("root")!).render(
  <StrictMode>
    <App />
  </StrictMode>,
);
