import { ApiError } from "./types";

/**
 * Client de api.php — reprend fidèlement les garanties de l'ancien wrapper :
 * jeton CSRF sur toute mutation, neutralisation des réponses d'une session
 * fermée, remontée du code métier (possible_duplicate…) et bascule vers
 * l'écran de connexion sur 401.
 */

type Query = Record<string, string | number | undefined>;

export interface ApiOptions {
  method?: "GET" | "POST";
  body?: unknown;
  formData?: FormData;
  query?: Query;
  signal?: AbortSignal;
}

interface ClientBindings {
  getCsrfToken: () => string;
  getSessionEpoch: () => number;
  onUnauthorized: () => void;
}

let bindings: ClientBindings = {
  getCsrfToken: () => "",
  getSessionEpoch: () => 0,
  onUnauthorized: () => {},
};

export function bindApiClient(next: ClientBindings): void {
  bindings = next;
}

/** Actions dont le 401 signifie « réauthentification refusée », pas « session perdue ». */
const REAUTHENTICATION_ACTIONS = new Set([
  "admin_purge_students",
  "admin_restore_snapshot",
  "admin_close_year",
]);

export async function api<T = Record<string, unknown>>(action: string, options: ApiOptions = {}): Promise<T> {
  const requestEpoch = bindings.getSessionEpoch();
  const method = options.method || "GET";
  const headers: Record<string, string> = { Accept: "application/json" };
  let body: BodyInit | undefined;
  if (method !== "GET") headers["X-CSRF-Token"] = bindings.getCsrfToken();
  if (options.formData) {
    body = options.formData;
  } else if (options.body !== undefined) {
    headers["Content-Type"] = "application/json";
    body = JSON.stringify(options.body);
  }
  const params = new URLSearchParams();
  if (options.query) {
    for (const [key, value] of Object.entries(options.query)) {
      if (value !== undefined && value !== "") params.set(key, String(value));
    }
  }
  const suffix = params.toString() ? `&${params.toString()}` : "";
  const response = await fetch(`api.php?action=${encodeURIComponent(action)}${suffix}`, {
    method,
    headers,
    body,
    credentials: "same-origin",
    signal: options.signal,
  });

  let data: Record<string, unknown>;
  try {
    data = (await response.json()) as Record<string, unknown>;
  } catch {
    throw new ApiError("Réponse technique illisible.", 0);
  }

  // Une réponse arrivée après une déconnexion ne doit jamais réafficher de
  // contexte métier de l'ancienne session.
  if (requestEpoch !== bindings.getSessionEpoch() && action !== "login") {
    throw new ApiError("La session a été fermée.", 401);
  }

  if (!response.ok) {
    if (response.status === 401 && action !== "login" && action !== "session"
      && !REAUTHENTICATION_ACTIONS.has(action)) {
      bindings.onUnauthorized();
    }
    const error = new ApiError(
      typeof data.error === "string" && data.error !== "" ? data.error : "Une erreur est survenue.",
      response.status,
    );
    error.code = typeof data.code === "string" ? data.code : null;
    error.installationRequired = Boolean(data.installation_required);
    error.previousAt = typeof data.previous_at === "string" ? data.previous_at : null;
    throw error;
  }
  return data as T;
}

/**
 * Export CSV serveur (permis à points) : POST avec CSRF, réponse binaire
 * téléchargée par le navigateur — reproduit le comportement historique, avec
 * le nom de fichier proposé par le serveur (Content-Disposition).
 */
export async function downloadCsv(action: string, query: Query, fallbackFilename: string): Promise<void> {
  const requestEpoch = bindings.getSessionEpoch();
  const params = new URLSearchParams();
  for (const [key, value] of Object.entries(query)) {
    if (value !== undefined && value !== "") params.set(key, String(value));
  }
  const suffix = params.toString() ? `&${params.toString()}` : "";
  const response = await fetch(`api.php?action=${encodeURIComponent(action)}${suffix}`, {
    method: "POST",
    headers: { "X-CSRF-Token": bindings.getCsrfToken(), Accept: "text/csv" },
    body: "{}",
    credentials: "same-origin",
  });
  if (!response.ok) {
    let message = "Export impossible.";
    try {
      const data = (await response.json()) as { error?: string };
      if (data.error) message = data.error;
    } catch {
      /* réponse non JSON : message générique */
    }
    if (response.status === 401 && requestEpoch === bindings.getSessionEpoch()) {
      bindings.onUnauthorized();
    }
    throw new ApiError(message, response.status);
  }
  if (requestEpoch !== bindings.getSessionEpoch()) {
    throw new ApiError("La session a été fermée.", 401);
  }
  const blob = await response.blob();
  const disposition = response.headers.get("Content-Disposition") || "";
  const match = /filename="([^"]+)"/i.exec(disposition);
  const url = URL.createObjectURL(blob);
  const link = document.createElement("a");
  link.href = url;
  link.download = match ? match[1] : fallbackFilename;
  document.body.appendChild(link);
  link.click();
  link.remove();
  window.setTimeout(() => URL.revokeObjectURL(url), 1000);
}
