/**
 * Types des réponses de api.php. Le backend PHP fait foi : ces types décrivent
 * les champs réellement utilisés par l'interface, sans en inventer.
 */

export type Role = "teacher" | "aed" | "cpe" | "direction" | "pp" | "service" | "admin";

export interface User {
  id: number;
  uid: string;
  first_name: string;
  last_name: string;
  email: string;
  role: Role;
  pp_class: string | null;
  active: boolean;
}

export interface Permissions {
  can_submit: boolean;
  can_validate: boolean;
  can_dashboard: boolean;
  can_history: boolean;
  can_pp: boolean;
  can_points: boolean;
  can_digital_pass: boolean;
  can_anonymous_report: boolean;
  can_admin: boolean;
}

export interface PointsTrimester {
  label: string;
  start: string;
  end: string;
}

export interface PointsThreshold {
  points: number;
  action: string;
}

export interface PointsConfig {
  enabled: boolean;
  capital: number;
  alert_threshold: number;
  trimesters: PointsTrimester[];
  action_thresholds: PointsThreshold[];
  college_name: string;
  letter_template: string;
}

export interface SessionData {
  authenticated: boolean;
  app_version: string;
  server_now_utc: string;
  csrf_token: string;
  user: User | null;
  permissions: Partial<Permissions>;
  environment: "test" | "production";
  school_year: string;
  installation_scope?: string;
  locations: string[];
  reasons: string[];
  cancellation_reasons: string[];
  points: PointsConfig;
  digital_passes: { enabled: boolean; destinations: string[]; durations: number[] };
  deferred_submissions?: { enabled: boolean };
  alert_count: number | null;
  pending_count: number | null;
  notification_count: number | null;
}

export interface Student {
  id: number;
  first_name: string;
  last_name: string;
  class_name: string;
  active_pass?: null | { active: true; id?: number; destination?: string; expires_at?: string };
}

export type ObservationStatus = "pending" | "confirmed" | "cancelled" | "withdrawn";

export interface MyObservation {
  id: number;
  student_id: number;
  first_name: string;
  last_name: string;
  class_name: string;
  occurred_at: string;
  location: string;
  reason: string;
  details: string;
  status: ObservationStatus;
  cancellation_reason: string | null;
  created_at: string;
  can_edit?: boolean;
  can_withdraw?: boolean;
}

export interface PendingObservation {
  id: number;
  student_id: number;
  first_name: string;
  last_name: string;
  class_name: string;
  occurred_at: string;
  location: string;
  reason: string;
  details: string;
  status: ObservationStatus;
  reporter_name: string;
  sequence_key: string | null;
  claimed_by_user_id: number | null;
  claimed_by_name?: string | null;
  claim_expires_at: string | null;
  digital_pass?: { destination: string; issued_at: string; expires_at: string } | null;
  nearby?: PendingObservation[];
  [key: string]: unknown;
}

export interface UserNotification {
  id: number;
  observation_id: number;
  event_type: "confirmed" | "cancelled";
  created_at: string;
  read_at: string | null;
  first_name: string;
  last_name: string;
  class_name: string;
  location: string;
  reason: string;
  occurred_at: string;
  cancellation_reason?: string | null;
}

export interface DigitalPass {
  id: number;
  student_id: number;
  first_name: string;
  last_name: string;
  class_name: string;
  destination: string;
  issued_at: string;
  expires_at: string;
  issuer_name?: string;
  can_revoke?: boolean;
}

export interface HotSlot {
  slot: string;
  location: string;
  total: number;
  intensity: number;
  [key: string]: unknown;
}

export interface DashboardData {
  total_pending: number;
  total_confirmed_today?: number;
  hot_slots: HotSlot[];
  locations?: string[];
  [key: string]: unknown;
}

export interface PointsStudentRow {
  id: number;
  first_name: string;
  last_name: string;
  class_name: string;
  points: number;
  confirmed: number;
  pending: number;
  restored: number;
  pending_actions: number;
  last_confirmed_at: string | null;
  alert: boolean;
  [key: string]: unknown;
}

export interface AdminUserRow {
  id: number;
  ldap_uid: string;
  first_name: string;
  last_name: string;
  email: string;
  role: Role;
  pp_class: string | null;
  active: boolean;
  last_login_at: string | null;
  [key: string]: unknown;
}

export interface AuthorizedUserRow {
  id: number;
  ldap_uid: string;
  label: string;
  preassigned_role: Role | null;
  preassigned_pp_class: string | null;
  active: boolean;
  access_expires_at: string | null;
  [key: string]: unknown;
}

export interface RecoverySnapshot {
  id: number;
  kind: "automatic" | "manual" | "before_purge" | "before_restore";
  school_year: string | null;
  created_at: string;
  expires_at: string;
  payload_bytes: number;
  counts: Record<string, number>;
  [key: string]: unknown;
}

export interface AuditLogRow {
  id: number;
  action: string;
  entity_type: string;
  entity_id: number | null;
  created_at: string;
  actor_name?: string;
  metadata?: Record<string, unknown> | null;
  [key: string]: unknown;
}

/** Erreur applicative renvoyée par api.php, enrichie côté client. */
export class ApiError extends Error {
  status: number;
  code: string | null;
  installationRequired: boolean;
  previousAt: string | null;

  constructor(message: string, status: number) {
    super(message);
    this.status = status;
    this.code = null;
    this.installationRequired = false;
    this.previousAt = null;
  }
}
