import { useSyncExternalStore } from "react";

/**
 * Enregistrement du service worker et détection d'une nouvelle version :
 * lorsque un worker attend, le bandeau « Actualiser » est proposé ; le
 * rechargement n'a lieu qu'après accord de l'utilisateur.
 */

interface PwaState {
  waitingWorker: ServiceWorker | null;
  installPromptAvailable: boolean;
  isStandalone: boolean;
}

let state: PwaState = {
  waitingWorker: null,
  installPromptAvailable: false,
  isStandalone: false,
};

let deferredInstallPrompt: (Event & { prompt: () => Promise<void> }) | null = null;
let reloadOnControllerChange = false;
const listeners = new Set<() => void>();

function emit(patch: Partial<PwaState>): void {
  state = { ...state, ...patch };
  for (const listener of listeners) listener();
}

export function initialisePwa(): void {
  state.isStandalone = window.matchMedia("(display-mode: standalone)").matches
    || Boolean((navigator as { standalone?: boolean }).standalone);

  window.addEventListener("beforeinstallprompt", (event) => {
    event.preventDefault();
    deferredInstallPrompt = event as Event & { prompt: () => Promise<void> };
    emit({ installPromptAvailable: true });
  });
  window.addEventListener("appinstalled", () => {
    deferredInstallPrompt = null;
    emit({ installPromptAvailable: false, isStandalone: true });
  });

  if (!("serviceWorker" in navigator)) return;
  window.addEventListener("load", () => {
    navigator.serviceWorker
      .register("./service-worker.js")
      .then((registration) => {
        if (registration.waiting && navigator.serviceWorker.controller) {
          emit({ waitingWorker: registration.waiting });
        }
        registration.addEventListener("updatefound", () => {
          const installing = registration.installing;
          if (!installing) return;
          installing.addEventListener("statechange", () => {
            if (installing.state === "installed" && navigator.serviceWorker.controller) {
              emit({ waitingWorker: registration.waiting });
            }
          });
        });
        // Recherche de mise à jour toutes les heures et au retour sur l'onglet.
        window.setInterval(() => registration.update().catch(() => {}), 60 * 60 * 1000);
        document.addEventListener("visibilitychange", () => {
          if (document.visibilityState === "visible") registration.update().catch(() => {});
        });
      })
      .catch(() => {
        /* L'application fonctionne sans service worker. */
      });
    navigator.serviceWorker.addEventListener("controllerchange", () => {
      if (reloadOnControllerChange) window.location.reload();
    });
  });
}

export function applyPwaUpdate(): void {
  if (!state.waitingWorker) return;
  reloadOnControllerChange = true;
  state.waitingWorker.postMessage({ type: "SKIP_WAITING" });
}

export function dismissPwaUpdate(): void {
  emit({ waitingWorker: null });
}

export async function triggerInstallPrompt(): Promise<boolean> {
  if (!deferredInstallPrompt) return false;
  const prompt = deferredInstallPrompt;
  deferredInstallPrompt = null;
  emit({ installPromptAvailable: false });
  try {
    await prompt.prompt();
    return true;
  } catch {
    return false;
  }
}

export function isIosSafari(): boolean {
  const ua = navigator.userAgent;
  return /iPad|iPhone|iPod/.test(ua) && !/CriOS|FxiOS/.test(ua);
}

export function usePwaState(): PwaState {
  return useSyncExternalStore(
    (listener) => {
      listeners.add(listener);
      return () => listeners.delete(listener);
    },
    () => state,
  );
}
