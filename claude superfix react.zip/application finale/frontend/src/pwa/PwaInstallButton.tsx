import { useState } from "react";
import { Dialog, DialogHeader, Button, cx } from "../components/ui";
import { isIosSafari, triggerInstallPrompt, usePwaState } from "./registerServiceWorker";

/**
 * Bouton d'installation : invite native quand elle existe, sinon consignes
 * iOS/Safari (« Partager → Sur l'écran d'accueil »).
 */
export function PwaInstallButton({ variant }: { variant: "sidebar" | "login" }) {
  const { installPromptAvailable, isStandalone } = usePwaState();
  const [helpOpen, setHelpOpen] = useState(false);
  if (isStandalone) return null;

  const onClick = async () => {
    if (installPromptAvailable) {
      const shown = await triggerInstallPrompt();
      if (shown) return;
    }
    setHelpOpen(true);
  };

  return (
    <>
      <button
        type="button"
        onClick={onClick}
        className={cx(
          variant === "sidebar"
            ? "flex w-full items-center gap-3 rounded-[var(--radius-control)] px-3 py-2 text-[13px] font-semibold text-white/65 hover:bg-white/8 hover:text-white"
            : "inline-flex items-center gap-2 rounded-[var(--radius-control)] border border-line bg-surface px-4 py-2.5 text-sm font-semibold text-ink hover:bg-surface-soft",
        )}
      >
        <span aria-hidden>↓</span>
        Installer l’application
      </button>
      <Dialog open={helpOpen} onClose={() => setHelpOpen(false)} labelledBy="pwa-help-title">
        <DialogHeader
          id="pwa-help-title"
          title="Ajouter l’application à l’écran d’accueil"
          onClose={() => setHelpOpen(false)}
        />
        <div className="px-5 py-4 text-sm">
          {isIosSafari() ? (
            <ol className="list-decimal space-y-2 pl-5">
              <li>Toucher le bouton <strong>Partager</strong> de Safari (carré avec flèche).</li>
              <li>Choisir <strong>« Sur l’écran d’accueil »</strong>.</li>
              <li>Confirmer avec <strong>Ajouter</strong> : l’icône apparaît comme une application.</li>
            </ol>
          ) : (
            <p>
              Dans le menu du navigateur, choisir <strong>« Installer l’application »</strong> ou
              <strong> « Ajouter à l’écran d’accueil »</strong>. L’outil s’ouvrira ensuite en plein
              écran, avec son icône.
            </p>
          )}
        </div>
        <footer className="flex justify-end border-t border-line px-5 py-3.5">
          <Button variant="primary" onClick={() => setHelpOpen(false)}>J’ai compris</Button>
        </footer>
      </Dialog>
    </>
  );
}
