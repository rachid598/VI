import { useEffect, useState, type ReactNode } from "react";
import type { SessionData } from "../api/types";
import {
  applyTheme,
  availableViews,
  currentTheme,
  setView,
  useAppState,
  viewDefinitions,
  type ViewKey,
} from "../state/appStore";
import { displayUser, roleLabels } from "../lib/format";
import { cx } from "./ui";
import { PwaInstallButton } from "../pwa/PwaInstallButton";
import logoUrl from "../assets/logo-college.jpeg";

export function ThemeToggle({ className }: { className?: string }) {
  const [, force] = useState(0);
  return (
    <button
      type="button"
      aria-label={currentTheme() === "dark" ? "Activer le thème clair" : "Activer le thème sombre"}
      title="Changer de thème"
      onClick={() => {
        applyTheme(currentTheme() === "dark" ? "light" : "dark", true);
        force((value) => value + 1);
      }}
      className={cx(
        "flex size-9 items-center justify-center rounded-[var(--radius-control)] border border-line bg-surface text-ink hover:bg-surface-soft",
        className,
      )}
    >
      {currentTheme() === "dark" ? (
        <svg className="size-4.5" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.8" aria-hidden>
          <circle cx="12" cy="12" r="3.5" />
          <path d="M12 2v2M12 20v2M4.9 4.9l1.4 1.4M17.7 17.7l1.4 1.4M2 12h2M20 12h2M4.9 19.1l1.4-1.4M17.7 6.3l1.4-1.4" strokeLinecap="round" />
        </svg>
      ) : (
        <svg className="size-4.5" viewBox="0 0 24 24" fill="currentColor" aria-hidden>
          <path d="M20.2 15.4A8.5 8.5 0 0 1 8.6 3.8 8.5 8.5 0 1 0 20.2 15.4Z" />
        </svg>
      )}
    </button>
  );
}

function navBadge(session: SessionData, view: ViewKey): number {
  if (view === "validation") return Number(session.pending_count || 0);
  if (view === "points") return Number(session.alert_count || 0);
  return 0;
}

export function Layout({
  session,
  onLogout,
  onOpenNotifications,
  onOpenHelp,
  children,
}: {
  session: SessionData;
  onLogout: () => void;
  onOpenNotifications: () => void;
  onOpenHelp: () => void;
  children: ReactNode;
}) {
  const { view } = useAppState();
  const [menuOpen, setMenuOpen] = useState(false);
  const views = availableViews(session);
  const notificationCount = Number(session.notification_count || 0);

  useEffect(() => {
    if (!menuOpen) return;
    const onKey = (event: KeyboardEvent) => {
      if (event.key === "Escape") setMenuOpen(false);
    };
    document.addEventListener("keydown", onKey);
    return () => document.removeEventListener("keydown", onKey);
  }, [menuOpen]);

  const navigation = (
    <nav aria-label="Navigation principale" className="flex flex-1 flex-col gap-0.5 overflow-y-auto px-3 py-2">
      {views.map((key) => {
        const definition = viewDefinitions[key];
        const active = key === view;
        const badge = navBadge(session, key);
        return (
          <button
            key={key}
            type="button"
            aria-current={active ? "page" : undefined}
            onClick={() => {
              setView(key);
              setMenuOpen(false);
            }}
            className={cx(
              "group relative flex items-center gap-3 rounded-[var(--radius-control)] px-3 py-2.5 text-left text-[13.5px] font-semibold",
              active ? "bg-white/12 text-white" : "text-white/65 hover:bg-white/8 hover:text-white",
            )}
          >
            {/* Repère or réservé à la page active (charte). */}
            <span
              aria-hidden
              className={cx(
                "absolute left-0 top-1/2 h-5 w-0.75 -translate-y-1/2 rounded-full bg-gold transition-opacity",
                active ? "opacity-100" : "opacity-0",
              )}
            />
            <span aria-hidden className="flex size-6 items-center justify-center rounded-md bg-white/10 text-[12px]">
              {definition.icon}
            </span>
            <span className="flex-1">{definition.label}</span>
            {badge > 0 && (
              <span className="rounded-full bg-gold px-1.5 py-0.5 text-[11px] font-bold text-institution-deep">
                {badge > 99 ? "99+" : badge}
              </span>
            )}
          </button>
        );
      })}
    </nav>
  );

  return (
    <div className="flex min-h-dvh">
      {/* Sidebar bleu institution */}
      <aside
        id="app-sidebar"
        aria-label="Menu de l’application"
        className={cx(
          "fixed inset-y-0 left-0 z-40 flex w-66 flex-col bg-institution text-white transition-transform duration-200 lg:static lg:translate-x-0",
          menuOpen ? "translate-x-0 shadow-[var(--shadow-pop)]" : "-translate-x-full",
        )}
      >
        <div className="flex items-center gap-3 px-5 pb-4 pt-5">
          <img src={logoUrl} alt="" className="size-10 rounded-lg object-cover ring-1 ring-white/20" />
          <div className="min-w-0">
            <p className="font-display text-[14px] font-bold leading-tight">Suivi des circulations</p>
            <p className="text-[12px] text-white/60">Année {session.school_year}</p>
          </div>
        </div>
        {navigation}
        <div className="border-t border-white/10 px-3 py-3">
          <PwaInstallButton variant="sidebar" />
          <p className="mt-2 px-3 text-[11px] text-white/40">v{session.app_version}</p>
        </div>
      </aside>
      {menuOpen && (
        <button
          type="button"
          aria-label="Fermer le menu"
          onClick={() => setMenuOpen(false)}
          className="fixed inset-0 z-30 bg-institution-deep/50 lg:hidden"
        />
      )}

      {/* Contenu principal */}
      <div className="flex min-w-0 flex-1 flex-col">
        <header className="sticky top-0 z-20 flex items-center gap-3 border-b border-line bg-surface/95 px-4 py-3 backdrop-blur-none lg:px-7">
          <button
            type="button"
            aria-label="Ouvrir le menu"
            aria-controls="app-sidebar"
            aria-expanded={menuOpen}
            onClick={() => setMenuOpen(true)}
            className="flex size-9 items-center justify-center rounded-[var(--radius-control)] border border-line text-ink lg:hidden"
          >
            ☰
          </button>
          <h1 className="min-w-0 flex-1 truncate font-display text-[17px] font-bold tracking-tight">
            {viewDefinitions[view].label}
          </h1>
          <button
            type="button"
            aria-label="Ouvrir l’aide"
            title="Aide"
            onClick={onOpenHelp}
            className="flex size-9 items-center justify-center rounded-[var(--radius-control)] border border-line bg-surface font-bold text-muted hover:bg-surface-soft hover:text-ink"
          >
            ?
          </button>
          <ThemeToggle />
          <button
            type="button"
            aria-label={`Ouvrir mes notifications${notificationCount ? `, ${notificationCount} non lue${notificationCount > 1 ? "s" : ""}` : ""}`}
            title="Mes notifications"
            onClick={onOpenNotifications}
            className="relative flex size-9 items-center justify-center rounded-[var(--radius-control)] border border-line bg-surface text-muted hover:bg-surface-soft hover:text-ink"
          >
            <svg className="size-4.5" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.8" aria-hidden>
              <path d="M6 9a6 6 0 1 1 12 0c0 4 1.5 5.5 2 6H4c.5-.5 2-2 2-6Z" strokeLinejoin="round" />
              <path d="M10 18a2 2 0 0 0 4 0" strokeLinecap="round" />
            </svg>
            {notificationCount > 0 && (
              <span className="absolute -right-1 -top-1 rounded-full bg-danger px-1.5 py-px text-[10.5px] font-bold text-white">
                {notificationCount > 99 ? "99+" : notificationCount}
              </span>
            )}
          </button>
          <div className="ml-1 hidden items-center gap-3 border-l border-line pl-4 sm:flex">
            <div className="text-right leading-tight">
              <p className="text-[13px] font-bold">{session.user ? displayUser(session.user) : ""}</p>
              <p className="text-[11.5px] text-muted">{session.user ? roleLabels[session.user.role] : ""}</p>
            </div>
            <button
              type="button"
              onClick={onLogout}
              className="rounded-[var(--radius-control)] border border-line px-3 py-1.5 text-[12.5px] font-semibold text-muted hover:bg-surface-soft hover:text-ink"
            >
              Déconnexion
            </button>
          </div>
          <button
            type="button"
            onClick={onLogout}
            className="rounded-[var(--radius-control)] border border-line px-2.5 py-1.5 text-[12px] font-semibold text-muted sm:hidden"
          >
            Sortir
          </button>
        </header>

        {session.environment === "test" && (
          <div role="status" className="flex items-center gap-2 border-b border-amber/30 bg-amber-soft px-4 py-1.5 text-[12.5px] font-semibold text-amber lg:px-7">
            <span aria-hidden className="size-1.5 rounded-full bg-amber" />
            Mode démonstration — données fictives uniquement
          </div>
        )}

        <main className="mx-auto w-full max-w-6xl flex-1 px-4 py-6 lg:px-7 lg:py-8">{children}</main>
      </div>
    </div>
  );
}
