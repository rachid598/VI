import type { ObservationStatus } from "../api/types";
import { Badge } from "./ui";

const statusMeta: Record<ObservationStatus, { label: string; tone: "pending" | "confirmed" | "danger" | "neutral" }> = {
  pending: { label: "À vérifier", tone: "pending" },
  confirmed: { label: "Confirmé", tone: "confirmed" },
  cancelled: { label: "Annulé", tone: "danger" },
  withdrawn: { label: "Retiré", tone: "neutral" },
};

export function StatusBadge({ status }: { status: ObservationStatus }) {
  const meta = statusMeta[status] ?? { label: status, tone: "neutral" as const };
  return <Badge tone={meta.tone}>{meta.label}</Badge>;
}
