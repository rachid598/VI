import { cx } from "./ui";

const dotColors = {
  green: "bg-accent",
  amber: "bg-amber",
  red: "bg-danger",
  neutral: "bg-line-strong",
} as const;

export function StatCard({
  label,
  value,
  detail,
  tone = "neutral",
}: {
  label: string;
  value: number | string;
  detail: string;
  tone?: keyof typeof dotColors;
}) {
  return (
    <article className="rounded-[var(--radius-card)] border border-line bg-surface p-4 shadow-[var(--shadow-card)]">
      <div className="flex items-center justify-between gap-2">
        <span className="text-[12px] font-semibold uppercase tracking-wide text-muted">{label}</span>
        <span aria-hidden className={cx("size-2 rounded-full", dotColors[tone])} />
      </div>
      <p className="mt-1.5 font-display text-[26px] font-bold leading-none tracking-tight">{value}</p>
      <p className="mt-1.5 text-[12px] text-muted">{detail}</p>
    </article>
  );
}

export function StatGrid({ children }: { children: React.ReactNode }) {
  return <div className="grid grid-cols-2 gap-3 lg:grid-cols-4">{children}</div>;
}
