import {
  forwardRef,
  useEffect,
  useRef,
  type ButtonHTMLAttributes,
  type InputHTMLAttributes,
  type ReactNode,
  type SelectHTMLAttributes,
  type TextareaHTMLAttributes,
} from "react";

/* ————————————————————————————————————————————————————————————————
   Bibliothèque de composants — « institution contemporaine ».
   Une surface, une fonction ; la couleur porte du sens ; focus visibles.
   ———————————————————————————————————————————————————————————————— */

export function cx(...parts: Array<string | false | null | undefined>): string {
  return parts.filter(Boolean).join(" ");
}

/* ——— Boutons ——— */

type ButtonVariant = "primary" | "secondary" | "ghost" | "danger";

const buttonVariants: Record<ButtonVariant, string> = {
  primary: "bg-accent text-white hover:bg-accent-hover shadow-[var(--shadow-card)] disabled:hover:bg-accent",
  secondary: "border border-line-strong bg-surface text-ink hover:bg-surface-soft hover:border-line-strong",
  ghost: "text-ink hover:bg-surface-strong",
  danger: "border border-danger/40 bg-surface text-danger hover:bg-danger-soft",
};

export interface ButtonProps extends ButtonHTMLAttributes<HTMLButtonElement> {
  variant?: ButtonVariant;
  size?: "sm" | "md";
  loading?: boolean;
}

export const Button = forwardRef<HTMLButtonElement, ButtonProps>(function Button(
  { variant = "secondary", size = "md", loading = false, className, children, disabled, ...rest },
  ref,
) {
  return (
    <button
      ref={ref}
      disabled={disabled || loading}
      className={cx(
        "inline-flex items-center justify-center gap-2 rounded-[var(--radius-control)] font-semibold",
        "disabled:opacity-55 disabled:cursor-not-allowed select-none",
        size === "sm" ? "px-3 py-1.5 text-[13px]" : "px-4 py-2.5 text-sm",
        buttonVariants[variant],
        className,
      )}
      {...rest}
    >
      {loading && <Spinner className="size-3.5" />}
      {children}
    </button>
  );
});

export function Spinner({ className }: { className?: string }) {
  return (
    <span
      aria-hidden
      className={cx(
        "inline-block animate-spin rounded-full border-2 border-current border-t-transparent",
        className ?? "size-4",
      )}
    />
  );
}

/* ——— Cartes ——— */

export function Card({ className, children }: { className?: string; children: ReactNode }) {
  return (
    <section
      className={cx(
        "rounded-[var(--radius-card)] border border-line bg-surface shadow-[var(--shadow-card)]",
        className,
      )}
    >
      {children}
    </section>
  );
}

export function CardHeader({
  title,
  description,
  aside,
  className,
}: {
  title: ReactNode;
  description?: ReactNode;
  aside?: ReactNode;
  className?: string;
}) {
  return (
    <header className={cx("flex items-start justify-between gap-4 border-b border-line px-5 py-4", className)}>
      <div className="min-w-0">
        <h3 className="font-display text-[15px] font-bold tracking-tight">{title}</h3>
        {description && <p className="mt-0.5 text-[13px] text-muted">{description}</p>}
      </div>
      {aside && <div className="shrink-0">{aside}</div>}
    </header>
  );
}

export function CardBody({ className, children }: { className?: string; children: ReactNode }) {
  return <div className={cx("px-5 py-4", className)}>{children}</div>;
}

/* ——— Champs ——— */

export function Field({
  label,
  hint,
  error,
  htmlFor,
  className,
  children,
}: {
  label: ReactNode;
  hint?: ReactNode;
  error?: string;
  htmlFor?: string;
  className?: string;
  children: ReactNode;
}) {
  return (
    <div className={cx("flex flex-col gap-1.5", className)}>
      <label htmlFor={htmlFor} className="text-[13px] font-semibold text-ink">
        {label}
        {hint && <span className="ml-2 font-normal text-muted">{hint}</span>}
      </label>
      {children}
      {error && (
        <p role="alert" className="text-[12.5px] font-medium text-danger">
          {error}
        </p>
      )}
    </div>
  );
}

const controlBase =
  "w-full rounded-[var(--radius-control)] border border-line-strong bg-surface px-3.5 py-2.5 text-sm text-ink " +
  "placeholder:text-muted/70 focus:border-focus focus:outline-none focus:ring-2 focus:ring-focus/25 " +
  "disabled:opacity-55 aria-[invalid=true]:border-danger";

export const Input = forwardRef<HTMLInputElement, InputHTMLAttributes<HTMLInputElement>>(
  function Input({ className, ...rest }, ref) {
    return <input ref={ref} className={cx(controlBase, className)} {...rest} />;
  },
);

export const Select = forwardRef<HTMLSelectElement, SelectHTMLAttributes<HTMLSelectElement>>(
  function Select({ className, children, ...rest }, ref) {
    return (
      <select ref={ref} className={cx(controlBase, "appearance-none pr-9 bg-no-repeat", "select-chevron", className)} {...rest}>
        {children}
      </select>
    );
  },
);

export const Textarea = forwardRef<HTMLTextAreaElement, TextareaHTMLAttributes<HTMLTextAreaElement>>(
  function Textarea({ className, ...rest }, ref) {
    return <textarea ref={ref} className={cx(controlBase, "min-h-24 resize-y", className)} {...rest} />;
  },
);

/* ——— Badges et pastilles ——— */

type BadgeTone = "neutral" | "confirmed" | "pending" | "danger" | "gold";

const badgeTones: Record<BadgeTone, string> = {
  neutral: "bg-surface-strong text-ink",
  confirmed: "bg-accent-soft text-accent",
  pending: "bg-amber-soft text-amber",
  danger: "bg-danger-soft text-danger",
  gold: "bg-gold/15 text-gold",
};

export function Badge({ tone = "neutral", className, children }: { tone?: BadgeTone; className?: string; children: ReactNode }) {
  return (
    <span className={cx("inline-flex items-center gap-1 rounded-full px-2.5 py-0.5 text-[12px] font-bold", badgeTones[tone], className)}>
      {children}
    </span>
  );
}

export function Avatar({ initials, className }: { initials: string; className?: string }) {
  return (
    <span
      aria-hidden
      className={cx(
        "flex size-9 shrink-0 items-center justify-center rounded-full bg-institution/10 text-[12px] font-bold text-institution dark:bg-white/10 dark:text-ink",
        className,
      )}
    >
      {initials}
    </span>
  );
}

/* ——— Onglets de statut avec compteurs ——— */

export function StatusTabs<T extends string>({
  value,
  onChange,
  options,
  label,
}: {
  value: T;
  onChange: (next: T) => void;
  options: Array<{ value: T; label: string; count?: number }>;
  label: string;
}) {
  return (
    <div role="tablist" aria-label={label} className="flex flex-wrap gap-1.5">
      {options.map((option) => {
        const active = option.value === value;
        return (
          <button
            key={option.value}
            role="tab"
            type="button"
            aria-selected={active}
            onClick={() => onChange(option.value)}
            className={cx(
              "inline-flex items-center gap-2 rounded-full border px-3.5 py-1.5 text-[13px] font-semibold",
              active
                ? "border-institution bg-institution text-white dark:border-accent dark:bg-accent dark:text-institution-deep"
                : "border-line bg-surface text-muted hover:text-ink hover:border-line-strong",
            )}
          >
            {option.label}
            {option.count !== undefined && (
              <span className={cx("rounded-full px-1.5 text-[11.5px] font-bold", active ? "bg-white/20" : "bg-surface-strong")}>
                {option.count}
              </span>
            )}
          </button>
        );
      })}
    </div>
  );
}

/* ——— Interrupteur d'administration ——— */

export function Toggle({
  checked,
  onToggle,
  disabled,
  label,
}: {
  checked: boolean;
  onToggle: () => void;
  disabled?: boolean;
  label: string;
}) {
  return (
    <button
      type="button"
      role="switch"
      aria-checked={checked}
      aria-label={label}
      disabled={disabled}
      onClick={onToggle}
      className={cx(
        "relative h-7 w-12 shrink-0 rounded-full border transition-colors disabled:opacity-55",
        checked ? "border-accent bg-accent" : "border-line-strong bg-surface-strong",
      )}
    >
      <span
        aria-hidden
        className={cx(
          "absolute top-0.5 size-5.5 rounded-full bg-white shadow transition-[left]",
          checked ? "left-[calc(100%-1.5rem)]" : "left-0.5",
        )}
      />
    </button>
  );
}

/* ——— États vides et chargement ——— */

export function EmptyState({ icon = "…", title, children }: { icon?: string; title: string; children?: ReactNode }) {
  return (
    <div className="flex flex-col items-center justify-center gap-2 px-6 py-14 text-center">
      <span aria-hidden className="flex size-11 items-center justify-center rounded-full bg-surface-strong text-lg text-muted">
        {icon}
      </span>
      <p className="font-semibold">{title}</p>
      {children && <div className="max-w-md text-[13px] text-muted">{children}</div>}
    </div>
  );
}

export function LoadingView() {
  return (
    <div className="flex items-center justify-center gap-3 py-20 text-muted">
      <Spinner />
      <span className="text-sm">Chargement…</span>
    </div>
  );
}

export function ErrorCard({ message, onRetry }: { message: string; onRetry?: () => void }) {
  return (
    <Card className="border-danger/40">
      <CardBody className="flex flex-wrap items-center justify-between gap-3">
        <p className="text-sm font-semibold text-danger">{message}</p>
        {onRetry && (
          <Button size="sm" onClick={onRetry}>
            Réessayer
          </Button>
        )}
      </CardBody>
    </Card>
  );
}

/* ——— Dialogue natif ——— */

export function Dialog({
  open,
  onClose,
  labelledBy,
  className,
  children,
}: {
  open: boolean;
  onClose: () => void;
  labelledBy: string;
  className?: string;
  children: ReactNode;
}) {
  const ref = useRef<HTMLDialogElement>(null);
  useEffect(() => {
    const dialog = ref.current;
    if (!dialog) return;
    if (open && !dialog.open) dialog.showModal();
    if (!open && dialog.open) dialog.close();
  }, [open]);
  return (
    <dialog
      ref={ref}
      aria-labelledby={labelledBy}
      className={className}
      onClose={onClose}
      onCancel={onClose}
    >
      {open ? children : null}
    </dialog>
  );
}

export function DialogHeader({
  id,
  title,
  description,
  onClose,
}: {
  id: string;
  title: ReactNode;
  description?: ReactNode;
  onClose: () => void;
}) {
  return (
    <header className="flex items-start justify-between gap-4 border-b border-line px-5 py-4">
      <div>
        <h2 id={id} className="font-display text-[15px] font-bold tracking-tight">{title}</h2>
        {description && <p className="mt-0.5 text-[13px] text-muted">{description}</p>}
      </div>
      <button
        type="button"
        aria-label="Fermer"
        onClick={onClose}
        className="flex size-8 items-center justify-center rounded-[var(--radius-control)] text-muted hover:bg-surface-strong hover:text-ink"
      >
        ×
      </button>
    </header>
  );
}

/* ——— Tableaux ——— */

export function DataTable({ head, children }: { head: ReactNode; children: ReactNode }) {
  return (
    <div className="table-scroll">
      <table className="w-full min-w-max border-collapse text-sm">
        <thead>
          <tr className="border-b border-line bg-surface-soft text-left text-[12.5px] text-muted [&>th]:px-4 [&>th]:py-2.5 [&>th]:font-semibold">
            {head}
          </tr>
        </thead>
        <tbody className="[&>tr]:border-b [&>tr]:border-line [&>tr:last-child]:border-0 [&>tr:hover]:bg-surface-soft/60 [&_td]:px-4 [&_td]:py-3">
          {children}
        </tbody>
      </table>
    </div>
  );
}
