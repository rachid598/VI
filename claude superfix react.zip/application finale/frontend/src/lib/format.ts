import type { Role, User } from "../api/types";

export const roleLabels: Record<Role, string> = {
  teacher: "Enseignant",
  aed: "AED",
  cpe: "CPE",
  direction: "Direction",
  pp: "Professeur principal",
  service: "Service médico-social",
  admin: "Administrateur",
};

/** Toutes les dates persistées sont en UTC ; l'affichage est en heure de Paris. */
export function parseUtcDate(value: unknown): Date {
  const source = String(value ?? "").trim();
  if (!source) return new Date(NaN);
  if (/^\d{4}-\d{2}-\d{2}$/.test(source)) return new Date(`${source}T00:00:00Z`);
  const normalized = source.includes("T") ? source : source.replace(" ", "T");
  return new Date(/Z|[+-]\d{2}:?\d{2}$/.test(normalized) ? normalized : `${normalized}Z`);
}

export function formatDate(value: unknown): string {
  const date = parseUtcDate(value);
  if (Number.isNaN(date.getTime())) return String(value ?? "");
  return new Intl.DateTimeFormat("fr-FR", {
    day: "2-digit",
    month: "short",
    hour: "2-digit",
    minute: "2-digit",
    timeZone: "Europe/Paris",
  }).format(date);
}

export function formatTime(value: unknown): string {
  const date = parseUtcDate(value);
  if (Number.isNaN(date.getTime())) return String(value ?? "");
  return new Intl.DateTimeFormat("fr-FR", {
    hour: "2-digit",
    minute: "2-digit",
    timeZone: "Europe/Paris",
  }).format(date);
}

export function formatDateOnly(value: unknown): string {
  const date = parseUtcDate(value);
  if (Number.isNaN(date.getTime())) return String(value ?? "");
  return new Intl.DateTimeFormat("fr-FR", {
    day: "2-digit",
    month: "long",
    year: "numeric",
    timeZone: "Europe/Paris",
  }).format(date);
}

export function displayName(firstName?: string, lastName?: string): string {
  return `${firstName || ""} ${lastName || ""}`.trim();
}

export function displayUser(user: User): string {
  return displayName(user.first_name, user.last_name) || user.uid;
}

export function initials(person: { first_name?: string; last_name?: string }): string {
  return `${(person.first_name || "")[0] || ""}${(person.last_name || "")[0] || ""}`.toUpperCase();
}

/** Niveau (3 à 6) déduit du nom de classe, ex. « 6G2 » → « 6 ». */
export function classLevel(className: string): string {
  const match = /^([3-6])(?=\D|$)/.exec(String(className || "").trim());
  return match ? match[1] : "";
}

export function formatBytes(bytes: number): string {
  if (!Number.isFinite(bytes) || bytes < 0) return "—";
  if (bytes < 1024) return `${bytes} o`;
  if (bytes < 1048576) return `${(bytes / 1024).toFixed(1)} Kio`;
  return `${(bytes / 1048576).toFixed(1)} Mio`;
}

export function plural(count: number, singular: string, pluralForm?: string): string {
  return count > 1 ? (pluralForm ?? `${singular}s`) : singular;
}
