import { useCallback, useEffect, useMemo, useState } from "react";
import { api } from "../../api/client";
import type { ObservationStatus } from "../../api/types";
import { patchSession, useAppState } from "../../state/appStore";
import { pollSession } from "../../state/sessionPoll";
import { showToast } from "../../state/toast";
import { classLevel, displayName, formatDate, formatTime } from "../../lib/format";
import {
  Badge, Button, Card, CardBody, EmptyState, ErrorCard, LoadingView, Select, cx,
} from "../../components/ui";
import { StatusBadge } from "../../components/StatusBadge";

/** Contexte immuable d'un billet valable à l'heure du constat (jamais décisionnel). */
interface PassContext {
  destination?: string;
  issued_at?: string;
  expires_at?: string;
}

interface QueueObservation {
  id: number;
  first_name: string;
  last_name: string;
  class_name: string;
  occurred_at: string;
  location: string;
  reason: string;
  details: string;
  status: ObservationStatus;
  reporter_first_name?: string;
  reporter_last_name?: string;
  digital_pass_context?: PassContext | null;
  sequence_linked?: boolean;
  same_sequence?: boolean;
  nearby_observations?: QueueObservation[];
  claimed_by_user_id?: number | null;
  claimant_user_id?: number | null;
  claimed_by_current_user?: boolean;
  claim_locked?: boolean;
  claimant_name?: string;
  claimed_by_name?: string;
  claimant_first_name?: string;
  claimed_by_first_name?: string;
  claimant_last_name?: string;
  claimed_by_last_name?: string;
  [key: string]: unknown;
}

interface QueueResponse {
  observations: QueueObservation[];
  total_pending?: number;
  filters?: { levels?: unknown[]; classes?: unknown[]; locations?: unknown[] };
  levels?: unknown[];
  classes?: unknown[];
  locations?: unknown[];
}

interface Filters {
  level: string;
  class_name: string;
  location: string;
  age: "all" | "today" | "over24" | "over48";
  path: "all" | "with" | "without";
}

const defaultFilters: Filters = { level: "", class_name: "", location: "", age: "all", path: "all" };

function normaliseFilterValues(values: unknown[], preferredKey = ""): string[] {
  const output = (Array.isArray(values) ? values : [])
    .map((value) => {
      if (value && typeof value === "object") {
        const record = value as Record<string, unknown>;
        return record[preferredKey] ?? record.value ?? record.label ?? "";
      }
      return value;
    })
    .map((value) => String(value ?? "").trim())
    .filter(Boolean);
  const unique = [...new Set(output)];
  if (preferredKey === "level") {
    const order = ["6", "5", "4", "3"];
    return unique.sort((left, right) => order.indexOf(left) - order.indexOf(right));
  }
  return unique.sort((left, right) => left.localeCompare(right, "fr", { numeric: true }));
}

function PassContextNote({ context, compact = false }: { context?: PassContext | null; compact?: boolean }) {
  if (!context?.destination || !context.issued_at || !context.expires_at) return null;
  if (compact) {
    return (
      <p className="mt-1 flex items-center gap-1.5 text-[11.5px] font-semibold text-gold">
        <span aria-hidden>↗</span>
        Billet numérique · {context.destination} · {formatTime(context.issued_at)}–{formatTime(context.expires_at)}
      </p>
    );
  }
  return (
    <div role="note" className="mt-2 flex items-start gap-2.5 rounded-[var(--radius-control)] border border-gold/30 bg-gold/8 px-3 py-2">
      <span aria-hidden className="text-gold">↗</span>
      <div className="text-[12.5px]">
        <p className="font-bold text-gold">Billet numérique valable au moment du constat</p>
        <p className="text-muted">{context.destination} · de {formatTime(context.issued_at)} à {formatTime(context.expires_at)}</p>
      </div>
    </div>
  );
}

export function ValidationQueue() {
  const { session } = useAppState();
  const [filters, setFilters] = useState<Filters>(defaultFilters);
  const [data, setData] = useState<QueueResponse | null>(null);
  const [error, setError] = useState("");
  const [busyId, setBusyId] = useState<number | null>(null);
  const [cancelReasons, setCancelReasons] = useState<Record<number, string>>({});
  /** Sélections de parcours : observation ancre → observations cochées. */
  const [sequenceSelections, setSequenceSelections] = useState<Record<number, number[]>>({});

  const load = useCallback(async (activeFilters: Filters) => {
    setError("");
    try {
      const response = await api<QueueResponse>("pending_observations", {
        query: { ...activeFilters },
      });
      setData(response);
      setSequenceSelections({});
      setCancelReasons({});
      patchSession({ pending_count: Number(response.total_pending ?? response.observations.length) });
    } catch (requestError) {
      setError(requestError instanceof Error ? requestError.message : "Chargement impossible.");
    }
  }, []);

  useEffect(() => {
    void load(filters);
  }, [filters, load]);

  const observations = data?.observations ?? [];
  const totalPending = Number(data?.total_pending ?? observations.length);
  const levels = useMemo(
    () => normaliseFilterValues(data?.filters?.levels || data?.levels || [], "level"),
    [data],
  );
  const allClasses = useMemo(
    () => normaliseFilterValues(data?.filters?.classes || data?.classes || [], "class_name"),
    [data],
  );
  const availableClasses = filters.level
    ? allClasses.filter((className) => classLevel(className) === filters.level)
    : allClasses;
  const locations = useMemo(
    () => normaliseFilterValues(data?.filters?.locations || data?.locations || session?.locations || [], "location"),
    [data, session],
  );
  const hasActiveFilters = Boolean(filters.level || filters.class_name || filters.location)
    || filters.age !== "all" || filters.path !== "all";

  async function reloadAfterAction() {
    await Promise.allSettled([load(filters), pollSession()]);
  }

  async function claim(id: number, claimed: boolean) {
    setBusyId(id);
    try {
      await api("observation_claim", { method: "POST", body: { id, claimed } });
      showToast(claimed ? "Signalement pris en charge pendant 20 minutes." : "Signalement libéré.");
      await load(filters);
    } catch (requestError) {
      showToast(requestError instanceof Error ? requestError.message : "Action impossible.");
    } finally {
      setBusyId(null);
    }
  }

  async function decide(id: number, status: "confirmed" | "cancelled") {
    const cancellationReason = status === "cancelled" ? (cancelReasons[id] || "") : "";
    if (status === "cancelled" && !cancellationReason) {
      showToast("Choisissez d’abord le motif d’annulation.");
      return;
    }
    setBusyId(id);
    try {
      await api("observation_status", {
        method: "POST",
        body: { id, status, cancellation_reason: cancellationReason },
      });
      showToast(status === "confirmed" ? "Signalement confirmé." : "Signalement annulé.");
      await reloadAfterAction();
    } catch (requestError) {
      showToast(requestError instanceof Error ? requestError.message : "Action impossible.");
    } finally {
      setBusyId(null);
    }
  }

  async function confirmPath(item: QueueObservation) {
    const selected = selectionFor(item);
    if (selected.length < 2) {
      showToast("Sélectionnez au moins deux observations du même déplacement.");
      return;
    }
    setBusyId(item.id);
    try {
      const result = await api<{ confirmed_count?: number; path_count?: number; count?: number }>(
        "observation_sequence",
        { method: "POST", body: { id: item.id, linked: true, observation_ids: selected } },
      );
      const confirmedCount = Number(result.confirmed_count || 0);
      const pathCount = Number(result.path_count || result.count || 0);
      showToast(`Parcours confirmé : ${confirmedCount} observation${confirmedCount > 1 ? "s" : ""} traitée${confirmedCount > 1 ? "s" : ""}, 1 situation comptabilisée (${pathCount} passage${pathCount > 1 ? "s" : ""}).`);
      await reloadAfterAction();
    } catch (requestError) {
      showToast(requestError instanceof Error ? requestError.message : "Action impossible.");
    } finally {
      setBusyId(null);
    }
  }

  function selectionFor(item: QueueObservation): number[] {
    const nearby = item.nearby_observations ?? [];
    const preLinked = [item.id, ...nearby.filter((observation) => observation.same_sequence).map((observation) => observation.id)];
    const extra = sequenceSelections[item.id] ?? [];
    return [...new Set([...preLinked, ...extra])];
  }

  function toggleSequenceMember(anchorId: number, observationId: number, checked: boolean) {
    setSequenceSelections((current) => {
      const existing = current[anchorId] ?? [];
      const next = checked
        ? [...new Set([...existing, observationId])]
        : existing.filter((value) => value !== observationId);
      return { ...current, [anchorId]: next };
    });
  }

  if (error) return <ErrorCard message={error} onRetry={() => void load(filters)} />;
  if (data === null) return <LoadingView />;

  return (
    <div className="flex flex-col gap-5">
      <Card>
        <CardBody className="flex flex-col gap-3">
          <div className="flex flex-wrap items-center justify-between gap-3">
            <div>
              <p className="text-[14px] font-bold">Affiner la file</p>
              <p className="text-[12.5px] text-muted">Plus anciens d’abord</p>
            </div>
            <Badge tone="pending">
              {totalPending > observations.length
                ? `${totalPending} en attente · ${observations.length} premiers affichés`
                : `${totalPending} en attente`}
            </Badge>
          </div>
          <div className="grid gap-3 sm:grid-cols-2 lg:grid-cols-5">
            <label className="flex flex-col gap-1 text-[12px] font-semibold text-muted">
              Niveau
              <Select
                value={filters.level}
                onChange={(event) => {
                  const level = event.target.value;
                  setFilters((current) => ({
                    ...current,
                    level,
                    class_name: current.class_name && classLevel(current.class_name) !== level ? "" : current.class_name,
                  }));
                }}
              >
                <option value="">Tous les niveaux</option>
                {levels.map((value) => <option key={value} value={value}>Niveau {value}e</option>)}
              </Select>
            </label>
            <label className="flex flex-col gap-1 text-[12px] font-semibold text-muted">
              Classe
              <Select
                value={filters.class_name}
                onChange={(event) => setFilters((current) => ({ ...current, class_name: event.target.value }))}
              >
                <option value="">{filters.level ? `Toutes les classes de ${filters.level}e` : "Toutes les classes"}</option>
                {availableClasses.map((value) => <option key={value} value={value}>{value}</option>)}
              </Select>
            </label>
            <label className="flex flex-col gap-1 text-[12px] font-semibold text-muted">
              Lieu
              <Select
                value={filters.location}
                onChange={(event) => setFilters((current) => ({ ...current, location: event.target.value }))}
              >
                <option value="">Tous les lieux</option>
                {locations.map((value) => <option key={value} value={value}>{value}</option>)}
              </Select>
            </label>
            <label className="flex flex-col gap-1 text-[12px] font-semibold text-muted">
              Ancienneté
              <Select
                value={filters.age}
                onChange={(event) => setFilters((current) => ({ ...current, age: event.target.value as Filters["age"] }))}
              >
                <option value="all">Toutes</option>
                <option value="today">Aujourd’hui</option>
                <option value="over24">Plus de 24 h</option>
                <option value="over48">Plus de 48 h</option>
              </Select>
            </label>
            <label className="flex flex-col gap-1 text-[12px] font-semibold text-muted">
              Parcours
              <Select
                value={filters.path}
                onChange={(event) => setFilters((current) => ({ ...current, path: event.target.value as Filters["path"] }))}
              >
                <option value="all">Tous</option>
                <option value="with">Parcours possible</option>
                <option value="without">Sans parcours rapproché</option>
              </Select>
            </label>
          </div>
          {hasActiveFilters && (
            <div>
              <Button size="sm" variant="ghost" onClick={() => setFilters(defaultFilters)}>
                Effacer les filtres
              </Button>
            </div>
          )}
        </CardBody>
      </Card>

      {observations.length === 0 ? (
        <Card>
          <EmptyState icon="✓" title="Aucun signalement en attente" />
        </Card>
      ) : (
        observations.map((item) => {
          const nearby = item.nearby_observations ?? [];
          const timeline = [
            { ...item, current: true },
            ...nearby.map((observation) => ({ ...observation, current: false })),
          ].sort((left, right) => String(left.occurred_at).localeCompare(String(right.occurred_at)) || left.id - right.id);
          const claimantId = Number(item.claimed_by_user_id || item.claimant_user_id || 0);
          const claimedByMe = Boolean(item.claimed_by_current_user)
            || (claimantId > 0 && claimantId === Number(session?.user?.id || 0));
          const claimedByOther = Boolean(item.claim_locked) || (claimantId > 0 && !claimedByMe);
          const claimantName = item.claimant_name || item.claimed_by_name
            || displayName(item.claimant_first_name || item.claimed_by_first_name, item.claimant_last_name || item.claimed_by_last_name)
            || "un autre membre de la vie scolaire";
          const selectedIds = selectionFor(item);
          const busy = busyId === item.id;

          return (
            <Card key={item.id} className={cx(claimedByOther && "opacity-75")}>
              <CardBody className="flex flex-col gap-4">
                <div className="flex flex-col gap-4 lg:flex-row lg:items-start lg:justify-between">
                  <div className="min-w-0 flex-1">
                    <h3 className="font-display text-[15px] font-bold">
                      {item.first_name} {item.last_name} · {item.class_name}
                    </h3>
                    <p className="text-[13.5px]">{item.reason} — {item.location}</p>
                    <p className="mt-1 flex flex-wrap gap-x-3 gap-y-0.5 text-[12.5px] text-muted">
                      <span>{formatDate(item.occurred_at)}</span>
                      <span>Signalé par {displayName(item.reporter_first_name, item.reporter_last_name)}</span>
                      {item.details && <span>{item.details}</span>}
                    </p>
                    <PassContextNote context={item.digital_pass_context} />
                    <div className="mt-3">
                      {claimantId ? (
                        <div className={cx(
                          "flex flex-wrap items-center gap-3 rounded-[var(--radius-control)] px-3 py-2 text-[12.5px] font-semibold",
                          claimedByMe ? "bg-accent-soft text-accent" : "bg-surface-strong text-muted",
                        )}>
                          <span>{claimedByMe ? "Vous traitez ce signalement" : `Pris en charge par ${claimantName}`}</span>
                          {claimedByMe && (
                            <Button size="sm" disabled={busy} onClick={() => void claim(item.id, false)}>Libérer</Button>
                          )}
                        </div>
                      ) : (
                        <Button size="sm" disabled={busy} onClick={() => void claim(item.id, true)}>
                          Je prends en charge
                        </Button>
                      )}
                    </div>
                  </div>

                  <div className="flex w-full shrink-0 flex-col gap-2.5 lg:w-72">
                    <Select
                      aria-label="Motif si annulation"
                      value={cancelReasons[item.id] || ""}
                      disabled={claimedByOther}
                      onChange={(event) => setCancelReasons((current) => ({ ...current, [item.id]: event.target.value }))}
                    >
                      <option value="">Motif si annulation…</option>
                      {(session?.cancellation_reasons ?? []).map((reason) => (
                        <option key={reason} value={reason}>{reason}</option>
                      ))}
                    </Select>
                    <div className="flex flex-wrap justify-end gap-2">
                      {!item.sequence_linked && (
                        <Button
                          size="sm"
                          variant="primary"
                          disabled={claimedByOther || busy}
                          onClick={() => void decide(item.id, "confirmed")}
                        >
                          Confirmer seulement ce constat
                        </Button>
                      )}
                      <Button
                        size="sm"
                        variant="danger"
                        disabled={claimedByOther || busy}
                        onClick={() => void decide(item.id, "cancelled")}
                      >
                        Annuler
                      </Button>
                    </div>
                  </div>
                </div>

                {nearby.length > 0 && (
                  <details className="rounded-[var(--radius-card)] border border-line bg-surface-soft/60">
                    <summary className="flex cursor-pointer items-center justify-between gap-3 px-4 py-3 text-[13.5px] font-bold">
                      <span>Parcours observé</span>
                      <Badge>{timeline.length} observations</Badge>
                    </summary>
                    <div className="border-t border-line px-4 py-3">
                      <p className="text-[12.5px] text-muted">
                        Cochez uniquement les observations qui appartiennent au même déplacement.
                      </p>
                      <ol className="mt-3 flex flex-col gap-3">
                        {timeline.map((observation) => {
                          const selectable = observation.current
                            || ["pending", "confirmed"].includes(observation.status);
                          const alreadyLinked = Boolean(observation.current || observation.same_sequence);
                          const checked = alreadyLinked || selectedIds.includes(observation.id);
                          return (
                            <li
                              key={observation.id}
                              aria-current={observation.current || undefined}
                              className={cx(
                                "flex gap-3 rounded-[var(--radius-control)] border bg-surface px-3 py-2.5",
                                observation.current ? "border-accent/50" : "border-line",
                              )}
                            >
                              <div className="flex shrink-0 flex-col items-center gap-1.5">
                                <input
                                  type="checkbox"
                                  className="size-4 accent-[var(--accent)]"
                                  checked={checked}
                                  disabled={alreadyLinked || !selectable || claimedByOther}
                                  aria-label={`Inclure l’observation de ${formatDate(observation.occurred_at)}`}
                                  onChange={(event) => toggleSequenceMember(item.id, observation.id, event.target.checked)}
                                />
                                <time
                                  dateTime={`${String(observation.occurred_at).replace(" ", "T")}Z`}
                                  className="text-[11px] font-semibold text-muted"
                                >
                                  {formatDate(observation.occurred_at)}
                                </time>
                              </div>
                              <div className="min-w-0">
                                <p className="flex flex-wrap items-center gap-2 text-[13px] font-bold">
                                  {observation.location}
                                  <StatusBadge status={observation.status} />
                                </p>
                                <p className="text-[12.5px]">{observation.reason}</p>
                                <p className="text-[11.5px] text-muted">
                                  {displayName(observation.reporter_first_name, observation.reporter_last_name)
                                    ? `Signalé par ${displayName(observation.reporter_first_name, observation.reporter_last_name)}`
                                    : ""}
                                  {displayName(observation.reporter_first_name, observation.reporter_last_name) && observation.details ? " · " : ""}
                                  {observation.details || ""}
                                </p>
                                <PassContextNote context={observation.digital_pass_context} compact />
                              </div>
                            </li>
                          );
                        })}
                      </ol>
                      <div className="mt-3 flex flex-wrap items-center justify-between gap-3">
                        <span className="text-[12px] text-muted">Les observations non cochées resteront inchangées.</span>
                        <Button
                          size="sm"
                          variant="primary"
                          disabled={selectedIds.length < 2 || claimedByOther || busy}
                          onClick={() => void confirmPath(item)}
                        >
                          {selectedIds.length < 2
                            ? "Sélectionnez au moins 2 observations"
                            : `Confirmer le parcours — ${selectedIds.length} observations`}
                        </Button>
                      </div>
                    </div>
                  </details>
                )}
              </CardBody>
            </Card>
          );
        })
      )}
    </div>
  );
}
