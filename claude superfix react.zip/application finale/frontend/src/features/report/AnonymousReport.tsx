import { useCallback, useEffect, useRef, useState } from "react";
import { createPortal } from "react-dom";
import { api } from "../../api/client";
import { useAppState } from "../../state/appStore";
import { formatDateOnly } from "../../lib/format";
import { Button, Card, CardHeader, ErrorCard, LoadingView, Select } from "../../components/ui";

interface DimensionRow {
  label?: string;
  dimension_value?: string;
  display?: string;
  total?: number;
  date?: string;
}

interface ReportData {
  school_year?: string;
  period?: { start_utc?: string; end_utc?: string };
  confirmed_total?: { display?: string; suppressed?: boolean };
  previous_period_total?: { display?: string };
  change_percent?: number | null;
  privacy_threshold?: number;
  total?: number;
  by_location?: DimensionRow[];
  by_weekday?: DimensionRow[];
  by_school_slot?: DimensionRow[];
  evolution?: DimensionRow[];
  [key: string]: unknown;
}

function csvCell(value: unknown): string {
  const source = String(value ?? "");
  const text = /^[=+\-@]/.test(source) ? `'${source}` : source;
  return `"${text.replaceAll('"', '""')}"`;
}

function Dimension({ title, rows }: { title: string; rows: DimensionRow[] }) {
  return (
    <section className="rounded-[var(--radius-card)] border border-line bg-surface p-4">
      <h3 className="text-[13.5px] font-bold">{title}</h3>
      {rows.length === 0 ? (
        <p className="mt-2 text-[13px] text-muted">Aucune donnée sur cette période.</p>
      ) : (
        <div className="mt-2 flex flex-col divide-y divide-line">
          {rows.map((row, index) => (
            <div key={index} className="flex items-center justify-between gap-3 py-1.5 text-[13px]">
              <span>{row.label || row.dimension_value || "—"}</span>
              <strong>{row.display ?? (row.total ?? "—")}</strong>
            </div>
          ))}
        </div>
      )}
    </section>
  );
}

function ReportContent({ data, schoolYear }: { data: ReportData; schoolYear: string }) {
  const total = data.confirmed_total || { display: String(data.total || 0) };
  const previous = data.previous_period_total || { display: "—" };
  const change = data.change_percent === null || data.change_percent === undefined
    ? "Comparaison indisponible"
    : `${Number(data.change_percent) > 0 ? "+" : ""}${Number(data.change_percent).toLocaleString("fr-FR")}% par rapport à la période précédente`;
  return (
    <div className="flex flex-col gap-4">
      <section aria-labelledby="report-summary-title" className="grid gap-4 rounded-[var(--radius-card)] border border-line bg-surface p-5 sm:grid-cols-3">
        <div>
          <h2 id="report-summary-title" className="font-display text-[15px] font-bold">
            Synthèse du {formatDateOnly(data.period?.start_utc)} au {formatDateOnly(data.period?.end_utc)}
          </h2>
          <p className="mt-0.5 text-[12.5px] text-muted">Données confirmées · année {data.school_year || schoolYear}</p>
        </div>
        <div>
          <strong className="font-display text-[28px] font-bold leading-none">{total.display ?? "—"}</strong>
          <p className="text-[12.5px] text-muted">observations confirmées</p>
        </div>
        <div>
          <strong className="text-[14px] font-bold">{change}</strong>
          <p className="text-[12.5px] text-muted">Période précédente : {previous.display ?? "—"}</p>
        </div>
      </section>
      <p className="text-[12px] text-muted">
        Les cellules contenant moins de {Number(data.privacy_threshold || 3)} observations sont affichées « &lt; {Number(data.privacy_threshold || 3)} ».
      </p>
      <div className="grid gap-4 lg:grid-cols-3">
        <Dimension title="Par lieu" rows={data.by_location || []} />
        <Dimension title="Par jour" rows={data.by_weekday || []} />
        <Dimension title="Par créneau" rows={data.by_school_slot || []} />
      </div>
      {(data.evolution || []).length > 0 && (
        <Card>
          <CardHeader title="Évolution quotidienne" description="Valeurs agrégées, sans donnée nominative" />
          <div className="table-scroll">
            <table className="w-full border-collapse text-sm">
              <thead>
                <tr className="border-b border-line bg-surface-soft text-left text-[12.5px] text-muted [&>th]:px-4 [&>th]:py-2.5 [&>th]:font-semibold">
                  <th>Date</th><th>Observations confirmées</th>
                </tr>
              </thead>
              <tbody>
                {(data.evolution || []).map((row, index) => (
                  <tr key={index} className="border-b border-line last:border-0">
                    <td className="px-4 py-2.5">{formatDateOnly(row.date || row.label)}</td>
                    <td className="px-4 py-2.5">{row.display ?? (row.total ?? "—")}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </Card>
      )}
    </div>
  );
}

export function AnonymousReport() {
  const { session } = useAppState();
  const [days, setDays] = useState(7);
  const [data, setData] = useState<ReportData | null>(null);
  const [error, setError] = useState("");
  const [printing, setPrinting] = useState(false);
  const printRequested = useRef(false);

  const load = useCallback(async (period: number) => {
    setError("");
    try {
      const response = await api<{ report?: ReportData } & ReportData>("anonymous_report", { query: { days: period } });
      setData(response.report || response);
    } catch (requestError) {
      setError(requestError instanceof Error ? requestError.message : "Chargement impossible.");
    }
  }, []);

  useEffect(() => {
    void load(days);
  }, [days, load]);

  // Impression : la feuille dédiée est montée, puis window.print() est appelé.
  useEffect(() => {
    if (!printing || printRequested.current) return;
    printRequested.current = true;
    const timer = window.setTimeout(() => {
      window.print();
      setPrinting(false);
      printRequested.current = false;
    }, 50);
    return () => window.clearTimeout(timer);
  }, [printing]);

  function exportCsv() {
    if (!data) return;
    const schoolYear = data.school_year || session?.school_year || "";
    const rows: string[][] = [
      ["Rapport anonymisé", schoolYear],
      ["Période", `${formatDateOnly(data.period?.start_utc)} - ${formatDateOnly(data.period?.end_utc)}`],
      ["Indicateur", "Valeur"],
      ["Observations confirmées", String(data.confirmed_total?.display ?? "—")],
      ["Période précédente", String(data.previous_period_total?.display ?? "—")],
    ];
    const dimensions: Array<[string, DimensionRow[] | undefined]> = [
      ["Lieu", data.by_location],
      ["Jour", data.by_weekday],
      ["Créneau", data.by_school_slot],
    ];
    for (const [dimension, values] of dimensions) {
      for (const row of values || []) {
        rows.push([`${dimension} : ${row.label || "—"}`, String(row.display ?? (row.total ?? "—"))]);
      }
    }
    for (const row of data.evolution || []) {
      rows.push([`Date : ${formatDateOnly(row.date || row.label)}`, String(row.display ?? (row.total ?? "—"))]);
    }
    const csv = rows.map((row) => row.map(csvCell).join(";")).join("\r\n");
    const blob = new Blob(["﻿", csv], { type: "text/csv;charset=utf-8" });
    const url = URL.createObjectURL(blob);
    const link = document.createElement("a");
    link.href = url;
    link.download = `rapport-anonymise-${schoolYear}-${days}j.csv`;
    document.body.appendChild(link);
    link.click();
    link.remove();
    window.setTimeout(() => URL.revokeObjectURL(url), 1000);
  }

  if (error) return <ErrorCard message={error} onRetry={() => void load(days)} />;
  if (data === null) return <LoadingView />;

  return (
    <div className="flex flex-col gap-4">
      <div className="flex flex-wrap items-center justify-between gap-3">
        <label className="flex items-center gap-2 text-[12.5px] font-semibold text-muted">
          Période
          <Select value={days} onChange={(event) => setDays(Number(event.target.value))} className="w-auto py-1.5">
            <option value={7}>7 jours</option>
            <option value={28}>28 jours</option>
            <option value={90}>90 jours</option>
          </Select>
        </label>
        <div className="flex gap-2">
          <Button size="sm" onClick={exportCsv}>Exporter en CSV</Button>
          <Button size="sm" variant="primary" onClick={() => setPrinting(true)}>Imprimer / PDF</Button>
        </div>
      </div>
      <ReportContent data={data} schoolYear={session?.school_year || ""} />
      {printing && createPortal(
        <div className="print-sheet">
          <header className="mb-4 flex items-baseline justify-between border-b border-black/20 pb-2">
            <strong>Suivi des circulations</strong>
            <span>Rapport anonymisé</span>
          </header>
          <ReportContent data={data} schoolYear={session?.school_year || ""} />
        </div>,
        document.body,
      )}
    </div>
  );
}
