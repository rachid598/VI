import type { SessionData } from "../api/types";
import { Button, Dialog, DialogHeader } from "../components/ui";

export function onboardingStorageKey(session: SessionData): string {
  return `suivi:onboarding:v1:${Number(session.user?.id || 0)}`;
}

export function hasSeenOnboarding(session: SessionData): boolean {
  try {
    return localStorage.getItem(onboardingStorageKey(session)) === "seen";
  } catch {
    return false;
  }
}

export function OnboardingDialog({
  open,
  manual,
  session,
  onClose,
}: {
  open: boolean;
  manual: boolean;
  session: SessionData;
  onClose: () => void;
}) {
  const permissions = session.permissions || {};

  function close() {
    try {
      localStorage.setItem(onboardingStorageKey(session), "seen");
    } catch {
      /* Le guide restera simplement proposé au prochain démarrage. */
    }
    onClose();
  }

  const roleStep = permissions.can_validate ? (
    <li>
      <strong>Vérifier</strong>
      <span>La file « À vérifier » permet de confirmer, annuler ou rapprocher un même parcours.</span>
    </li>
  ) : permissions.can_pp ? (
    <li>
      <strong>Suivre sa classe</strong>
      <span>Le bilan PP affiche uniquement les constats confirmés de votre classe.</span>
    </li>
  ) : (
    <li>
      <strong>Suivre</strong>
      <span>La zone « Mes signalements » indique ensuite si votre constat est confirmé ou annulé.</span>
    </li>
  );

  return (
    <Dialog open={open} onClose={close} labelledBy="onboarding-title">
      <DialogHeader
        id="onboarding-title"
        title="Prendre en main l’application"
        description={manual
          ? "Les repères essentiels restent disponibles ici à tout moment."
          : "Trois repères avant votre première utilisation."}
        onClose={close}
      />
      <ol className="flex flex-col gap-4 px-5 py-5 [counter-reset:step] [&>li]:relative [&>li]:grid [&>li]:gap-0.5 [&>li]:pl-10 [&>li>strong]:text-[14px] [&>li>span]:text-[13px] [&>li>span]:text-muted [&>li]:before:[counter-increment:step] [&>li]:before:content-[counter(step)] [&>li]:before:absolute [&>li]:before:left-0 [&>li]:before:top-0.5 [&>li]:before:flex [&>li]:before:size-7 [&>li]:before:items-center [&>li]:before:justify-center [&>li]:before:rounded-full [&>li]:before:bg-accent-soft [&>li]:before:text-[12.5px] [&>li]:before:font-bold [&>li]:before:text-accent">
        <li>
          <strong>Choisir l’élève</strong>
          <span>Recherchez par nom, prénom ou classe, puis sélectionnez le bon résultat.</span>
        </li>
        <li>
          <strong>Décrire le constat</strong>
          <span>Indiquez le lieu, le motif et l’heure. La précision reste courte et factuelle.</span>
        </li>
        <li>
          <strong>Envoyer pour vérification</strong>
          <span>L’enregistrement est transmis à la vie scolaire ; aucune décision n’est automatique.</span>
        </li>
        {roleStep}
      </ol>
      <footer className="flex justify-end border-t border-line px-5 py-3.5">
        <Button variant="primary" onClick={close}>{manual ? "Fermer" : "Commencer"}</Button>
      </footer>
    </Dialog>
  );
}
