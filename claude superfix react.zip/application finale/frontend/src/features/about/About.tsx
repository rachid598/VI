import { useAppState } from "../../state/appStore";
import { Card, CardBody } from "../../components/ui";

export function About() {
  const { session } = useAppState();
  const pointsEnabled = !session?.points || session.points.enabled !== false;
  const passesEnabled = Boolean(session?.digital_passes?.enabled);

  const rows: Array<[string, string]> = [
    ["Finalité", "Repérer les circulations à vérifier et mieux organiser la présence adulte"],
    ["Validation", "Chaque signalement est confirmé ou annulé par la vie scolaire"],
    ["Accès", "Authentification Kwartz et droits attribués selon le rôle"],
    ["Permis à points", pointsEnabled ? "Module activé, avec décision humaine" : "Module désactivé"],
    ["Billets numériques", passesEnabled ? "Module activé, autorisations temporaires" : "Module désactivé"],
    ["Données", "Aucune donnée élève n’est conservée hors ligne"],
    ["Conservation", "Année scolaire en cours"],
  ];

  return (
    <Card>
      <CardBody>
        <dl className="grid gap-x-8 gap-y-4 sm:grid-cols-2">
          {rows.map(([term, description]) => (
            <div key={term} className="border-l-2 border-accent/40 pl-3.5">
              <dt className="text-[12px] font-bold uppercase tracking-wide text-muted">{term}</dt>
              <dd className="mt-0.5 text-[13.5px]">{description}</dd>
            </div>
          ))}
        </dl>
      </CardBody>
    </Card>
  );
}
