import { useState, type FormEvent } from "react";
import { api } from "../api/client";
import type { SessionData } from "../api/types";
import { applySession, refreshLoginSecurity, useAppState } from "../state/appStore";
import { ThemeToggle } from "../components/Layout";
import { Button, Input } from "../components/ui";
import { PwaInstallButton } from "../pwa/PwaInstallButton";
import { ApiError } from "../api/types";
import logoUrl from "../assets/logo-college.jpeg";

export function LoginScreen({ version }: { version: string }) {
  const { loginNotice, session } = useAppState();
  const [error, setError] = useState("");
  const [submitting, setSubmitting] = useState(false);
  const csrfReady = Boolean(session?.csrf_token) || loginNotice === "";

  async function handleSubmit(event: FormEvent<HTMLFormElement>) {
    event.preventDefault();
    setError("");
    setSubmitting(true);
    const form = new FormData(event.currentTarget);
    try {
      await api("login", {
        method: "POST",
        body: { username: form.get("username"), password: form.get("password") },
      });
      // Recharger la session complète : listes, réglages et compteurs.
      const data = await api<SessionData>("session");
      applySession(data);
    } catch (requestError) {
      if (requestError instanceof ApiError && requestError.status === 419) {
        const refreshed = await refreshLoginSecurity();
        setError(refreshed
          ? "La sécurité de la session a été actualisée. Vous pouvez réessayer."
          : "Connexion au serveur impossible. Rechargez la page.");
      } else {
        setError(requestError instanceof Error ? requestError.message : "Connexion impossible.");
      }
    } finally {
      setSubmitting(false);
    }
  }

  return (
    <main className="flex min-h-dvh items-center justify-center bg-institution px-4 py-8">
      <section className="relative grid w-full max-w-4xl overflow-hidden rounded-[1.25rem] border border-white/10 bg-surface shadow-[var(--shadow-pop)] lg:grid-cols-[1.05fr_1fr]">
        {/* Identité du collège */}
        <div className="relative flex flex-col justify-between gap-10 bg-institution p-8 text-white lg:p-10">
          <div className="absolute right-4 top-4 lg:hidden">
            <ThemeToggle />
          </div>
          <div>
            <img src={logoUrl} alt="Logo du collège Jean-Jaurès" className="size-16 rounded-xl object-cover ring-2 ring-white/25" />
            <p className="mt-6 text-[13px] font-semibold uppercase tracking-[0.14em] text-white/55">Collège Jean-Jaurès</p>
            <h2 className="mt-1 font-display text-3xl font-bold leading-tight tracking-tight">
              Suivi des<br />circulations
            </h2>
          </div>
          <div className="flex items-start gap-3 rounded-[var(--radius-card)] bg-white/8 p-4">
            <span aria-hidden className="mt-0.5 flex size-6 shrink-0 items-center justify-center rounded-full bg-gold text-[12px] font-bold text-institution-deep">✓</span>
            <p className="text-[13.5px] leading-snug text-white/85">
              <strong className="text-white">Un signalement à vérifier, jamais une sanction automatique.</strong>
            </p>
          </div>
        </div>

        {/* Formulaire */}
        <div className="relative flex flex-col justify-center gap-5 p-8 lg:p-10">
          <div className="absolute right-5 top-5 hidden lg:block">
            <ThemeToggle />
          </div>
          <div>
            <h1 className="font-display text-2xl font-bold tracking-tight">Bienvenue</h1>
            <p className="mt-1 text-sm text-muted">Utilisez vos identifiants habituels du collège.</p>
          </div>
          <form onSubmit={handleSubmit} className="flex flex-col gap-4" autoComplete="on">
            <div className="flex flex-col gap-1.5">
              <label htmlFor="username" className="text-[13px] font-semibold">Identifiant Kwartz</label>
              <Input id="username" name="username" autoComplete="username" required maxLength={64} placeholder="Votre identifiant" />
            </div>
            <div className="flex flex-col gap-1.5">
              <label htmlFor="password" className="text-[13px] font-semibold">Mot de passe</label>
              <Input id="password" name="password" type="password" autoComplete="current-password" required maxLength={1024} placeholder="Votre mot de passe" />
            </div>
            {(error || loginNotice) && (
              <p role="alert" className="rounded-[var(--radius-control)] bg-danger-soft px-3.5 py-2.5 text-[13px] font-semibold text-danger">
                {error || loginNotice}
              </p>
            )}
            <Button type="submit" variant="primary" loading={submitting} disabled={!csrfReady} className="mt-1 justify-between">
              <span>Se connecter</span>
              <span aria-hidden>→</span>
            </Button>
          </form>
          <div className="flex items-center justify-between gap-3 border-t border-line pt-4">
            <PwaInstallButton variant="login" />
            {version && <p className="text-[11.5px] text-muted">v{version}</p>}
          </div>
        </div>
      </section>
    </main>
  );
}
