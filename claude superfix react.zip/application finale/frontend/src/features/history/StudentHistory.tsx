import { useState } from "react";
import { api } from "../../api/client";
import type { Student } from "../../api/types";
import { formatDate } from "../../lib/format";
import { Badge, Card, CardBody, CardHeader, DataTable, ErrorCard, Field, LoadingView } from "../../components/ui";
import { StudentPicker } from "../observation/StudentPicker";

interface HistoryRow {
  occurred_at: string;
  location: string;
  reason: string;
  details?: string;
}

interface HistoryData {
  student: { first_name: string; last_name: string; class_name: string };
  observations: HistoryRow[];
}

export function StudentHistory() {
  const [selected, setSelected] = useState<Student[]>([]);
  const [data, setData] = useState<HistoryData | null>(null);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState("");

  async function loadHistory(students: Student[]) {
    setSelected(students);
    setData(null);
    setError("");
    if (students.length === 0) return;
    setLoading(true);
    try {
      setData(await api<HistoryData>("student_history", { query: { student_id: students[0].id } }));
    } catch (requestError) {
      setError(requestError instanceof Error ? requestError.message : "Chargement impossible.");
    } finally {
      setLoading(false);
    }
  }

  return (
    <div className="flex flex-col gap-5">
      <Card>
        <CardBody>
          <Field label="Rechercher un élève">
            <StudentPicker selected={selected} onChange={(next) => void loadHistory(next)} singleMode />
          </Field>
        </CardBody>
      </Card>

      {loading && <LoadingView />}
      {error && <ErrorCard message={error} />}
      {data && (
        <Card>
          <CardHeader
            title={`${data.student.first_name} ${data.student.last_name}`}
            description={`${data.student.class_name} · uniquement les signalements confirmés`}
            aside={<Badge>{data.observations.length}</Badge>}
          />
          {data.observations.length === 0 ? (
            <CardBody><p className="text-[13px] text-muted">Aucun signalement confirmé pour cet élève.</p></CardBody>
          ) : (
            <DataTable head={<><th>Date</th><th>Lieu</th><th>Motif</th><th>Précision</th></>}>
              {data.observations.map((row, index) => (
                <tr key={index}>
                  <td>{formatDate(row.occurred_at)}</td>
                  <td>{row.location}</td>
                  <td>{row.reason}</td>
                  <td>{row.details || "—"}</td>
                </tr>
              ))}
            </DataTable>
          )}
        </Card>
      )}
    </div>
  );
}
