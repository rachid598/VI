import { useEffect, useState } from "react";
import { api } from "../api/client";
import type { UserNotification } from "../api/types";
import { patchSession } from "../state/appStore";
import { showToast } from "../state/toast";
import { formatDate } from "../lib/format";
import { Badge, Button, Dialog, DialogHeader, EmptyState, LoadingView } from "../components/ui";

export function NotificationsDialog({ open, onClose }: { open: boolean; onClose: () => void }) {
  const [rows, setRows] = useState<UserNotification[] | null>(null);
  const [error, setError] = useState("");

  useEffect(() => {
    if (!open) return;
    setRows(null);
    setError("");
    api<{ notifications: UserNotification[] }>("notifications")
      .then((data) => setRows(Array.isArray(data.notifications) ? data.notifications : []))
      .catch((requestError: Error) => setError(requestError.message));
  }, [open]);

  async function markAllRead() {
    try {
      await api("notifications_read", { method: "POST", body: {} });
      patchSession({ notification_count: 0 });
      setRows((current) => (current ?? []).map((row) => ({ ...row, read_at: row.read_at ?? "now" })));
      showToast("Notifications marquées comme lues.");
    } catch (requestError) {
      showToast(requestError instanceof Error ? requestError.message : "Action impossible.");
    }
  }

  return (
    <Dialog open={open} onClose={onClose} labelledBy="notifications-title" className="max-w-lg">
      <DialogHeader
        id="notifications-title"
        title="Mes notifications"
        description="Évolution de vos propres signalements."
        onClose={onClose}
      />
      <div aria-live="polite" className="max-h-[60vh] overflow-y-auto px-5 py-3">
        {error && <p className="py-6 text-center text-sm font-semibold text-danger">{error}</p>}
        {!error && rows === null && <LoadingView />}
        {!error && rows !== null && rows.length === 0 && (
          <EmptyState icon="●" title="Aucune notification">
            Vous serez informé(e) ici lorsqu’un de vos constats est confirmé ou annulé.
          </EmptyState>
        )}
        {!error && rows !== null && rows.length > 0 && (
          <ul className="flex flex-col divide-y divide-line">
            {rows.map((item) => {
              const confirmed = item.event_type === "confirmed";
              return (
                <li key={item.id} className={`flex flex-col gap-1 py-3 ${item.read_at ? "opacity-65" : ""}`}>
                  <div className="flex items-center justify-between gap-3">
                    <p className="text-[13.5px] font-bold">
                      {item.first_name} {item.last_name} · {item.class_name}
                    </p>
                    <Badge tone={confirmed ? "confirmed" : "danger"}>{confirmed ? "Confirmé" : "Annulé"}</Badge>
                  </div>
                  <p className="text-[13px] text-ink">{item.reason} — {item.location}</p>
                  <p className="text-[12px] text-muted">
                    Constat du {formatDate(item.occurred_at)} · traité le {formatDate(item.created_at)}
                  </p>
                  {!confirmed && item.cancellation_reason && (
                    <p className="text-[12px] font-medium text-danger">Motif : {item.cancellation_reason}</p>
                  )}
                </li>
              );
            })}
          </ul>
        )}
      </div>
      <footer className="flex justify-between gap-3 border-t border-line px-5 py-3.5">
        <Button size="sm" onClick={markAllRead} disabled={!rows || rows.length === 0}>
          Tout marquer comme lu
        </Button>
        <Button size="sm" variant="primary" onClick={onClose}>
          Fermer
        </Button>
      </footer>
    </Dialog>
  );
}
