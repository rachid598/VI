import { formatTime } from "../../lib/format";
import {
  discardDeferredEntry,
  flushDeferredQueue,
  useDeferredQueue,
} from "../../state/deferredQueue";
import { showToast } from "../../state/toast";
import { Button } from "../../components/ui";

/** Bandeau des envois différés en attente, sur l'écran de saisie. */
export function DeferredQueueBanner() {
  const entries = useDeferredQueue();
  if (entries.length === 0) return null;
  const blockedCount = entries.filter((entry) => entry.blocked).length;

  return (
    <section
      role="status"
      aria-live="polite"
      className="mb-5 rounded-[var(--radius-card)] border border-amber/35 bg-amber-soft p-4"
    >
      <div className="flex items-start gap-3">
        <span aria-hidden className="flex size-7 shrink-0 items-center justify-center rounded-full bg-amber/15 text-[13px] font-bold text-amber">↻</span>
        <div>
          <p className="text-[13.5px] font-bold text-amber">
            {entries.length > 1 ? `${entries.length} envois en attente` : "1 envoi en attente"} de réseau
          </p>
          <p className="text-[12.5px] text-muted">
            {blockedCount > 0
              ? `${blockedCount} demande${blockedCount > 1 ? "nt" : ""} une vérification. `
              : "Transmission automatique dès le retour du réseau. "}
            Conservé au maximum 12 h tant que cette page reste ouverte sans être actualisée.
          </p>
        </div>
      </div>
      <ul className="mt-3 flex flex-col gap-1.5">
        {entries.map((entry, index) => (
          <li
            key={`${entry.body.submission_key}`}
            className={`flex items-center gap-3 rounded-[var(--radius-control)] border bg-surface px-3 py-2 ${entry.blocked ? "border-danger/40" : "border-line"}`}
          >
            <div className="min-w-0 flex-1">
              <p className="truncate text-[13px] font-semibold">{entry.summary || "Signalement"}</p>
              <p className="text-[11.5px] text-muted">Saisi à {formatTime(new Date(entry.captured_at).toISOString())}</p>
              {entry.blocked && (
                <p className="text-[11.5px] font-medium text-danger">
                  {entry.error || "Vérification nécessaire avant un nouvel envoi."}
                </p>
              )}
            </div>
            <Button
              size="sm"
              onClick={() => {
                if (!window.confirm(`Abandonner définitivement « ${entry.summary || "cet envoi"} » ?`)) return;
                discardDeferredEntry(index);
                showToast("Envoi différé abandonné.");
              }}
            >
              Abandonner
            </Button>
          </li>
        ))}
      </ul>
      <div className="mt-3 flex justify-end">
        <Button size="sm" variant="primary" onClick={() => void flushDeferredQueue(true)}>
          Réessayer maintenant
        </Button>
      </div>
    </section>
  );
}
