import { useEffect, useId, useRef, useState } from "react";
import { api } from "../../api/client";
import type { Student } from "../../api/types";
import { formatTime, initials } from "../../lib/format";
import { Avatar, Input, cx } from "../../components/ui";

/**
 * Recherche et sélection d'élèves : autocomplétion accessible (combobox),
 * huit élèves maximum, indication d'un billet numérique actif quand le module
 * est activé (trajet réservé aux rôles habilités).
 */

export function ActivePassHint({ student, compact = false }: { student: Student; compact?: boolean }) {
  const pass = student.active_pass;
  if (!pass) return null;
  const label = !pass.destination && !pass.expires_at
    ? "Billet actif"
    : `Billet vers ${pass.destination || "déplacement autorisé"}${pass.expires_at ? ` jusqu’à ${formatTime(pass.expires_at)}` : ""}`;
  return (
    <span className={cx("inline-flex items-center gap-1 font-semibold text-gold", compact ? "text-[11px]" : "text-[11.5px]")}>
      <span aria-hidden>↗</span>
      {label}
    </span>
  );
}

export function StudentPicker({
  selected,
  onChange,
  maxStudents = 8,
  disabled = false,
  error,
  singleMode = false,
}: {
  selected: Student[];
  onChange: (next: Student[]) => void;
  maxStudents?: number;
  disabled?: boolean;
  error?: string;
  singleMode?: boolean;
}) {
  const listId = useId();
  const [query, setQuery] = useState("");
  const [results, setResults] = useState<Student[] | null>(null);
  const [open, setOpen] = useState(false);
  const [activeIndex, setActiveIndex] = useState(-1);
  const timerRef = useRef<number | null>(null);
  const controllerRef = useRef<AbortController | null>(null);
  const sequenceRef = useRef(0);
  const inputRef = useRef<HTMLInputElement>(null);
  const rootRef = useRef<HTMLDivElement>(null);

  useEffect(() => () => {
    if (timerRef.current !== null) window.clearTimeout(timerRef.current);
    controllerRef.current?.abort();
  }, []);

  function runSearch(value: string) {
    const trimmed = value.trim();
    sequenceRef.current++;
    const sequence = sequenceRef.current;
    controllerRef.current?.abort();
    if (trimmed.length < 2) {
      setResults(null);
      setOpen(false);
      setActiveIndex(-1);
      return;
    }
    const controller = new AbortController();
    controllerRef.current = controller;
    api<{ students: Student[] }>("students", { query: { q: trimmed }, signal: controller.signal })
      .then((data) => {
        if (sequence !== sequenceRef.current) return;
        setResults(Array.isArray(data.students) ? data.students : []);
        setOpen(true);
        setActiveIndex(-1);
      })
      .catch(() => {
        if (sequence !== sequenceRef.current) return;
        setResults([]);
        setOpen(true);
      });
  }

  function onInput(value: string) {
    setQuery(value);
    if (timerRef.current !== null) window.clearTimeout(timerRef.current);
    timerRef.current = window.setTimeout(() => runSearch(value), 220);
  }

  function pick(student: Student) {
    if (selected.some((item) => item.id === student.id)) {
      setOpen(false);
      setQuery("");
      return;
    }
    if (singleMode) {
      onChange([student]);
    } else {
      if (selected.length >= maxStudents) return;
      onChange([...selected, student]);
    }
    setQuery("");
    setResults(null);
    setOpen(false);
    setActiveIndex(-1);
    inputRef.current?.focus();
  }

  function onKeyDown(event: React.KeyboardEvent<HTMLInputElement>) {
    if (!open || !results || results.length === 0) return;
    if (event.key === "ArrowDown") {
      event.preventDefault();
      setActiveIndex((index) => (index + 1) % results.length);
    } else if (event.key === "ArrowUp") {
      event.preventDefault();
      setActiveIndex((index) => (index <= 0 ? results.length - 1 : index - 1));
    } else if (event.key === "Enter" && activeIndex >= 0) {
      event.preventDefault();
      pick(results[activeIndex]);
    } else if (event.key === "Escape") {
      setOpen(false);
      setActiveIndex(-1);
    }
  }

  return (
    <div ref={rootRef} className="flex flex-col gap-2">
      <div className="relative">
        <span aria-hidden className="pointer-events-none absolute left-3.5 top-1/2 -translate-y-1/2 text-muted">⌕</span>
        <Input
          ref={inputRef}
          role="combobox"
          aria-autocomplete="list"
          aria-controls={listId}
          aria-expanded={open}
          aria-invalid={error ? true : undefined}
          autoComplete="off"
          placeholder="Nom, prénom ou classe"
          className="pl-9"
          value={query}
          disabled={disabled}
          onChange={(event) => onInput(event.target.value)}
          onKeyDown={onKeyDown}
          onBlur={() => {
            window.setTimeout(() => {
              if (!rootRef.current?.contains(document.activeElement)) setOpen(false);
            }, 120);
          }}
        />
        {open && (
          <div
            id={listId}
            role="listbox"
            aria-label="Résultats de recherche"
            className="absolute inset-x-0 top-[calc(100%+0.375rem)] z-30 max-h-72 overflow-y-auto rounded-[var(--radius-card)] border border-line bg-surface p-1.5 shadow-[var(--shadow-pop)]"
          >
            {results && results.length > 0 ? (
              results.map((student, index) => {
                const alreadySelected = selected.some((item) => item.id === student.id);
                return (
                  <button
                    key={student.id}
                    type="button"
                    role="option"
                    aria-selected={index === activeIndex}
                    tabIndex={-1}
                    disabled={alreadySelected}
                    onMouseDown={(event) => event.preventDefault()}
                    onClick={() => pick(student)}
                    className={cx(
                      "flex w-full items-center gap-3 rounded-[var(--radius-control)] px-3 py-2 text-left",
                      index === activeIndex ? "bg-accent-soft" : "hover:bg-surface-soft",
                      alreadySelected && "opacity-45",
                    )}
                  >
                    <Avatar initials={initials(student)} />
                    <span className="min-w-0">
                      <span className="block truncate text-[13.5px] font-bold">
                        {student.first_name} {student.last_name}
                      </span>
                      <span className="flex items-center gap-2 text-[12px] text-muted">
                        {student.class_name}
                        <ActivePassHint student={student} compact />
                      </span>
                    </span>
                  </button>
                );
              })
            ) : (
              <p role="option" aria-disabled className="px-3 py-2.5 text-[13px] text-muted">
                Aucun élève trouvé
              </p>
            )}
          </div>
        )}
      </div>

      {selected.length > 0 && (
        <div aria-live="polite" className="flex flex-wrap gap-2">
          {selected.map((student) => (
            <span
              key={student.id}
              className="inline-flex items-center gap-2 rounded-full border border-line bg-surface-soft py-1 pl-1 pr-1.5"
            >
              <Avatar initials={initials(student)} className="size-7 text-[10.5px]" />
              <span className="text-[13px]">
                <strong>{student.first_name} {student.last_name}</strong>
                <span className="ml-1.5 text-muted">{student.class_name}</span>
                <ActivePassHint student={student} compact />
              </span>
              <button
                type="button"
                aria-label={`Retirer ${student.first_name} ${student.last_name}`}
                disabled={disabled}
                onClick={() => onChange(selected.filter((item) => item.id !== student.id))}
                className="flex size-6 items-center justify-center rounded-full text-muted hover:bg-surface-strong hover:text-ink"
              >
                ×
              </button>
            </span>
          ))}
        </div>
      )}
      {error && (
        <p role="alert" className="text-[12.5px] font-medium text-danger">{error}</p>
      )}
    </div>
  );
}
