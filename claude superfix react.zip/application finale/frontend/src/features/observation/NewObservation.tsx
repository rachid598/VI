import { useCallback, useEffect, useMemo, useRef, useState, type CSSProperties, type FormEvent } from "react";
import { api } from "../../api/client";
import { ApiError, type MyObservation, type Student } from "../../api/types";
import { estimatedServerNow, useAppState } from "../../state/appStore";
import { enqueueDeferredObservation, type DeferredBody } from "../../state/deferredQueue";
import { pollSession } from "../../state/sessionPoll";
import { showToast } from "../../state/toast";
import { formatDate } from "../../lib/format";
import { Button, Card, CardBody, CardHeader, Field, Select, StatusTabs, Textarea, cx } from "../../components/ui";
import { StatusBadge } from "../../components/StatusBadge";
import { StudentPicker } from "./StudentPicker";
import { DeferredQueueBanner } from "./DeferredQueueBanner";

function createSubmissionKey(): string {
  if (window.crypto && typeof window.crypto.randomUUID === "function") {
    return window.crypto.randomUUID();
  }
  const random = window.crypto && typeof window.crypto.getRandomValues === "function"
    ? Array.from(window.crypto.getRandomValues(new Uint32Array(4)), (value) => value.toString(36)).join("")
    : `${Date.now().toString(36)}${Math.random().toString(36).slice(2)}`;
  return `obs_${random}`.slice(0, 64);
}

type ObservationFilter = "all" | "pending" | "confirmed" | "cancelled";

function filterMatches(item: MyObservation, filter: ObservationFilter): boolean {
  if (filter === "all") return true;
  if (filter === "cancelled") return item.status === "cancelled" || item.status === "withdrawn";
  return item.status === filter;
}

/** Curseur « heure du constat » : recul de 0 à 20 min, heure calculée par le serveur. */
function OccurrenceSlider({ offset, onChange }: { offset: number; onChange: (next: number) => void }) {
  const [, tick] = useState(0);
  useEffect(() => {
    const interval = window.setInterval(() => tick((value) => value + 1), 30000);
    return () => window.clearInterval(interval);
  }, []);
  const serverNow = estimatedServerNow();
  const occurredAt = serverNow ? new Date(serverNow.getTime() - offset * 60000) : null;
  const relativeText = offset === 0 ? "Maintenant" : `Il y a ${offset} min`;
  const exactText = occurredAt
    ? `Heure enregistrée : ${new Intl.DateTimeFormat("fr-FR", { hour: "2-digit", minute: "2-digit", timeZone: "Europe/Paris" }).format(occurredAt)}`
    : "Heure calculée par le serveur à l’enregistrement";
  return (
    <fieldset className="rounded-[var(--radius-card)] border border-line bg-surface-soft/60 p-4">
      <legend className="px-1.5 text-[13px] font-semibold">Heure du constat</legend>
      <output htmlFor="occurred-offset" className="flex flex-wrap items-baseline justify-between gap-x-3">
        <strong className="font-display text-[15px] font-bold">{relativeText}</strong>
        <span className="text-[12.5px] text-muted">{exactText}</span>
      </output>
      <input
        id="occurred-offset"
        type="range"
        min={0}
        max={20}
        step={1}
        value={offset}
        aria-label="Décalage de l’heure du constat en minutes"
        aria-valuetext={`${relativeText}. ${exactText}.`}
        className="occurrence-range mt-3"
        style={{ "--range-progress": `${offset * 5}%` } as CSSProperties}
        onChange={(event) => onChange(Math.min(20, Math.max(0, Number(event.target.value) || 0)))}
      />
      <div aria-hidden className="mt-1.5 flex justify-between text-[11px] text-muted">
        <span>Maintenant</span><span>5 min</span><span>10 min</span><span>15 min</span><span>20 min</span>
      </div>
      <p className="mt-2 text-[12px] text-muted">Réglage précis, de maintenant à 20 minutes auparavant.</p>
    </fieldset>
  );
}

export function NewObservation() {
  const { session } = useAppState();
  const [selectedStudents, setSelectedStudents] = useState<Student[]>([]);
  const [editing, setEditing] = useState<MyObservation | null>(null);
  const [location, setLocation] = useState("");
  const [reason, setReason] = useState("");
  const [details, setDetails] = useState("");
  const [offset, setOffset] = useState(0);
  const [errors, setErrors] = useState<{ student?: string; location?: string; reason?: string; general?: string }>({});
  const [status, setStatus] = useState<{ kind: "sending" | "error"; text: string } | null>(null);
  const [submitting, setSubmitting] = useState(false);
  const [retrySuggested, setRetrySuggested] = useState(false);
  const [myObservations, setMyObservations] = useState<MyObservation[] | null>(null);
  const [recentUnavailable, setRecentUnavailable] = useState(false);
  const [filter, setFilter] = useState<ObservationFilter>("all");
  const submissionKeyRef = useRef<string | null>(null);
  const formRef = useRef<HTMLFormElement>(null);

  const loadMyObservations = useCallback(async () => {
    try {
      const data = await api<{ observations: MyObservation[] }>("my_observations", { query: { status: "all" } });
      setMyObservations(Array.isArray(data.observations) ? data.observations : []);
      setRecentUnavailable(false);
    } catch (error) {
      // Hors connexion, le formulaire doit rester utilisable ; une vraie
      // erreur serveur (401…) est déjà gérée par le client API.
      void error;
      setMyObservations([]);
      setRecentUnavailable(true);
    }
  }, []);

  useEffect(() => {
    void loadMyObservations();
  }, [loadMyObservations]);

  function resetForm() {
    setSelectedStudents([]);
    setEditing(null);
    setLocation("");
    setReason("");
    setDetails("");
    setOffset(0);
    setErrors({});
    setStatus(null);
    setRetrySuggested(false);
    submissionKeyRef.current = null;
  }

  async function afterSuccess(message: string) {
    showToast(message);
    resetForm();
    await Promise.allSettled([loadMyObservations(), pollSession()]);
  }

  function validate(): boolean {
    const nextErrors: typeof errors = {};
    if (selectedStudents.length === 0) nextErrors.student = "Recherchez puis choisissez au moins un élève dans la liste.";
    if (!location) nextErrors.location = "Choisissez le lieu du constat.";
    if (!reason) nextErrors.reason = "Choisissez le motif à vérifier.";
    setErrors(nextErrors);
    return Object.keys(nextErrors).length === 0;
  }

  async function handleSubmit(event: FormEvent<HTMLFormElement>) {
    event.preventDefault();
    if (!validate()) return;
    const isEditing = editing !== null;
    const successMessage = (count: number) => (count > 1
      ? `${count} signalements enregistrés et transmis pour vérification.`
      : "Signalement enregistré et transmis pour vérification.");

    const body: Record<string, unknown> = { location, reason, details };
    if (isEditing) {
      body.id = editing.id;
      body.student_id = selectedStudents[0].id;
    } else {
      body.student_ids = selectedStudents.map((student) => student.id);
      body.occurred_offset_minutes = offset;
      submissionKeyRef.current = submissionKeyRef.current || createSubmissionKey();
      body.submission_key = submissionKeyRef.current;
    }

    setSubmitting(true);
    setRetrySuggested(false);
    setErrors({});
    setStatus({ kind: "sending", text: isEditing ? "Enregistrement des modifications…" : "Envoi au serveur…" });
    try {
      const result = await api<{ created?: number; idempotent?: boolean }>(
        isEditing ? "update_own_observation" : "observations",
        { method: "POST", body },
      );
      const created = isEditing ? 1 : Number(result.created || 1);
      await afterSuccess(isEditing
        ? "Signalement modifié."
        : (result.idempotent ? "Signalement déjà enregistré : aucun doublon créé." : successMessage(created)));
    } catch (error) {
      const apiError = error instanceof ApiError ? error : null;
      if (!isEditing && apiError?.code === "possible_duplicate"
        && window.confirm(`${apiError.message}\n\nEnregistrer quand même ?`)) {
        try {
          const result = await api<{ created?: number; idempotent?: boolean }>("observations", {
            method: "POST",
            body: { ...body, allow_duplicate: true },
          });
          await afterSuccess(result.idempotent
            ? "Signalement déjà enregistré : aucun doublon créé."
            : `${successMessage(Number(result.created || 1))} Doublon possible confirmé.`);
          return;
        } catch (confirmationError) {
          const confirmApiError = confirmationError instanceof ApiError ? confirmationError : null;
          if (!Number(confirmApiError?.status || 0)
            && enqueueDeferredObservation({ ...body, allow_duplicate: true } as unknown as unknown as DeferredBody, selectedStudents.length)) {
            showToast("Connexion interrompue : l’envoi reste en attente tant que l’application est ouverte.");
            resetForm();
            return;
          }
          setErrors({ general: confirmationError instanceof Error ? confirmationError.message : "Envoi impossible." });
          setStatus({ kind: "error", text: "Envoi non confirmé. Vous pouvez réessayer sans créer de doublon." });
          return;
        } finally {
          setSubmitting(false);
        }
      }
      const networkFailure = !Number(apiError?.status || 0);
      if (networkFailure && !isEditing
        && enqueueDeferredObservation(body as unknown as DeferredBody, selectedStudents.length)) {
        showToast("Connexion interrompue : l’envoi reste en attente tant que l’application est ouverte.");
        resetForm();
        return;
      }
      setRetrySuggested(networkFailure);
      setErrors({ general: error instanceof Error ? error.message : "Envoi impossible." });
      setStatus({
        kind: "error",
        text: networkFailure
          ? "Connexion interrompue. Réessayez : le même envoi ne sera pas enregistré deux fois."
          : "Envoi refusé. Corrigez les informations indiquées puis réessayez.",
      });
    } finally {
      setSubmitting(false);
    }
  }

  function startEditing(observation: MyObservation) {
    setEditing(observation);
    setSelectedStudents([{
      id: observation.student_id,
      first_name: observation.first_name,
      last_name: observation.last_name,
      class_name: observation.class_name,
    }]);
    setLocation(observation.location);
    setReason(observation.reason);
    setDetails(observation.details || "");
    setErrors({});
    setStatus(null);
    setRetrySuggested(false);
    formRef.current?.scrollIntoView({ behavior: "smooth", block: "start" });
  }

  async function withdraw(observation: MyObservation) {
    if (!window.confirm(`Retirer votre signalement concernant ${observation.first_name} ${observation.last_name} ?`)) return;
    try {
      await api("withdraw_own_observation", { method: "POST", body: { id: observation.id } });
      showToast("Signalement retiré.");
      resetForm();
      await Promise.allSettled([loadMyObservations(), pollSession()]);
    } catch (error) {
      showToast(error instanceof Error ? error.message : "Retrait impossible.");
    }
  }

  const rows = myObservations ?? [];
  const visibleRows = useMemo(() => rows.filter((item) => filterMatches(item, filter)), [rows, filter]);
  const isEditing = editing !== null;

  return (
    <div className="flex flex-col gap-5">
      <DeferredQueueBanner />

      <Card>
        <CardBody className="py-5">
          <form ref={formRef} onSubmit={(event) => void handleSubmit(event)} noValidate className="grid gap-5">
            <Field
              label={isEditing ? "Élève concerné" : "Élèves concernés"}
              hint={isEditing ? undefined : `${selectedStudents.length}/8 sélectionné${selectedStudents.length > 1 ? "s" : ""}`}
            >
              <StudentPicker
                selected={selectedStudents}
                onChange={setSelectedStudents}
                singleMode={isEditing}
                error={errors.student}
              />
              {!isEditing && selectedStudents.length > 1 && (
                <p className="text-[12px] text-muted">Un signalement identique sera créé pour chaque élève sélectionné.</p>
              )}
            </Field>

            <div className="grid gap-5 sm:grid-cols-2">
              <Field label="Lieu" htmlFor="location" error={errors.location}>
                <Select
                  id="location"
                  required
                  value={location}
                  aria-invalid={errors.location ? true : undefined}
                  onChange={(event) => {
                    setLocation(event.target.value);
                    setErrors((current) => ({ ...current, location: undefined }));
                  }}
                >
                  <option value="">Choisir…</option>
                  {(session?.locations ?? []).map((item) => <option key={item} value={item}>{item}</option>)}
                </Select>
              </Field>
              <Field label="Motif" htmlFor="reason" error={errors.reason}>
                <Select
                  id="reason"
                  required
                  value={reason}
                  aria-invalid={errors.reason ? true : undefined}
                  onChange={(event) => {
                    setReason(event.target.value);
                    setErrors((current) => ({ ...current, reason: undefined }));
                  }}
                >
                  <option value="">Choisir…</option>
                  {(session?.reasons ?? []).map((item) => <option key={item} value={item}>{item}</option>)}
                </Select>
              </Field>
            </div>

            {!isEditing && <OccurrenceSlider offset={offset} onChange={setOffset} />}

            <Field label="Précision factuelle" hint="facultatif · 160 caractères" htmlFor="details">
              <Textarea
                id="details"
                maxLength={160}
                placeholder="Ex. aucun billet présenté, cinq minutes après la sonnerie…"
                value={details}
                onChange={(event) => setDetails(event.target.value)}
              />
            </Field>

            {errors.general && (
              <p role="alert" className="rounded-[var(--radius-control)] bg-danger-soft px-3.5 py-2.5 text-[13px] font-semibold text-danger">
                {errors.general}
              </p>
            )}

            <div className="flex items-start gap-2.5 rounded-[var(--radius-control)] bg-accent-soft px-3.5 py-2.5 text-[12.5px] text-accent">
              <span aria-hidden className="mt-px font-bold">i</span>
              <p>Transmis à la vie scolaire pour vérification — aucune sanction automatique.</p>
            </div>

            <div className="flex flex-wrap items-center justify-end gap-3">
              <p
                role="status"
                aria-live="polite"
                className={cx(
                  "mr-auto text-[12.5px] font-medium",
                  status?.kind === "error" ? "text-danger" : "text-muted",
                )}
              >
                {status?.text || ""}
              </p>
              {isEditing && (
                <Button type="button" onClick={resetForm}>Annuler la modification</Button>
              )}
              <Button type="submit" variant="primary" loading={submitting}>
                {retrySuggested
                  ? "Réessayer l’envoi"
                  : isEditing ? "Enregistrer les modifications" : "Enregistrer le signalement"}
              </Button>
            </div>
          </form>
        </CardBody>
      </Card>

      <Card>
        <CardHeader
          title="Mes signalements"
          description="Retrouvez l’état de vos constats de l’année scolaire."
        />
        <CardBody className="flex flex-col gap-4">
          {recentUnavailable ? (
            <p className="text-[13px] text-muted">
              Liste momentanément indisponible hors connexion. La saisie reste possible.
            </p>
          ) : (
            <>
              <StatusTabs
                label="Filtrer mes signalements"
                value={filter}
                onChange={setFilter}
                options={[
                  { value: "all", label: "Tous", count: rows.length },
                  { value: "pending", label: "À vérifier", count: rows.filter((row) => filterMatches(row, "pending")).length },
                  { value: "confirmed", label: "Confirmés", count: rows.filter((row) => filterMatches(row, "confirmed")).length },
                  { value: "cancelled", label: "Annulés", count: rows.filter((row) => filterMatches(row, "cancelled")).length },
                ]}
              />
              {visibleRows.length === 0 ? (
                <p className="text-[13px] text-muted">Aucun signalement enregistré.</p>
              ) : (
                <ul className="flex flex-col divide-y divide-line">
                  {visibleRows.map((item) => (
                    <li key={item.id} className="flex flex-wrap items-center gap-3 py-3">
                      <div className="min-w-0 flex-1">
                        <p className="text-[13.5px] font-bold">
                          {item.first_name} {item.last_name} · {item.class_name}
                        </p>
                        <p className="text-[12.5px] text-muted">
                          {formatDate(item.occurred_at)} · {item.location} · {item.reason}
                          {item.cancellation_reason ? ` · ${item.cancellation_reason}` : ""}
                        </p>
                      </div>
                      <div className="flex items-center gap-2">
                        <StatusBadge status={item.status} />
                        {item.status === "pending" && (
                          <>
                            <Button size="sm" onClick={() => startEditing(item)}>Modifier</Button>
                            <Button size="sm" variant="danger" onClick={() => void withdraw(item)}>Retirer</Button>
                          </>
                        )}
                      </div>
                    </li>
                  ))}
                </ul>
              )}
            </>
          )}
        </CardBody>
      </Card>
    </div>
  );
}
