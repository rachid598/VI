import { Fragment, useCallback, useEffect, useState } from "react";
import { api } from "../../api/client";
import { useAppState } from "../../state/appStore";
import { displayName, formatDate } from "../../lib/format";
import { Card, CardBody, CardHeader, ErrorCard, LoadingView, Select, cx } from "../../components/ui";
import { StatCard, StatGrid } from "../../components/StatCard";

interface RepetitionObservation {
  occurred_at: string;
  location: string;
  reason: string;
  details?: string;
  reporter_first_name?: string;
  reporter_last_name?: string;
}

interface RepetitionSituation {
  started_at: string;
  observations: RepetitionObservation[];
}

interface RepetitionRow {
  first_name: string;
  last_name: string;
  class_name: string;
  total: number;
  observation_total?: number;
  situations?: RepetitionSituation[];
  [key: string]: unknown;
}

interface DashboardResponse {
  totals: {
    confirmed?: number;
    pending?: number;
    students?: number;
    previous_confirmed?: number;
    comparison_percent?: number | null;
  };
  repetition_count?: number;
  repetitions: RepetitionRow[];
  locations: Array<{ location: string; total: number }>;
  heatmap: Array<{ location: string; time_slot: string; total: number }>;
  hot_slots: Array<{ day_number: number; time_slot: string; location: string; total: number }>;
  hot_period_days?: number;
  [key: string]: unknown;
}

export const schoolTimeSlots = [
  { label: "Accueil", time: "avant 8h05" },
  { label: "M1", time: "8h05–9h03" },
  { label: "M2", time: "9h03–9h58" },
  { label: "Récréation matin", time: "9h58–10h17", break: true },
  { label: "M3", time: "10h17–11h15" },
  { label: "M4", time: "11h15–12h10" },
  { label: "Pause méridienne", time: "12h10–13h35", break: true },
  { label: "S1", time: "13h35–14h33" },
  { label: "S2", time: "14h33–15h28" },
  { label: "Récréation après-midi", time: "15h28–15h47", break: true },
  { label: "S3", time: "15h47–16h42" },
  { label: "S4", time: "16h42–17h30" },
] as const;

/** Intensité fixe et comparable des créneaux (jamais relative au maximum). */
function heatClass(count: number): string {
  const value = Math.max(0, Number(count) || 0);
  if (value === 0) return "text-muted/50";
  if (value === 1) return "bg-accent/12 font-semibold";
  if (value <= 3) return "bg-accent/28 font-semibold";
  if (value <= 5) return "bg-accent/55 font-bold text-white";
  return "bg-accent font-bold text-white";
}

function HeatLegend() {
  return (
    <div aria-label="Légende de l’intensité" className="flex flex-wrap items-center gap-4 px-5 py-3 text-[11.5px] text-muted">
      {[["bg-accent/12", "1"], ["bg-accent/28", "2–3"], ["bg-accent/55", "4–5"], ["bg-accent", "6 et plus"]].map(([tone, label]) => (
        <span key={label} className="inline-flex items-center gap-1.5">
          <i aria-hidden className={cx("inline-block size-3 rounded-sm", tone)} />
          {label}
        </span>
      ))}
    </div>
  );
}

function SlotHeaderCells() {
  return (
    <>
      {schoolTimeSlots.map((slot) => (
        <th key={slot.label} className={cx("min-w-16", "break" in slot && slot.break && "bg-amber-soft/70")}>
          <span className="block">{slot.label}</span>
          <span className="block font-normal text-muted/80">{slot.time}</span>
        </th>
      ))}
    </>
  );
}

export function Dashboard() {
  const { session } = useAppState();
  const [data, setData] = useState<DashboardResponse | null>(null);
  const [error, setError] = useState("");
  const [hotLocation, setHotLocation] = useState("");

  const load = useCallback(async () => {
    setError("");
    try {
      setData(await api<DashboardResponse>("dashboard"));
    } catch (requestError) {
      setError(requestError instanceof Error ? requestError.message : "Chargement impossible.");
    }
  }, []);

  useEffect(() => {
    void load();
  }, [load]);

  if (error) return <ErrorCard message={error} onRetry={() => void load()} />;
  if (data === null) return <LoadingView />;

  const confirmed = Number(data.totals.confirmed || 0);
  const pending = Number(data.totals.pending || 0);
  const studentCount = Number(data.totals.students || 0);
  const previousConfirmed = Number(data.totals.previous_confirmed || 0);
  const repetitionCount = Number(
    data.repetition_count ?? data.repetitions.filter((item) => Number(item.total) >= 2).length,
  );
  const comparison = data.totals.comparison_percent === null || data.totals.comparison_percent === undefined
    ? null
    : Number(data.totals.comparison_percent);
  const maxLocation = Math.max(1, ...data.locations.map((row) => Number(row.total)));

  const heatmapLocations = [...new Set(data.heatmap.map((row) => row.location))];
  const heatmapValues = new Map(data.heatmap.map((row) => [`${row.location}|${row.time_slot}`, Number(row.total)]));

  const days: Array<[number, string]> = [[1, "Lundi"], [2, "Mardi"], [3, "Mercredi"], [4, "Jeudi"], [5, "Vendredi"], [6, "Samedi"], [7, "Dimanche"]];
  const filteredHotRows = hotLocation ? data.hot_slots.filter((row) => row.location === hotLocation) : data.hot_slots;
  const hotValues = new Map<string, number>();
  for (const row of filteredHotRows) {
    const key = `${Number(row.day_number)}|${row.time_slot}`;
    hotValues.set(key, (hotValues.get(key) || 0) + Number(row.total));
  }

  return (
    <div className="flex flex-col gap-5">
      <div className="flex flex-wrap items-baseline justify-between gap-2 rounded-[var(--radius-card)] border border-line bg-institution px-5 py-4 text-white">
        <strong className="font-display text-[16px]">
          {comparison === null
            ? "Première période comparable"
            : `${comparison > 0 ? "+" : ""}${comparison}% par rapport à la semaine précédente`}
        </strong>
        <span className="text-[13px] text-white/70">
          {confirmed} situation(s) confirmée(s) cette semaine · {previousConfirmed} la semaine précédente
        </span>
      </div>

      <StatGrid>
        <StatCard label="Situations confirmées" value={confirmed} detail="sur les 7 derniers jours" tone="green" />
        <StatCard label="À vérifier" value={pending} detail="sur les 7 derniers jours" tone="amber" />
        <StatCard label="Élèves concernés" value={studentCount} detail="au moins une situation confirmée" />
        <StatCard label="Répétitions" value={repetitionCount} detail="élèves avec au moins 2 situations" />
      </StatGrid>

      <div className="grid items-start gap-5 lg:grid-cols-2">
        <Card>
          <CardHeader title="Lieux observés" description="Passages confirmés, 7 derniers jours" />
          <CardBody className="flex flex-col gap-2.5">
            {data.locations.length === 0 ? (
              <p className="text-[13px] text-muted">Aucune donnée confirmée.</p>
            ) : (
              data.locations.map((row) => (
                <div key={row.location} className="grid grid-cols-[minmax(7rem,auto)_1fr_2.5rem] items-center gap-3 text-[13px]">
                  <span className="truncate font-semibold">{row.location}</span>
                  <span className="h-2 overflow-hidden rounded-full bg-surface-strong">
                    <span
                      className="block h-full rounded-full bg-accent"
                      style={{ width: `${Math.max(5, Math.round((Number(row.total) / maxLocation) * 100))}%` }}
                    />
                  </span>
                  <span className="text-right font-bold">{Number(row.total)}</span>
                </div>
              ))
            )}
          </CardBody>
        </Card>

        <Card>
          <CardHeader title="Parcours et situations répétées" description="Ouvrir un élève pour voir la chronologie" />
          {data.repetitions.length === 0 ? (
            <CardBody><p className="text-[13px] text-muted">Aucun parcours ni aucune situation répétée sur cette période.</p></CardBody>
          ) : (
            <div className="divide-y divide-line">
              {data.repetitions.map((item, index) => {
                const situationCount = Number(item.total || 0);
                const observationCount = Number(item.observation_total || 0);
                const situations = Array.isArray(item.situations) ? item.situations : [];
                return (
                  <details key={index} className="group">
                    <summary className="flex cursor-pointer flex-wrap items-center gap-3 px-5 py-3">
                      <span className="min-w-0 flex-1">
                        <strong className="text-[13.5px]">{item.first_name} {item.last_name}</strong>
                        <small className="ml-2 text-muted">{item.class_name}</small>
                      </span>
                      <span className="text-[12.5px]">
                        <b>{situationCount}</b> situation{situationCount > 1 ? "s" : ""}
                        <small className="ml-2 text-muted">{observationCount} observation{observationCount > 1 ? "s" : ""}</small>
                      </span>
                      <span className="text-[12px] font-semibold text-accent group-open:hidden">Voir le parcours</span>
                    </summary>
                    <div className="flex flex-col gap-3 border-t border-line bg-surface-soft/50 px-5 py-3">
                      {situations.map((situation, situationIndex) => {
                        const observations = Array.isArray(situation.observations) ? situation.observations : [];
                        const isPath = observations.length > 1;
                        return (
                          <section key={situationIndex}>
                            <header className="flex items-baseline justify-between text-[12.5px]">
                              <strong>{isPath ? `Parcours · ${observations.length} observations` : `Situation ${situationIndex + 1}`}</strong>
                              <span className="text-muted">{formatDate(situation.started_at)}</span>
                            </header>
                            <ol className="mt-1.5 flex flex-col gap-1.5 border-l-2 border-line pl-3">
                              {observations.map((observation, observationIndex) => {
                                const reporter = displayName(observation.reporter_first_name, observation.reporter_last_name);
                                return (
                                  <li key={observationIndex} className="text-[12.5px]">
                                    <time className="font-semibold text-muted">{formatDate(observation.occurred_at)}</time>
                                    <span className="ml-2 font-bold">{observation.location}</span>
                                    <span className="ml-2">{observation.reason}</span>
                                    {(reporter || observation.details) && (
                                      <small className="block text-muted">
                                        {reporter ? `Signalé par ${reporter}` : ""}
                                        {reporter && observation.details ? " · " : ""}
                                        {observation.details || ""}
                                      </small>
                                    )}
                                  </li>
                                );
                              })}
                            </ol>
                          </section>
                        );
                      })}
                    </div>
                  </details>
                );
              })}
            </div>
          )}
        </Card>
      </div>

      <Card>
        <CardHeader title="Lieux et créneaux" description="Répartition des observations confirmées sur les 7 derniers jours" />
        {heatmapLocations.length === 0 ? (
          <CardBody><p className="text-[13px] text-muted">Aucune donnée confirmée sur cette période.</p></CardBody>
        ) : (
          <>
            <div className="table-scroll">
              <table className="w-full min-w-max border-collapse text-center text-[12.5px]">
                <thead>
                  <tr className="border-b border-line bg-surface-soft text-[11.5px] text-muted [&>th]:px-2.5 [&>th]:py-2 [&>th]:font-semibold">
                    <th className="text-left">Lieu</th>
                    <SlotHeaderCells />
                  </tr>
                </thead>
                <tbody>
                  {heatmapLocations.map((location) => (
                    <tr key={location} className="border-b border-line last:border-0">
                      <td className="px-2.5 py-2 text-left font-bold">{location}</td>
                      {schoolTimeSlots.map((slot) => {
                        const count = heatmapValues.get(`${location}|${slot.label}`) || 0;
                        return (
                          <td key={slot.label} className={cx("px-2.5 py-2", heatClass(count), "break" in slot && slot.break && count === 0 && "bg-amber-soft/40")}>
                            {count || "—"}
                          </td>
                        );
                      })}
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
            <HeatLegend />
          </>
        )}
      </Card>

      <Card>
        <CardHeader
          title="Créneaux chauds"
          description={`${Number(data.hot_period_days || 7)} derniers jours`}
          aside={(
            <label className="flex items-center gap-2 text-[12px] font-semibold text-muted">
              Lieu
              <Select value={hotLocation} onChange={(event) => setHotLocation(event.target.value)} className="w-auto py-1.5">
                <option value="">Tous les lieux</option>
                {(session?.locations ?? []).map((location) => <option key={location} value={location}>{location}</option>)}
              </Select>
            </label>
          )}
        />
        {filteredHotRows.length === 0 ? (
          <CardBody><p className="text-[13px] text-muted">Aucune observation confirmée pour ce lieu sur cette période.</p></CardBody>
        ) : (
          <>
            <div className="table-scroll">
              <table className="w-full min-w-max border-collapse text-center text-[12.5px]">
                <thead>
                  <tr className="border-b border-line bg-surface-soft text-[11.5px] text-muted [&>th]:px-2.5 [&>th]:py-2 [&>th]:font-semibold">
                    <th className="text-left">Jour</th>
                    <SlotHeaderCells />
                  </tr>
                </thead>
                <tbody>
                  {days.map(([dayNumber, dayLabel]) => (
                    <tr key={dayNumber} className="border-b border-line last:border-0">
                      <td className="px-2.5 py-2 text-left font-bold">{dayLabel}</td>
                      {schoolTimeSlots.map((slot) => {
                        const count = hotValues.get(`${dayNumber}|${slot.label}`) || 0;
                        return (
                          <td
                            key={slot.label}
                            aria-label={`${dayLabel}, ${slot.label} (${slot.time}) : ${count} observation${count > 1 ? "s" : ""}`}
                            className={cx("px-2.5 py-2", heatClass(count), "break" in slot && slot.break && count === 0 && "bg-amber-soft/40")}
                          >
                            {count || "—"}
                          </td>
                        );
                      })}
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
            <HeatLegend />
          </>
        )}
      </Card>

      <Fragment />
    </div>
  );
}
