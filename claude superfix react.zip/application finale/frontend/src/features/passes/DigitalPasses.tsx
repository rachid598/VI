import { useCallback, useEffect, useRef, useState, type FormEvent } from "react";
import { api } from "../../api/client";
import type { Student } from "../../api/types";
import { useAppState } from "../../state/appStore";
import { showToast } from "../../state/toast";
import { displayName, formatTime, initials } from "../../lib/format";
import {
  Avatar, Badge, Button, Card, CardBody, CardHeader, EmptyState, ErrorCard, Field, LoadingView, Select,
} from "../../components/ui";
import { StudentPicker } from "../observation/StudentPicker";

interface ActivePass {
  id: number;
  student_first_name?: string;
  first_name?: string;
  student_last_name?: string;
  last_name?: string;
  class_name?: string;
  destination?: string;
  expires_at: string;
  issuer_first_name?: string;
  issuer_last_name?: string;
  issuer_name?: string;
  issuer_user_id?: number;
  can_revoke?: boolean;
  [key: string]: unknown;
}

function extractPasses(data: unknown): ActivePass[] {
  if (Array.isArray(data)) return data as ActivePass[];
  const record = data as Record<string, unknown>;
  const list = record.passes ?? record.digital_passes ?? [];
  return Array.isArray(list) ? (list as ActivePass[]) : [];
}

export function DigitalPasses() {
  const { session } = useAppState();
  const [passes, setPasses] = useState<ActivePass[] | null>(null);
  const [error, setError] = useState("");
  const [selectedStudent, setSelectedStudent] = useState<Student[]>([]);
  const [destination, setDestination] = useState("");
  const [duration, setDuration] = useState(15);
  const [formError, setFormError] = useState("");
  const [submitting, setSubmitting] = useState(false);
  const timerRef = useRef<number | null>(null);

  const canViewAllPasses = Boolean(session?.permissions?.can_validate);
  const destinations = session?.digital_passes?.destinations ?? [];
  const durations = (session?.digital_passes?.durations?.length ? session.digital_passes.durations : [5, 10, 15, 20, 30, 45, 60]);

  const load = useCallback(async (silent = false) => {
    try {
      const data = await api("digital_passes");
      setPasses(extractPasses(data));
      setError("");
    } catch (requestError) {
      // Une coupure passagère ne remplace pas la liste visible par une erreur.
      if (!silent) setError(requestError instanceof Error ? requestError.message : "Chargement impossible.");
    }
  }, []);

  useEffect(() => {
    void load();
    const schedule = () => {
      timerRef.current = window.setTimeout(async () => {
        if (!document.hidden) await load(true);
        schedule();
      }, 45000);
    };
    schedule();
    return () => {
      if (timerRef.current !== null) window.clearTimeout(timerRef.current);
    };
  }, [load]);

  async function issue(event: FormEvent<HTMLFormElement>) {
    event.preventDefault();
    setFormError("");
    if (selectedStudent.length === 0) {
      setFormError("Choisissez d’abord l’élève concerné.");
      return;
    }
    if (!destination) {
      setFormError("Choisissez la destination du billet.");
      return;
    }
    setSubmitting(true);
    try {
      await api("digital_pass_issue", {
        method: "POST",
        body: {
          student_id: selectedStudent[0].id,
          destination,
          duration_minutes: duration,
        },
      });
      showToast("Billet créé. Il expirera automatiquement.");
      setSelectedStudent([]);
      setDestination("");
      setDuration(15);
      await load(true);
    } catch (requestError) {
      setFormError(requestError instanceof Error ? requestError.message : "Création impossible.");
    } finally {
      setSubmitting(false);
    }
  }

  async function revoke(pass: ActivePass) {
    const student = `${pass.student_first_name || pass.first_name || ""} ${pass.student_last_name || pass.last_name || ""}`.trim();
    if (!window.confirm(`Révoquer le billet de ${student || "cet élève"} ?`)) return;
    try {
      await api("digital_pass_revoke", { method: "POST", body: { id: pass.id } });
      showToast("Billet révoqué.");
      await load(true);
    } catch (requestError) {
      showToast(requestError instanceof Error ? requestError.message : "Révocation impossible.");
    }
  }

  if (error && passes === null) return <ErrorCard message={error} onRetry={() => void load()} />;

  return (
    <div className="grid items-start gap-5 lg:grid-cols-[1fr_1.15fr]">
      <Card>
        <CardHeader
          title="Émettre un billet"
          description="Autorisation temporaire, sans motif libre ni donnée sur l’appareil de l’élève."
        />
        <CardBody>
          <form onSubmit={(event) => void issue(event)} noValidate className="grid gap-4">
            <Field label="Élève">
              <StudentPicker selected={selectedStudent} onChange={setSelectedStudent} singleMode />
            </Field>
            <Field label="Destination" htmlFor="pass-destination">
              <Select
                id="pass-destination"
                required
                value={destination}
                onChange={(event) => setDestination(event.target.value)}
              >
                <option value="">Choisir…</option>
                {destinations.map((item) => <option key={item} value={item}>{item}</option>)}
              </Select>
            </Field>
            <Field label="Durée" htmlFor="pass-duration">
              <Select
                id="pass-duration"
                required
                value={duration}
                onChange={(event) => setDuration(Number(event.target.value))}
              >
                {durations.map((item) => <option key={item} value={item}>{item} minutes</option>)}
              </Select>
            </Field>
            {formError && (
              <p role="alert" className="rounded-[var(--radius-control)] bg-danger-soft px-3.5 py-2.5 text-[13px] font-semibold text-danger">
                {formError}
              </p>
            )}
            <div className="flex justify-end">
              <Button type="submit" variant="primary" loading={submitting}>Créer le billet</Button>
            </div>
          </form>
        </CardBody>
      </Card>

      <Card>
        <CardHeader
          title={canViewAllPasses ? "Billets actifs" : "Mes billets actifs"}
          description={`${canViewAllPasses ? "Billets en cours dans le collège" : "Billets que vous avez émis"} · disparition automatique à l’expiration.`}
          aside={<Badge>{passes?.length ?? 0}</Badge>}
        />
        <div>
          {passes === null ? (
            <LoadingView />
          ) : passes.length === 0 ? (
            <EmptyState icon="↗" title="Aucun billet actif">
              Les billets créés apparaîtront ici jusqu’à leur expiration.
            </EmptyState>
          ) : (
            <ul className="divide-y divide-line">
              {passes.map((pass) => {
                const firstName = pass.student_first_name || pass.first_name || "";
                const lastName = pass.student_last_name || pass.last_name || "";
                const issuer = displayName(pass.issuer_first_name, pass.issuer_last_name) || pass.issuer_name || "Personnel";
                const canRevoke = Boolean(pass.can_revoke) || canViewAllPasses
                  || ["direction", "admin"].includes(String(session?.user?.role))
                  || Number(pass.issuer_user_id) === Number(session?.user?.id || 0);
                return (
                  <li key={pass.id} className="flex flex-wrap items-center gap-3 px-5 py-3">
                    <div className="flex min-w-0 flex-1 items-center gap-3">
                      <Avatar initials={initials({ first_name: firstName, last_name: lastName })} />
                      <div className="min-w-0">
                        <p className="truncate text-[13.5px] font-bold">{firstName} {lastName}</p>
                        <p className="text-[12px] text-muted">{pass.class_name || ""}</p>
                      </div>
                    </div>
                    <div className="min-w-0 flex-1">
                      <p className="text-[13px] font-semibold">{pass.destination || "Déplacement autorisé"}</p>
                      <p className="text-[12px] text-muted">Jusqu’à {formatTime(pass.expires_at)} · par {issuer}</p>
                    </div>
                    {canRevoke && (
                      <Button size="sm" variant="danger" onClick={() => void revoke(pass)}>Révoquer</Button>
                    )}
                  </li>
                );
              })}
            </ul>
          )}
        </div>
      </Card>
    </div>
  );
}
