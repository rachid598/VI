import { useRef, useState, type FormEvent } from "react";
import { api } from "../../api/client";
import { useAppState } from "../../state/appStore";
import { showToast } from "../../state/toast";
import { Button, Card, CardBody, CardHeader, cx } from "../../components/ui";

interface SyncPreview {
  student_count?: number;
  class_count?: number;
  active_before?: number;
  skipped?: number;
  classes?: Array<{ class_name: string; total: number }>;
  conflicts?: string[];
  suspicious?: Array<{ class_name: string; members: string[] }>;
  warning?: string;
  safe_to_apply?: boolean;
  preview_token?: string;
  row_count?: number;
  snapshot_id?: number;
  [key: string]: unknown;
}

function PreviewSummary({ result, blockedLabel }: { result: SyncPreview; blockedLabel: string }) {
  const classList = (result.classes || []).map((row) => `${row.class_name} (${Number(row.total)})`).join(" · ");
  return (
    <div className="flex flex-col gap-2 text-[12.5px]">
      <div>
        <strong className="text-[14px]">{Number(result.student_count)} élèves</strong>
        <span className="ml-2 text-muted">
          {Number(result.class_count)} classes · liste actuelle : {Number(result.active_before)} élèves
          {Number(result.skipped) ? ` · ${Number(result.skipped)} compte(s) ignoré(s)` : ""}
        </span>
      </div>
      {classList && <p className="text-muted">{classList}</p>}
      {(result.conflicts || []).length > 0 && (
        <div className="rounded-[var(--radius-control)] border border-danger/40 bg-danger-soft p-2.5">
          <strong className="text-danger">Appartenances multiples à vérifier dans Kwartz</strong>
          {(result.conflicts || []).map((item, index) => <span key={index} className="block">{item}</span>)}
        </div>
      )}
      {(result.suspicious || []).length > 0 && (
        <div className="rounded-[var(--radius-control)] border border-line bg-surface p-2.5">
          <strong>Très petits effectifs à vérifier</strong>
          {(result.suspicious || []).map((row, index) => (
            <span key={index} className="block">{row.class_name} : {row.members.join(", ")}</span>
          ))}
        </div>
      )}
      {result.warning && (
        <div className="rounded-[var(--radius-control)] border border-danger/40 bg-danger-soft p-2.5">
          <strong className="text-danger">{blockedLabel}</strong>
          <span className="block">{result.warning}</span>
        </div>
      )}
    </div>
  );
}

export function LdapSync({ onChanged }: { onChanged: () => Promise<void> }) {
  const { session } = useAppState();
  const [preview, setPreview] = useState<SyncPreview | null>(null);
  const [error, setError] = useState("");
  const [token, setToken] = useState("");
  const [busy, setBusy] = useState<"analyze" | "apply" | null>(null);

  async function analyze() {
    setBusy("analyze");
    setToken("");
    setError("");
    try {
      const result = await api<SyncPreview>("admin_sync_students", { method: "POST", body: {} });
      setPreview(result);
      if (result.safe_to_apply && result.preview_token) setToken(String(result.preview_token));
    } catch (requestError) {
      setPreview(null);
      setError(requestError instanceof Error ? requestError.message : "Analyse impossible.");
      showToast(requestError instanceof Error ? requestError.message : "Analyse impossible.");
    } finally {
      setBusy(null);
    }
  }

  async function apply() {
    if (!token || !window.confirm(`Remplacer la liste active de ${session?.school_year} par cet aperçu LDAP ? Les anciennes observations resteront archivées.`)) return;
    setBusy("apply");
    try {
      const result = await api<SyncPreview>("admin_sync_students", {
        method: "POST",
        body: { apply: true, preview_token: token },
      });
      showToast(`${Number(result.row_count)} élèves synchronisés dans ${Number(result.class_count)} classes.`);
      setPreview(null);
      setToken("");
      await onChanged();
    } catch (requestError) {
      setToken("");
      setError(requestError instanceof Error ? requestError.message : "Synchronisation impossible.");
      showToast(requestError instanceof Error ? requestError.message : "Synchronisation impossible.");
    } finally {
      setBusy(null);
    }
  }

  return (
    <Card>
      <CardHeader
        title="Synchroniser les élèves depuis Kwartz"
        description="Lecture directe des groupes-classes LDAP, avec aperçu obligatoire"
      />
      <CardBody className="flex flex-col gap-3">
        <div aria-live="polite" className={cx("rounded-[var(--radius-control)] border p-3", error || (preview && !preview.safe_to_apply) ? "border-danger/40 bg-danger-soft/40" : "border-line bg-surface-soft/60")}>
          {error ? (
            <p className="text-[13px] font-semibold text-danger">{error}</p>
          ) : preview ? (
            <PreviewSummary result={preview} blockedLabel="Synchronisation bloquée" />
          ) : (
            <p className="text-[12.5px] text-muted">
              L’analyse ne modifie aucune donnée. Vous confirmerez seulement après avoir vérifié les effectifs par classe.
            </p>
          )}
        </div>
        <div className="flex justify-end gap-2">
          <Button size="sm" loading={busy === "analyze"} onClick={() => void analyze()}>
            {preview || error ? "Analyser à nouveau" : "Analyser l’annuaire"}
          </Button>
          {token && (
            <Button size="sm" variant="primary" loading={busy === "apply"} onClick={() => void apply()}>
              Appliquer cette liste
            </Button>
          )}
        </div>
      </CardBody>
    </Card>
  );
}

export function CsvImport({ onChanged }: { onChanged: () => Promise<void> }) {
  const { session } = useAppState();
  const fileRef = useRef<HTMLInputElement>(null);
  const [fileName, setFileName] = useState("");
  const [preview, setPreview] = useState<SyncPreview | null>(null);
  const [error, setError] = useState("");
  const [token, setToken] = useState("");
  const [busy, setBusy] = useState<"analyze" | "apply" | null>(null);

  async function requestImport(apply: boolean): Promise<SyncPreview> {
    const file = fileRef.current?.files?.[0];
    if (!file) throw new Error("Choisissez d’abord un fichier CSV.");
    const formData = new FormData();
    formData.append("students", file);
    formData.append("apply", apply ? "1" : "0");
    if (apply) formData.append("preview_token", token);
    return api<SyncPreview>("import_students", { method: "POST", formData });
  }

  async function analyze(event: FormEvent<HTMLFormElement>) {
    event.preventDefault();
    setBusy("analyze");
    setToken("");
    setError("");
    try {
      const result = await requestImport(false);
      setPreview(result);
      if (result.safe_to_apply && result.preview_token) setToken(String(result.preview_token));
    } catch (requestError) {
      setPreview(null);
      setError(requestError instanceof Error ? requestError.message : "Analyse impossible.");
      showToast(requestError instanceof Error ? requestError.message : "Analyse impossible.");
    } finally {
      setBusy(null);
    }
  }

  async function apply() {
    if (!token || !window.confirm(`Remplacer la liste active de ${session?.school_year} par cet aperçu CSV ? Une sauvegarde sera créée avant l’import lorsqu’elle est disponible.`)) return;
    setBusy("apply");
    try {
      const result = await requestImport(true);
      const recoveryMessage = result.snapshot_id ? " Un point de récupération a été créé." : "";
      showToast(`${Number(result.row_count)} élèves importés dans ${Number(result.class_count)} classes.${recoveryMessage}`);
      setPreview(null);
      setToken("");
      setFileName("");
      if (fileRef.current) fileRef.current.value = "";
      await onChanged();
    } catch (requestError) {
      setToken("");
      setError(requestError instanceof Error ? requestError.message : "Import impossible.");
      showToast(requestError instanceof Error ? requestError.message : "Import impossible.");
    } finally {
      setBusy(null);
    }
  }

  return (
    <Card>
      <CardHeader
        title="Importer les élèves par CSV"
        description="Solution de secours avec un export préparé depuis SIECLE, avec aperçu obligatoire"
      />
      <CardBody className="flex flex-col gap-3">
        <form onSubmit={(event) => void analyze(event)} className="flex flex-col items-center gap-2.5 rounded-[var(--radius-card)] border border-dashed border-line-strong bg-surface-soft/50 px-4 py-6 text-center">
          <span aria-hidden className="text-xl text-muted">⇧</span>
          <h4 className="text-[14px] font-bold">Fichier CSV</h4>
          <p className="text-[12.5px] text-muted">
            Colonnes obligatoires : ID, NOM, PRENOM, CLASSE. Séparateur virgule ou point-virgule.
          </p>
          <input
            ref={fileRef}
            id="students-file"
            type="file"
            accept=".csv,text/csv"
            required
            className="sr-only"
            onChange={(event) => {
              setFileName(event.target.files?.[0]?.name || "");
              setToken("");
              setPreview(null);
              setError("");
            }}
          />
          <div className="flex flex-wrap items-center justify-center gap-2.5">
            <label htmlFor="students-file" className="cursor-pointer rounded-[var(--radius-control)] border border-line-strong bg-surface px-4 py-2 text-sm font-semibold hover:bg-surface-soft">
              Choisir un fichier
            </label>
            <span className="text-[12.5px] text-muted">{fileName || "Aucun fichier"}</span>
            <Button type="submit" size="sm" variant="primary" loading={busy === "analyze"} disabled={!fileName}>
              {preview || error ? "Analyser à nouveau" : "Analyser le fichier"}
            </Button>
          </div>
        </form>
        <div aria-live="polite" className={cx("rounded-[var(--radius-control)] border p-3", error || (preview && !preview.safe_to_apply) ? "border-danger/40 bg-danger-soft/40" : "border-line bg-surface-soft/60")}>
          {error ? (
            <p className="text-[13px] font-semibold text-danger">{error}</p>
          ) : preview ? (
            <PreviewSummary result={preview} blockedLabel="Import bloqué" />
          ) : (
            <p className="text-[12.5px] text-muted">
              L’analyse ne modifie aucune donnée. Vous vérifierez l’effectif et les classes avant d’appliquer le fichier.
            </p>
          )}
        </div>
        {token && (
          <div className="flex justify-end">
            <Button size="sm" variant="primary" loading={busy === "apply"} onClick={() => void apply()}>
              Appliquer pour {session?.school_year}
            </Button>
          </div>
        )}
      </CardBody>
    </Card>
  );
}
