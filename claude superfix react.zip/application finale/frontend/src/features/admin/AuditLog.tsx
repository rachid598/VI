import { useMemo, useState } from "react";
import { displayName, formatDate } from "../../lib/format";
import { Card, CardHeader, Select } from "../../components/ui";
import type { AuditRow } from "./adminTypes";

const categoryDefinitions = [
  { value: "all", label: "Toutes les actions" },
  { value: "auth", label: "Connexions / déconnexions" },
  { value: "observations", label: "Signalements" },
  { value: "students", label: "Élèves et annuaire" },
  { value: "accounts", label: "Comptes et accès" },
  { value: "points", label: "Permis à points" },
  { value: "passes", label: "Billets numériques" },
  { value: "recovery", label: "Récupération et purge" },
  { value: "settings", label: "Réglages" },
  { value: "other", label: "Autres actions" },
] as const;

const actionLabels: Record<string, string> = {
  "auth.login": "Connexion",
  "auth.logout": "Déconnexion",
  "observation.create": "Signalement créé",
  "observation.update": "Signalement modifié",
  "observation.withdraw": "Signalement retiré",
  "observation.confirmed": "Signalement confirmé",
  "observation.cancelled": "Signalement annulé",
  "observation.claim": "Signalement pris en charge",
  "observation.release": "Prise en charge libérée",
  "observation.sequence_link": "Observations liées",
  "observation.sequence_unlink": "Séquence dissociée",
  "observation.sequence_confirm": "Parcours confirmé",
  "user.update": "Droits modifiés",
  "students.import": "Élèves importés",
  "students.ldap_sync": "Élèves synchronisés depuis LDAP",
  "access.authorize": "Accès autorisé",
  "access.revoke": "Accès retiré",
  "school_year.change": "Année scolaire changée",
  "school_year.close": "Année scolaire clôturée",
  "points.restore": "Point rendu",
  "points.action": "Action éducative enregistrée",
  "points.export": "Permis exporté",
  "points.module_toggle": "Module permis à points modifié",
  "digital_pass.issue": "Billet numérique créé",
  "digital_pass.revoke": "Billet numérique révoqué",
  "digital_pass.module_toggle": "Module billets numériques modifié",
  "submission_queue.module_toggle": "Envoi différé modifié",
  "recovery.snapshot_manual": "Point de récupération créé",
  "recovery.purge": "Données élèves vidées",
  "recovery.restore": "Point de récupération restauré",
};

function categoryForAction(action: unknown): string {
  const value = String(action || "");
  if (value.startsWith("auth.")) return "auth";
  if (value.startsWith("observation.")) return "observations";
  if (value.startsWith("students.")) return "students";
  if (value.startsWith("user.") || value.startsWith("access.")) return "accounts";
  if (value.startsWith("points.")) return "points";
  if (value.startsWith("digital_pass.")) return "passes";
  if (value.startsWith("recovery.")) return "recovery";
  if (value.startsWith("school_year.") || value.startsWith("submission_queue.")) return "settings";
  return "other";
}

function formatMetadata(metadata: unknown): string {
  if (!metadata || typeof metadata !== "object") return "—";
  return Object.entries(metadata as Record<string, unknown>)
    .filter(([, value]) => value !== null && value !== "")
    .map(([key, value]) => `${key}: ${String(value)}`)
    .join(" · ") || "—";
}

export function AuditLog({ rows }: { rows: AuditRow[] }) {
  const [category, setCategory] = useState("all");
  const [order, setOrder] = useState<"newest" | "oldest">("newest");

  const counts = useMemo(() => rows.reduce<Record<string, number>>((result, row) => {
    const rowCategory = categoryForAction(row.action);
    result[rowCategory] = (result[rowCategory] || 0) + 1;
    return result;
  }, {}), [rows]);

  const visibleRows = useMemo(() => {
    const filtered = category === "all" ? [...rows] : rows.filter((row) => categoryForAction(row.action) === category);
    const direction = order === "oldest" ? 1 : -1;
    return filtered.sort((left, right) => {
      const dateComparison = String(left.created_at || "").localeCompare(String(right.created_at || ""));
      if (dateComparison !== 0) return dateComparison * direction;
      return ((Number(left.id) || 0) - (Number(right.id) || 0)) * direction;
    });
  }, [rows, category, order]);

  return (
    <Card>
      <CardHeader
        title="Journal des actions"
        description="250 dernières opérations, sans mot de passe ni contenu détaillé des observations"
      />
      <div role="group" aria-label="Filtrer et trier le journal des actions" className="flex flex-wrap items-end gap-3 border-b border-line px-5 py-3">
        <label className="flex flex-col gap-1 text-[12px] font-semibold text-muted">
          Type d’action
          <Select className="w-auto py-1.5 text-[13px]" value={category} onChange={(event) => setCategory(event.target.value)}>
            {categoryDefinitions.map((definition) => (
              <option key={definition.value} value={definition.value}>
                {definition.label} ({definition.value === "all" ? rows.length : Number(counts[definition.value] || 0)})
              </option>
            ))}
          </Select>
        </label>
        <label className="flex flex-col gap-1 text-[12px] font-semibold text-muted">
          Ordre
          <Select className="w-auto py-1.5 text-[13px]" value={order} onChange={(event) => setOrder(event.target.value as "newest" | "oldest")}>
            <option value="newest">Plus récentes d’abord</option>
            <option value="oldest">Plus anciennes d’abord</option>
          </Select>
        </label>
        <span aria-live="polite" className="pb-2 text-[12px] text-muted">
          {visibleRows.length} sur {rows.length} opération{rows.length === 1 ? "" : "s"}
        </span>
      </div>
      {visibleRows.length === 0 ? (
        <p className="px-5 py-5 text-[13px] text-muted">
          {rows.length === 0 ? "Aucune action journalisée." : "Aucune opération ne correspond à ce filtre."}
        </p>
      ) : (
        <div className="table-scroll">
          <table className="w-full min-w-max border-collapse text-sm">
            <thead>
              <tr className="border-b border-line bg-surface-soft text-left text-[12.5px] text-muted [&>th]:px-4 [&>th]:py-2.5 [&>th]:font-semibold">
                <th>Date</th><th>Utilisateur</th><th>Action</th><th>Informations</th>
              </tr>
            </thead>
            <tbody>
              {visibleRows.map((row) => (
                <tr key={row.id} className="border-b border-line last:border-0 [&>td]:px-4 [&>td]:py-2.5">
                  <td className="whitespace-nowrap">{formatDate(row.created_at)}</td>
                  <td>{displayName(row.first_name, row.last_name) || row.ldap_uid || "Système"}</td>
                  <td>{actionLabels[row.action] || row.action}</td>
                  <td className="max-w-96 truncate text-[12.5px] text-muted" title={formatMetadata(row.metadata)}>
                    {formatMetadata(row.metadata)}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}
    </Card>
  );
}
