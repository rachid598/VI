import type { AdminUserRow, AuthorizedUserRow } from "../../api/types";

export interface AdminUsersData {
  users: AdminUserRow[];
  classes: string[];
  authorized_users: AuthorizedUserRow[];
  active_school_year: string;
  school_years?: Array<string | { school_year: string }>;
  closed_years?: Array<string | { school_year: string }>;
  [key: string]: unknown;
}

export interface ServiceHealth {
  ok?: boolean;
  message?: string;
  latency_ms?: number | null;
}

export interface HealthData {
  unavailable?: boolean;
  error?: string;
  app_version?: string;
  active_students?: number;
  active_classes?: number;
  pending_over_24h?: number;
  inactive_accounts_count?: number;
  inactive_accounts?: Array<{ first_name?: string; last_name?: string; uid?: string; ldap_uid?: string; role?: string }>;
  last_import?: { created_at?: string } | null;
  last_ldap_sync?: { created_at?: string } | null;
  last_backup?: { created_at?: string } | null;
  last_connection?: { last_login_at?: string } | null;
  services?: Record<string, ServiceHealth | undefined>;
  [key: string]: unknown;
}

export interface RecoverySnapshotRow {
  id: number | string;
  kind?: string;
  school_year?: string | null;
  created_at?: string;
  size_bytes?: number;
  counts?: Record<string, number>;
  [key: string]: unknown;
}

export interface RecoveryStatus {
  unavailable?: boolean;
  error?: string;
  environment?: string;
  retention_days?: number;
  interval_minutes?: number;
  storage_bytes?: number;
  storage_limit_bytes?: number;
  snapshot_count?: number;
  counts?: Record<string, number>;
  snapshots?: RecoverySnapshotRow[];
  purge_confirmation?: string;
  restore_confirmation_prefix?: string;
  [key: string]: unknown;
}

export interface AuditRow {
  id: number;
  action: string;
  created_at: string;
  first_name?: string;
  last_name?: string;
  ldap_uid?: string;
  metadata?: Record<string, unknown> | null;
  [key: string]: unknown;
}

export function recoverySnapshotKind(kind: unknown): string {
  const labels: Record<string, string> = {
    automatic: "Point automatique",
    manual: "Point manuel",
    before_purge: "Avant une purge",
    pre_purge: "Avant une purge",
    before_restore: "Avant une restauration",
    pre_restore: "Avant une restauration",
  };
  return labels[String(kind || "")] || "Point de récupération";
}

export function formatRecoveryCounts(counts: unknown): string {
  if (!counts || typeof counts !== "object") return "aucune donnée";
  const labels: Record<string, string> = {
    students: "élèves",
    observations: "observations",
    point_adjustments: "ajustements de points",
    action_records: "actions éducatives",
    points: "points",
    actions: "actions",
    student_imports: "imports",
    imports: "imports",
  };
  const values = Object.entries(counts as Record<string, unknown>)
    .filter(([, value]) => Number.isFinite(Number(value)))
    .map(([key, value]) => `${new Intl.NumberFormat("fr-FR").format(Number(value))} ${labels[key] || key}`);
  return values.join(" · ") || "aucune donnée";
}

export function formatRecoverySize(bytes: unknown): string {
  const value = Math.max(0, Number(bytes) || 0);
  if (value < 1024) return `${value} o`;
  if (value < 1024 * 1024) {
    return `${new Intl.NumberFormat("fr-FR", { maximumFractionDigits: 1 }).format(value / 1024)} Ko`;
  }
  return `${new Intl.NumberFormat("fr-FR", { maximumFractionDigits: 1 }).format(value / (1024 * 1024))} Mo`;
}

export function shortRecoveryId(id: unknown): string {
  const value = String(id ?? "");
  return value.length > 12 ? `…${value.slice(-10)}` : value;
}

export function nextSchoolYear(schoolYear: string): string {
  const match = /^(\d{4})-(\d{4})$/.exec(String(schoolYear || ""));
  if (!match) return schoolYear || "";
  return `${Number(match[1]) + 1}-${Number(match[2]) + 1}`;
}
