import { useState } from "react";
import { api } from "../../api/client";
import type { AdminUserRow, Role } from "../../api/types";
import { displayName, roleLabels } from "../../lib/format";
import { showToast } from "../../state/toast";
import { Button, Card, CardHeader, Select } from "../../components/ui";

export function UserAccounts({
  users,
  classes,
  onChanged,
}: {
  users: AdminUserRow[];
  classes: string[];
  onChanged: () => Promise<void>;
}) {
  const [draft, setDraft] = useState<Record<number, { role: Role; pp_class: string; active: boolean }>>({});
  const [savingId, setSavingId] = useState<number | null>(null);

  function rowState(user: AdminUserRow) {
    return draft[user.id] ?? {
      role: user.role,
      pp_class: user.pp_class || "",
      active: Boolean(user.active),
    };
  }

  async function save(user: AdminUserRow) {
    const state = rowState(user);
    setSavingId(user.id);
    try {
      await api("admin_update_user", {
        method: "POST",
        body: { id: user.id, role: state.role, pp_class: state.pp_class, active: state.active },
      });
      showToast("Droits enregistrés.");
      setDraft((current) => {
        const next = { ...current };
        delete next[user.id];
        return next;
      });
      await onChanged();
    } catch (error) {
      showToast(error instanceof Error ? error.message : "Enregistrement impossible.");
    } finally {
      setSavingId(null);
    }
  }

  return (
    <Card>
      <CardHeader
        title="Comptes autorisés"
        description="Les administrateurs gèrent les rôles ; une classe PP peut compléter n’importe quel rôle"
      />
      <div className="table-scroll">
        <table className="w-full min-w-max border-collapse text-sm">
          <thead>
            <tr className="border-b border-line bg-surface-soft text-left text-[12.5px] text-muted [&>th]:px-4 [&>th]:py-2.5 [&>th]:font-semibold">
              <th>Compte</th><th>Rôle et classe PP</th><th>Actif</th><th></th>
            </tr>
          </thead>
          <tbody>
            {users.map((user) => {
              const fixedAdmin = user.role === "admin";
              const state = rowState(user);
              const roleEntries = fixedAdmin
                ? ([["admin", roleLabels.admin]] as Array<[Role, string]>)
                : (Object.entries(roleLabels).filter(([value]) => value !== "admin") as Array<[Role, string]>);
              return (
                <tr key={user.id} className="border-b border-line last:border-0 [&>td]:px-4 [&>td]:py-3">
                  <td>
                    <strong className="block">{displayName(user.first_name, user.last_name) || user.ldap_uid}</strong>
                    <span className="text-[12px] text-muted">
                      {user.ldap_uid}
                      {user.email ? ` · ${user.email}` : ""}
                      {fixedAdmin ? " · compte administrateur initial" : ""}
                    </span>
                  </td>
                  <td>
                    <div className="flex flex-wrap gap-2">
                      <Select
                        aria-label="Rôle"
                        className="w-auto py-1.5 text-[13px]"
                        disabled={fixedAdmin}
                        value={state.role}
                        onChange={(event) => setDraft((current) => ({
                          ...current,
                          [user.id]: { ...state, role: event.target.value as Role },
                        }))}
                      >
                        {roleEntries.map(([value, label]) => <option key={value} value={value}>{label}</option>)}
                      </Select>
                      <Select
                        aria-label="Classe de professeur principal"
                        className="w-auto py-1.5 text-[13px]"
                        disabled={fixedAdmin}
                        value={state.pp_class}
                        onChange={(event) => setDraft((current) => ({
                          ...current,
                          [user.id]: { ...state, pp_class: event.target.value },
                        }))}
                      >
                        <option value="">Classe PP…</option>
                        {classes.map((value) => <option key={value} value={value}>{value}</option>)}
                      </Select>
                    </div>
                  </td>
                  <td>
                    <input
                      type="checkbox"
                      className="size-4 accent-[var(--accent)]"
                      aria-label="Compte actif"
                      disabled={fixedAdmin}
                      checked={state.active}
                      onChange={(event) => setDraft((current) => ({
                        ...current,
                        [user.id]: { ...state, active: event.target.checked },
                      }))}
                    />
                  </td>
                  <td>
                    <Button size="sm" disabled={fixedAdmin} loading={savingId === user.id} onClick={() => void save(user)}>
                      Enregistrer
                    </Button>
                  </td>
                </tr>
              );
            })}
          </tbody>
        </table>
      </div>
    </Card>
  );
}
