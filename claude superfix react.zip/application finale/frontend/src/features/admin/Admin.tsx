import { useCallback, useEffect, useRef, useState } from "react";
import { api } from "../../api/client";
import { useAppState } from "../../state/appStore";
import { ErrorCard, LoadingView } from "../../components/ui";
import type { AdminUsersData, AuditRow, HealthData, RecoveryStatus } from "./adminTypes";
import { AdminHealth } from "./AdminHealth";
import { UserAccounts } from "./UserAccounts";
import { ModuleToggles } from "./ModuleToggles";
import { AuthorizedUsers } from "./AuthorizedUsers";
import { CsvImport, LdapSync } from "./StudentSync";
import { YearClosure, YearRollover } from "./YearManagement";
import { RecoverySection } from "./RecoverySection";
import { AuditLog } from "./AuditLog";

interface AdminData {
  users: AdminUsersData;
  audit: AuditRow[];
  recovery: RecoveryStatus;
  health: HealthData;
}

export function Admin() {
  const { session } = useAppState();
  const [data, setData] = useState<AdminData | null>(null);
  const [error, setError] = useState("");
  const refreshTimer = useRef<number | null>(null);

  const load = useCallback(async () => {
    setError("");
    try {
      const recoveryRequest = api<RecoveryStatus>("recovery_status").catch((requestError: Error) => ({
        unavailable: true,
        error: requestError.message || "Service de récupération indisponible.",
      } as RecoveryStatus));
      const healthRequest = api<{ health?: HealthData } & HealthData>("admin_health")
        .then((result) => result.health || result)
        .catch((requestError: Error) => ({ unavailable: true, error: requestError.message } as HealthData));
      const [users, audit, recovery, health] = await Promise.all([
        api<AdminUsersData>("admin_users"),
        api<{ logs?: AuditRow[] }>("audit_logs"),
        recoveryRequest,
        healthRequest,
      ]);
      setData({
        users,
        audit: Array.isArray(audit.logs) ? audit.logs : [],
        recovery,
        health,
      });
    } catch (requestError) {
      setError(requestError instanceof Error ? requestError.message : "Chargement impossible.");
    }
  }, []);

  useEffect(() => {
    void load();
  }, [load]);

  // Actualisation périodique de l'état de récupération, calée sur l'intervalle
  // configuré, uniquement quand l'onglet est visible.
  useEffect(() => {
    if (!data) return;
    const intervalMinutes = Math.min(1440, Math.max(1, Number(data.recovery.interval_minutes) || 30));
    refreshTimer.current = window.setInterval(() => {
      if (document.visibilityState !== "visible") return;
      api<RecoveryStatus>("recovery_status")
        .then((latest) => setData((current) => (current ? { ...current, recovery: latest } : current)))
        .catch(() => {
          /* L'état déjà affiché reste disponible ; nouvel essai au prochain cycle. */
        });
    }, intervalMinutes * 60 * 1000);
    return () => {
      if (refreshTimer.current !== null) window.clearInterval(refreshTimer.current);
    };
  }, [data]);

  if (error) return <ErrorCard message={error} onRetry={() => void load()} />;
  if (data === null || !session) return <LoadingView />;

  return (
    <div className="flex flex-col gap-5">
      <AdminHealth health={data.health} appVersion={session.app_version} />
      <p className="text-[12.5px] text-muted">Les comptes apparaissent après leur première connexion LDAP.</p>

      <div className="grid items-start gap-5 xl:grid-cols-[1.25fr_1fr]">
        <div className="flex min-w-0 flex-col gap-5">
          <UserAccounts users={data.users.users} classes={data.users.classes} onChanged={load} />
          <RecoverySection status={data.recovery} onChanged={load} />
        </div>
        <div className="flex min-w-0 flex-col gap-5">
          <ModuleToggles session={session} onChanged={load} />
          <YearRollover
            activeSchoolYear={data.users.active_school_year}
            health={data.health}
            onChanged={load}
          />
          <AuthorizedUsers
            authorizedUsers={data.users.authorized_users}
            classes={data.users.classes}
            onChanged={load}
          />
          <LdapSync onChanged={load} />
          <CsvImport onChanged={load} />
          <YearClosure
            schoolYears={data.users.school_years || []}
            activeSchoolYear={data.users.active_school_year}
            closedYears={data.users.closed_years || []}
            onChanged={load}
          />
        </div>
      </div>

      <AuditLog rows={data.audit} />
    </div>
  );
}
