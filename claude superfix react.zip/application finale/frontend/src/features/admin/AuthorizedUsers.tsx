import { useState, type FormEvent } from "react";
import { api } from "../../api/client";
import type { AuthorizedUserRow, Role } from "../../api/types";
import { formatDateOnly, roleLabels } from "../../lib/format";
import { showToast } from "../../state/toast";
import { Badge, Button, Card, CardBody, CardHeader, Input, Select } from "../../components/ui";

export function AuthorizedUsers({
  authorizedUsers,
  classes,
  onChanged,
}: {
  authorizedUsers: AuthorizedUserRow[];
  classes: string[];
  onChanged: () => Promise<void>;
}) {
  const [uid, setUid] = useState("");
  const [label, setLabel] = useState("");
  const [role, setRole] = useState<Role>("teacher");
  const [ppClass, setPpClass] = useState("");
  const [expires, setExpires] = useState("");
  const [submitting, setSubmitting] = useState(false);

  async function add(event: FormEvent<HTMLFormElement>) {
    event.preventDefault();
    setSubmitting(true);
    try {
      await api("admin_add_authorized_user", {
        method: "POST",
        body: { uid, label, role, pp_class: role === "pp" ? ppClass : "", access_expires_at: expires },
      });
      showToast("Identifiant autorisé. Il peut maintenant se connecter.");
      setUid("");
      setLabel("");
      setRole("teacher");
      setPpClass("");
      setExpires("");
      await onChanged();
    } catch (error) {
      showToast(error instanceof Error ? error.message : "Autorisation impossible.");
    } finally {
      setSubmitting(false);
    }
  }

  async function remove(id: number) {
    if (!window.confirm("Retirer cette autorisation individuelle ?")) return;
    try {
      await api("admin_remove_authorized_user", { method: "POST", body: { id } });
      showToast("Autorisation retirée.");
      await onChanged();
    } catch (error) {
      showToast(error instanceof Error ? error.message : "Retrait impossible.");
    }
  }

  return (
    <Card>
      <CardHeader
        title="Accès hors groupes LDAP"
        description="Préautoriser un compte avec son rôle, sa classe PP et une éventuelle date de fin"
      />
      <CardBody className="flex flex-col gap-4">
        <form onSubmit={(event) => void add(event)} className="grid gap-2.5 sm:grid-cols-2">
          <Input
            placeholder="Identifiant Kwartz"
            required
            maxLength={64}
            value={uid}
            onChange={(event) => setUid(event.target.value)}
          />
          <Input
            placeholder="Fonction ou nom (facultatif)"
            maxLength={128}
            value={label}
            onChange={(event) => setLabel(event.target.value)}
          />
          <Select
            aria-label="Rôle attribué"
            value={role}
            onChange={(event) => {
              const nextRole = event.target.value as Role;
              setRole(nextRole);
              if (nextRole !== "pp") setPpClass("");
            }}
          >
            {(Object.entries(roleLabels) as Array<[Role, string]>)
              .filter(([value]) => value !== "admin")
              .map(([value, roleLabel]) => <option key={value} value={value}>{roleLabel}</option>)}
          </Select>
          <Select
            aria-label="Classe de professeur principal"
            disabled={role !== "pp"}
            value={ppClass}
            onChange={(event) => setPpClass(event.target.value)}
          >
            <option value="">Aucune classe PP</option>
            {classes.map((value) => <option key={value} value={value}>{value}</option>)}
          </Select>
          <label className="flex flex-col gap-1 text-[12px] font-semibold text-muted">
            Fin d’accès (facultatif)
            <Input type="date" value={expires} onChange={(event) => setExpires(event.target.value)} />
          </label>
          <div className="flex items-end justify-end">
            <Button type="submit" variant="primary" loading={submitting}>Autoriser</Button>
          </div>
        </form>

        {authorizedUsers.length === 0 ? (
          <p className="text-[13px] text-muted">Aucun accès individuel supplémentaire.</p>
        ) : (
          <ul className="flex flex-col divide-y divide-line">
            {authorizedUsers.map((row) => {
              const rowRole = (row.preassigned_role || "teacher") as Role;
              const rowClass = row.preassigned_pp_class || "";
              const expiry = row.access_expires_at || "";
              const active = Boolean(row.active);
              return (
                <li key={row.id} className={`flex items-center gap-3 py-2.5 ${active ? "" : "opacity-60"}`}>
                  <div className="min-w-0 flex-1">
                    <strong className="text-[13px]">{row.ldap_uid}</strong>
                    <span className="block text-[12px] text-muted">
                      {row.label || "Sans libellé"} · {roleLabels[rowRole] || rowRole}
                      {rowClass ? ` · PP ${rowClass}` : ""}
                      {expiry ? ` · jusqu’au ${formatDateOnly(expiry)}` : ""}
                    </span>
                  </div>
                  {active ? (
                    <Button size="sm" variant="danger" onClick={() => void remove(row.id)}>Retirer</Button>
                  ) : (
                    <Badge tone="danger">Retiré</Badge>
                  )}
                </li>
              );
            })}
          </ul>
        )}
      </CardBody>
    </Card>
  );
}
