import { useState, type FormEvent } from "react";
import { api } from "../../api/client";
import { useAppState } from "../../state/appStore";
import { showToast } from "../../state/toast";
import { formatDate } from "../../lib/format";
import { Badge, Button, Card, CardBody, CardHeader, Dialog, DialogHeader, Input, cx } from "../../components/ui";
import {
  formatRecoveryCounts,
  formatRecoverySize,
  recoverySnapshotKind,
  shortRecoveryId,
  type RecoverySnapshotRow,
  type RecoveryStatus,
} from "./adminTypes";

/**
 * Dialogue commun purge/restauration : réauthentification LDAP + phrase exacte.
 * Le bouton ne s'active que lorsque la phrase correspond exactement.
 */
function DangerDialog({
  open,
  danger,
  title,
  titleId,
  description,
  environmentLabel,
  environment,
  target,
  warning,
  phrase,
  submitLabel,
  busyLabel,
  onSubmit,
  onClose,
}: {
  open: boolean;
  danger: boolean;
  title: string;
  titleId: string;
  description: string;
  environmentLabel: string;
  environment: string;
  target: React.ReactNode;
  warning: React.ReactNode;
  phrase: string;
  submitLabel: string;
  busyLabel: string;
  onSubmit: (password: string, confirmation: string) => Promise<void>;
  onClose: () => void;
}) {
  const [password, setPassword] = useState("");
  const [confirmation, setConfirmation] = useState("");
  const [feedback, setFeedback] = useState("");
  const [busy, setBusy] = useState(false);

  function reset() {
    setPassword("");
    setConfirmation("");
    setFeedback("");
    setBusy(false);
  }

  async function submit(event: FormEvent<HTMLFormElement>) {
    event.preventDefault();
    if (busy || password.length === 0 || confirmation !== phrase) return;
    setBusy(true);
    setFeedback("");
    try {
      await onSubmit(password, confirmation);
      reset();
    } catch (error) {
      setFeedback(error instanceof Error ? error.message : "Opération impossible.");
      setPassword("");
      setBusy(false);
    }
  }

  const confirmationValid = confirmation === phrase;

  return (
    <Dialog
      open={open}
      onClose={() => {
        if (!busy) {
          reset();
          onClose();
        }
      }}
      labelledBy={titleId}
    >
      <DialogHeader
        id={titleId}
        title={(
          <span className="flex items-center gap-2.5">
            <span className={cx(
              "rounded-full px-2 py-0.5 text-[10.5px] font-bold uppercase tracking-wide",
              environment === "production" ? "bg-danger-soft text-danger" : "bg-amber-soft text-amber",
            )}>
              {environmentLabel}
            </span>
            {title}
          </span>
        )}
        onClose={() => {
          if (!busy) {
            reset();
            onClose();
          }
        }}
      />
      <form onSubmit={(event) => void submit(event)} noValidate aria-busy={busy}>
        <div className="flex flex-col gap-3.5 px-5 py-4">
          <p className="text-[13px] text-muted">{description}</p>
          <div className="rounded-[var(--radius-control)] border border-line bg-surface-soft/60 px-3.5 py-2.5 text-[13px]">
            {target}
          </div>
          <div className={cx(
            "rounded-[var(--radius-control)] px-3.5 py-2.5 text-[12.5px] font-semibold",
            danger ? "bg-danger-soft text-danger" : "bg-accent-soft text-accent",
          )}>
            {warning}
          </div>
          <label className="flex flex-col gap-1 text-[12px] font-semibold text-muted">
            Votre mot de passe LDAP
            <Input
              type="password"
              autoComplete="current-password"
              required
              maxLength={1024}
              value={password}
              disabled={busy}
              onChange={(event) => setPassword(event.target.value)}
            />
          </label>
          <label className="flex flex-col gap-1 text-[12px] font-semibold text-muted">
            Recopiez exactement la phrase suivante
            <code className="rounded-[var(--radius-control)] bg-surface-strong px-3 py-2 text-[13px] font-bold tracking-wide text-ink">
              {phrase}
            </code>
            <Input
              autoComplete="off"
              autoCapitalize="characters"
              spellCheck={false}
              required
              value={confirmation}
              disabled={busy}
              aria-invalid={confirmation.length > 0 && !confirmationValid}
              onChange={(event) => setConfirmation(event.target.value)}
            />
          </label>
          {feedback && (
            <p role="alert" aria-live="assertive" className="text-[13px] font-semibold text-danger">{feedback}</p>
          )}
        </div>
        <footer className="flex justify-end gap-2 border-t border-line px-5 py-3.5">
          <Button type="button" disabled={busy} onClick={() => { reset(); onClose(); }}>Annuler</Button>
          <Button type="submit" variant="danger" loading={busy} disabled={password.length === 0 || !confirmationValid}>
            {busy ? busyLabel : submitLabel}
          </Button>
        </footer>
      </form>
    </Dialog>
  );
}

export function RecoverySection({
  status,
  onChanged,
}: {
  status: RecoveryStatus;
  onChanged: () => Promise<void>;
}) {
  const { session } = useAppState();
  const [creating, setCreating] = useState(false);
  const [purgeOpen, setPurgeOpen] = useState(false);
  const [restoreTarget, setRestoreTarget] = useState<RecoverySnapshotRow | null>(null);

  if (status.unavailable) {
    return (
      <Card className="border-danger/40">
        <CardHeader
          title="Points de récupération"
          description="Protection locale des données élèves"
          aside={<Badge tone="danger">Indisponible</Badge>}
        />
        <CardBody>
          <p className="text-[13px]">
            <strong className="text-danger">La récupération locale n’est pas disponible.</strong>{" "}
            {status.error || "Réessayez dans quelques instants."} Aucun bouton de purge ou de restauration
            n’est proposé tant que ce contrôle échoue.
          </p>
        </CardBody>
      </Card>
    );
  }

  const environment = status.environment === "production" ? "production" : "test";
  const environmentLabel = environment === "production" ? "Production" : "Test";
  const retentionDays = Number(status.retention_days) || 7;
  const intervalMinutes = Number(status.interval_minutes) || 30;
  const storageBytes = Math.max(0, Number(status.storage_bytes) || 0);
  const storageLimitBytes = Math.max(1, Number(status.storage_limit_bytes) || (512 * 1024 * 1024));
  const snapshotCount = Math.max(0, Number(status.snapshot_count) || 0);
  const snapshots = Array.isArray(status.snapshots)
    ? [...status.snapshots].sort((left, right) => String(right.created_at || "").localeCompare(String(left.created_at || "")))
    : [];
  const latest = snapshots[0] || null;
  const purgePhrase = String(status.purge_confirmation
    || `VIDER ${environmentLabel.toUpperCase()} ${session?.school_year || ""}`).trim();
  const restorePrefix = String(status.restore_confirmation_prefix || "RESTAURER").trim();

  async function createSnapshot() {
    setCreating(true);
    try {
      await api("admin_create_snapshot", { method: "POST", body: {} });
      showToast("Point de récupération créé.");
      await onChanged();
    } catch (error) {
      showToast(error instanceof Error ? error.message : "Création impossible.");
    } finally {
      setCreating(false);
    }
  }

  return (
    <>
      <Card>
        <CardHeader
          title="Points de récupération"
          description="Sauvegardes temporaires des données élèves de cette installation"
          aside={(
            <Badge tone={environment === "production" ? "danger" : "pending"}>{environmentLabel}</Badge>
          )}
        />
        <CardBody className="flex flex-col gap-4">
          <div className="flex flex-wrap items-center justify-between gap-3">
            <div className="flex items-start gap-3">
              <span aria-hidden className={cx(
                "flex size-8 shrink-0 items-center justify-center rounded-full text-[14px] font-bold",
                latest ? "bg-accent-soft text-accent" : "bg-surface-strong text-muted",
              )}>
                {latest ? "✓" : "○"}
              </span>
              <div>
                <strong className="text-[13.5px]">
                  {latest ? `Dernier point créé le ${formatDate(latest.created_at)}` : "Aucun point de récupération disponible"}
                </strong>
                <p className="text-[12.5px] text-muted">
                  {latest
                    ? `${recoverySnapshotKind(latest.kind)} · ${formatRecoveryCounts(latest.counts)}`
                    : "Créez un premier point avant toute opération importante."}
                </p>
              </div>
            </div>
            <Button size="sm" loading={creating} onClick={() => void createSnapshot()}>Créer maintenant</Button>
          </div>

          <div aria-label="Politique de récupération" className="grid grid-cols-2 gap-3 lg:grid-cols-4">
            {[
              [`${retentionDays} jours`, "de conservation glissante"],
              [`${intervalMinutes} minutes`, "entre deux points automatiques"],
              [formatRecoveryCounts(status.counts), "données élèves actuelles"],
              [`${formatRecoverySize(storageBytes)} / ${formatRecoverySize(storageLimitBytes)}`, `${snapshotCount} point${snapshotCount > 1 ? "s" : ""} stocké${snapshotCount > 1 ? "s" : ""} dans MySQL`],
            ].map(([value, label], index) => (
              <div key={index} className="rounded-[var(--radius-control)] border border-line bg-surface-soft/60 px-3 py-2.5">
                <strong className="block text-[13px]">{value}</strong>
                <span className="text-[11.5px] text-muted">{label}</span>
              </div>
            ))}
          </div>

          <p className="rounded-[var(--radius-control)] bg-surface-soft px-3.5 py-2.5 text-[12.5px] text-muted">
            <strong className="text-ink">Récupération locale :</strong> ces points restent dans cette même base MySQL ;
            ils ne remplacent pas une sauvegarde du serveur. Les points automatiques sont déclenchés par une session
            WebUI active, au maximum toutes les {intervalMinutes} minutes. Si personne n’utilise l’application, aucun
            point n’est créé pendant cette période.
          </p>

          <div className="flex flex-wrap items-baseline justify-between gap-2">
            <div>
              <h4 className="text-[13.5px] font-bold">Points récents</h4>
              <p className="text-[12px] text-muted">
                La restauration remplace les élèves, observations, billets, points, actions, imports et clôtures
                annuelles. Elle conserve les utilisateurs, rôles, réglages et le journal d’audit.
              </p>
            </div>
            <span className="text-[12px] text-muted">{snapshots.length} disponible{snapshots.length > 1 ? "s" : ""}</span>
          </div>
          {snapshots.length === 0 ? (
            <div className="flex items-center gap-3 rounded-[var(--radius-control)] border border-dashed border-line-strong px-4 py-4">
              <span aria-hidden className="text-lg text-muted">↺</span>
              <div>
                <strong className="text-[13px]">Pas encore de sauvegarde</strong>
                <p className="text-[12px] text-muted">
                  Un point sera proposé avec l’activité de l’application, ou vous pouvez le créer maintenant.
                </p>
              </div>
            </div>
          ) : (
            <ul role="list" className="flex flex-col divide-y divide-line">
              {snapshots.slice(0, 30).map((snapshot) => (
                <li key={String(snapshot.id)} className="flex flex-wrap items-center gap-3 py-2.5">
                  <span aria-hidden className="flex size-7 shrink-0 items-center justify-center rounded-full bg-surface-strong text-[13px] text-muted">↺</span>
                  <div className="min-w-0 flex-1">
                    <strong className="text-[13px]">{formatDate(snapshot.created_at)}</strong>
                    <span className="block text-[12px] text-muted">
                      {recoverySnapshotKind(snapshot.kind)}
                      {snapshot.school_year ? ` · ${snapshot.school_year}` : ""}
                      {Number(snapshot.size_bytes) > 0 ? ` · ${formatRecoverySize(snapshot.size_bytes)}` : ""}
                    </span>
                    <small className="text-[11.5px] text-muted">
                      {formatRecoveryCounts(snapshot.counts)} · identifiant {shortRecoveryId(snapshot.id)}
                    </small>
                  </div>
                  <Button size="sm" onClick={() => setRestoreTarget(snapshot)}>Restaurer</Button>
                </li>
              ))}
            </ul>
          )}
        </CardBody>
      </Card>

      <Card className="border-danger/40">
        <CardHeader
          title="Vider les données élèves"
          description={`Opération exceptionnelle et réversible pendant ${retentionDays} jours`}
          aside={<Badge tone="danger">Zone dangereuse</Badge>}
        />
        <CardBody className="flex flex-wrap items-center justify-between gap-3">
          <div className="min-w-0 flex-1">
            <strong className="text-[13.5px]">Supprimer toutes les données élèves de cette installation</strong>
            <p className="text-[12.5px] text-muted">
              Les élèves, observations, points, actions et imports seront retirés. Les comptes, rôles, réglages et
              journaux d’audit resteront intacts. Un point de récupération est créé juste avant la purge.
            </p>
            <p className="mt-1.5 text-[12px] text-muted">
              Confirmation demandée : <code className="rounded bg-surface-strong px-1.5 py-0.5 font-bold text-ink">{purgePhrase}</code>
            </p>
          </div>
          <Button variant="danger" onClick={() => setPurgeOpen(true)}>Vider les données élèves</Button>
        </CardBody>
      </Card>

      <DangerDialog
        open={purgeOpen}
        danger
        title="Vider les données élèves ?"
        titleId="recovery-purge-title"
        description={`Cette opération supprime les élèves et toutes leurs données liées. Un point de récupération sera créé avant la suppression et restera restaurable pendant ${retentionDays} jours.`}
        environmentLabel={environmentLabel.toUpperCase()}
        environment={environment}
        target={(
          <>
            <strong>Volumes actuellement concernés</strong>
            <span className="block text-muted">{formatRecoveryCounts(status.counts)}</span>
          </>
        )}
        warning={<strong>Les nouvelles saisies effectuées après cette purge ne feront pas partie du point créé avant l’opération.</strong>}
        phrase={purgePhrase}
        submitLabel="Vider définitivement"
        busyLabel="Suppression…"
        onSubmit={async (password, confirmation) => {
          await api("admin_purge_students", { method: "POST", body: { password, confirmation } });
          setPurgeOpen(false);
          showToast(`Données élèves vidées. Le point de récupération est conservé ${retentionDays} jours.`);
          await onChanged();
        }}
        onClose={() => setPurgeOpen(false)}
      />

      <DangerDialog
        open={restoreTarget !== null}
        danger={false}
        title="Restaurer ce point ?"
        titleId="recovery-restore-title"
        description="La restauration remplace les élèves, observations, billets, points, actions, imports et clôtures annuelles. Les utilisateurs, rôles, réglages et journaux d’audit sont conservés."
        environmentLabel={environmentLabel.toUpperCase()}
        environment={environment}
        target={restoreTarget ? (
          <>
            <strong>État du {formatDate(restoreTarget.created_at)}</strong>
            <span className="block text-muted">
              {recoverySnapshotKind(restoreTarget.kind)} · {formatRecoveryCounts(restoreTarget.counts)}
            </span>
          </>
        ) : null}
        warning={(
          <>
            <strong>Un nouveau point de récupération est créé avant la restauration.</strong>{" "}
            Vous pourrez ainsi revenir à l’état actuel si nécessaire.
          </>
        )}
        phrase={restoreTarget ? `${restorePrefix} ${String(restoreTarget.id)}` : ""}
        submitLabel="Restaurer ce point"
        busyLabel="Restauration…"
        onSubmit={async (password, confirmation) => {
          await api("admin_restore_snapshot", {
            method: "POST",
            body: { snapshot_id: String(restoreTarget?.id || ""), password, confirmation },
          });
          setRestoreTarget(null);
          showToast("Point restauré. Un état de sécurité a été créé avant l’opération.");
          await onChanged();
        }}
        onClose={() => setRestoreTarget(null)}
      />
    </>
  );
}
