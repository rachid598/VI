import { useState } from "react";
import { api } from "../../api/client";
import type { SessionData } from "../../api/types";
import { applySession } from "../../state/appStore";
import { loadDeferredQueue, maintainDeferredQueues } from "../../state/deferredQueue";
import { showToast } from "../../state/toast";
import { Card, CardBody, CardHeader, Toggle } from "../../components/ui";

interface ModuleDefinition {
  key: string;
  action: string;
  title: string;
  subtitle: string;
  enabledTitle: string;
  disabledTitle: string;
  enabledDescription: string;
  disabledDescription: string;
  confirmEnable: string;
  confirmDisable: (pendingDeferred: number) => string;
  successEnable: string;
  successDisable: string;
}

const modules: ModuleDefinition[] = [
  {
    key: "points",
    action: "admin_set_points_enabled",
    title: "Module permis à points",
    subtitle: "Fonction facultative, indépendante du suivi des circulations",
    enabledTitle: "Module activé",
    disabledTitle: "Module désactivé",
    enabledDescription: "La vue est visible selon les droits CPE, direction et PP.",
    disabledDescription: "La vue est masquée pour tous. Les données déjà enregistrées sont conservées.",
    confirmEnable: "Activer le permis à points ? La vue redeviendra visible pour les personnels qui disposent des droits correspondants.",
    confirmDisable: () => "Désactiver le permis à points ? La vue sera masquée pour tous, mais les observations et les données de points resteront conservées.",
    successEnable: "Permis à points activé.",
    successDisable: "Permis à points désactivé. Les données sont conservées.",
  },
  {
    key: "passes",
    action: "admin_set_digital_passes_enabled",
    title: "Module billets numériques",
    subtitle: "Autorisation temporaire de déplacement, sans QR code ni appareil élève",
    enabledTitle: "Module activé",
    disabledTitle: "Module désactivé",
    enabledDescription: "Les personnels autorisés peuvent émettre et consulter les billets actifs.",
    disabledDescription: "La vue et l’émission sont masquées. Les anciens billets restent dans le journal.",
    confirmEnable: "Activer les billets numériques ? Les personnels autorisés pourront créer des autorisations temporaires de déplacement.",
    confirmDisable: () => "Désactiver les billets numériques ? La vue sera masquée et aucun nouveau billet ne pourra être créé.",
    successEnable: "Billets numériques activés.",
    successDisable: "Billets numériques désactivés.",
  },
  {
    key: "deferred",
    action: "admin_set_deferred_submissions_enabled",
    title: "Envoi différé",
    subtitle: "Protection facultative en cas de coupure au moment de l’envoi",
    enabledTitle: "Protection activée",
    disabledTitle: "Protection désactivée",
    enabledDescription: "Un envoi interrompu reste temporairement en mémoire tant que la page reste ouverte sans être actualisée, pendant 12 heures au maximum. Rien n’est enregistré sur le disque du navigateur.",
    disabledDescription: "Aucune observation n’est conservée dans le navigateur après un échec réseau.",
    confirmEnable: "Activer l’envoi différé ? En cas de coupure au moment de l’envoi, la requête pourra rester en mémoire tant que la page reste ouverte sans être actualisée, pendant 12 heures au maximum. Rien ne sera enregistré sur le disque du navigateur.",
    confirmDisable: (pendingCount) => `Désactiver l’envoi différé ?${pendingCount > 0 ? ` ${pendingCount} envoi${pendingCount > 1 ? "s" : ""} en attente dans cette session sera supprimé.` : " Les attentes en mémoire seront supprimées au prochain contrôle serveur."}`,
    successEnable: "Envoi différé activé.",
    successDisable: "Envoi différé désactivé et attente en mémoire supprimée.",
  },
];

export function ModuleToggles({
  session,
  onChanged,
}: {
  session: SessionData;
  onChanged: () => Promise<void>;
}) {
  const [busyKey, setBusyKey] = useState<string | null>(null);
  const [feedback, setFeedback] = useState<Record<string, string>>({});

  const enabledByKey: Record<string, boolean> = {
    points: !session.points || session.points.enabled !== false,
    passes: Boolean(session.digital_passes?.enabled),
    deferred: Boolean(session.deferred_submissions?.enabled),
  };

  async function toggle(module: ModuleDefinition) {
    const currentlyEnabled = enabledByKey[module.key];
    const enabled = !currentlyEnabled;
    const confirmation = enabled
      ? module.confirmEnable
      : module.confirmDisable(module.key === "deferred" ? loadDeferredQueue().length : 0);
    if (!window.confirm(confirmation)) return;
    setBusyKey(module.key);
    setFeedback((current) => ({ ...current, [module.key]: "" }));
    try {
      await api(module.action, { method: "POST", body: { enabled } });
      const data = await api<SessionData>("session");
      applySession(data);
      if (module.key === "deferred") maintainDeferredQueues();
      showToast(enabled ? module.successEnable : module.successDisable);
      await onChanged();
    } catch (error) {
      setFeedback((current) => ({
        ...current,
        [module.key]: error instanceof Error ? error.message : "Modification impossible.",
      }));
    } finally {
      setBusyKey(null);
    }
  }

  return (
    <>
      {modules.map((module) => {
        const enabled = enabledByKey[module.key];
        return (
          <Card key={module.key}>
            <CardHeader title={module.title} description={module.subtitle} />
            <CardBody className="flex items-start justify-between gap-4">
              <div>
                <strong className="text-[13.5px]">{enabled ? module.enabledTitle : module.disabledTitle}</strong>
                <p className="mt-0.5 text-[12.5px] text-muted">
                  {enabled ? module.enabledDescription : module.disabledDescription}
                </p>
                {feedback[module.key] && (
                  <p role="alert" className="mt-1.5 text-[12.5px] font-semibold text-danger">{feedback[module.key]}</p>
                )}
              </div>
              <Toggle
                checked={enabled}
                disabled={busyKey === module.key}
                label={`${enabled ? "Désactiver" : "Activer"} : ${module.title}`}
                onToggle={() => void toggle(module)}
              />
            </CardBody>
          </Card>
        );
      })}
    </>
  );
}
