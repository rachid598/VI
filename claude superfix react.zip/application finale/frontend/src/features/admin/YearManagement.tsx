import { useState, type FormEvent } from "react";
import { api } from "../../api/client";
import type { SessionData } from "../../api/types";
import { applySession } from "../../state/appStore";
import { showToast } from "../../state/toast";
import { Badge, Button, Card, CardBody, CardHeader, Input, Select } from "../../components/ui";
import type { HealthData } from "./adminTypes";
import { nextSchoolYear } from "./adminTypes";

export function YearRollover({
  activeSchoolYear,
  health,
  onChanged,
}: {
  activeSchoolYear: string;
  health: HealthData;
  onChanged: () => Promise<void>;
}) {
  const suggested = nextSchoolYear(activeSchoolYear);
  const [year, setYear] = useState(suggested);
  const [submitting, setSubmitting] = useState(false);
  const hasStudents = Number(health.active_students || 0) > 0;

  async function activate(event: FormEvent<HTMLFormElement>) {
    event.preventDefault();
    const schoolYear = year.trim();
    if (!window.confirm(`Activer l’année scolaire ${schoolYear} ? Les anciennes données resteront conservées.`)) return;
    setSubmitting(true);
    try {
      await api("admin_set_school_year", { method: "POST", body: { school_year: schoolYear } });
      const data = await api<SessionData>("session");
      applySession(data);
      showToast(`Année ${schoolYear} activée. Importez maintenant son annuaire élèves.`);
      await onChanged();
    } catch (error) {
      showToast(error instanceof Error ? error.message : "Activation impossible.");
    } finally {
      setSubmitting(false);
    }
  }

  const steps: Array<[string, React.ReactNode]> = [
    ["Activer la nouvelle année", (
      <>
        <p className="text-[12.5px] text-muted">À faire uniquement quand vous êtes prêt à importer sa liste d’élèves.</p>
        <form onSubmit={(event) => void activate(event)} className="mt-2 flex flex-wrap gap-2">
          <Input
            className="max-w-36 py-1.5"
            pattern="[0-9]{4}-[0-9]{4}"
            aria-label="Nouvelle année scolaire"
            required
            value={year}
            onChange={(event) => setYear(event.target.value)}
          />
          <Button type="submit" size="sm" loading={submitting}>Activer {year || suggested}</Button>
        </form>
      </>
    )],
    ["Importer ou synchroniser les élèves", (
      <p className="text-[12.5px] text-muted">
        {hasStudents
          ? `${Number(health.active_students)} élèves sont actuellement actifs. Vérifiez bien l’année affichée avant l’import.`
          : "Aucun élève actif : utilisez la synchronisation LDAP ou l’import CSV ci-dessous."}
      </p>
    )],
    ["Contrôler puis clôturer l’ancienne année", (
      <p className="text-[12.5px] text-muted">
        La clôture reste séparée et demande un aperçu, votre mot de passe et une phrase de confirmation.
      </p>
    )],
  ];

  return (
    <Card>
      <CardHeader
        title="Passage à l’année suivante"
        description="Un parcours guidé, sans modifier les anciennes données par surprise"
        aside={<Badge>Année active : {activeSchoolYear}</Badge>}
      />
      <CardBody className="flex flex-col gap-4">
        {steps.map(([title, body], index) => (
          <div key={index} className="flex gap-3">
            <span aria-hidden className="flex size-7 shrink-0 items-center justify-center rounded-full bg-institution text-[12.5px] font-bold text-white dark:bg-accent dark:text-institution-deep">
              {index + 1}
            </span>
            <div className="min-w-0 flex-1">
              <strong className="text-[13.5px]">{title}</strong>
              {body}
            </div>
          </div>
        ))}
      </CardBody>
    </Card>
  );
}

interface ClosurePreview {
  school_year?: string;
  counts?: Record<string, number>;
  [key: string]: unknown;
}

export function YearClosure({
  schoolYears,
  activeSchoolYear,
  closedYears,
  onChanged,
}: {
  schoolYears: Array<string | { school_year: string }>;
  activeSchoolYear: string;
  closedYears: Array<string | { school_year: string }>;
  onChanged: () => Promise<void>;
}) {
  const [selectedYear, setSelectedYear] = useState("");
  const [preview, setPreview] = useState<ClosurePreview | null>(null);
  const [previewError, setPreviewError] = useState("");
  const [loadingPreview, setLoadingPreview] = useState(false);
  const [password, setPassword] = useState("");
  const [confirmation, setConfirmation] = useState("");
  const [closureError, setClosureError] = useState("");
  const [closing, setClosing] = useState(false);

  const closed = new Set(closedYears.map((value) => String(typeof value === "object" ? value.school_year : value)));
  const previousYears = [...new Set(schoolYears
    .map((value) => String(typeof value === "object" ? value.school_year : value).trim())
    .filter(Boolean))]
    .filter((year) => year !== activeSchoolYear && !closed.has(year))
    .sort();

  async function loadPreview() {
    if (!selectedYear) {
      setPreviewError("Choisissez une ancienne année scolaire.");
      return;
    }
    setLoadingPreview(true);
    setPreviewError("");
    try {
      const response = await api<{ preview?: ClosurePreview } & ClosurePreview>(
        "admin_year_closure_preview",
        { query: { school_year: selectedYear } },
      );
      setPreview(response.preview || response);
      setPassword("");
      setConfirmation("");
      setClosureError("");
    } catch (error) {
      setPreview(null);
      setPreviewError(error instanceof Error ? error.message : "Aperçu impossible.");
    } finally {
      setLoadingPreview(false);
    }
  }

  async function close(event: FormEvent<HTMLFormElement>) {
    event.preventDefault();
    const schoolYear = preview?.school_year || selectedYear;
    const phrase = `CLOTURER ${schoolYear}`;
    if (confirmation.trim() !== phrase) {
      setClosureError(`Recopiez exactement « ${phrase} ».`);
      return;
    }
    if (!window.confirm("Cette action supprimera définitivement les données nominatives de cette année. Continuer ?")) return;
    setClosing(true);
    setClosureError("");
    try {
      await api("admin_close_year", {
        method: "POST",
        body: { school_year: schoolYear, password, confirmation: confirmation.trim() },
      });
      showToast("Année clôturée. Les agrégats anonymisés sont conservés.");
      setPreview(null);
      setSelectedYear("");
      await onChanged();
    } catch (error) {
      setClosureError(error instanceof Error ? error.message : "Clôture impossible.");
    } finally {
      setClosing(false);
    }
  }

  const counts = preview?.counts || preview || {};
  const phrase = preview ? `CLOTURER ${preview.school_year || selectedYear}` : "";

  return (
    <Card className="border-danger/30">
      <CardHeader
        title="Clôture d’une ancienne année"
        description="Conserve uniquement des totaux anonymisés puis supprime les données élèves de l’année choisie"
        aside={<Badge tone="danger">Action critique</Badge>}
      />
      <CardBody className="flex flex-col gap-3">
        {previousYears.length === 0 ? (
          <p className="text-[13px] text-muted">
            Aucune ancienne année contenant des données n’est disponible. Activez d’abord la nouvelle année scolaire.
          </p>
        ) : (
          <>
            <div className="flex flex-wrap items-end gap-2.5">
              <label className="flex flex-col gap-1 text-[12px] font-semibold text-muted">
                Année à clôturer
                <Select
                  className="w-auto"
                  value={selectedYear}
                  onChange={(event) => {
                    setSelectedYear(event.target.value);
                    setPreview(null);
                    setPreviewError("");
                  }}
                >
                  <option value="">Choisir une ancienne année…</option>
                  {previousYears.map((year) => <option key={year} value={year}>{year}</option>)}
                </Select>
              </label>
              <Button size="sm" loading={loadingPreview} onClick={() => void loadPreview()}>
                {preview ? "Actualiser l’aperçu" : "Afficher l’aperçu"}
              </Button>
            </div>
            <div aria-live="polite" className="rounded-[var(--radius-control)] border border-line bg-surface-soft/60 p-3.5">
              {previewError ? (
                <p className="text-[13px] font-semibold text-danger">{previewError}</p>
              ) : preview ? (
                <div className="flex flex-col gap-3">
                  <div className="flex flex-wrap gap-x-5 gap-y-1 text-[13px]">
                    <span><strong>{Number((counts as Record<string, unknown>).students || 0)}</strong> élèves</span>
                    <span><strong>{Number((counts as Record<string, unknown>).observations || 0)}</strong> observations</span>
                    <span><strong>{Number((counts as Record<string, unknown>).point_adjustments || 0)}</strong> ajustements de points</span>
                    <span><strong>{Number((counts as Record<string, unknown>).digital_passes || 0)}</strong> billets</span>
                  </div>
                  <p className="text-[12.5px] text-muted">
                    Un point de récupération sera créé avant la clôture et conservé selon la durée configurée.
                  </p>
                  <form onSubmit={(event) => void close(event)} className="flex flex-col gap-2.5">
                    <label className="flex flex-col gap-1 text-[12px] font-semibold text-muted">
                      Mot de passe Kwartz
                      <Input
                        type="password"
                        autoComplete="current-password"
                        required
                        value={password}
                        onChange={(event) => setPassword(event.target.value)}
                      />
                    </label>
                    <label className="flex flex-col gap-1 text-[12px] font-semibold text-muted">
                      <span>Recopiez <strong className="text-ink">{phrase}</strong></span>
                      <Input
                        autoComplete="off"
                        required
                        value={confirmation}
                        onChange={(event) => setConfirmation(event.target.value)}
                      />
                    </label>
                    {closureError && (
                      <p role="alert" className="text-[12.5px] font-semibold text-danger">{closureError}</p>
                    )}
                    <div>
                      <Button type="submit" variant="danger" loading={closing}>
                        Clôturer définitivement {preview.school_year || selectedYear}
                      </Button>
                    </div>
                  </form>
                </div>
              ) : (
                <p className="text-[12.5px] text-muted">Aucune donnée ne sera modifiée avant la confirmation finale.</p>
              )}
            </div>
          </>
        )}
      </CardBody>
    </Card>
  );
}
