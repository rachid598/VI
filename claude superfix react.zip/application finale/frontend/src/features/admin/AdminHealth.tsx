import { formatDate } from "../../lib/format";
import { displayName, roleLabels } from "../../lib/format";
import type { Role } from "../../api/types";
import { Badge, Card, CardBody, CardHeader, cx } from "../../components/ui";
import type { HealthData, ServiceHealth } from "./adminTypes";

function ServiceRow({ label, service }: { label: string; service?: ServiceHealth }) {
  const ok = service?.ok === true;
  const latency = Number.isFinite(Number(service?.latency_ms)) && service?.latency_ms !== null
    ? ` · ${Number(service?.latency_ms)} ms`
    : "";
  return (
    <div className="flex items-center gap-3 px-5 py-2.5">
      <span
        aria-hidden
        className={cx(
          "flex size-6 shrink-0 items-center justify-center rounded-full text-[12px] font-bold",
          ok ? "bg-accent-soft text-accent" : "bg-amber-soft text-amber",
        )}
      >
        {ok ? "✓" : "!"}
      </span>
      <div className="min-w-0 flex-1">
        <strong className="text-[13px]">{label}</strong>
        <span className="block truncate text-[12px] text-muted">{service?.message || "Contrôle indisponible"}{latency}</span>
      </div>
      <Badge tone={ok ? "confirmed" : "pending"}>{ok ? "OK" : "À vérifier"}</Badge>
    </div>
  );
}

export function AdminHealth({ health, appVersion }: { health: HealthData; appVersion: string }) {
  if (!health || health.unavailable) {
    return (
      <Card>
        <CardHeader title="Santé de l’application" description="Indicateurs de fonctionnement" aside={<Badge tone="danger">Indisponible</Badge>} />
        <CardBody><p className="text-[13px] text-muted">{health?.error || "Impossible de charger les indicateurs."}</p></CardBody>
      </Card>
    );
  }
  const services = health.services || {};
  const serviceRows: Array<[string, ServiceHealth | undefined]> = [
    ["MySQL", services.mysql],
    ["Annuaire LDAP", services.ldap],
    ["Dossier var", services.storage],
    ["Récupération", services.recovery],
  ];
  const pendingOld = Number(health.pending_over_24h || 0);
  const inactive = Number(health.inactive_accounts_count || 0);
  const serviceWarning = serviceRows.some(([, service]) => !service || service.ok !== true);
  const needsAttention = serviceWarning || pendingOld > 0 || inactive > 0;
  const facts: Array<[string, string, boolean?]> = [
    [`v${health.app_version || appVersion || "?"}`, "version installée"],
    [String(Number(health.active_students || 0)), "élèves actifs"],
    [String(Number(health.active_classes || 0)), "classes actives"],
    [health.last_import?.created_at ? formatDate(health.last_import.created_at) : "Jamais", "dernier import CSV"],
    [health.last_ldap_sync?.created_at ? formatDate(health.last_ldap_sync.created_at) : "Jamais", "dernière synchro LDAP"],
    [health.last_backup?.created_at ? formatDate(health.last_backup.created_at) : "Aucun", "dernier point de récupération"],
    [health.last_connection?.last_login_at ? formatDate(health.last_connection.last_login_at) : "Aucune", "dernière connexion"],
    [String(pendingOld), "signalements de plus de 24 h", pendingOld > 0],
    [String(inactive), "comptes inactifs depuis 90 jours ou jamais utilisés", inactive > 0],
  ];

  return (
    <Card>
      <CardHeader
        title="État du système"
        description="Disponibilité des services et repères d’administration"
        aside={<Badge tone={needsAttention ? "pending" : "confirmed"}>{needsAttention ? "À examiner" : "Opérationnel"}</Badge>}
      />
      <div className="grid divide-y divide-line sm:grid-cols-2 sm:divide-y-0">
        {serviceRows.map(([label, service]) => <ServiceRow key={label} label={label} service={service} />)}
      </div>
      <div className="grid grid-cols-2 gap-px border-t border-line bg-line sm:grid-cols-3 lg:grid-cols-5">
        {facts.map(([value, label, warning], index) => (
          <div key={index} className={cx("bg-surface px-4 py-3", warning && "bg-amber-soft")}>
            <strong className={cx("block text-[14px]", warning && "text-amber")}>{value}</strong>
            <span className="text-[11.5px] text-muted">{label}</span>
          </div>
        ))}
      </div>
      {inactive > 0 && Array.isArray(health.inactive_accounts) && (
        <details className="border-t border-line px-5 py-3">
          <summary className="cursor-pointer text-[13px] font-semibold">Voir les comptes à examiner</summary>
          <div className="mt-2 flex flex-wrap gap-x-4 gap-y-1 text-[12.5px]">
            {health.inactive_accounts.slice(0, 30).map((account, index) => (
              <span key={index}>
                <strong>{displayName(account.first_name, account.last_name) || account.uid || account.ldap_uid}</strong>
                {" · "}
                {roleLabels[account.role as Role] || account.role || ""}
              </span>
            ))}
          </div>
        </details>
      )}
    </Card>
  );
}
