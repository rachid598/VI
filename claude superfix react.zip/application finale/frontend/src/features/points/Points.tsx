import { useCallback, useEffect, useMemo, useState } from "react";
import { createPortal } from "react-dom";
import { api, downloadCsv } from "../../api/client";
import { patchSession, useAppState } from "../../state/appStore";
import { showToast } from "../../state/toast";
import { classLevel, formatDate } from "../../lib/format";
import {
  Badge, Button, Card, Dialog, DialogHeader, ErrorCard, Input, LoadingView, Select, cx,
} from "../../components/ui";
import { StatusBadge } from "../../components/StatusBadge";
import { StatCard, StatGrid } from "../../components/StatCard";
import type { ObservationStatus, PointsStudentRow } from "../../api/types";

interface PointsData {
  trimester: number;
  capital: number;
  alert_threshold: number;
  window_start: string;
  window_end: string;
  scope_class: string | null;
  can_manage?: boolean;
  totals: { confirmed: number; restored: number; alert: number; zero: number; actions: number };
  students: PointsStudentRow[];
}

interface DetailObservation {
  id: number;
  occurred_at: string;
  location: string;
  reason: string;
  details?: string;
  status: ObservationStatus;
  reporter?: string;
  situation_id?: string;
}

interface DetailAdjustment {
  created_at: string;
  reason: string;
  granted_by: string;
  points: number;
}

interface DetailAction {
  action: string;
  threshold_points: number;
  crossed?: boolean;
  done?: { done_at: string; done_by: string; note?: string } | null;
}

interface PointsDetail {
  student: { first_name: string; last_name: string; class_name: string };
  points: number;
  capital: number;
  restored?: number;
  trimester: number;
  trimester_label?: string;
  confirmed_situations?: number;
  pending_situations?: number;
  observations: DetailObservation[];
  adjustments: DetailAdjustment[];
  actions: DetailAction[];
  can_manage?: boolean;
}

function pointsTone(points: number, alertThreshold: number): "green" | "amber" | "red" {
  if (points === 0) return "red";
  return points <= alertThreshold ? "amber" : "green";
}

const toneStyles = {
  green: "bg-accent-soft text-accent",
  amber: "bg-amber-soft text-amber",
  red: "bg-danger-soft text-danger",
} as const;

const gaugeStyles = {
  green: "bg-accent",
  amber: "bg-amber",
  red: "bg-danger",
} as const;

/** Aperçu et impression du courrier famille prérempli (jamais envoyé automatiquement). */
function FamilyLetter({
  detail,
  template,
  collegeName,
  onClose,
}: {
  detail: PointsDetail;
  template: string;
  collegeName: string;
  onClose: () => void;
}) {
  const [printing, setPrinting] = useState(false);

  const factsList = useMemo(() => {
    const situations = new Map<string, DetailObservation[]>();
    for (const item of detail.observations.filter((observation) => observation.status === "confirmed")) {
      const situationId = item.situation_id || `observation:${item.id}`;
      const list = situations.get(situationId) ?? [];
      list.push(item);
      situations.set(situationId, list);
    }
    return [...situations.values()].map((items) => {
      const chronology = [...items].sort((left, right) => String(left.occurred_at).localeCompare(String(right.occurred_at)));
      if (chronology.length === 1) {
        const item = chronology[0];
        return `${formatDate(item.occurred_at)} — ${item.reason} (${item.location})`;
      }
      const places = chronology.map((item) => item.location)
        .filter((value, index, list) => index === 0 || value !== list[index - 1]);
      const reasons = [...new Set(chronology.map((item) => item.reason))];
      return `${formatDate(chronology[0].occurred_at)} — Parcours observé : ${places.join(" → ")} (${reasons.join(" ; ")})`;
    });
  }, [detail]);

  const segments = useMemo(() => {
    const filled = template
      .replaceAll("{ELEVE}", `${detail.student.first_name} ${detail.student.last_name}`)
      .replaceAll("{CLASSE}", detail.student.class_name)
      .replaceAll("{POINTS}", String(detail.points))
      .replaceAll("{CAPITAL}", String(detail.capital))
      .replaceAll("{TRIMESTRE}", detail.trimester_label || `trimestre ${detail.trimester}`)
      .replaceAll("{COLLEGE}", collegeName)
      .replaceAll("{DATE}", new Intl.DateTimeFormat("fr-FR", { dateStyle: "long" }).format(new Date()));
    return filled.split("{FAITS}");
  }, [template, detail, collegeName]);

  useEffect(() => {
    if (!printing) return;
    const timer = window.setTimeout(() => {
      window.print();
      setPrinting(false);
    }, 50);
    return () => window.clearTimeout(timer);
  }, [printing]);

  const letterBody = (
    <div className="whitespace-pre-line text-[13.5px] leading-relaxed">
      {segments[0]}
      {segments.length > 1 && (
        <>
          {factsList.length > 0 ? (
            <ul className="my-2 list-disc pl-6">
              {factsList.map((fact, index) => <li key={index}>{fact}</li>)}
            </ul>
          ) : (
            <p>—</p>
          )}
          {segments[1]}
        </>
      )}
    </div>
  );

  return (
    <Dialog open onClose={onClose} labelledBy="letter-dialog-title" className="max-w-2xl">
      <DialogHeader
        id="letter-dialog-title"
        title="Aperçu du courrier famille"
        description="À faire valider par la direction avant utilisation réelle."
        onClose={onClose}
      />
      <article className="max-h-[60vh] overflow-y-auto px-6 py-5">{letterBody}</article>
      <footer className="flex justify-end gap-2 border-t border-line px-5 py-3.5">
        <Button onClick={onClose}>Retour</Button>
        <Button variant="primary" onClick={() => setPrinting(true)}>Imprimer le courrier</Button>
      </footer>
      {printing && createPortal(<div className="print-sheet">{letterBody}</div>, document.body)}
    </Dialog>
  );
}

function PointsDetailDialog({
  studentId,
  trimester,
  onClose,
  onChanged,
  onOpenLetter,
}: {
  studentId: number;
  trimester: number;
  onClose: () => void;
  onChanged: () => Promise<void>;
  onOpenLetter: (detail: PointsDetail) => void;
}) {
  const [detail, setDetail] = useState<PointsDetail | null>(null);
  const [error, setError] = useState("");
  const [restoreReason, setRestoreReason] = useState("");
  const [actionNotes, setActionNotes] = useState<Record<number, string>>({});
  const [busy, setBusy] = useState(false);

  const load = useCallback(async () => {
    try {
      setDetail(await api<PointsDetail>("points_detail", { query: { student_id: studentId, t: trimester } }));
    } catch (requestError) {
      setError(requestError instanceof Error ? requestError.message : "Chargement impossible.");
    }
  }, [studentId, trimester]);

  useEffect(() => {
    void load();
  }, [load]);

  async function restorePoint() {
    if (!detail) return;
    const reason = restoreReason.trim();
    if (reason.length < 3) {
      showToast("Indiquez le motif du point rendu.");
      return;
    }
    const studentName = `${detail.student.first_name} ${detail.student.last_name}`;
    if (!window.confirm(`Rendre un point à ${studentName} pour le motif suivant ?\n\n${reason}`)) return;
    setBusy(true);
    try {
      await api("points_restore", { method: "POST", body: { student_id: studentId, reason } });
      showToast("Point rendu et journalisé.");
      setRestoreReason("");
      await onChanged();
      await load();
    } catch (requestError) {
      showToast(requestError instanceof Error ? requestError.message : "Action impossible.");
    } finally {
      setBusy(false);
    }
  }

  async function markActionDone(threshold: number) {
    if (!window.confirm("Confirmer que cette action éducative a bien été réalisée ?")) return;
    setBusy(true);
    try {
      await api("points_action_done", {
        method: "POST",
        body: { student_id: studentId, threshold_points: threshold, note: (actionNotes[threshold] || "").trim() },
      });
      showToast("Action éducative enregistrée.");
      await onChanged();
      await load();
    } catch (requestError) {
      showToast(requestError instanceof Error ? requestError.message : "Action impossible.");
    } finally {
      setBusy(false);
    }
  }

  const timeline = useMemo(() => {
    if (!detail) return [];
    return [
      ...detail.observations.map((item) => ({ kind: "observation" as const, date: item.occurred_at, observation: item, adjustment: null })),
      ...detail.adjustments.map((item) => ({ kind: "adjustment" as const, date: item.created_at, observation: null, adjustment: item })),
    ].sort((left, right) => String(right.date).localeCompare(String(left.date)));
  }, [detail]);

  const confirmedCount = detail
    ? Number(detail.confirmed_situations ?? detail.observations.filter((item) => item.status === "confirmed").length)
    : 0;
  const pendingCount = detail
    ? Number(detail.pending_situations ?? detail.observations.filter((item) => item.status === "pending").length)
    : 0;
  const visibleActions = (detail?.actions ?? []).filter((action) => action.crossed || action.done);

  return (
    <Dialog open onClose={onClose} labelledBy="points-modal-title" className="max-w-2xl">
      <DialogHeader
        id="points-modal-title"
        title={detail ? `${detail.student.last_name} ${detail.student.first_name} — ${detail.student.class_name}` : "Détail de l’élève"}
        description={detail
          ? `${detail.points} point(s) restant(s) sur ${detail.capital} · ${confirmedCount} situation(s) confirmée(s)`
            + (detail.restored ? ` · ${detail.restored} rendu(s)` : "")
            + (pendingCount ? ` · ${pendingCount} en attente` : "")
          : undefined}
        onClose={onClose}
      />
      <div className="max-h-[65vh] overflow-y-auto px-5 py-4">
        {error && <p className="py-4 text-center text-sm font-semibold text-danger">{error}</p>}
        {!error && detail === null && <LoadingView />}
        {detail && (
          <div className="flex flex-col gap-5">
            {visibleActions.length > 0 && (
              <section>
                <h4 className="text-[13px] font-bold uppercase tracking-wide text-muted">Actions éducatives</h4>
                <div className="mt-2 flex flex-col gap-2.5">
                  {visibleActions.map((action) => action.done ? (
                    <div key={action.threshold_points} className="flex items-start gap-3 rounded-[var(--radius-control)] border border-line bg-surface-soft/60 p-3">
                      <span aria-hidden className="flex size-6 shrink-0 items-center justify-center rounded-full bg-accent-soft text-[12px] font-bold text-accent">✓</span>
                      <div className="text-[13px]">
                        <strong>{action.action}</strong> <span className="text-muted">(seuil {action.threshold_points})</span>
                        <p className="text-[12px] text-muted">
                          Fait le {formatDate(action.done.done_at)} par {action.done.done_by}
                          {action.done.note ? ` — ${action.done.note}` : ""}
                        </p>
                      </div>
                    </div>
                  ) : (
                    <div key={action.threshold_points} className="flex items-start gap-3 rounded-[var(--radius-control)] border border-amber/40 bg-amber-soft p-3">
                      <span aria-hidden className="flex size-6 shrink-0 items-center justify-center rounded-full bg-amber/15 text-[12px] font-bold text-amber">!</span>
                      <div className="flex-1 text-[13px]">
                        <strong>{action.action}</strong> <span className="text-muted">(seuil {action.threshold_points} franchi)</span>
                        {detail.can_manage ? (
                          <>
                            <div className="mt-2 flex flex-wrap gap-2">
                              <Input
                                className="max-w-64 py-1.5 text-[12.5px]"
                                maxLength={160}
                                placeholder="Note facultative"
                                value={actionNotes[action.threshold_points] || ""}
                                onChange={(event) => setActionNotes((current) => ({ ...current, [action.threshold_points]: event.target.value }))}
                              />
                              <Button size="sm" disabled={busy} onClick={() => void markActionDone(action.threshold_points)}>
                                Marquer comme fait
                              </Button>
                            </div>
                            <p className="mt-1 text-[11.5px] text-muted">
                              Cette action sera journalisée et ne pourra pas être enregistrée deux fois.
                            </p>
                          </>
                        ) : (
                          <p className="text-[12px] text-muted">À traiter par la vie scolaire</p>
                        )}
                      </div>
                    </div>
                  ))}
                </div>
              </section>
            )}

            {detail.can_manage && (
              <section className="rounded-[var(--radius-control)] border border-line bg-surface-soft/60 p-3.5">
                <h4 className="text-[13px] font-bold">Valoriser une évolution positive</h4>
                <p className="mt-0.5 text-[12px] text-muted">
                  Un point peut être rendu après décision de la vie scolaire. Le motif est obligatoire et conservé dans le journal.
                </p>
                <div className="mt-2 flex flex-wrap gap-2">
                  <Input
                    className="max-w-72 py-1.5 text-[12.5px]"
                    maxLength={160}
                    placeholder="Ex. engagement tenu pendant une semaine"
                    value={restoreReason}
                    onChange={(event) => setRestoreReason(event.target.value)}
                  />
                  <Button size="sm" variant="primary" disabled={busy} onClick={() => void restorePoint()}>
                    Rendre 1 point
                  </Button>
                </div>
              </section>
            )}

            <section>
              <h4 className="text-[13px] font-bold uppercase tracking-wide text-muted">Historique du trimestre</h4>
              {timeline.length === 0 ? (
                <p className="mt-2 text-[13px] text-muted">Aucun mouvement sur ce trimestre.</p>
              ) : (
                <div className="mt-2 flex flex-col gap-2">
                  {timeline.map((entry, index) => entry.kind === "observation" && entry.observation ? (
                    <div key={index} className="flex items-center gap-3 rounded-[var(--radius-control)] border border-line px-3 py-2.5 text-[13px]">
                      <span className="w-24 shrink-0 font-bold">{formatDate(entry.observation.occurred_at)}</span>
                      <span className="min-w-0 flex-1">
                        {entry.observation.reason}
                        <span className="block text-[11.5px] text-muted">
                          {entry.observation.location}
                          {entry.observation.reporter ? ` — signalé par ${entry.observation.reporter}` : ""}
                          {entry.observation.details ? ` — ${entry.observation.details}` : ""}
                        </span>
                      </span>
                      <StatusBadge status={entry.observation.status} />
                    </div>
                  ) : entry.adjustment && (
                    <div key={index} className="flex items-center gap-3 rounded-[var(--radius-control)] border border-accent/40 bg-accent-soft/50 px-3 py-2.5 text-[13px]">
                      <span className="w-24 shrink-0 font-bold">{formatDate(entry.adjustment.created_at)}</span>
                      <span className="min-w-0 flex-1">
                        Point rendu : {entry.adjustment.reason}
                        <span className="block text-[11.5px] text-muted">par {entry.adjustment.granted_by}</span>
                      </span>
                      <Badge tone="confirmed">+{Number(entry.adjustment.points)} point</Badge>
                    </div>
                  ))}
                </div>
              )}
            </section>

            {detail.can_manage && (
              <div>
                <Button size="sm" onClick={() => onOpenLetter(detail)}>Préparer le courrier famille</Button>
              </div>
            )}
            <p className="rounded-[var(--radius-control)] bg-surface-soft px-3.5 py-2.5 text-[12px] text-muted">
              Chaque situation confirmée retire un point. Les passages d’un même parcours restent visibles mais ne comptent qu’une fois.
            </p>
          </div>
        )}
      </div>
    </Dialog>
  );
}

export function Points() {
  const { session } = useAppState();
  const [trimester, setTrimester] = useState(0);
  const [data, setData] = useState<PointsData | null>(null);
  const [error, setError] = useState("");
  const [search, setSearch] = useState("");
  const [levelFilter, setLevelFilter] = useState("");
  const [classFilter, setClassFilter] = useState("");
  const [detailStudentId, setDetailStudentId] = useState<number | null>(null);
  const [letterDetail, setLetterDetail] = useState<PointsDetail | null>(null);
  const [exporting, setExporting] = useState(false);

  const load = useCallback(async (requested: number) => {
    setError("");
    try {
      const response = await api<PointsData>("points", { query: requested ? { t: requested } : {} });
      setData(response);
      setTrimester(response.trimester);
      patchSession({ alert_count: Number(response.totals.alert) + Number(response.totals.zero) });
    } catch (requestError) {
      setError(requestError instanceof Error ? requestError.message : "Chargement impossible.");
    }
  }, []);

  useEffect(() => {
    void load(0);
  }, [load]);

  const students = data?.students ?? [];
  const classes = useMemo(() => [...new Set(students.map((row) => row.class_name))].sort(), [students]);
  const levels = useMemo(
    () => [...new Set(classes.map(classLevel).filter(Boolean))].sort().reverse(),
    [classes],
  );
  const availableClasses = levelFilter ? classes.filter((className) => classLevel(className) === levelFilter) : classes;

  const filteredRows = useMemo(() => {
    const needle = search.trim().toLowerCase();
    return students.filter((row) =>
      (!levelFilter || classLevel(row.class_name) === levelFilter)
      && (!classFilter || row.class_name === classFilter)
      && (!needle || `${row.last_name} ${row.first_name} ${row.class_name}`.toLowerCase().includes(needle)));
  }, [students, search, levelFilter, classFilter]);

  if (error) return <ErrorCard message={error} onRetry={() => void load(trimester)} />;
  if (data === null) return <LoadingView />;

  const bareme = session?.points;
  const hasActiveFilters = Boolean(search.trim() || levelFilter || classFilter);
  const windowLabel = `${data.window_start.slice(8, 10)}/${data.window_start.slice(5, 7)} → ${data.window_end.slice(8, 10)}/${data.window_end.slice(5, 7)}`;

  async function exportCsv() {
    setExporting(true);
    try {
      await downloadCsv("points_export", { t: trimester }, `permis-points-T${trimester}.csv`);
      showToast("Export CSV préparé.");
    } catch (requestError) {
      showToast(requestError instanceof Error ? requestError.message : "Export impossible.");
    } finally {
      setExporting(false);
    }
  }

  return (
    <div className="flex flex-col gap-5">
      <div className="flex flex-wrap items-start justify-between gap-3">
        <div>
          <h2 className="font-display text-[17px] font-bold tracking-tight">
            {data.scope_class ? `Permis à points — classe ${data.scope_class}` : "Permis à points de l’établissement"}
          </h2>
          <p className="text-[13px] text-muted">
            Seules les situations <strong className="text-ink">confirmées</strong> retirent un point.
            Plusieurs observations d’un même parcours ne comptent qu’une fois.
          </p>
        </div>
        <Button size="sm" loading={exporting} onClick={() => void exportCsv()}>Exporter toute la période</Button>
      </div>

      <p className="rounded-[var(--radius-card)] border border-line bg-surface px-4 py-2.5 text-[12.5px] text-muted">
        Capital <b className="text-ink">{Number(data.capital)} points</b> par trimestre ·{" "}
        <b className="text-ink">−1 point</b> par situation confirmée ·{" "}
        <b className="text-ink">+1 point</b> possible sur décision CPE · alerte à{" "}
        <b className="text-ink">≤ {Number(data.alert_threshold)}</b>
        <span className="ml-2 text-[11.5px]">Barème et seuils configurables</span>
      </p>

      <StatGrid>
        <StatCard label="Situations confirmées" value={data.totals.confirmed} detail={`trimestre ${data.trimester} (${windowLabel})`} tone="green" />
        <StatCard label="Points rendus" value={data.totals.restored} detail="évolutions positives valorisées" tone="green" />
        <StatCard label="Élèves en alerte" value={Number(data.totals.alert) + Number(data.totals.zero)} detail={`capital ≤ ${Number(data.alert_threshold)} ou épuisé`} tone="amber" />
        <StatCard label="Actions à suivre" value={data.totals.actions} detail="seuils franchis non traités" tone="red" />
      </StatGrid>

      <Card>
        <div className="flex flex-col gap-3 border-b border-line px-5 py-4">
          <div>
            <h3 className="font-display text-[15px] font-bold">Capital par élève</h3>
            <p className="text-[12.5px] text-muted">Tri : points restants croissants — les situations prioritaires en premier</p>
          </div>
          <div role="search" aria-label="Filtrer les élèves" className="grid gap-3 sm:grid-cols-2 lg:grid-cols-4">
            <label className="flex flex-col gap-1 text-[12px] font-semibold text-muted">
              Rechercher
              <Input
                type="search"
                placeholder="Nom, prénom ou classe…"
                autoComplete="off"
                value={search}
                onChange={(event) => setSearch(event.target.value)}
              />
            </label>
            {!data.scope_class && (
              <>
                <label className="flex flex-col gap-1 text-[12px] font-semibold text-muted">
                  Niveau
                  <Select
                    value={levelFilter}
                    onChange={(event) => {
                      const level = event.target.value;
                      setLevelFilter(level);
                      if (classFilter && classLevel(classFilter) !== level) setClassFilter("");
                    }}
                  >
                    <option value="">Tous les niveaux</option>
                    {levels.map((value) => <option key={value} value={value}>Niveau {value}e</option>)}
                  </Select>
                </label>
                <label className="flex flex-col gap-1 text-[12px] font-semibold text-muted">
                  Classe
                  <Select
                    value={classFilter}
                    onChange={(event) => {
                      const className = event.target.value;
                      setClassFilter(className);
                      const level = classLevel(className);
                      if (className && level && level !== levelFilter) setLevelFilter(level);
                    }}
                  >
                    <option value="">{levelFilter ? `Toutes les classes de ${levelFilter}e` : "Toutes les classes"}</option>
                    {availableClasses.map((value) => <option key={value} value={value}>{value}</option>)}
                  </Select>
                </label>
              </>
            )}
            <label className="flex flex-col gap-1 text-[12px] font-semibold text-muted">
              Période
              <Select value={data.trimester} onChange={(event) => void load(Number(event.target.value))}>
                {(bareme?.trimesters ?? []).map((item, index) => (
                  <option key={index} value={index + 1}>
                    {item.label} ({item.start.slice(8, 10)}/{item.start.slice(5, 7)} → {item.end.slice(8, 10)}/{item.end.slice(5, 7)})
                  </option>
                ))}
              </Select>
            </label>
          </div>
          <div className="flex items-center justify-between gap-3 text-[12.5px] text-muted">
            <span aria-live="polite">
              {hasActiveFilters
                ? `${filteredRows.length} élève${filteredRows.length > 1 ? "s" : ""} affiché${filteredRows.length > 1 ? "s" : ""} sur ${students.length}`
                : `${students.length} élève${students.length > 1 ? "s" : ""}`}
            </span>
            {hasActiveFilters && (
              <Button size="sm" variant="ghost" onClick={() => { setSearch(""); setLevelFilter(""); setClassFilter(""); }}>
                Effacer les filtres
              </Button>
            )}
          </div>
        </div>

        <div className="table-scroll">
          <table className="w-full min-w-max border-collapse text-sm">
            <thead>
              <tr className="border-b border-line bg-surface-soft text-left text-[12.5px] text-muted [&>th]:px-4 [&>th]:py-2.5 [&>th]:font-semibold">
                <th>Élève</th><th>Capital restant</th><th>Points</th><th>Situations confirmées</th>
                <th>En attente</th><th>Rendus</th><th>Actions</th><th>Dernière confirmée</th>
              </tr>
            </thead>
            <tbody>
              {filteredRows.length === 0 ? (
                <tr><td colSpan={8} className="px-4 py-6 text-center text-muted">Aucun élève ne correspond.</td></tr>
              ) : (
                filteredRows.map((row) => {
                  const tone = pointsTone(Number(row.points), Number(data.alert_threshold));
                  return (
                    <tr
                      key={row.id}
                      tabIndex={0}
                      role="button"
                      aria-haspopup="dialog"
                      aria-label={`Ouvrir le détail de ${row.first_name} ${row.last_name}, ${row.class_name}, ${Number(row.points)} point(s) restant(s)`}
                      onClick={() => setDetailStudentId(row.id)}
                      onKeyDown={(event) => {
                        if (event.key !== "Enter" && event.key !== " ") return;
                        event.preventDefault();
                        setDetailStudentId(row.id);
                      }}
                      className="cursor-pointer border-b border-line last:border-0 hover:bg-surface-soft/70 [&>td]:px-4 [&>td]:py-3"
                    >
                      <td>
                        <strong className="block">{row.last_name} {row.first_name}</strong>
                        <span className="text-[12px] text-muted">{row.class_name}</span>
                      </td>
                      <td className="min-w-28">
                        <span className="block h-2 w-24 overflow-hidden rounded-full bg-surface-strong">
                          <span
                            className={cx("block h-full rounded-full", gaugeStyles[tone])}
                            style={{ width: `${Math.min(100, Math.max(0, (Number(row.points) / Number(data.capital)) * 100))}%` }}
                          />
                        </span>
                      </td>
                      <td>
                        <span className={cx("inline-flex min-w-8 items-center justify-center rounded-full px-2 py-0.5 text-[13px] font-bold", toneStyles[tone])}>
                          {row.points}
                        </span>
                      </td>
                      <td>{row.confirmed || "—"}</td>
                      <td>{row.pending ? <span className="font-semibold text-amber">+{row.pending} à vérifier</span> : "—"}</td>
                      <td>{row.restored ? <span className="font-semibold text-accent">+{row.restored}</span> : "—"}</td>
                      <td>{row.pending_actions
                        ? <span className="font-semibold text-danger">{row.pending_actions} à faire</span>
                        : <span className="text-muted">à jour</span>}</td>
                      <td>{row.last_confirmed_at ? formatDate(row.last_confirmed_at) : "—"}</td>
                    </tr>
                  );
                })
              )}
            </tbody>
          </table>
        </div>
        <div className="flex flex-wrap items-center gap-4 px-5 py-3 text-[11.5px] text-muted">
          <span className="inline-flex items-center gap-1.5"><i aria-hidden className="size-2.5 rounded-full bg-accent" />Situation normale</span>
          <span className="inline-flex items-center gap-1.5"><i aria-hidden className="size-2.5 rounded-full bg-amber" />Alerte (≤ {Number(data.alert_threshold)})</span>
          <span className="inline-flex items-center gap-1.5"><i aria-hidden className="size-2.5 rounded-full bg-danger" />Capital épuisé</span>
          <span>Cliquer sur un élève pour le détail et les actions éducatives</span>
        </div>
      </Card>

      {detailStudentId !== null && (
        <PointsDetailDialog
          studentId={detailStudentId}
          trimester={trimester}
          onClose={() => setDetailStudentId(null)}
          onChanged={() => load(trimester)}
          onOpenLetter={(detail) => {
            setDetailStudentId(null);
            setLetterDetail(detail);
          }}
        />
      )}
      {letterDetail && (
        <FamilyLetter
          detail={letterDetail}
          template={bareme?.letter_template || ""}
          collegeName={bareme?.college_name || "Le collège"}
          onClose={() => setLetterDetail(null)}
        />
      )}
    </div>
  );
}
