import { useCallback, useEffect, useState } from "react";
import { api } from "../../api/client";
import { formatDate } from "../../lib/format";
import { Badge, Card, CardBody, DataTable, ErrorCard, LoadingView } from "../../components/ui";

interface PpObservation {
  occurred_at: string;
  first_name: string;
  last_name: string;
  class_name: string;
  location: string;
  reason: string;
  details?: string;
}

interface PpData {
  class_name: string;
  observations: PpObservation[];
}

export function PpReport() {
  const [data, setData] = useState<PpData | null>(null);
  const [error, setError] = useState("");

  const load = useCallback(async () => {
    setError("");
    try {
      setData(await api<PpData>("pp_report"));
    } catch (requestError) {
      setError(requestError instanceof Error ? requestError.message : "Chargement impossible.");
    }
  }, []);

  useEffect(() => {
    void load();
  }, [load]);

  if (error) return <ErrorCard message={error} onRetry={() => void load()} />;
  if (data === null) return <LoadingView />;

  return (
    <div className="flex flex-col gap-5">
      <div className="flex flex-wrap items-center justify-between gap-3 rounded-[var(--radius-card)] border border-line bg-institution px-5 py-4 text-white">
        <div>
          <strong className="font-display text-[15px]">Classe {data.class_name}</strong>
          <p className="text-[12.5px] text-white/70">7 derniers jours · déclarant masqué</p>
        </div>
        <Badge className="bg-white/15 text-white">{data.observations.length} observation(s)</Badge>
      </div>

      <Card>
        {data.observations.length === 0 ? (
          <CardBody><p className="text-[13px] text-muted">Aucune observation confirmée sur cette période.</p></CardBody>
        ) : (
          <DataTable head={<><th>Date</th><th>Élève</th><th>Lieu</th><th>Motif</th><th>Précision</th></>}>
            {data.observations.map((item, index) => (
              <tr key={index}>
                <td>{formatDate(item.occurred_at)}</td>
                <td>
                  <strong className="block">{item.first_name} {item.last_name}</strong>
                  <span className="text-[12px] text-muted">{item.class_name}</span>
                </td>
                <td>{item.location}</td>
                <td>{item.reason}</td>
                <td>{item.details || "—"}</td>
              </tr>
            ))}
          </DataTable>
        )}
      </Card>
    </div>
  );
}
