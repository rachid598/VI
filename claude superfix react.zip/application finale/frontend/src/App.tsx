import { useEffect, useRef, useState, type JSX } from "react";
import { api } from "./api/client";
import {
  refreshLoginSecurity,
  useAppState,
  type ViewKey,
} from "./state/appStore";
import { clearDeferredQueue, flushDeferredQueue, loadDeferredQueue } from "./state/deferredQueue";
import { pollSession } from "./state/sessionPoll";
import { useToast } from "./state/toast";
import { applyPwaUpdate, dismissPwaUpdate, usePwaState } from "./pwa/registerServiceWorker";
import { Layout } from "./components/Layout";
import { Button, LoadingView } from "./components/ui";
import { LoginScreen } from "./features/Login";
import { NotificationsDialog } from "./features/NotificationsDialog";
import { hasSeenOnboarding, OnboardingDialog } from "./features/OnboardingDialog";
import { NewObservation } from "./features/observation/NewObservation";
import { ValidationQueue } from "./features/validation/ValidationQueue";
import { DigitalPasses } from "./features/passes/DigitalPasses";
import { Dashboard } from "./features/dashboard/Dashboard";
import { AnonymousReport } from "./features/report/AnonymousReport";
import { StudentHistory } from "./features/history/StudentHistory";
import { Points } from "./features/points/Points";
import { PpReport } from "./features/pp/PpReport";
import { Admin } from "./features/admin/Admin";
import { About } from "./features/about/About";

function ToastHost() {
  const message = useToast();
  if (!message) return null;
  return (
    <div
      role="status"
      aria-live="polite"
      className="fixed inset-x-4 bottom-5 z-50 mx-auto w-fit max-w-[92vw] rounded-[var(--radius-card)] bg-institution-deep px-5 py-3 text-[13.5px] font-semibold text-white shadow-[var(--shadow-pop)]"
    >
      {message}
    </div>
  );
}

function UpdateNotice() {
  const { waitingWorker } = usePwaState();
  const [applying, setApplying] = useState(false);
  if (!waitingWorker) return null;
  return (
    <div
      role="status"
      className="fixed inset-x-4 top-4 z-50 mx-auto flex w-fit max-w-[92vw] items-center gap-3 rounded-[var(--radius-card)] border border-line bg-surface px-4 py-2.5 shadow-[var(--shadow-pop)]"
    >
      <span className="text-[13px] font-semibold">Une nouvelle version est prête.</span>
      <Button
        size="sm"
        variant="primary"
        loading={applying}
        onClick={() => {
          setApplying(true);
          applyPwaUpdate();
        }}
      >
        Actualiser
      </Button>
      <button
        type="button"
        aria-label="Masquer cette notification"
        onClick={dismissPwaUpdate}
        className="text-muted hover:text-ink"
      >
        ×
      </button>
    </div>
  );
}

const viewComponents: Record<ViewKey, () => JSX.Element> = {
  new: NewObservation,
  validation: ValidationQueue,
  passes: DigitalPasses,
  dashboard: Dashboard,
  report: AnonymousReport,
  history: StudentHistory,
  points: Points,
  pp: PpReport,
  admin: Admin,
  about: About,
};

export function App() {
  const { booted, session, view } = useAppState();
  const [notificationsOpen, setNotificationsOpen] = useState(false);
  const [onboarding, setOnboarding] = useState<{ open: boolean; manual: boolean }>({ open: false, manual: false });
  const onboardingShownFor = useRef<number | null>(null);

  useEffect(() => {
    void refreshLoginSecurity();
  }, []);

  // Reprise des envois différés au retour du réseau.
  useEffect(() => {
    const onOnline = () => void flushDeferredQueue();
    window.addEventListener("online", onOnline);
    return () => window.removeEventListener("online", onOnline);
  }, []);

  // Relève périodique des compteurs (60 s) tant qu'une session est ouverte.
  const authenticated = Boolean(session?.authenticated);
  useEffect(() => {
    if (!authenticated) return;
    void flushDeferredQueue();
    const interval = window.setInterval(() => void pollSession(), 60000);
    return () => window.clearInterval(interval);
  }, [authenticated]);

  // Guide de première connexion, une fois par utilisateur et par navigateur.
  useEffect(() => {
    if (!session?.authenticated || !session.user) return;
    if (onboardingShownFor.current === session.user.id) return;
    onboardingShownFor.current = session.user.id;
    if (!hasSeenOnboarding(session)) {
      setOnboarding({ open: true, manual: false });
    }
  }, [session]);

  async function handleLogout() {
    const pendingDeferred = loadDeferredQueue();
    if (pendingDeferred.length > 0) {
      const confirmed = window.confirm(
        `${pendingDeferred.length} envoi${pendingDeferred.length > 1 ? "s sont" : " est"} encore en attente.\n\n`
        + "Annulez pour rester connecté et réessayer. Si vous vous déconnectez, cette attente sera supprimée.",
      );
      if (!confirmed) return;
      clearDeferredQueue();
    }
    try {
      await api("logout", { method: "POST", body: {} });
    } catch {
      /* La session côté client est réinitialisée dans tous les cas. */
    } finally {
      window.location.reload();
    }
  }

  if (!booted) {
    return (
      <main className="flex min-h-dvh items-center justify-center bg-app">
        <LoadingView />
      </main>
    );
  }

  if (!session?.authenticated || !session.user) {
    return (
      <>
        <LoginScreen version={session?.app_version || ""} />
        <ToastHost />
        <UpdateNotice />
      </>
    );
  }

  const ViewComponent = viewComponents[view];

  return (
    <>
      <Layout
        session={session}
        onLogout={() => void handleLogout()}
        onOpenNotifications={() => setNotificationsOpen(true)}
        onOpenHelp={() => setOnboarding({ open: true, manual: true })}
      >
        <div key={view} className="view-enter">
          <ViewComponent />
        </div>
      </Layout>
      <NotificationsDialog open={notificationsOpen} onClose={() => setNotificationsOpen(false)} />
      <OnboardingDialog
        open={onboarding.open}
        manual={onboarding.manual}
        session={session}
        onClose={() => setOnboarding({ open: false, manual: false })}
      />
      <ToastHost />
      <UpdateNotice />
    </>
  );
}
