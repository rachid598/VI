import { useSyncExternalStore } from "react";

/** Toast unique, remplacé à chaque message — comportement historique. */

let currentToast = "";
let timer: number | null = null;
const listeners = new Set<() => void>();

function emit(): void {
  for (const listener of listeners) listener();
}

export function showToast(message: string): void {
  currentToast = message;
  emit();
  if (timer !== null) window.clearTimeout(timer);
  timer = window.setTimeout(() => {
    currentToast = "";
    timer = null;
    emit();
  }, 4200);
}

export function clearToast(): void {
  if (timer !== null) window.clearTimeout(timer);
  timer = null;
  currentToast = "";
  emit();
}

export function useToast(): string {
  return useSyncExternalStore(
    (listener) => {
      listeners.add(listener);
      return () => listeners.delete(listener);
    },
    () => currentToast,
  );
}
