import { api } from "../api/client";
import type { SessionData } from "../api/types";
import {
  getSession,
  patchSession,
  setCsrfToken,
  showLogin,
  synchroniseServerClock,
} from "./appStore";
import { flushDeferredQueue, loadDeferredQueue, maintainDeferredQueues } from "./deferredQueue";
import { showToast } from "./toast";

/**
 * Relève périodique de la session : compteurs de navigation, réglages de
 * modules, notification discrète quand un signalement personnel vient d'être
 * traité, et seconde voie de reprise des envois différés (certains mobiles
 * n'émettent pas l'événement « online »).
 */
export async function pollSession(): Promise<void> {
  const current = getSession();
  if (!current?.authenticated) return;
  const previousNotificationCount = Number(current.notification_count || 0);
  try {
    const data = await api<SessionData>("session");
    if (!data.authenticated) {
      showLogin();
      return;
    }
    setCsrfToken(data.csrf_token);
    synchroniseServerClock(data.server_now_utc);
    patchSession({
      alert_count: data.alert_count,
      pending_count: data.pending_count,
      notification_count: data.notification_count,
      points: data.points,
      digital_passes: data.digital_passes,
      deferred_submissions: data.deferred_submissions,
      installation_scope: data.installation_scope,
      permissions: data.permissions,
      environment: data.environment,
      school_year: data.school_year,
      app_version: data.app_version,
      server_now_utc: data.server_now_utc,
    });
    maintainDeferredQueues();
    if (loadDeferredQueue().length > 0) {
      void flushDeferredQueue();
    }
    if (Number(data.notification_count || 0) > previousNotificationCount) {
      showToast("Un de vos signalements vient d’être traité.");
    }
  } catch {
    /* Une nouvelle tentative silencieuse aura lieu au prochain intervalle. */
  }
}
