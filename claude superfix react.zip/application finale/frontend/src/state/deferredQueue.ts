import { useSyncExternalStore } from "react";
import { api } from "../api/client";
import type { SessionData } from "../api/types";
import {
  getSession,
  patchSession,
  refreshNavigationCounts,
  setCsrfToken,
  showLogin,
  synchroniseServerClock,
} from "./appStore";
import { showToast } from "./toast";

/**
 * Envoi différé des signalements — transposition exacte du module v2 :
 * - fonctionnalité désactivée par défaut, pilotée par l'administrateur ;
 * - file UNIQUEMENT en mémoire de page : rien n'est écrit dans le stockage
 *   persistant du navigateur, tout disparaît à l'actualisation ;
 * - isolation par installation, environnement et compte connecté ;
 * - 10 envois et 12 heures maximum ; clé d'envoi = aucun doublon technique ;
 * - un refus du serveur bloque l'entrée (jamais de renvoi forcé automatique).
 */

const DEFERRED_QUEUE_LIMIT = 10;
const DEFERRED_QUEUE_TTL_MS = 12 * 60 * 60 * 1000;
const DEFERRED_QUEUE_PREFIX = "suivi:deferred:v2:";
const UNSAFE_LEGACY_QUEUE_PREFIX = "suivi:offline-queue:v1:";

export interface DeferredBody {
  student_ids: number[];
  location: string;
  reason: string;
  details: string;
  occurred_offset_minutes: number;
  submission_key: string;
  [key: string]: unknown;
}

export interface DeferredEntry {
  body: DeferredBody;
  summary: string;
  captured_at: number;
  school_year: string;
  blocked: boolean;
  error: string;
}

let queueMemory: DeferredEntry[] = [];
let queueOwner = "";
let flushInProgress = false;
let queueVersion = 0;

const listeners = new Set<() => void>();

function emit(): void {
  queueVersion++;
  for (const listener of listeners) listener();
}

export function deferredFeatureEnabled(): boolean {
  return Boolean(getSession()?.deferred_submissions?.enabled);
}

function authenticatedSessionIdentity(value: SessionData | null): string {
  const userId = Number(value?.user?.id || 0);
  const uid = String(value?.user?.uid || "").trim().toLowerCase();
  return value?.authenticated && userId > 0 && uid ? `${userId}:${uid}` : "";
}

function deferredQueueKey(): string | null {
  const session = getSession();
  const scope = String(session?.installation_scope || "").toLowerCase();
  const environment = session?.environment === "production" ? "production" : "test";
  const userId = Number(session?.user?.id || 0);
  const uid = String(session?.user?.uid || "").trim().toLowerCase();
  if (!/^[a-f0-9]{32,64}$/.test(scope) || userId <= 0 || !uid) return null;
  return `${DEFERRED_QUEUE_PREFIX}${scope}:${environment}:${userId}:${encodeURIComponent(uid)}`;
}

/** Purge les files persistées par d'anciennes versions : plus jamais de
 *  données de signalement dans localStorage. */
export function discardUnsafeLegacyQueues(): void {
  try {
    for (let index = localStorage.length - 1; index >= 0; index--) {
      const key = localStorage.key(index);
      if (key && (key.startsWith(UNSAFE_LEGACY_QUEUE_PREFIX) || key.startsWith(DEFERRED_QUEUE_PREFIX))) {
        localStorage.removeItem(key);
      }
    }
  } catch {
    /* Le nettoyage d'une ancienne version ne doit jamais bloquer l'application. */
  }
}

function freshEntries(entries: DeferredEntry[]): DeferredEntry[] {
  if (!Array.isArray(entries)) return [];
  const now = Date.now();
  return entries.filter((entry) => {
    const capturedAt = Number(entry?.captured_at || 0);
    const age = now - capturedAt;
    return Boolean(entry)
      && typeof entry.body === "object" && entry.body !== null
      && typeof entry.body.submission_key === "string"
      && Array.isArray(entry.body.student_ids)
      && entry.body.student_ids.length >= 1
      && entry.body.student_ids.length <= 8
      && Number.isFinite(capturedAt)
      && age >= -5 * 60 * 1000
      && age < DEFERRED_QUEUE_TTL_MS;
  });
}

export function clearDeferredQueue(): void {
  queueMemory = [];
  queueOwner = "";
  emit();
}

/** À appeler à chaque changement de session : purge si le compte, l'année ou
 *  l'installation a changé. */
export function maintainDeferredQueues(): void {
  discardUnsafeLegacyQueues();
  const key = deferredQueueKey();
  if (!deferredFeatureEnabled() || !key || (queueOwner && queueOwner !== key)) {
    clearDeferredQueue();
    return;
  }
  queueOwner = key;
  queueMemory = freshEntries(queueMemory);
  emit();
}

export function loadDeferredQueue(): DeferredEntry[] {
  const key = deferredQueueKey();
  if (!key || !deferredFeatureEnabled()) {
    if (queueMemory.length > 0 || queueOwner !== "") clearDeferredQueue();
    return [];
  }
  if (queueOwner && queueOwner !== key) clearDeferredQueue();
  queueOwner = key;
  queueMemory = freshEntries(queueMemory);
  return queueMemory.slice();
}

function saveDeferredQueue(entries: DeferredEntry[]): boolean {
  const key = deferredQueueKey();
  if (!key || !deferredFeatureEnabled() || !Array.isArray(entries)) {
    clearDeferredQueue();
    return false;
  }
  if (queueOwner && queueOwner !== key) clearDeferredQueue();
  queueOwner = key;
  queueMemory = freshEntries(entries).slice(0, DEFERRED_QUEUE_LIMIT);
  emit();
  return queueMemory.length === entries.length;
}

export function enqueueDeferredObservation(body: DeferredBody, studentCount: number): boolean {
  if (!deferredFeatureEnabled()) return false;
  const entries = loadDeferredQueue();
  if (entries.length >= DEFERRED_QUEUE_LIMIT) return false;
  const count = Math.max(1, Number(studentCount) || 1);
  const safeBody = JSON.parse(JSON.stringify(body)) as DeferredBody;
  entries.push({
    body: safeBody,
    summary: `${count} ${count > 1 ? "élèves" : "élève"} — ${String(body.location || "Lieu non indiqué")}`,
    captured_at: Date.now(),
    school_year: String(getSession()?.school_year || ""),
    blocked: false,
    error: "",
  });
  return saveDeferredQueue(entries);
}

export function discardDeferredEntry(index: number): void {
  const entries = loadDeferredQueue();
  if (!entries[index]) return;
  entries.splice(index, 1);
  saveDeferredQueue(entries);
}

/** Exportée pour les tests : mêmes statuts « à réessayer » que la v2 historique. */
export function isDeferredRetryableStatus(status: number): boolean {
  return !status
    || status === 401
    || status === 408
    || status === 419
    || status === 425
    || status === 429
    || status >= 500;
}

/** Exportée pour les tests : jamais de reprise sous une autre identité. */
export async function refreshDeferredCsrf(): Promise<boolean> {
  const expectedIdentity = authenticatedSessionIdentity(getSession());
  try {
    const data = await api<SessionData>("session");
    if (!data.authenticated) {
      clearDeferredQueue();
      showLogin();
      return false;
    }
    if (!expectedIdentity || authenticatedSessionIdentity(data) !== expectedIdentity) {
      // Un autre compte s'est connecté dans un autre onglet : jamais de reprise
      // sous une identité différente.
      clearDeferredQueue();
      window.location.reload();
      return false;
    }
    setCsrfToken(data.csrf_token);
    synchroniseServerClock(data.server_now_utc);
    patchSession({
      deferred_submissions: data.deferred_submissions,
      alert_count: data.alert_count,
      pending_count: data.pending_count,
      notification_count: data.notification_count,
    });
    maintainDeferredQueues();
    return deferredFeatureEnabled();
  } catch {
    return false;
  }
}

export async function flushDeferredQueue(manual = false): Promise<void> {
  if (flushInProgress || !getSession()?.authenticated || !deferredFeatureEnabled()) return;
  const entries = loadDeferredQueue();
  if (entries.length === 0) return;
  flushInProgress = true;
  let sent = 0;
  let capped = false;
  let needsAttention = "";
  let csrfRefreshed = false;
  try {
    while (entries.length > 0) {
      const entry = entries[0];
      if (entry.blocked) {
        if (!manual) {
          needsAttention = String(entry.error || "Cet envoi doit être vérifié.");
          break;
        }
        entry.blocked = false;
        entry.error = "";
        saveDeferredQueue(entries);
      }
      if (String(entry.school_year || "") !== String(getSession()?.school_year || "")) {
        entry.blocked = true;
        entry.error = "L’année scolaire a changé : cet envoi ne sera pas transmis automatiquement.";
        saveDeferredQueue(entries);
        needsAttention = entry.error;
        break;
      }
      const elapsedMinutes = Math.max(0, Math.round(
        (Date.now() - Number(entry.captured_at || Date.now())) / 60000,
      ));
      const originalOffset = Number(entry.body.occurred_offset_minutes || 0);
      const adjustedOffset = Math.min(20, Math.max(0, originalOffset + elapsedMinutes));
      try {
        await api("observations", {
          method: "POST",
          body: { ...entry.body, occurred_offset_minutes: adjustedOffset },
        });
        sent++;
        if (originalOffset + elapsedMinutes > 20) capped = true;
        entries.shift();
        saveDeferredQueue(entries);
      } catch (error) {
        const status = error instanceof Error && "status" in error ? Number((error as { status: unknown }).status || 0) : 0;
        if (status === 419 && !csrfRefreshed && await refreshDeferredCsrf()) {
          csrfRefreshed = true;
          continue;
        }
        if (isDeferredRetryableStatus(status)) break;
        entry.blocked = true;
        entry.error = error instanceof Error && error.message ? error.message : "Le serveur a refusé cet envoi.";
        saveDeferredQueue(entries);
        needsAttention = entry.error;
        break;
      }
    }
  } finally {
    flushInProgress = false;
  }
  emit();
  if (sent > 0) {
    showToast(`${sent > 1 ? `${sent} envois différés transmis` : "Envoi différé transmis"}.${capped ? " Heure plafonnée à 20 minutes en arrière." : ""}`);
  } else if (needsAttention) {
    showToast(`Un envoi différé demande votre attention : ${needsAttention}`);
  } else if (manual) {
    showToast("Le serveur reste inaccessible. L’envoi différé est conservé.");
  }
  if (sent > 0) void refreshNavigationCounts();
}

export function useDeferredQueue(): DeferredEntry[] {
  useSyncExternalStore(
    (listener) => {
      listeners.add(listener);
      return () => listeners.delete(listener);
    },
    () => queueVersion,
  );
  return loadDeferredQueue();
}
