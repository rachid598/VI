import { useSyncExternalStore } from "react";
import { api, bindApiClient } from "../api/client";
import type { SessionData } from "../api/types";

/**
 * Magasin d'état central, volontairement minimal (pas de bibliothèque) :
 * session, jeton CSRF, vue courante, horloge serveur et thème.
 * L'« epoch » de session neutralise les réponses arrivées après une
 * déconnexion, comme dans la version historique.
 */

export type ViewKey =
  | "new" | "validation" | "passes" | "dashboard" | "report"
  | "history" | "points" | "pp" | "admin" | "about";

export const viewDefinitions: Record<ViewKey, { label: string; icon: string }> = {
  new: { label: "Nouvelle observation", icon: "+" },
  validation: { label: "À vérifier", icon: "✓" },
  passes: { label: "Billets numériques", icon: "↗" },
  dashboard: { label: "Tableau de bord", icon: "▥" },
  report: { label: "Bilan hebdomadaire", icon: "▤" },
  history: { label: "Historique élève", icon: "⌕" },
  points: { label: "Permis à points", icon: "◎" },
  pp: { label: "Bilan de ma classe", icon: "◇" },
  admin: { label: "Administration", icon: "⚙" },
  about: { label: "Cadre du pilote", icon: "i" },
};

interface AppState {
  booted: boolean;
  session: SessionData | null;
  view: ViewKey;
  loginNotice: string;
}

let state: AppState = { booted: false, session: null, view: "new", loginNotice: "" };
let csrfToken = "";
let sessionEpoch = 0;
let serverClockBaseUtcMs = Number.NaN;
let serverClockBaseMonotonicMs = 0;

const listeners = new Set<() => void>();

function emit(): void {
  for (const listener of listeners) listener();
}

function setState(patch: Partial<AppState>): void {
  state = { ...state, ...patch };
  emit();
}

export function getCsrfToken(): string {
  return csrfToken;
}

export function setCsrfToken(token: string): void {
  csrfToken = token;
}

export function getSession(): SessionData | null {
  return state.session;
}

export function synchroniseServerClock(value: string): void {
  const parsed = new Date(String(value || "").replace(" ", "T") + "Z");
  if (Number.isNaN(parsed.getTime())) return;
  serverClockBaseUtcMs = parsed.getTime();
  serverClockBaseMonotonicMs = performance.now();
}

export function estimatedServerNow(): Date | null {
  if (!Number.isFinite(serverClockBaseUtcMs)) return null;
  return new Date(serverClockBaseUtcMs + Math.max(0, performance.now() - serverClockBaseMonotonicMs));
}

export function availableViews(session: SessionData): ViewKey[] {
  const permissions = session.permissions || {};
  const list: ViewKey[] = [];
  if (permissions.can_submit) list.push("new");
  if (permissions.can_validate) list.push("validation");
  if (permissions.can_digital_pass) list.push("passes");
  if (permissions.can_dashboard) list.push("dashboard");
  if (permissions.can_anonymous_report) list.push("report");
  if (permissions.can_history) list.push("history");
  if (permissions.can_points) list.push("points");
  if (permissions.can_pp) list.push("pp");
  if (permissions.can_admin) list.push("admin");
  list.push("about");
  return list;
}

export function applySession(next: SessionData): void {
  csrfToken = next.csrf_token || csrfToken;
  synchroniseServerClock(next.server_now_utc);
  const previous = state.session;
  let view = state.view;
  if (next.authenticated) {
    const views = availableViews(next);
    if (!previous?.authenticated || !views.includes(view)) view = views[0];
  }
  setState({ booted: true, session: next, view, loginNotice: "" });
}

/** Mise à jour partielle (compteurs, réglages de modules…) sans toucher à la vue. */
export function patchSession(patch: Partial<SessionData>): void {
  if (!state.session) return;
  setState({ session: { ...state.session, ...patch } });
}

export function showLogin(notice = "Votre session a expiré. Reconnectez-vous."): void {
  sessionEpoch++;
  csrfToken = "";
  const previous = state.session;
  setState({
    booted: true,
    view: "new",
    loginNotice: previous?.authenticated ? notice : state.loginNotice,
    session: previous
      ? { ...previous, authenticated: false, user: null, permissions: {}, alert_count: null, pending_count: null, notification_count: null }
      : null,
  });
  void refreshLoginSecurity();
}

export async function refreshLoginSecurity(): Promise<boolean> {
  try {
    const data = await api<SessionData>("session");
    csrfToken = data.csrf_token;
    synchroniseServerClock(data.server_now_utc);
    if (data.authenticated) {
      applySession(data);
    } else {
      setState({ booted: true, session: { ...data, authenticated: false } });
    }
    return true;
  } catch (error) {
    setState({
      booted: true,
      loginNotice: error instanceof Error ? error.message : "Connexion au serveur impossible.",
    });
    return false;
  }
}

export function setView(view: ViewKey): void {
  setState({ view });
}

export function setLoginNotice(notice: string): void {
  setState({ loginNotice: notice });
}

export async function refreshNavigationCounts(): Promise<void> {
  const current = state.session;
  if (!current?.authenticated) return;
  try {
    const data = await api<SessionData>("session");
    if (!data.authenticated) {
      showLogin();
      return;
    }
    csrfToken = data.csrf_token;
    synchroniseServerClock(data.server_now_utc);
    patchSession({
      alert_count: data.alert_count,
      pending_count: data.pending_count,
      notification_count: data.notification_count,
      deferred_submissions: data.deferred_submissions,
      points: data.points,
      digital_passes: data.digital_passes,
      permissions: data.permissions,
      school_year: data.school_year,
    });
  } catch {
    /* Rafraîchissement silencieux : la prochaine action réessaiera. */
  }
}

bindApiClient({
  getCsrfToken: () => csrfToken,
  getSessionEpoch: () => sessionEpoch,
  onUnauthorized: () => showLogin(),
});

export function subscribeApp(listener: () => void): () => void {
  listeners.add(listener);
  return () => listeners.delete(listener);
}

export function useAppState(): AppState {
  return useSyncExternalStore(subscribeApp, () => state);
}

/* ——— Thème clair/sombre (préférence conservée dans le navigateur) ——— */

const THEME_STORAGE_KEY = "suivi:theme";

export function applyTheme(theme: "light" | "dark", persist: boolean): void {
  document.documentElement.dataset.theme = theme;
  const meta = document.querySelector<HTMLMetaElement>("#theme-color");
  if (meta) meta.content = theme === "dark" ? "#0b1519" : "#102f3a";
  if (persist) {
    try {
      window.localStorage.setItem(THEME_STORAGE_KEY, theme);
    } catch {
      /* préférence non persistée */
    }
  }
  emit();
}

export function initialiseTheme(): void {
  let saved: string | null = null;
  try {
    saved = window.localStorage.getItem(THEME_STORAGE_KEY);
  } catch {
    saved = null;
  }
  const theme = saved === "dark" || saved === "light"
    ? saved
    : (window.matchMedia("(prefers-color-scheme: dark)").matches ? "dark" : "light");
  applyTheme(theme, false);
}

export function currentTheme(): "light" | "dark" {
  return document.documentElement.dataset.theme === "dark" ? "dark" : "light";
}
