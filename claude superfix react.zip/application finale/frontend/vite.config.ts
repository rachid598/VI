import { defineConfig } from "vite";
import react from "@vitejs/plugin-react";
import tailwindcss from "@tailwindcss/vite";
import { readFileSync } from "node:fs";

// La version applicative vient du fichier VERSION du dossier parent : une seule
// source de vérité, partagée avec le backend PHP et le service worker.
const appVersion = readFileSync(new URL("../VERSION", import.meta.url), "utf8").trim();

export default defineConfig({
  // Chemins relatifs : l'application fonctionne sous /suivi2/ comme sous /suivi/.
  base: "./",
  plugins: [react(), tailwindcss()],
  define: {
    __APP_VERSION__: JSON.stringify(appVersion),
  },
  server: {
    // En développement local, l'API PHP reste servie par le serveur Kwartz (ou
    // un PHP local) : adapter la cible si besoin.
    proxy: {
      "/api.php": {
        target: "http://127.0.0.1:8080",
        changeOrigin: true,
      },
    },
  },
  build: {
    target: "es2020",
    outDir: "dist",
    assetsDir: "assets",
    sourcemap: false,
    // La CSP du serveur impose script-src 'self' : le build n'émet aucun
    // script ni style inline (comportement par défaut de Vite, sans plugin
    // legacy). Ne jamais ajouter @vitejs/plugin-legacy sans revoir la CSP.
    modulePreload: { polyfill: true },
  },
});
