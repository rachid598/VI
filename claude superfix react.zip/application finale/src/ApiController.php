<?php

declare(strict_types=1);

final class ApiController
{
    private const SUBMIT_ROLES = ['teacher', 'aed', 'cpe', 'direction', 'pp', 'service', 'admin'];
    private const VALIDATE_ROLES = ['aed', 'cpe', 'direction', 'admin'];
    private const DASHBOARD_ROLES = ['cpe', 'direction', 'admin'];
    private const ROLES = ['teacher', 'aed', 'cpe', 'direction', 'pp', 'service', 'admin'];
    private const LOCATIONS = [
        'Rez-de-chaussée',
        '1er étage',
        '2e étage',
        'Escaliers',
        'Abords de l’infirmerie',
        'Autre',
    ];
    private const REASONS = [
        'Circulation sans billet',
        'Présence prolongée',
        'Déplacement incohérent avec le billet',
        'Autre situation à vérifier',
    ];
    private const CANCELLATION_REASONS = [
        'Billet ou autorisation retrouvé',
        'Déplacement confirmé comme justifié',
        'Erreur d’élève',
        'Doublon',
        'Signalement non retenu après vérification',
    ];
    private const DIGITAL_PASS_DESTINATIONS = [
        'Vie scolaire',
        'Infirmerie',
        'Administration',
        'Salle indiquée',
        'Service médico-social',
        'Autre déplacement autorisé',
    ];
    private const DIGITAL_PASS_DURATIONS = [5, 10, 15, 20, 30, 45, 60];
    private const RECOVERY_LOCKED_ACTIONS = [
        'observations',
        'update_own_observation',
        'withdraw_own_observation',
        'observation_status',
        'observation_sequence',
        'observation_claim',
        'digital_pass_issue',
        'digital_pass_revoke',
        'points_restore',
        'points_action_done',
        'admin_set_school_year',
        'admin_set_digital_passes_enabled',
        'import_students',
    ];
    private const RECOVERY_SELF_MANAGED_ACTIONS = [
        'session',
        'login',
        'logout',
        'recovery_status',
        'admin_create_snapshot',
        'admin_purge_students',
        'admin_restore_snapshot',
        'admin_close_year',
    ];

    /** @var Database */
    private $database;
    /** @var AuthService */
    private $auth;
    /** @var array */
    private $config;
    /** @var LdapAuthenticator|null */
    private $ldap;
    /** @var RecoveryService|null */
    private $recovery;
    /** @var DigitalPassService */
    private $digitalPasses;
    /** @var FinalAdminService */
    private $finalAdmin;
    /** @var bool|null */
    private $pointsEnabledCache;
    /** @var bool|null */
    private $digitalPassesEnabledCache;
    /** @var bool|null */
    private $deferredSubmissionsEnabledCache;

    public function __construct(
        Database $database,
        AuthService $auth,
        array $config,
        ?LdapAuthenticator $ldap = null,
        ?RecoveryService $recovery = null,
        ?DigitalPassService $digitalPasses = null,
        ?FinalAdminService $finalAdmin = null
    )
    {
        $this->database = $database;
        $this->auth = $auth;
        $this->config = $config;
        $this->ldap = $ldap;
        $this->recovery = $recovery;
        $this->digitalPasses = $digitalPasses !== null
            ? $digitalPasses
            : new DigitalPassService($database->pdo());
        $this->finalAdmin = $finalAdmin !== null
            ? $finalAdmin
            : new FinalAdminService($database->pdo());
    }

    public function dispatch(string $action): void
    {
        if ($this->recovery !== null
            && !in_array($action, self::RECOVERY_SELF_MANAGED_ACTIONS, true)
            && $this->auth->user() !== null) {
            $this->tryCreateAutomaticRecovery();
        }
        if ($this->recovery !== null && in_array($action, self::RECOVERY_LOCKED_ACTIONS, true)) {
            // Refuser une requête anonyme ou sans jeton avant d’attendre le
            // verrou global : sinon elle pourrait ralentir les vraies saisies.
            requireMethod('POST');
            $this->auth->requireUser();
            requireCsrf($this->auth);
            $this->recovery->acquireMutationLock(5);
        }
        switch ($action) {
            case 'session':
                $this->session();
                return;
            case 'login':
                $this->login();
                return;
            case 'logout':
                $this->logout();
                return;
            case 'students':
                $this->students();
                return;
            case 'observations':
                $this->createObservation();
                return;
            case 'update_own_observation':
                $this->updateOwnObservation();
                return;
            case 'withdraw_own_observation':
                $this->withdrawOwnObservation();
                return;
            case 'my_observations':
                $this->myObservations();
                return;
            case 'notifications':
                $this->notifications();
                return;
            case 'notifications_read':
                $this->notificationsRead();
                return;
            case 'pending_observations':
                $this->pendingObservations();
                return;
            case 'observation_status':
                $this->updateObservationStatus();
                return;
            case 'observation_sequence':
                $this->updateObservationSequence();
                return;
            case 'observation_claim':
                $this->observationClaim();
                return;
            case 'digital_passes':
                $this->digitalPassesList();
                return;
            case 'digital_pass_issue':
                $this->digitalPassIssue();
                return;
            case 'digital_pass_revoke':
                $this->digitalPassRevoke();
                return;
            case 'dashboard':
                $this->dashboard();
                return;
            case 'student_history':
                $this->studentHistory();
                return;
            case 'points':
                $this->points();
                return;
            case 'points_detail':
                $this->pointsDetail();
                return;
            case 'points_export':
                $this->pointsExport();
                return;
            case 'points_restore':
                $this->pointsRestore();
                return;
            case 'points_action_done':
                $this->pointsActionDone();
                return;
            case 'pp_report':
                $this->ppReport();
                return;
            case 'admin_users':
                $this->adminUsers();
                return;
            case 'admin_update_user':
                $this->adminUpdateUser();
                return;
            case 'admin_add_authorized_user':
                $this->adminAddAuthorizedUser();
                return;
            case 'admin_remove_authorized_user':
                $this->adminRemoveAuthorizedUser();
                return;
            case 'admin_set_school_year':
                $this->adminSetSchoolYear();
                return;
            case 'admin_set_points_enabled':
                $this->adminSetPointsEnabled();
                return;
            case 'admin_set_digital_passes_enabled':
                $this->adminSetDigitalPassesEnabled();
                return;
            case 'admin_set_deferred_submissions_enabled':
                $this->adminSetDeferredSubmissionsEnabled();
                return;
            case 'anonymous_report':
                $this->anonymousReport();
                return;
            case 'admin_health':
                $this->adminHealth();
                return;
            case 'admin_year_closure_preview':
                $this->adminYearClosurePreview();
                return;
            case 'admin_close_year':
                $this->adminCloseYear();
                return;
            case 'recovery_status':
                $this->recoveryStatus();
                return;
            case 'admin_create_snapshot':
                $this->adminCreateSnapshot();
                return;
            case 'admin_purge_students':
                $this->adminPurgeStudents();
                return;
            case 'admin_restore_snapshot':
                $this->adminRestoreSnapshot();
                return;
            case 'audit_logs':
                $this->auditLogs();
                return;
            case 'import_students':
                $this->importStudents();
                return;
            case 'admin_sync_students':
                $this->adminSyncStudents();
                return;
            default:
                throw new HttpException(404, 'Action inconnue.');
        }
    }

    private function session(): void
    {
        requireMethod('GET');
        $user = $this->auth->user();
        if ($user !== null) {
            $this->tryCreateAutomaticRecovery();
        }
        $serverNowUtc = (string) $this->database->pdo()
            ->query('SELECT UTC_TIMESTAMP()')
            ->fetchColumn();
        jsonResponse([
            'authenticated' => $user !== null,
            'app_version' => defined('SC_APP_VERSION') ? SC_APP_VERSION : '0.0.0-dev',
            'server_now_utc' => $serverNowUtc,
            'csrf_token' => $this->auth->csrfToken(),
            'user' => $user,
            'permissions' => $user !== null ? $this->permissions($user) : [],
            'environment' => isset($this->config['app']['environment'])
                ? (string) $this->config['app']['environment']
                : 'test',
            'installation_scope' => isset($this->config['app']['installation_scope_hash'])
                ? (string) $this->config['app']['installation_scope_hash']
                : '',
            'school_year' => (string) $this->config['app']['school_year'],
            'locations' => self::LOCATIONS,
            'reasons' => self::REASONS,
            'cancellation_reasons' => self::CANCELLATION_REASONS,
            'points' => $this->pointsConfig(),
            'digital_passes' => [
                'enabled' => $this->digitalPassesEnabled(),
                'destinations' => self::DIGITAL_PASS_DESTINATIONS,
                'durations' => self::DIGITAL_PASS_DURATIONS,
            ],
            'deferred_submissions' => [
                'enabled' => $this->deferredSubmissionsEnabled(),
                'limit' => 10,
                'ttl_hours' => 12,
            ],
            'alert_count' => $this->alertCount($user),
            'pending_count' => $this->pendingCount($user),
            'notification_count' => $this->notificationCount($user),
        ]);
    }

    private function login(): void
    {
        requireMethod('POST');
        requireCsrf($this->auth);
        $input = jsonInput();
        $username = isset($input['username']) ? (string) $input['username'] : '';
        $password = isset($input['password']) ? (string) $input['password'] : '';
        $user = $this->auth->login($username, $password);
        auditLog($this->database, (int) $user['id'], 'auth.login', 'user', (int) $user['id']);
        jsonResponse([
            'ok' => true,
            'csrf_token' => $this->auth->csrfToken(),
            'user' => $user,
            'permissions' => $this->permissions($user),
            'alert_count' => $this->alertCount($user),
            'pending_count' => $this->pendingCount($user),
            'notification_count' => $this->notificationCount($user),
        ]);
    }

    private function logout(): void
    {
        requireMethod('POST');
        $user = $this->auth->requireUser();
        requireCsrf($this->auth);
        auditLog($this->database, (int) $user['id'], 'auth.logout', 'user', (int) $user['id']);
        $this->auth->logout();
        jsonResponse(['ok' => true]);
    }

    private function students(): void
    {
        requireMethod('GET');
        $user = $this->auth->requireUser();
        $query = trim(isset($_GET['q']) ? (string) $_GET['q'] : '');
        if ($this->length($query) < 2) {
            jsonResponse(['students' => []]);
        }
        $like = '%' . $query . '%';
        $statement = $this->database->pdo()->prepare(
            "SELECT id, first_name, last_name, class_name
             FROM students
             WHERE school_year = :school_year AND active = 1
             AND (last_name LIKE :last_name OR first_name LIKE :first_name
                  OR CONCAT(first_name, ' ', last_name) LIKE :full_name
                  OR class_name LIKE :class_name)
             ORDER BY last_name, first_name, class_name
             LIMIT 12"
        );
        $statement->execute([
            'school_year' => $this->config['app']['school_year'],
            'last_name' => $like,
            'first_name' => $like,
            'full_name' => $like,
            'class_name' => $like,
        ]);
        $students = array_map([$this, 'studentOutput'], $statement->fetchAll());
        if ($this->digitalPassesEnabled()) {
            $canViewPassDetails = in_array((string) $user['role'], self::VALIDATE_ROLES, true);
            foreach ($students as &$student) {
                $activePass = $this->digitalPasses->activeForStudent(
                    (int) $student['id'],
                    (string) $this->config['app']['school_year']
                );
                if ($activePass === null) {
                    $student['active_pass'] = null;
                } elseif ($canViewPassDetails) {
                    $student['active_pass'] = [
                        'active' => true,
                        'id' => (int) $activePass['id'],
                        'destination' => (string) $activePass['destination'],
                        'expires_at' => (string) $activePass['expires_at'],
                    ];
                } else {
                    // La recherche signale seulement qu'un billet existe. Son
                    // trajet et sa durée restent réservés à la vie scolaire.
                    $student['active_pass'] = ['active' => true];
                }
            }
            unset($student);
        }
        jsonResponse(['students' => $students]);
    }

    private function createObservation(): void
    {
        requireMethod('POST');
        $user = $this->auth->requireRoles(self::SUBMIT_ROLES);
        requireCsrf($this->auth);
        $input = jsonInput();
        $studentIds = [];
        if (isset($input['student_ids']) && is_array($input['student_ids'])) {
            foreach ($input['student_ids'] as $value) {
                $studentIds[] = (int) $value;
            }
        } elseif (isset($input['student_id'])) {
            $studentIds[] = (int) $input['student_id'];
        }
        $studentIds = array_values(array_unique(array_filter($studentIds, static function (int $id): bool {
            return $id > 0;
        })));
        sort($studentIds, SORT_NUMERIC);
        $location = trim(isset($input['location']) ? (string) $input['location'] : '');
        $reason = trim(isset($input['reason']) ? (string) $input['reason'] : '');
        $details = trim(isset($input['details']) ? (string) $input['details'] : '');
        $allowDuplicate = !empty($input['allow_duplicate']);
        $submissionKey = trim(isset($input['submission_key']) ? (string) $input['submission_key'] : '');
        $occurredOffsetInput = $input['occurred_offset_minutes'] ?? 0;
        $occurredOffsetMinutes = (!is_bool($occurredOffsetInput) && !is_array($occurredOffsetInput))
            ? filter_var(
                $occurredOffsetInput,
                FILTER_VALIDATE_INT,
                ['options' => ['min_range' => 0, 'max_range' => 20]]
            )
            : false;

        if (count($studentIds) === 0 || !in_array($location, self::LOCATIONS, true) || !in_array($reason, self::REASONS, true)) {
            throw new HttpException(422, 'Élève(s), lieu ou motif invalide.');
        }
        if (count($studentIds) > 8) {
            throw new HttpException(422, 'Huit élèves maximum par signalement groupé.');
        }
        if ($occurredOffsetMinutes === false) {
            throw new HttpException(422, 'Heure du constat invalide.');
        }
        $occurredOffsetMinutes = (int) $occurredOffsetMinutes;
        if ($this->length($details) > (int) $this->config['security']['details_max_length']) {
            throw new HttpException(422, 'Le détail est trop long.');
        }
        if ($submissionKey !== '' && !preg_match('/^[a-zA-Z0-9_-]{16,64}$/D', $submissionKey)) {
            throw new HttpException(422, 'Identifiant d’envoi invalide. Rechargez le formulaire.');
        }

        if ($submissionKey !== '') {
            $existingSubmission = $this->existingObservationSubmission((int) $user['id'], $submissionKey);
            if ($existingSubmission !== null) {
                jsonResponse($existingSubmission + ['ok' => true, 'idempotent' => true]);
            }
        }

        $students = [];
        foreach ($studentIds as $studentId) {
            $students[$studentId] = $this->activeStudent($studentId);
        }

        // L'heure vient de MySQL sur le serveur Kwartz, jamais de l'appareil
        // du collègue. Le formulaire permet seulement un recul borné à 20 min.
        $databaseNow = (string) $this->database->pdo()->query('SELECT UTC_TIMESTAMP()')->fetchColumn();
        try {
            $occurredDate = (new DateTimeImmutable($databaseNow, new DateTimeZone('UTC')))
                ->modify('-' . $occurredOffsetMinutes . ' minutes');
        } catch (Exception $error) {
            throw new RuntimeException('Horloge du serveur invalide.', 0, $error);
        }
        $occurredAt = $occurredDate->format('Y-m-d H:i:s');
        $duplicateWindowStart = $occurredDate->modify('-2 minutes')->format('Y-m-d H:i:s');
        $duplicateWindowEnd = $occurredDate->modify('+2 minutes')->format('Y-m-d H:i:s');
        $placeholders = implode(', ', array_fill(0, count($studentIds), '?'));
        $duplicate = $this->database->pdo()->prepare(
            "SELECT student_id, occurred_at, location, reason FROM observations
             WHERE student_id IN ($placeholders)
               AND reporter_user_id = ?
               AND location = ?
               AND reason = ?
               AND status IN ('pending', 'confirmed')
               AND occurred_at BETWEEN ? AND ?
             ORDER BY occurred_at DESC, id DESC"
        );
        $duplicate->execute(array_merge(
            $studentIds,
            [(int) $user['id'], $location, $reason, $duplicateWindowStart, $duplicateWindowEnd]
        ));
        $recentByStudent = [];
        foreach ($duplicate->fetchAll() as $recent) {
            $recentStudentId = (int) $recent['student_id'];
            if (!isset($recentByStudent[$recentStudentId])) {
                $recentByStudent[$recentStudentId] = $recent;
            }
        }
        if (count($recentByStudent) > 0 && !$allowDuplicate) {
            $descriptions = [];
            foreach ($recentByStudent as $recentStudentId => $recent) {
                if (!isset($students[$recentStudentId])) {
                    continue;
                }
                $student = $students[$recentStudentId];
                $descriptions[] = $student['first_name'] . ' ' . $student['last_name']
                    . ' (' . $student['class_name'] . ') — ' . $recent['reason'] . ', ' . $recent['location'];
            }
            jsonResponse([
                'error' => (count($descriptions) > 1
                    ? 'Vous avez déjà envoyé le même constat dans les deux dernières minutes pour ces élèves : '
                    : 'Vous avez déjà envoyé le même constat dans les deux dernières minutes pour cet élève : ')
                    . implode(' ; ', $descriptions)
                    . '. Confirmez uniquement s’il s’agit bien d’un nouveau fait distinct.',
                'code' => 'possible_duplicate',
            ], 409);
        }

        $observationIds = [];
        try {
            $this->database->transaction(function (PDO $pdo) use (
            $studentIds,
            $students,
            $user,
            $location,
            $reason,
            $details,
            $occurredAt,
            $occurredOffsetMinutes,
            $submissionKey,
            &$observationIds
            ): void {
            $statement = $pdo->prepare(
                'INSERT INTO observations
                 (student_id, reporter_user_id, occurred_at, location, reason, details, submission_key,
                  digital_pass_destination, digital_pass_issued_at, digital_pass_expires_at)
                 VALUES (:student_id, :reporter_id, :occurred_at, :location, :reason, :details, :submission_key,
                         :digital_pass_destination, :digital_pass_issued_at, :digital_pass_expires_at)'
            );
            foreach ($studentIds as $studentId) {
                $passContext = $this->digitalPassContextAt($pdo, $studentId, $occurredAt);
                $statement->execute([
                    'student_id' => $studentId,
                    'reporter_id' => $user['id'],
                    'occurred_at' => $occurredAt,
                    'location' => $location,
                    'reason' => $reason,
                    'details' => $details,
                    'submission_key' => $submissionKey !== '' ? $submissionKey : null,
                    'digital_pass_destination' => $passContext['destination'] ?? null,
                    'digital_pass_issued_at' => $passContext['issued_at'] ?? null,
                    'digital_pass_expires_at' => $passContext['expires_at'] ?? null,
                ]);
                $observationId = (int) $pdo->lastInsertId();
                $observationIds[] = $observationId;
                auditLog($this->database, (int) $user['id'], 'observation.create', 'observation', $observationId, [
                    'student_id' => $studentId,
                    'class_name' => $students[$studentId]['class_name'],
                    'group_size' => count($studentIds),
                    'occurred_offset_minutes' => $occurredOffsetMinutes,
                ], $pdo);
            }
            });
        } catch (PDOException $error) {
            // Deux requêtes identiques peuvent arriver ensemble après un
            // réseau mobile instable. L'index unique laisse une seule écriture
            // gagner ; l'autre reçoit le résultat déjà enregistré.
            if ($submissionKey !== '' && (string) $error->getCode() === '23000') {
                $existingSubmission = $this->existingObservationSubmission(
                    (int) $user['id'],
                    $submissionKey
                );
                if ($existingSubmission !== null) {
                    jsonResponse($existingSubmission + ['ok' => true, 'idempotent' => true]);
                }
            }
            throw $error;
        }
        jsonResponse([
            'ok' => true,
            'created' => count($observationIds),
            'observation_id' => $observationIds[0],
            'observation_ids' => $observationIds,
        ], 201);
    }

    /** @return array<string,mixed>|null */
    private function existingObservationSubmission(int $reporterUserId, string $submissionKey): ?array
    {
        $statement = $this->database->pdo()->prepare(
            'SELECT id FROM observations
             WHERE reporter_user_id = :reporter_user_id
               AND submission_key = :submission_key
             ORDER BY id ASC'
        );
        $statement->execute([
            'reporter_user_id' => $reporterUserId,
            'submission_key' => $submissionKey,
        ]);
        $ids = array_map('intval', array_column($statement->fetchAll(), 'id'));
        if (count($ids) === 0) {
            return null;
        }
        return [
            'created' => count($ids),
            'observation_id' => $ids[0],
            'observation_ids' => $ids,
        ];
    }

    private function updateOwnObservation(): void
    {
        requireMethod('POST');
        $user = $this->auth->requireRoles(self::SUBMIT_ROLES);
        requireCsrf($this->auth);
        $input = jsonInput();
        $id = isset($input['id']) ? (int) $input['id'] : 0;
        $studentId = isset($input['student_id']) ? (int) $input['student_id'] : 0;
        $location = trim(isset($input['location']) ? (string) $input['location'] : '');
        $reason = trim(isset($input['reason']) ? (string) $input['reason'] : '');
        $details = trim(isset($input['details']) ? (string) $input['details'] : '');
        if ($id <= 0 || $studentId <= 0 || !in_array($location, self::LOCATIONS, true) || !in_array($reason, self::REASONS, true)) {
            throw new HttpException(422, 'Signalement, élève, lieu ou motif invalide.');
        }
        if ($this->length($details) > (int) $this->config['security']['details_max_length']) {
            throw new HttpException(422, 'Le détail est trop long.');
        }
        $this->activeStudent($studentId);
        $this->database->transaction(function (PDO $pdo) use ($id, $studentId, $location, $reason, $details, $user): void {
            $lookup = $pdo->prepare(
                'SELECT reporter_user_id, student_id, occurred_at, status, sequence_key,
                        claimed_by_user_id, claim_expires_at,
                        digital_pass_destination, digital_pass_issued_at, digital_pass_expires_at
                 FROM observations WHERE id = :id FOR UPDATE'
            );
            $lookup->execute(['id' => $id]);
            $observation = $lookup->fetch();
            if (!$observation) {
                throw new HttpException(404, 'Signalement introuvable.');
            }
            if ((int) $observation['reporter_user_id'] !== (int) $user['id']) {
                throw new HttpException(403, 'Vous ne pouvez modifier que vos propres signalements.');
            }
            if ((string) $observation['status'] !== 'pending') {
                throw new HttpException(409, 'Ce signalement a déjà été traité et ne peut plus être modifié.');
            }
            $this->assertClaimAvailable($observation, $user);
            if ($observation['sequence_key'] !== null
                && (int) $observation['student_id'] !== $studentId) {
                throw new HttpException(409, 'Dissociez d’abord ce signalement de sa séquence avant de changer d’élève.');
            }
            $passContext = null;
            $sameStudent = (int) $observation['student_id'] === $studentId;
            if ($sameStudent
                && $observation['digital_pass_destination'] !== null
                && $observation['digital_pass_issued_at'] !== null
                && $observation['digital_pass_expires_at'] !== null) {
                $passContext = [
                    'destination' => (string) $observation['digital_pass_destination'],
                    'issued_at' => (string) $observation['digital_pass_issued_at'],
                    'expires_at' => (string) $observation['digital_pass_expires_at'],
                ];
            } else {
                $passContext = $this->digitalPassContextAt(
                    $pdo,
                    $studentId,
                    (string) $observation['occurred_at']
                );
            }
            $update = $pdo->prepare(
                'UPDATE observations
                 SET student_id = :student_id, location = :location, reason = :reason, details = :details,
                     digital_pass_destination = :digital_pass_destination,
                     digital_pass_issued_at = :digital_pass_issued_at,
                     digital_pass_expires_at = :digital_pass_expires_at
                 WHERE id = :id'
            );
            $update->execute([
                'student_id' => $studentId,
                'location' => $location,
                'reason' => $reason,
                'details' => $details,
                'digital_pass_destination' => $passContext['destination'] ?? null,
                'digital_pass_issued_at' => $passContext['issued_at'] ?? null,
                'digital_pass_expires_at' => $passContext['expires_at'] ?? null,
                'id' => $id,
            ]);
            auditLog($this->database, (int) $user['id'], 'observation.update', 'observation', $id, [
                'student_id' => $studentId,
            ], $pdo);
        });
        jsonResponse(['ok' => true]);
    }

    private function withdrawOwnObservation(): void
    {
        requireMethod('POST');
        $user = $this->auth->requireRoles(self::SUBMIT_ROLES);
        requireCsrf($this->auth);
        $input = jsonInput();
        $id = isset($input['id']) ? (int) $input['id'] : 0;
        if ($id <= 0) {
            throw new HttpException(422, 'Signalement invalide.');
        }
        $this->database->transaction(function (PDO $pdo) use ($id, $user): void {
            $lookup = $pdo->prepare(
                'SELECT reporter_user_id, student_id, status, sequence_key,
                        claimed_by_user_id, claim_expires_at
                 FROM observations WHERE id = :id FOR UPDATE'
            );
            $lookup->execute(['id' => $id]);
            $observation = $lookup->fetch();
            if (!$observation || (int) $observation['reporter_user_id'] !== (int) $user['id']) {
                throw new HttpException(404, 'Signalement introuvable.');
            }
            if ((string) $observation['status'] !== 'pending') {
                throw new HttpException(409, 'Ce signalement a déjà été traité et ne peut plus être retiré.');
            }
            $this->assertClaimAvailable($observation, $user);
            $update = $pdo->prepare(
                "UPDATE observations
                 SET status = 'withdrawn', withdrawn_at = UTC_TIMESTAMP(), sequence_key = NULL,
                     claimed_by_user_id = NULL, claimed_at = NULL, claim_expires_at = NULL
                 WHERE id = :id"
            );
            $update->execute(['id' => $id]);
            if ($observation['sequence_key'] !== null) {
                $this->dissolveSequenceSingleton(
                    $pdo,
                    (string) $observation['sequence_key'],
                    (int) $observation['student_id']
                );
            }
            auditLog($this->database, (int) $user['id'], 'observation.withdraw', 'observation', $id, [], $pdo);
        });
        jsonResponse(['ok' => true]);
    }

    private function myObservations(): void
    {
        requireMethod('GET');
        $user = $this->auth->requireUser();
        $status = isset($_GET['status']) ? strtolower(trim((string) $_GET['status'])) : 'all';
        if (!in_array($status, ['all', 'pending', 'confirmed', 'cancelled'], true)) {
            throw new HttpException(422, 'Filtre de statut invalide.');
        }
        $statement = $this->database->pdo()->prepare(
            'SELECT o.id, o.occurred_at, o.location, o.reason, o.details, o.status, o.cancellation_reason,
                    s.id AS student_id, s.first_name, s.last_name, s.class_name
             FROM observations o
             JOIN students s ON s.id = o.student_id
             WHERE o.reporter_user_id = :reporter_id
               AND s.school_year = :school_year
               AND (:status_all = 1 OR o.status = :status_exact
                    OR (:include_withdrawn = 1 AND o.status = \'withdrawn\'))
             ORDER BY o.occurred_at DESC, o.id DESC
             LIMIT 100'
        );
        $statement->execute([
            'reporter_id' => $user['id'],
            'school_year' => $this->config['app']['school_year'],
            'status_all' => $status === 'all' ? 1 : 0,
            'status_exact' => $status === 'cancelled' ? 'cancelled' : $status,
            'include_withdrawn' => $status === 'cancelled' ? 1 : 0,
        ]);
        jsonResponse(['observations' => $statement->fetchAll()]);
    }

    private function notifications(): void
    {
        requireMethod('GET');
        $user = $this->auth->requireUser();
        $statement = $this->database->pdo()->prepare(
            'SELECT n.id, n.event_type, n.created_at, n.read_at,
                    o.id AS observation_id, o.occurred_at, o.location, o.reason,
                    o.status, o.cancellation_reason,
                    s.first_name, s.last_name, s.class_name
             FROM user_notifications n
             JOIN observations o ON o.id = n.observation_id
             JOIN students s ON s.id = o.student_id
             WHERE n.user_id = :user_id
             ORDER BY n.created_at DESC, n.id DESC
             LIMIT 40'
        );
        $statement->execute(['user_id' => (int) $user['id']]);
        jsonResponse([
            'notifications' => $statement->fetchAll(),
            'unread_count' => $this->notificationCount($user),
        ]);
    }

    private function notificationsRead(): void
    {
        requireMethod('POST');
        $user = $this->auth->requireUser();
        requireCsrf($this->auth);
        $statement = $this->database->pdo()->prepare(
            'UPDATE user_notifications
             SET read_at = UTC_TIMESTAMP()
             WHERE user_id = :user_id AND read_at IS NULL'
        );
        $statement->execute(['user_id' => (int) $user['id']]);
        jsonResponse(['ok' => true, 'marked_read' => $statement->rowCount()]);
    }

    private function pendingObservations(): void
    {
        requireMethod('GET');
        $user = $this->auth->requireRoles(self::VALIDATE_ROLES);
        $pdo = $this->database->pdo();

        $level = trim(isset($_GET['level']) ? (string) $_GET['level'] : '');
        $className = trim(isset($_GET['class_name']) ? (string) $_GET['class_name'] : '');
        $location = trim(isset($_GET['location']) ? (string) $_GET['location'] : '');
        $age = trim(isset($_GET['age']) ? (string) $_GET['age'] : 'all');
        $path = trim(isset($_GET['path']) ? (string) $_GET['path'] : 'all');
        if ($level !== '' && !preg_match('/^[3-6]$/', $level)) {
            throw new HttpException(422, 'Niveau invalide.');
        }
        if ($this->length($className) > 32) {
            throw new HttpException(422, 'Classe invalide.');
        }
        if ($location !== '' && !in_array($location, self::LOCATIONS, true)) {
            throw new HttpException(422, 'Lieu invalide.');
        }
        if (!in_array($age, ['all', 'today', 'over24', 'over48'], true)
            || !in_array($path, ['all', 'with', 'without'], true)) {
            throw new HttpException(422, 'Filtre invalide.');
        }

        $where = ["o.status = 'pending'", 's.school_year = :school_year'];
        $parameters = ['school_year' => $this->config['app']['school_year']];
        if ($level !== '') {
            $where[] = 's.class_name LIKE :level_prefix';
            $parameters['level_prefix'] = $level . '%';
        }
        if ($className !== '') {
            $where[] = 's.class_name = :class_name';
            $parameters['class_name'] = $className;
        }
        if ($location !== '') {
            $where[] = 'o.location = :location';
            $parameters['location'] = $location;
        }
        if ($age === 'today') {
            $todayParis = new DateTimeImmutable('today', new DateTimeZone('Europe/Paris'));
            $where[] = 'o.occurred_at >= :age_cutoff';
            $parameters['age_cutoff'] = $todayParis->setTimezone(new DateTimeZone('UTC'))->format('Y-m-d H:i:s');
        } elseif ($age === 'over24' || $age === 'over48') {
            $hours = $age === 'over48' ? 48 : 24;
            $where[] = 'o.occurred_at <= :age_cutoff';
            $parameters['age_cutoff'] = gmdate('Y-m-d H:i:s', time() - ($hours * 3600));
        }

        $statement = $pdo->prepare(
            "SELECT o.id, o.student_id, o.occurred_at, o.location, o.reason, o.details, o.status,
                    o.digital_pass_destination, o.digital_pass_issued_at, o.digital_pass_expires_at,
                    o.sequence_key, o.claimed_by_user_id, o.claimed_at, o.claim_expires_at,
                    s.first_name, s.last_name, s.class_name,
                    u.first_name AS reporter_first_name, u.last_name AS reporter_last_name,
                    claimant.first_name AS claimant_first_name,
                    claimant.last_name AS claimant_last_name
             FROM observations o
             JOIN students s ON s.id = o.student_id
             JOIN users u ON u.id = o.reporter_user_id
             LEFT JOIN users claimant ON claimant.id = o.claimed_by_user_id
             WHERE " . implode(' AND ', $where) . "
             ORDER BY o.occurred_at ASC, o.id ASC
             LIMIT 200"
        );
        $statement->execute($parameters);
        $observations = $statement->fetchAll();
        $this->attachNearbyObservations($observations);
        if ($path !== 'all') {
            $observations = array_values(array_filter(
                $observations,
                static function (array $observation) use ($path): bool {
                    $hasNearby = count($observation['nearby_observations']) > 0;
                    return $path === 'with' ? $hasNearby : !$hasNearby;
                }
            ));
        }
        foreach ($observations as &$observation) {
            $claimExpired = $observation['claim_expires_at'] !== null
                && strtotime((string) $observation['claim_expires_at'] . ' UTC') <= time();
            $claimantId = $observation['claimed_by_user_id'] !== null
                ? (int) $observation['claimed_by_user_id']
                : null;
            if ($claimExpired) {
                // Une revendication expirée est libre immédiatement, sans
                // transformer cette requête de lecture en écriture cachée.
                $claimantId = null;
                $observation['claimed_by_user_id'] = null;
                $observation['claimed_at'] = null;
                $observation['claim_expires_at'] = null;
            }
            $observation['claimed_by_current_user'] = $claimantId !== null
                && $claimantId === (int) $user['id'];
            $observation['claim_locked'] = $claimantId !== null
                && $claimantId !== (int) $user['id'];
            if ($claimantId === null) {
                $observation['claimant_name'] = null;
            } else {
                $observation['claimant_name'] = trim(
                    (string) $observation['claimant_first_name'] . ' '
                    . (string) $observation['claimant_last_name']
                );
            }
            unset($observation['claimant_first_name'], $observation['claimant_last_name']);
            $this->attachDigitalPassContext($observation);
        }
        unset($observation);

        $classesStatement = $pdo->prepare(
            'SELECT DISTINCT class_name FROM students
             WHERE school_year = :school_year AND active = 1
             ORDER BY class_name'
        );
        $classesStatement->execute(['school_year' => $this->config['app']['school_year']]);
        $classes = array_column($classesStatement->fetchAll(), 'class_name');
        $totalPending = $this->pendingCount($user);
        jsonResponse([
            'observations' => $observations,
            'total_pending' => $totalPending !== null ? $totalPending : count($observations),
            'display_limit' => 200,
            'filters' => [
                'levels' => ['6', '5', '4', '3'],
                'classes' => $classes,
                'locations' => self::LOCATIONS,
            ],
        ]);
    }

    /** @param array<int,array<string,mixed>> $observations */
    private function attachNearbyObservations(array &$observations): void
    {
        if (count($observations) === 0) {
            return;
        }
        $anchorIds = array_map(static function (array $observation): int {
            return (int) $observation['id'];
        }, $observations);
        $placeholders = implode(', ', array_fill(0, count($anchorIds), '?'));
        $statement = $this->database->pdo()->prepare(
            "SELECT anchor.id AS anchor_id, anchor.sequence_key AS anchor_sequence_key,
                    related.id, related.occurred_at, related.location, related.reason,
                    related.details, related.status, related.sequence_key,
                    related.digital_pass_destination, related.digital_pass_issued_at,
                    related.digital_pass_expires_at,
                    reporter.first_name AS reporter_first_name,
                    reporter.last_name AS reporter_last_name
             FROM observations anchor
             JOIN observations related
               ON related.student_id = anchor.student_id
              AND related.id <> anchor.id
              AND (
                    (related.status IN ('pending', 'confirmed')
                     AND related.occurred_at BETWEEN DATE_SUB(anchor.occurred_at, INTERVAL 20 MINUTE)
                                                 AND DATE_ADD(anchor.occurred_at, INTERVAL 20 MINUTE))
                    OR (anchor.sequence_key IS NOT NULL AND related.sequence_key = anchor.sequence_key)
                  )
             JOIN users reporter ON reporter.id = related.reporter_user_id
             WHERE anchor.id IN ($placeholders)
             ORDER BY anchor.id, related.occurred_at, related.id"
        );
        $statement->execute($anchorIds);
        $nearbyByAnchor = [];
        foreach ($statement->fetchAll() as $related) {
            $anchorId = (int) $related['anchor_id'];
            if (!isset($nearbyByAnchor[$anchorId])) {
                $nearbyByAnchor[$anchorId] = [];
            }
            $anchorSequenceKey = $related['anchor_sequence_key'] === null
                ? null
                : (string) $related['anchor_sequence_key'];
            $relatedSequenceKey = $related['sequence_key'] === null
                ? null
                : (string) $related['sequence_key'];
            $related['same_sequence'] = $anchorSequenceKey !== null
                && $relatedSequenceKey === $anchorSequenceKey;
            unset($related['anchor_id'], $related['anchor_sequence_key'], $related['sequence_key']);
            $this->attachDigitalPassContext($related);
            $nearbyByAnchor[$anchorId][] = $related;
        }
        foreach ($observations as &$observation) {
            $observationId = (int) $observation['id'];
            $observation['sequence_linked'] = $observation['sequence_key'] !== null;
            $observation['nearby_observations'] = $nearbyByAnchor[$observationId] ?? [];
            unset($observation['sequence_key'], $observation['student_id']);
        }
        unset($observation);
    }

    private function observationClaim(): void
    {
        requireMethod('POST');
        $user = $this->auth->requireRoles(self::VALIDATE_ROLES);
        requireCsrf($this->auth);
        $input = jsonInput();
        $id = isset($input['id']) ? (int) $input['id'] : 0;
        if ($id <= 0 || !array_key_exists('claimed', $input) || !is_bool($input['claimed'])) {
            throw new HttpException(422, 'Prise en charge invalide.');
        }
        $claimed = (bool) $input['claimed'];
        $this->database->transaction(function (PDO $pdo) use ($id, $claimed, $user): void {
            $lookup = $pdo->prepare(
                "SELECT o.status, o.claimed_by_user_id, o.claim_expires_at, s.school_year
                 FROM observations o
                 JOIN students s ON s.id = o.student_id
                 WHERE o.id = :id
                 FOR UPDATE"
            );
            $lookup->execute(['id' => $id]);
            $observation = $lookup->fetch();
            if (!$observation || (string) $observation['school_year'] !== (string) $this->config['app']['school_year']) {
                throw new HttpException(404, 'Signalement introuvable.');
            }
            if ((string) $observation['status'] !== 'pending') {
                throw new HttpException(409, 'Ce signalement a déjà été traité.');
            }
            $claimedBy = $observation['claimed_by_user_id'] !== null
                ? (int) $observation['claimed_by_user_id']
                : null;
            $claimExpired = $observation['claim_expires_at'] !== null
                && strtotime((string) $observation['claim_expires_at'] . ' UTC') <= time();

            if ($claimed) {
                if ($claimedBy !== null && !$claimExpired && $claimedBy !== (int) $user['id']) {
                    throw new HttpException(409, 'Ce signalement est déjà pris en charge par un collègue.');
                }
                $update = $pdo->prepare(
                    'UPDATE observations
                     SET claimed_by_user_id = :user_id, claimed_at = UTC_TIMESTAMP(),
                         claim_expires_at = DATE_ADD(UTC_TIMESTAMP(), INTERVAL 20 MINUTE)
                     WHERE id = :id'
                );
                $update->execute(['user_id' => $user['id'], 'id' => $id]);
                $action = 'observation.claim';
            } else {
                $canOverride = in_array((string) $user['role'], ['cpe', 'direction', 'admin'], true);
                if ($claimedBy !== null && $claimedBy !== (int) $user['id'] && !$canOverride && !$claimExpired) {
                    throw new HttpException(403, 'Seul le collègue qui a pris en charge ce signalement peut le libérer.');
                }
                $update = $pdo->prepare(
                    'UPDATE observations
                     SET claimed_by_user_id = NULL, claimed_at = NULL, claim_expires_at = NULL
                     WHERE id = :id'
                );
                $update->execute(['id' => $id]);
                $action = 'observation.release';
            }
            auditLog($this->database, (int) $user['id'], $action, 'observation', $id, [], $pdo);
        });
        jsonResponse(['ok' => true, 'claimed' => $claimed]);
    }

    private function updateObservationStatus(): void
    {
        requireMethod('POST');
        $user = $this->auth->requireRoles(self::VALIDATE_ROLES);
        requireCsrf($this->auth);
        $input = jsonInput();
        $id = isset($input['id']) ? (int) $input['id'] : 0;
        $status = isset($input['status']) ? (string) $input['status'] : '';
        $cancellationReason = trim(isset($input['cancellation_reason']) ? (string) $input['cancellation_reason'] : '');
        if ($id <= 0 || !in_array($status, ['confirmed', 'cancelled'], true)) {
            throw new HttpException(422, 'Décision invalide.');
        }
        if ($status === 'cancelled' && !in_array($cancellationReason, self::CANCELLATION_REASONS, true)) {
            throw new HttpException(422, 'Choisissez un motif d’annulation.');
        }
        if ($status === 'confirmed') {
            $cancellationReason = '';
        }
        $this->database->transaction(function (PDO $pdo) use ($id, $status, $cancellationReason, $user): void {
            $targetLookup = $pdo->prepare(
                'SELECT student_id FROM observations WHERE id = :id AND status = \'pending\''
            );
            $targetLookup->execute(['id' => $id]);
            $studentId = (int) $targetLookup->fetchColumn();
            if ($studentId <= 0) {
                throw new HttpException(409, 'Ce signalement a déjà été traité ou n’existe plus.');
            }
            $studentLock = $pdo->prepare('SELECT id FROM students WHERE id = :id FOR UPDATE');
            $studentLock->execute(['id' => $studentId]);
            if (!$studentLock->fetchColumn()) {
                throw new HttpException(404, 'Élève introuvable.');
            }
            $targetStatement = $pdo->prepare(
                'SELECT student_id, reporter_user_id, sequence_key,
                        claimed_by_user_id, claim_expires_at FROM observations
                 WHERE id = :id AND status = \'pending\'
                 FOR UPDATE'
            );
            $targetStatement->execute(['id' => $id]);
            $target = $targetStatement->fetch();
            if (!$target) {
                throw new HttpException(409, 'Ce signalement a déjà été traité ou n’existe plus.');
            }
            $this->assertClaimAvailable($target, $user);
            $sequenceKey = $target['sequence_key'] === null ? null : (string) $target['sequence_key'];
            if ($sequenceKey !== null && $status === 'confirmed') {
                throw new HttpException(409, 'Ce signalement fait partie d’un parcours. Utilisez « Confirmer ce parcours ».');
            }
            if ($sequenceKey !== null && $status === 'cancelled') {
                $detach = $pdo->prepare('UPDATE observations SET sequence_key = NULL WHERE id = :id');
                $detach->execute(['id' => $id]);
                $this->dissolveSequenceSingleton($pdo, $sequenceKey, $studentId);
            }
            $statement = $pdo->prepare(
                "UPDATE observations
                 SET status = :status, cancellation_reason = :cancellation_reason,
                     validator_user_id = :validator_id, validated_at = UTC_TIMESTAMP(),
                     claimed_by_user_id = NULL, claimed_at = NULL, claim_expires_at = NULL
                 WHERE id = :id AND status = 'pending'"
            );
            $statement->execute([
                'status' => $status,
                'cancellation_reason' => $cancellationReason !== '' ? $cancellationReason : null,
                'validator_id' => $user['id'],
                'id' => $id,
            ]);
            if ($statement->rowCount() !== 1) {
                throw new HttpException(409, 'Ce signalement a déjà été traité ou n’existe plus.');
            }
            $this->createObservationNotification(
                $pdo,
                (int) $target['reporter_user_id'],
                $id,
                $status
            );
            auditLog($this->database, (int) $user['id'], 'observation.' . $status, 'observation', $id, [
                'cancellation_reason' => $cancellationReason !== '' ? $cancellationReason : null,
            ], $pdo);
        });
        jsonResponse(['ok' => true]);
    }

    private function updateObservationSequence(): void
    {
        requireMethod('POST');
        $user = $this->auth->requireRoles(self::VALIDATE_ROLES);
        requireCsrf($this->auth);
        $input = jsonInput();
        $id = isset($input['id']) ? (int) $input['id'] : 0;
        if ($id <= 0 || !array_key_exists('linked', $input) || !is_bool($input['linked'])) {
            throw new HttpException(422, 'Demande de parcours invalide.');
        }
        $linked = (bool) $input['linked'];
        $selectedIds = [];
        if ($linked && isset($input['observation_ids']) && is_array($input['observation_ids'])) {
            foreach ($input['observation_ids'] as $selectedId) {
                $selectedIds[] = (int) $selectedId;
            }
        }
        $selectedIds = array_values(array_unique(array_filter($selectedIds, static function (int $selectedId): bool {
            return $selectedId > 0;
        })));
        if ($linked && (count($selectedIds) < 2 || count($selectedIds) > 10 || !in_array($id, $selectedIds, true))) {
            throw new HttpException(422, 'Sélectionnez entre deux et dix observations, dont le signalement courant.');
        }
        $result = $this->database->transaction(function (PDO $pdo) use ($id, $linked, $selectedIds, $user): array {
            $anchorLookup = $pdo->prepare(
                "SELECT o.id, o.student_id, o.occurred_at, o.status, o.sequence_key, s.school_year
                 FROM observations o
                 JOIN students s ON s.id = o.student_id
                 WHERE o.id = :id"
            );
            $anchorLookup->execute(['id' => $id]);
            $anchor = $anchorLookup->fetch();
            if (!$anchor || (string) $anchor['school_year'] !== (string) $this->config['app']['school_year']) {
                throw new HttpException(404, 'Signalement introuvable.');
            }
            $studentId = (int) $anchor['student_id'];
            $studentLock = $pdo->prepare('SELECT id FROM students WHERE id = :id FOR UPDATE');
            $studentLock->execute(['id' => $studentId]);
            if (!$studentLock->fetchColumn()) {
                throw new HttpException(404, 'Élève introuvable.');
            }
            $anchorStatement = $pdo->prepare(
                "SELECT o.id, o.student_id, o.occurred_at, o.status, o.sequence_key, s.school_year
                 FROM observations o
                 JOIN students s ON s.id = o.student_id
                 WHERE o.id = :id
                 FOR UPDATE"
            );
            $anchorStatement->execute(['id' => $id]);
            $anchor = $anchorStatement->fetch();
            if (!$anchor || (int) $anchor['student_id'] !== $studentId
                || (string) $anchor['school_year'] !== (string) $this->config['app']['school_year']) {
                throw new HttpException(404, 'Signalement introuvable.');
            }
            if (!in_array((string) $anchor['status'], ['pending', 'confirmed'], true)) {
                throw new HttpException(409, 'Ce signalement ne peut plus faire partie d’un parcours.');
            }
            $currentSequenceKey = $anchor['sequence_key'] === null
                ? null
                : (string) $anchor['sequence_key'];
            if (!$linked) {
                if ($currentSequenceKey === null) {
                    return ['linked' => false, 'count' => 0];
                }
                $members = $pdo->prepare(
                    'SELECT id, status FROM observations
                     WHERE student_id = :student_id AND sequence_key = :sequence_key
                     FOR UPDATE'
                );
                $members->execute([
                    'student_id' => $studentId,
                    'sequence_key' => $currentSequenceKey,
                ]);
                $memberRows = $members->fetchAll();
                foreach ($memberRows as $member) {
                    if ((string) $member['status'] === 'confirmed') {
                        throw new HttpException(409, 'Un parcours confirmé ne peut plus être dissocié, car cela modifierait rétroactivement les points.');
                    }
                }
                $memberIds = array_map('intval', array_column($memberRows, 'id'));
                $unlink = $pdo->prepare(
                    'UPDATE observations SET sequence_key = NULL
                     WHERE student_id = :student_id AND sequence_key = :sequence_key'
                );
                $unlink->execute([
                    'student_id' => $studentId,
                    'sequence_key' => $currentSequenceKey,
                ]);
                auditLog($this->database, (int) $user['id'], 'observation.sequence_unlink', 'observation', $id, [
                    'linked_count' => count($memberIds),
                ], $pdo);
                return ['linked' => false, 'count' => count($memberIds)];
            }

            try {
                $occurredAt = new DateTimeImmutable((string) $anchor['occurred_at'], new DateTimeZone('UTC'));
            } catch (Exception $error) {
                throw new RuntimeException('Date du signalement invalide.', 0, $error);
            }
            $selectedPlaceholders = implode(', ', array_fill(0, count($selectedIds), '?'));
            $candidates = $pdo->prepare(
                "SELECT o.id, o.reporter_user_id, o.occurred_at, o.status, o.sequence_key,
                        o.claimed_by_user_id, o.claim_expires_at
                 FROM observations o
                 JOIN students s ON s.id = o.student_id
                 WHERE o.student_id = ?
                   AND s.school_year = ?
                   AND o.status IN ('pending', 'confirmed')
                   AND o.id IN ($selectedPlaceholders)
                 ORDER BY o.occurred_at, o.id
                 FOR UPDATE"
            );
            $candidates->execute(array_merge(
                [$studentId, (string) $this->config['app']['school_year']],
                $selectedIds
            ));
            $candidateRows = $candidates->fetchAll();
            if (count($candidateRows) !== count($selectedIds)) {
                throw new HttpException(409, 'Une observation sélectionnée a changé ou ne concerne pas cet élève. Rechargez la liste.');
            }
            foreach ($candidateRows as $candidate) {
                $candidateAt = new DateTimeImmutable((string) $candidate['occurred_at'], new DateTimeZone('UTC'));
                $sameExistingSequence = $currentSequenceKey !== null
                    && $candidate['sequence_key'] !== null
                    && (string) $candidate['sequence_key'] === $currentSequenceKey;
                if (!$sameExistingSequence
                    && abs($candidateAt->getTimestamp() - $occurredAt->getTimestamp()) > 20 * 60) {
                    throw new HttpException(409, 'Les observations d’un même parcours doivent être espacées de vingt minutes au maximum.');
                }
                if ((string) $candidate['status'] === 'pending') {
                    $this->assertClaimAvailable($candidate, $user);
                }
            }
            $existingKeys = [];
            foreach ($candidateRows as $candidate) {
                if ($candidate['sequence_key'] !== null) {
                    $existingKeys[(string) $candidate['sequence_key']] = true;
                }
            }
            if (count($existingKeys) > 1) {
                throw new HttpException(409, 'Ces observations appartiennent déjà à deux parcours différents. Traitez-les séparément.');
            }
            $sequenceKey = count($existingKeys) === 1
                ? (string) array_key_first($existingKeys)
                : bin2hex(random_bytes(16));

            if (count($existingKeys) === 1) {
                $existingMembers = $pdo->prepare(
                    "SELECT o.id, o.status, o.sequence_key
                     FROM observations o
                     JOIN students s ON s.id = o.student_id
                     WHERE o.student_id = :student_id
                       AND s.school_year = :school_year
                       AND o.sequence_key = :sequence_key
                       AND o.status IN ('pending', 'confirmed')
                     FOR UPDATE"
                );
                $existingMembers->execute([
                    'student_id' => $studentId,
                    'school_year' => (string) $this->config['app']['school_year'],
                    'sequence_key' => $sequenceKey,
                ]);
                $existingMemberIds = array_map('intval', array_column($existingMembers->fetchAll(), 'id'));
                foreach ($existingMemberIds as $existingMemberId) {
                    if (!in_array($existingMemberId, $selectedIds, true)) {
                        throw new HttpException(409, 'Sélectionnez toutes les observations du parcours déjà constitué.');
                    }
                }
            }
            $candidateIds = array_map('intval', array_column($candidateRows, 'id'));
            $idPlaceholders = implode(', ', array_fill(0, count($candidateIds), '?'));
            $link = $pdo->prepare(
                "UPDATE observations SET sequence_key = ?
                 WHERE student_id = ? AND id IN ($idPlaceholders)"
            );
            $link->execute(array_merge([$sequenceKey, $studentId], $candidateIds));

            $pendingIds = [];
            foreach ($candidateRows as $candidate) {
                if ((string) $candidate['status'] === 'pending') {
                    $pendingIds[] = (int) $candidate['id'];
                }
            }
            if (count($pendingIds) === 0) {
                throw new HttpException(409, 'Toutes les observations de ce parcours ont déjà été traitées.');
            }
            $pendingPlaceholders = implode(', ', array_fill(0, count($pendingIds), '?'));
            $confirm = $pdo->prepare(
                "UPDATE observations
                 SET status = 'confirmed', cancellation_reason = NULL,
                     validator_user_id = ?, validated_at = UTC_TIMESTAMP(),
                     claimed_by_user_id = NULL, claimed_at = NULL, claim_expires_at = NULL
                 WHERE id IN ($pendingPlaceholders) AND status = 'pending'"
            );
            $confirm->execute(array_merge([(int) $user['id']], $pendingIds));
            if ($confirm->rowCount() !== count($pendingIds)) {
                throw new HttpException(409, 'Une observation du parcours vient d’être traitée. Rechargez la liste.');
            }
            $this->createObservationNotificationsForIds($pdo, $pendingIds, 'confirmed');
            $memberCount = $pdo->prepare(
                'SELECT COUNT(*) FROM observations
                 WHERE student_id = :student_id AND sequence_key = :sequence_key'
            );
            $memberCount->execute([
                'student_id' => $studentId,
                'sequence_key' => $sequenceKey,
            ]);
            $count = (int) $memberCount->fetchColumn();
            auditLog($this->database, (int) $user['id'], 'observation.sequence_confirm', 'observation', $id, [
                'path_observations' => $count,
                'confirmed_count' => count($pendingIds),
            ], $pdo);
            return [
                'linked' => true,
                'count' => $count,
                'path_count' => $count,
                'confirmed_count' => count($pendingIds),
            ];
        });
        jsonResponse(['ok' => true] + $result);
    }

    private function dissolveSequenceSingleton(PDO $pdo, string $sequenceKey, int $studentId): void
    {
        $members = $pdo->prepare(
            'SELECT id FROM observations
             WHERE student_id = :student_id AND sequence_key = :sequence_key
             FOR UPDATE'
        );
        $members->execute([
            'student_id' => $studentId,
            'sequence_key' => $sequenceKey,
        ]);
        $memberIds = array_map('intval', array_column($members->fetchAll(), 'id'));
        if (count($memberIds) <= 1) {
            $clear = $pdo->prepare(
                'UPDATE observations SET sequence_key = NULL
                 WHERE student_id = :student_id AND sequence_key = :sequence_key'
            );
            $clear->execute([
                'student_id' => $studentId,
                'sequence_key' => $sequenceKey,
            ]);
        }
    }

    private function digitalPassesList(): void
    {
        requireMethod('GET');
        $this->requireDigitalPassesEnabled();
        $user = $this->auth->requireRoles(self::SUBMIT_ROLES);
        $canRevokeAny = in_array((string) $user['role'], self::VALIDATE_ROLES, true);
        $passes = $this->digitalPasses->listActive(
            (string) $this->config['app']['school_year'],
            $canRevokeAny ? null : (int) $user['id']
        );
        foreach ($passes as &$pass) {
            $pass['id'] = (int) $pass['id'];
            $pass['student_id'] = (int) $pass['student_id'];
            $pass['issuer_user_id'] = (int) $pass['issuer_user_id'];
            $pass['can_revoke'] = $canRevokeAny
                || (int) $pass['issuer_user_id'] === (int) $user['id'];
        }
        unset($pass);
        jsonResponse([
            'passes' => $passes,
            'server_now' => gmdate('Y-m-d H:i:s'),
        ]);
    }

    private function digitalPassIssue(): void
    {
        requireMethod('POST');
        $this->requireDigitalPassesEnabled();
        $user = $this->auth->requireRoles(self::SUBMIT_ROLES);
        requireCsrf($this->auth);
        $input = jsonInput();
        $studentId = isset($input['student_id']) ? (int) $input['student_id'] : 0;
        $destination = trim(isset($input['destination']) ? (string) $input['destination'] : '');
        $duration = isset($input['duration_minutes']) ? (int) $input['duration_minutes'] : 0;
        if ($studentId <= 0 || !in_array($destination, self::DIGITAL_PASS_DESTINATIONS, true)
            || !in_array($duration, self::DIGITAL_PASS_DURATIONS, true)) {
            throw new HttpException(422, 'Élève, destination ou durée invalide.');
        }
        try {
            $pass = $this->digitalPasses->issue(
                $studentId,
                (int) $user['id'],
                (string) $this->config['app']['school_year'],
                $destination,
                $duration,
                function (PDO $pdo, string $action, string $entityType, int $entityId, array $metadata) use ($user): void {
                    auditLog(
                        $this->database,
                        (int) $user['id'],
                        $action,
                        $entityType,
                        $entityId,
                        $metadata,
                        $pdo
                    );
                }
            );
        } catch (RuntimeException $error) {
            throw new HttpException(409, $error->getMessage());
        }
        jsonResponse(['ok' => true, 'pass' => $pass], 201);
    }

    private function digitalPassRevoke(): void
    {
        requireMethod('POST');
        $this->requireDigitalPassesEnabled();
        $user = $this->auth->requireRoles(self::SUBMIT_ROLES);
        requireCsrf($this->auth);
        $input = jsonInput();
        $passId = isset($input['id']) ? (int) $input['id'] : 0;
        if ($passId <= 0) {
            throw new HttpException(422, 'Billet invalide.');
        }
        try {
            $this->digitalPasses->revoke(
                $passId,
                (int) $user['id'],
                in_array((string) $user['role'], self::VALIDATE_ROLES, true),
                function (PDO $pdo, string $action, string $entityType, int $entityId, array $metadata) use ($user): void {
                    auditLog(
                        $this->database,
                        (int) $user['id'],
                        $action,
                        $entityType,
                        $entityId,
                        $metadata,
                        $pdo
                    );
                }
            );
        } catch (RuntimeException $error) {
            throw new HttpException(409, $error->getMessage());
        }
        jsonResponse(['ok' => true]);
    }

    private function dashboard(): void
    {
        requireMethod('GET');
        $this->auth->requireRoles(self::DASHBOARD_ROLES);
        $pdo = $this->database->pdo();
        $cutoff = gmdate('Y-m-d H:i:s', time() - 7 * 86400);
        $previousCutoff = gmdate('Y-m-d H:i:s', time() - 14 * 86400);
        $hotSlotsCutoff = gmdate('Y-m-d H:i:s', time() - 28 * 86400);

        $totals = $pdo->prepare(
            "SELECT
                COUNT(DISTINCT CASE
                    WHEN o.status = 'confirmed' AND o.occurred_at >= :cutoff_confirmed
                    THEN CASE WHEN o.sequence_key IS NULL
                        THEN CONCAT('observation:', o.id)
                        ELSE CONCAT('sequence:', o.sequence_key)
                    END
                END) AS confirmed,
                SUM(o.status = 'pending' AND o.occurred_at >= :cutoff_pending) AS pending,
                COUNT(DISTINCT CASE WHEN o.status = 'confirmed' AND o.occurred_at >= :cutoff_students THEN o.student_id END) AS students,
                COUNT(DISTINCT CASE
                    WHEN o.status = 'confirmed' AND o.occurred_at >= :previous_cutoff AND o.occurred_at < :cutoff_previous
                    THEN CASE WHEN o.sequence_key IS NULL
                        THEN CONCAT('observation:', o.id)
                        ELSE CONCAT('sequence:', o.sequence_key)
                    END
                END) AS previous_confirmed
             FROM observations o
             JOIN students s ON s.id = o.student_id
             WHERE o.occurred_at >= :previous_cutoff_where
               AND s.school_year = :school_year"
        );
        $totals->execute([
            'cutoff_confirmed' => $cutoff,
            'cutoff_pending' => $cutoff,
            'cutoff_students' => $cutoff,
            'previous_cutoff' => $previousCutoff,
            'cutoff_previous' => $cutoff,
            'previous_cutoff_where' => $previousCutoff,
            'school_year' => $this->config['app']['school_year'],
        ]);

        $locations = $pdo->prepare(
            "SELECT o.location, COUNT(*) AS total
             FROM observations o
             JOIN students s ON s.id = o.student_id
             WHERE o.status = 'confirmed' AND o.occurred_at >= :cutoff
               AND s.school_year = :school_year
             GROUP BY o.location ORDER BY total DESC, o.location ASC"
        );
        $locations->execute([
            'cutoff' => $cutoff,
            'school_year' => $this->config['app']['school_year'],
        ]);

        $repetitions = $pdo->prepare(
            "SELECT s.id, s.first_name, s.last_name, s.class_name,
                    COUNT(DISTINCT CASE WHEN o.sequence_key IS NULL
                        THEN CONCAT('observation:', o.id)
                        ELSE CONCAT('sequence:', o.sequence_key)
                    END) AS total,
                    COUNT(*) AS observation_total
             FROM observations o JOIN students s ON s.id = o.student_id
             WHERE o.status = 'confirmed' AND o.occurred_at >= :cutoff
               AND s.school_year = :school_year
             GROUP BY s.id, s.first_name, s.last_name, s.class_name
             HAVING COUNT(DISTINCT CASE WHEN o.sequence_key IS NULL
                        THEN CONCAT('observation:', o.id)
                        ELSE CONCAT('sequence:', o.sequence_key)
                    END) >= 2
             ORDER BY total DESC, observation_total DESC, s.last_name, s.first_name"
        );
        $repetitions->execute([
            'cutoff' => $cutoff,
            'school_year' => $this->config['app']['school_year'],
        ]);
        $repetitionRows = $repetitions->fetchAll();
        $repetitionCount = count(array_filter($repetitionRows, static function (array $row): bool {
            return (int) $row['total'] >= 2;
        }));
        $repetitionRows = array_slice($repetitionRows, 0, 30);
        $repetitionSituations = [];
        if (count($repetitionRows) > 0) {
            $repetitionStudentIds = array_map('intval', array_column($repetitionRows, 'id'));
            $repetitionPlaceholders = implode(', ', array_fill(0, count($repetitionStudentIds), '?'));
            $repetitionObservations = $pdo->prepare(
                "SELECT o.id, o.student_id, o.occurred_at, o.location, o.reason, o.details,
                        o.sequence_key, u.first_name AS reporter_first_name,
                        u.last_name AS reporter_last_name
                 FROM observations o
                 JOIN students s ON s.id = o.student_id
                 JOIN users u ON u.id = o.reporter_user_id
                 WHERE o.status = 'confirmed' AND o.occurred_at >= ?
                   AND s.school_year = ?
                   AND o.student_id IN ($repetitionPlaceholders)
                 ORDER BY o.student_id, o.occurred_at, o.id"
            );
            $repetitionObservations->execute(array_merge(
                [$cutoff, (string) $this->config['app']['school_year']],
                $repetitionStudentIds
            ));
            foreach ($repetitionObservations->fetchAll() as $observation) {
                $studentId = (int) $observation['student_id'];
                $situationKey = $observation['sequence_key'] === null
                    ? 'observation:' . (int) $observation['id']
                    : 'sequence:' . (string) $observation['sequence_key'];
                if (!isset($repetitionSituations[$studentId][$situationKey])) {
                    $repetitionSituations[$studentId][$situationKey] = [
                        'started_at' => (string) $observation['occurred_at'],
                        'ended_at' => (string) $observation['occurred_at'],
                        'observations' => [],
                    ];
                }
                $repetitionSituations[$studentId][$situationKey]['ended_at'] = (string) $observation['occurred_at'];
                $repetitionSituations[$studentId][$situationKey]['observations'][] = [
                    'id' => (int) $observation['id'],
                    'occurred_at' => (string) $observation['occurred_at'],
                    'location' => (string) $observation['location'],
                    'reason' => (string) $observation['reason'],
                    'details' => (string) $observation['details'],
                    'reporter_first_name' => (string) $observation['reporter_first_name'],
                    'reporter_last_name' => (string) $observation['reporter_last_name'],
                ];
            }
        }
        foreach ($repetitionRows as &$repetitionRow) {
            $studentId = (int) $repetitionRow['id'];
            $situations = array_values($repetitionSituations[$studentId] ?? []);
            usort($situations, static function (array $left, array $right): int {
                return strcmp((string) $right['ended_at'], (string) $left['ended_at']);
            });
            foreach ($situations as &$situation) {
                $situation['observation_count'] = count($situation['observations']);
            }
            unset($situation);
            $repetitionRow['id'] = $studentId;
            $repetitionRow['total'] = (int) $repetitionRow['total'];
            $repetitionRow['observation_total'] = (int) $repetitionRow['observation_total'];
            $repetitionRow['situations'] = $situations;
        }
        unset($repetitionRow);

        $heatmapSource = $pdo->prepare(
            "SELECT o.location, o.occurred_at
             FROM observations o
             JOIN students s ON s.id = o.student_id
             WHERE o.status = 'confirmed' AND o.occurred_at >= :cutoff
               AND s.school_year = :school_year
             ORDER BY o.location, o.occurred_at"
        );
        $heatmapSource->execute([
            'cutoff' => $cutoff,
            'school_year' => $this->config['app']['school_year'],
        ]);
        $heatmapCounts = [];
        $utcTimezone = new DateTimeZone('UTC');
        $localTimezone = new DateTimeZone('Europe/Paris');
        foreach ($heatmapSource->fetchAll() as $observation) {
            $localDate = (new DateTimeImmutable((string) $observation['occurred_at'], $utcTimezone))
                ->setTimezone($localTimezone);
            $timeSlot = $this->schoolTimeSlot($localDate);
            if ($timeSlot === null) {
                continue;
            }
            $key = (string) $observation['location'] . '|' . $timeSlot;
            if (!isset($heatmapCounts[$key])) {
                $heatmapCounts[$key] = [
                    'location' => (string) $observation['location'],
                    'time_slot' => $timeSlot,
                    'total' => 0,
                ];
            }
            $heatmapCounts[$key]['total']++;
        }
        $heatmap = array_values($heatmapCounts);

        $hotSlotsSource = $pdo->prepare(
            "SELECT o.location, o.occurred_at
             FROM observations o
             JOIN students s ON s.id = o.student_id
             WHERE o.status = 'confirmed' AND o.occurred_at >= :cutoff
               AND s.school_year = :school_year
             ORDER BY o.location, o.occurred_at"
        );
        $hotSlotsSource->execute([
            'cutoff' => $hotSlotsCutoff,
            'school_year' => $this->config['app']['school_year'],
        ]);
        $hotSlotsCounts = [];
        foreach ($hotSlotsSource->fetchAll() as $observation) {
            $localDate = (new DateTimeImmutable((string) $observation['occurred_at'], $utcTimezone))
                ->setTimezone($localTimezone);
            $dayNumber = (int) $localDate->format('N');
            $timeSlot = $this->schoolTimeSlot($localDate);
            if ($timeSlot === null) {
                continue;
            }
            $location = (string) $observation['location'];
            $key = $location . '|' . $dayNumber . '|' . $timeSlot;
            if (!isset($hotSlotsCounts[$key])) {
                $hotSlotsCounts[$key] = [
                    'location' => $location,
                    'day_number' => $dayNumber,
                    'time_slot' => $timeSlot,
                    'total' => 0,
                ];
            }
            $hotSlotsCounts[$key]['total']++;
        }
        $hotSlots = array_values($hotSlotsCounts);

        $totalsRow = $totals->fetch();
        $confirmed = (int) ($totalsRow['confirmed'] ?: 0);
        $previousConfirmed = (int) ($totalsRow['previous_confirmed'] ?: 0);
        $totalsRow['comparison_percent'] = $previousConfirmed > 0
            ? (int) round((($confirmed - $previousConfirmed) / $previousConfirmed) * 100)
            : null;

        jsonResponse([
            'period_days' => 7,
            'totals' => $totalsRow,
            'locations' => $locations->fetchAll(),
            'repetitions' => $repetitionRows,
            'repetition_count' => $repetitionCount,
            'heatmap' => $heatmap,
            'hot_period_days' => 28,
            'hot_slots' => $hotSlots,
        ]);
    }

    private function studentHistory(): void
    {
        requireMethod('GET');
        $this->auth->requireRoles(self::DASHBOARD_ROLES);
        $studentId = isset($_GET['student_id']) ? (int) $_GET['student_id'] : 0;
        if ($studentId <= 0) {
            throw new HttpException(422, 'Élève invalide.');
        }
        $student = $this->activeStudent($studentId);
        $statement = $this->database->pdo()->prepare(
            "SELECT id, occurred_at, location, reason, details
             FROM observations
             WHERE student_id = :student_id AND status = 'confirmed'
             ORDER BY occurred_at DESC, id DESC LIMIT 200"
        );
        $statement->execute(['student_id' => $studentId]);
        jsonResponse([
            'student' => $this->studentOutput($student),
            'observations' => $statement->fetchAll(),
        ]);
    }

    private function ppReport(): void
    {
        requireMethod('GET');
        $user = $this->auth->requireUser();
        if ($user['pp_class'] === null || trim((string) $user['pp_class']) === '') {
            throw new HttpException(403, 'Aucune classe PP ne vous est attribuée.');
        }
        $cutoff = gmdate('Y-m-d H:i:s', time() - 7 * 86400);
        $statement = $this->database->pdo()->prepare(
            "SELECT o.id, o.occurred_at, o.location, o.reason, o.details,
                    s.first_name, s.last_name, s.class_name
             FROM observations o
             JOIN students s ON s.id = o.student_id
             WHERE o.status = 'confirmed' AND o.occurred_at >= :cutoff
               AND s.school_year = :school_year AND s.class_name = :class_name
             ORDER BY o.occurred_at DESC, o.id DESC"
        );
        $statement->execute([
            'cutoff' => $cutoff,
            'school_year' => $this->config['app']['school_year'],
            'class_name' => $user['pp_class'],
        ]);
        jsonResponse([
            'class_name' => $user['pp_class'],
            'period_days' => 7,
            'observations' => $statement->fetchAll(),
        ]);
    }

    private function adminUsers(): void
    {
        requireMethod('GET');
        $this->auth->requireRoles(['admin']);
        $pdo = $this->database->pdo();
        $users = $pdo->query(
            'SELECT id, ldap_uid, first_name, last_name, email, role, pp_class, active, last_login_at
             FROM users ORDER BY last_name, first_name, ldap_uid'
        )->fetchAll();
        $classes = $pdo->prepare(
            'SELECT DISTINCT class_name FROM students
             WHERE school_year = :school_year AND active = 1 ORDER BY class_name'
        );
        $classes->execute(['school_year' => $this->config['app']['school_year']]);
        $authorizedUsers = $pdo->query(
            'SELECT id, ldap_uid, label, preassigned_role, preassigned_pp_class,
                    access_expires_at, active, created_at
             FROM authorized_users ORDER BY active DESC, ldap_uid'
        )->fetchAll();
        $years = $pdo->query(
            'SELECT DISTINCT school_year FROM students ORDER BY school_year DESC'
        )->fetchAll();
        $schoolYears = array_column($years, 'school_year');
        if (!in_array($this->config['app']['school_year'], $schoolYears, true)) {
            array_unshift($schoolYears, $this->config['app']['school_year']);
        }
        $closedYears = $pdo->query(
            'SELECT id, school_year, closed_at, student_count, observation_count
             FROM year_closures ORDER BY school_year DESC'
        )->fetchAll();
        $cleanup = [
            'last_applied_at' => null,
            'status' => null,
            'result' => null,
        ];
        $cleanupSettings = $pdo->query(
            "SELECT setting_key, setting_value FROM app_settings
             WHERE setting_key IN (
                 'privacy_cleanup_last_applied_at',
                 'privacy_cleanup_last_status',
                 'privacy_cleanup_last_result'
             )"
        );
        foreach ($cleanupSettings->fetchAll() as $setting) {
            $key = (string) $setting['setting_key'];
            $value = (string) $setting['setting_value'];
            if ($key === 'privacy_cleanup_last_applied_at') {
                $cleanup['last_applied_at'] = $value;
            } elseif ($key === 'privacy_cleanup_last_status') {
                $cleanup['status'] = $value;
            } elseif ($key === 'privacy_cleanup_last_result') {
                $decoded = json_decode($value, true);
                $cleanup['result'] = is_array($decoded) ? $decoded : null;
            }
        }
        jsonResponse([
            'users' => $users,
            'classes' => array_column($classes->fetchAll(), 'class_name'),
            'roles' => self::ROLES,
            'authorized_users' => $authorizedUsers,
            'school_years' => array_values(array_unique($schoolYears)),
            'active_school_year' => $this->config['app']['school_year'],
            'closed_years' => $closedYears,
            'cleanup' => $cleanup,
        ]);
    }

    private function adminUpdateUser(): void
    {
        requireMethod('POST');
        $admin = $this->auth->requireRoles(['admin']);
        requireCsrf($this->auth);
        $input = jsonInput();
        $id = isset($input['id']) ? (int) $input['id'] : 0;
        $role = isset($input['role']) ? (string) $input['role'] : '';
        $ppClass = isset($input['pp_class']) ? trim((string) $input['pp_class']) : '';
        $active = !isset($input['active']) || (bool) $input['active'];
        if ($id <= 0 || !in_array($role, self::ROLES, true)) {
            throw new HttpException(422, 'Compte ou rôle invalide.');
        }
        if ($role === 'pp' && $ppClass === '') {
            throw new HttpException(422, 'Une classe doit être attribuée au PP.');
        }
        if ($this->length($ppClass) > 32) {
            throw new HttpException(422, 'Nom de classe trop long.');
        }
        if ($ppClass !== '') {
            $classCheck = $this->database->pdo()->prepare(
                'SELECT 1 FROM students
                 WHERE school_year = :school_year AND active = 1 AND class_name = :class_name LIMIT 1'
            );
            $classCheck->execute([
                'school_year' => $this->config['app']['school_year'],
                'class_name' => $ppClass,
            ]);
            if (!$classCheck->fetchColumn()) {
                throw new HttpException(422, 'Cette classe n’existe pas dans l’annuaire actif.');
            }
        }

        $bootstrapAdmins = array_map('strtolower', $this->config['ldap']['bootstrap_admins']);
        $this->database->transaction(function (PDO $pdo) use (
            $id,
            $role,
            $ppClass,
            $active,
            $admin,
            $bootstrapAdmins
        ): void {
            $lookup = $pdo->prepare('SELECT ldap_uid FROM users WHERE id = :id FOR UPDATE');
            $lookup->execute(['id' => $id]);
            $target = $lookup->fetch();
            if (!$target) {
                throw new HttpException(404, 'Compte introuvable.');
            }
            $isBootstrapAdmin = in_array(strtolower((string) $target['ldap_uid']), $bootstrapAdmins, true);
            if ($isBootstrapAdmin && ($role !== 'admin' || !$active)) {
                throw new HttpException(422, 'L’administrateur initial ne peut pas être désactivé ni rétrogradé ici.');
            }
            if (!$isBootstrapAdmin && $role === 'admin') {
                throw new HttpException(422, 'Le rôle administrateur est réservé aux administrateurs initiaux configurés sur le serveur.');
            }

            $statement = $pdo->prepare(
                'UPDATE users SET role = :role, pp_class = :pp_class, active = :active WHERE id = :id'
            );
            $statement->execute([
                'role' => $role,
                'pp_class' => $ppClass !== '' ? $ppClass : null,
                'active' => $active ? 1 : 0,
                'id' => $id,
            ]);
            auditLog($this->database, (int) $admin['id'], 'user.update', 'user', $id, [
                'role' => $role,
                'pp_class' => $ppClass !== '' ? $ppClass : null,
                'active' => $active,
            ], $pdo);
        });
        jsonResponse(['ok' => true]);
    }

    private function adminAddAuthorizedUser(): void
    {
        requireMethod('POST');
        $admin = $this->auth->requireRoles(['admin']);
        requireCsrf($this->auth);
        $input = jsonInput();
        $uid = strtolower(trim(isset($input['uid']) ? (string) $input['uid'] : ''));
        $label = trim(isset($input['label']) ? (string) $input['label'] : '');
        $role = isset($input['role']) ? trim((string) $input['role']) : 'teacher';
        $ppClass = isset($input['pp_class']) ? trim((string) $input['pp_class']) : '';
        $expiresInput = isset($input['access_expires_at']) ? trim((string) $input['access_expires_at']) : '';
        if (!preg_match('/^[a-z0-9._-]{1,64}$/i', $uid) || $this->length($label) > 128) {
            throw new HttpException(422, 'Identifiant ou libellé invalide.');
        }
        if (!in_array($role, ['teacher', 'aed', 'cpe', 'direction', 'pp', 'service'], true)) {
            throw new HttpException(422, 'Rôle préattribué invalide.');
        }
        if ($role === 'pp' && $ppClass === '') {
            throw new HttpException(422, 'Choisissez la classe du professeur principal.');
        }
        if ($role !== 'pp') {
            $ppClass = '';
        }
        if ($this->length($ppClass) > 32) {
            throw new HttpException(422, 'Classe invalide.');
        }
        if ($ppClass !== '') {
            $classCheck = $this->database->pdo()->prepare(
                'SELECT 1 FROM students
                 WHERE school_year = :school_year AND active = 1 AND class_name = :class_name LIMIT 1'
            );
            $classCheck->execute([
                'school_year' => $this->config['app']['school_year'],
                'class_name' => $ppClass,
            ]);
            if (!$classCheck->fetchColumn()) {
                throw new HttpException(422, 'Cette classe n’existe pas dans l’année active.');
            }
        }
        $expiresAt = $this->parseOptionalLocalDateTime($expiresInput);
        if ($expiresAt !== null && strtotime($expiresAt . ' UTC') <= time()) {
            throw new HttpException(422, 'La date d’expiration doit être future.');
        }
        $bootstrapAdmins = array_map('strtolower', $this->config['ldap']['bootstrap_admins']);
        if (in_array($uid, $bootstrapAdmins, true)) {
            throw new HttpException(422, 'Le compte administrateur initial est géré par la configuration du serveur.');
        }
        $this->database->transaction(function (PDO $pdo) use (
            $uid,
            $label,
            $role,
            $ppClass,
            $expiresAt,
            $admin
        ): void {
            $statement = $pdo->prepare(
                'INSERT INTO authorized_users
                    (ldap_uid, label, preassigned_role, preassigned_pp_class,
                     access_expires_at, active, created_by)
                 VALUES
                    (:ldap_uid, :label, :preassigned_role, :preassigned_pp_class,
                     :access_expires_at, 1, :created_by)
                 ON DUPLICATE KEY UPDATE
                    label = VALUES(label), preassigned_role = VALUES(preassigned_role),
                    preassigned_pp_class = VALUES(preassigned_pp_class),
                    access_expires_at = VALUES(access_expires_at), active = 1,
                    created_by = VALUES(created_by)'
            );
            $statement->execute([
                'ldap_uid' => $uid,
                'label' => $label,
                'preassigned_role' => $role,
                'preassigned_pp_class' => $ppClass !== '' ? $ppClass : null,
                'access_expires_at' => $expiresAt,
                'created_by' => $admin['id'],
            ]);
            $reactivate = $pdo->prepare(
                'UPDATE users
                 SET active = 1, role = :role, pp_class = :pp_class
                 WHERE ldap_uid = :ldap_uid'
            );
            $reactivate->execute([
                'role' => $role,
                'pp_class' => $ppClass !== '' ? $ppClass : null,
                'ldap_uid' => $uid,
            ]);
            auditLog($this->database, (int) $admin['id'], 'access.authorize', 'authorized_user', null, [
                'uid' => $uid,
                'role' => $role,
                'pp_class' => $ppClass !== '' ? $ppClass : null,
                'expires' => $expiresAt !== null,
            ], $pdo);
        });
        jsonResponse(['ok' => true]);
    }

    private function adminRemoveAuthorizedUser(): void
    {
        requireMethod('POST');
        $admin = $this->auth->requireRoles(['admin']);
        requireCsrf($this->auth);
        $input = jsonInput();
        $id = isset($input['id']) ? (int) $input['id'] : 0;
        if ($id <= 0) {
            throw new HttpException(422, 'Autorisation invalide.');
        }
        $bootstrapAdmins = array_map(
            'strtolower',
            isset($this->config['ldap']['bootstrap_admins']) && is_array($this->config['ldap']['bootstrap_admins'])
                ? $this->config['ldap']['bootstrap_admins']
                : []
        );
        $this->database->transaction(function (PDO $pdo) use ($id, $admin, $bootstrapAdmins): void {
            $lookup = $pdo->prepare('SELECT ldap_uid FROM authorized_users WHERE id = :id FOR UPDATE');
            $lookup->execute(['id' => $id]);
            $entry = $lookup->fetch();
            if (!$entry) {
                throw new HttpException(404, 'Autorisation introuvable.');
            }
            if (in_array(strtolower((string) $entry['ldap_uid']), $bootstrapAdmins, true)) {
                throw new HttpException(422, 'L’accès de l’administrateur initial ne peut pas être retiré.');
            }
            $statement = $pdo->prepare('UPDATE authorized_users SET active = 0 WHERE id = :id');
            $statement->execute(['id' => $id]);
            $disableUser = $pdo->prepare('UPDATE users SET active = 0 WHERE ldap_uid = :ldap_uid');
            $disableUser->execute(['ldap_uid' => (string) $entry['ldap_uid']]);
            auditLog($this->database, (int) $admin['id'], 'access.revoke', 'authorized_user', $id, [
                'uid' => (string) $entry['ldap_uid'],
            ], $pdo);
        });
        jsonResponse(['ok' => true]);
    }

    private function adminSetSchoolYear(): void
    {
        requireMethod('POST');
        $admin = $this->auth->requireRoles(['admin']);
        requireCsrf($this->auth);
        $input = jsonInput();
        $schoolYear = trim(isset($input['school_year']) ? (string) $input['school_year'] : '');
        if (!preg_match('/^(\d{4})-(\d{4})$/', $schoolYear, $matches) || (int) $matches[2] !== (int) $matches[1] + 1) {
            throw new HttpException(422, 'Année scolaire invalide. Exemple : 2027-2028.');
        }
        $this->database->transaction(function (PDO $pdo) use ($schoolYear, $admin): void {
            // Même ordre de verrous que la clôture : année active, puis
            // registre des clôtures. Cela évite une interversion concurrente.
            $activeSetting = $pdo->prepare(
                'SELECT setting_value FROM app_settings
                 WHERE setting_key = :setting_key FOR UPDATE'
            );
            $activeSetting->execute(['setting_key' => 'active_school_year']);
            $previousSchoolYear = $activeSetting->fetchColumn();
            if (!is_string($previousSchoolYear) || $previousSchoolYear === '') {
                throw new HttpException(409, 'L’année scolaire active est indisponible.');
            }
            $closed = $pdo->prepare(
                'SELECT id FROM year_closures WHERE school_year = :school_year FOR UPDATE'
            );
            $closed->execute(['school_year' => $schoolYear]);
            if ($closed->fetchColumn() !== false) {
                throw new HttpException(409, 'Une année scolaire clôturée ne peut pas redevenir l’année active.');
            }
            $statement = $pdo->prepare(
                'INSERT INTO app_settings (setting_key, setting_value)
                 VALUES (:setting_key, :setting_value)
                 ON DUPLICATE KEY UPDATE setting_value = VALUES(setting_value)'
            );
            $statement->execute(['setting_key' => 'active_school_year', 'setting_value' => $schoolYear]);
            auditLog($this->database, (int) $admin['id'], 'school_year.change', 'app_setting', null, [
                'previous' => $previousSchoolYear,
                'new' => $schoolYear,
            ], $pdo);
        });
        jsonResponse(['ok' => true, 'school_year' => $schoolYear]);
    }

    private function adminSetPointsEnabled(): void
    {
        requireMethod('POST');
        $admin = $this->auth->requireRoles(['admin']);
        requireCsrf($this->auth);
        $input = jsonInput();
        if (!array_key_exists('enabled', $input) || !is_bool($input['enabled'])) {
            throw new HttpException(422, 'L’état du module permis à points est invalide.');
        }
        $enabled = $input['enabled'];
        $defaultEnabled = $this->pointsEnabled();

        $this->database->transaction(function (PDO $pdo) use ($admin, $enabled, $defaultEnabled): void {
            // On matérialise la valeur par défaut issue de la configuration
            // afin de verrouiller la ligne et journaliser l'état précédent exact.
            $ensureSetting = $pdo->prepare(
                'INSERT IGNORE INTO app_settings (setting_key, setting_value)
                 VALUES (:setting_key, :setting_value)'
            );
            $ensureSetting->execute([
                'setting_key' => 'points_enabled',
                'setting_value' => $defaultEnabled ? '1' : '0',
            ]);
            $lookup = $pdo->prepare(
                'SELECT setting_value FROM app_settings WHERE setting_key = :setting_key FOR UPDATE'
            );
            $lookup->execute(['setting_key' => 'points_enabled']);
            $previousRaw = strtolower(trim((string) $lookup->fetchColumn()));
            $previous = in_array($previousRaw, ['1', 'true', 'yes', 'on'], true);

            $setting = $pdo->prepare(
                'UPDATE app_settings SET setting_value = :setting_value WHERE setting_key = :setting_key'
            );
            $setting->execute([
                'setting_key' => 'points_enabled',
                'setting_value' => $enabled ? '1' : '0',
            ]);
            auditLog($this->database, (int) $admin['id'], 'points.module_toggle', 'app_setting', null, [
                'previous' => $previous,
                'enabled' => $enabled,
            ], $pdo);
        });
        $this->pointsEnabledCache = $enabled;
        jsonResponse(['ok' => true, 'enabled' => $enabled]);
    }

    private function adminSetDigitalPassesEnabled(): void
    {
        requireMethod('POST');
        $admin = $this->auth->requireRoles(['admin']);
        requireCsrf($this->auth);
        $input = jsonInput();
        if (!array_key_exists('enabled', $input) || !is_bool($input['enabled'])) {
            throw new HttpException(422, 'L’état du module billets numériques est invalide.');
        }
        $enabled = (bool) $input['enabled'];
        $previous = $this->digitalPassesEnabled();
        $this->database->transaction(function (PDO $pdo) use ($admin, $enabled, $previous): void {
            $ensureSetting = $pdo->prepare(
                'INSERT IGNORE INTO app_settings (setting_key, setting_value)
                 VALUES (:setting_key, :setting_value)'
            );
            $ensureSetting->execute([
                'setting_key' => 'digital_passes_enabled',
                'setting_value' => $previous ? '1' : '0',
            ]);
            // Le même verrou est pris lors de l'émission d'un billet. Une
            // désactivation ne peut donc pas courir avec une création.
            $settingLock = $pdo->prepare(
                'SELECT setting_value FROM app_settings
                 WHERE setting_key = :setting_key FOR UPDATE'
            );
            $settingLock->execute(['setting_key' => 'digital_passes_enabled']);
            $previousRaw = strtolower(trim((string) $settingLock->fetchColumn()));
            $lockedPrevious = in_array($previousRaw, ['1', 'true', 'yes', 'on'], true);

            if (!$enabled) {
                $activePass = $pdo->query(
                    'SELECT id FROM digital_passes
                     WHERE revoked_at IS NULL AND expires_at > UTC_TIMESTAMP()
                     LIMIT 1'
                );
                if ($activePass->fetchColumn() !== false) {
                    throw new HttpException(
                        409,
                        'Des billets sont encore actifs. Attendez leur expiration ou révoquez-les avant de désactiver le module.'
                    );
                }
            }

            $setting = $pdo->prepare(
                'UPDATE app_settings SET setting_value = :setting_value
                 WHERE setting_key = :setting_key'
            );
            $setting->execute([
                'setting_key' => 'digital_passes_enabled',
                'setting_value' => $enabled ? '1' : '0',
            ]);
            auditLog($this->database, (int) $admin['id'], 'digital_pass.module_toggle', 'app_setting', null, [
                'previous' => $lockedPrevious,
                'enabled' => $enabled,
            ], $pdo);
        });
        $this->digitalPassesEnabledCache = $enabled;
        jsonResponse(['ok' => true, 'enabled' => $enabled]);
    }

    private function adminSetDeferredSubmissionsEnabled(): void
    {
        requireMethod('POST');
        $admin = $this->auth->requireRoles(['admin']);
        requireCsrf($this->auth);
        $input = jsonInput();
        if (!array_key_exists('enabled', $input) || !is_bool($input['enabled'])) {
            throw new HttpException(422, 'L’état de l’envoi différé est invalide.');
        }
        $enabled = (bool) $input['enabled'];
        $previous = $this->deferredSubmissionsEnabled();
        $this->database->transaction(function (PDO $pdo) use ($admin, $enabled, $previous): void {
            $ensureSetting = $pdo->prepare(
                'INSERT IGNORE INTO app_settings (setting_key, setting_value)
                 VALUES (:setting_key, :setting_value)'
            );
            $ensureSetting->execute([
                'setting_key' => 'deferred_submissions_enabled',
                'setting_value' => $previous ? '1' : '0',
            ]);
            $settingLock = $pdo->prepare(
                'SELECT setting_value FROM app_settings
                 WHERE setting_key = :setting_key FOR UPDATE'
            );
            $settingLock->execute(['setting_key' => 'deferred_submissions_enabled']);
            $previousRaw = strtolower(trim((string) $settingLock->fetchColumn()));
            $lockedPrevious = in_array($previousRaw, ['1', 'true', 'yes', 'on'], true);

            $setting = $pdo->prepare(
                'UPDATE app_settings SET setting_value = :setting_value
                 WHERE setting_key = :setting_key'
            );
            $setting->execute([
                'setting_key' => 'deferred_submissions_enabled',
                'setting_value' => $enabled ? '1' : '0',
            ]);
            auditLog($this->database, (int) $admin['id'], 'submission_queue.module_toggle', 'app_setting', null, [
                'previous' => $lockedPrevious,
                'enabled' => $enabled,
            ], $pdo);
        });
        $this->deferredSubmissionsEnabledCache = $enabled;
        jsonResponse(['ok' => true, 'enabled' => $enabled]);
    }

    private function anonymousReport(): void
    {
        requireMethod('GET');
        $this->auth->requireRoles(self::DASHBOARD_ROLES);
        $days = isset($_GET['days']) ? (int) $_GET['days'] : 28;
        try {
            $report = $this->finalAdmin->anonymousReport(
                (string) $this->config['app']['school_year'],
                $days
            );
        } catch (InvalidArgumentException $error) {
            throw new HttpException(422, $error->getMessage());
        }
        jsonResponse(['report' => $report]);
    }

    private function adminHealth(): void
    {
        requireMethod('GET');
        $this->auth->requireRoles(['admin']);
        try {
            $health = $this->finalAdmin->health((string) $this->config['app']['school_year']);
        } catch (InvalidArgumentException $error) {
            throw new HttpException(422, $error->getMessage());
        }
        $mysqlStartedAt = microtime(true);
        $mysqlOk = false;
        try {
            $mysqlOk = (int) $this->database->pdo()->query('SELECT 1')->fetchColumn() === 1;
        } catch (Throwable $error) {
            $mysqlOk = false;
        }
        $ldapHealth = $this->ldap !== null
            ? $this->ldap->healthCheck()
            : ['ok' => false, 'latency_ms' => null, 'message' => 'Service LDAP non configuré.'];
        $varPath = defined('SC_ROOT') ? SC_ROOT . '/var' : dirname(__DIR__) . '/var';
        $settingsPath = $varPath . '/settings.php';
        $lastBackupAt = isset($health['last_backup']['created_at'])
            ? strtotime((string) $health['last_backup']['created_at'] . ' UTC')
            : false;
        $backupFresh = $lastBackupAt !== false && $lastBackupAt >= time() - 86400;
        $health['services'] = [
            'mysql' => [
                'ok' => $mysqlOk,
                'latency_ms' => (int) round((microtime(true) - $mysqlStartedAt) * 1000),
                'message' => $mysqlOk ? 'Base MySQL joignable.' : 'Base MySQL indisponible.',
            ],
            'ldap' => $ldapHealth,
            'storage' => [
                'ok' => is_dir($varPath) && is_writable($varPath) && is_readable($settingsPath),
                'latency_ms' => null,
                'message' => is_dir($varPath) && is_writable($varPath) && is_readable($settingsPath)
                    ? 'Configuration lisible et dossier var accessible.'
                    : 'Vérifiez les droits du dossier var et de settings.php.',
            ],
            'recovery' => [
                'ok' => $backupFresh,
                'latency_ms' => null,
                'message' => $backupFresh
                    ? 'Point de récupération créé depuis moins de 24 heures.'
                    : 'Aucun point récent : créez-en un avant une opération importante.',
            ],
        ];
        $health['app_version'] = defined('SC_APP_VERSION') ? SC_APP_VERSION : '0.0.0-dev';
        jsonResponse(['health' => $health]);
    }

    private function adminYearClosurePreview(): void
    {
        requireMethod('GET');
        $this->auth->requireRoles(['admin']);
        $schoolYear = trim(isset($_GET['school_year']) ? (string) $_GET['school_year'] : '');
        if ($schoolYear === (string) $this->config['app']['school_year']) {
            throw new HttpException(409, 'L’année active ne peut pas être clôturée. Activez d’abord la nouvelle année.');
        }
        try {
            $preview = $this->finalAdmin->closurePreview($schoolYear);
        } catch (InvalidArgumentException $error) {
            throw new HttpException(422, $error->getMessage());
        }
        $preview['confirmation'] = 'CLOTURER ' . $schoolYear;
        jsonResponse(['preview' => $preview]);
    }

    private function adminCloseYear(): void
    {
        requireMethod('POST');
        $admin = $this->auth->requireRoles(['admin']);
        requireCsrf($this->auth);
        $input = jsonInput();
        $schoolYear = trim(isset($input['school_year']) ? (string) $input['school_year'] : '');
        $password = isset($input['password']) ? (string) $input['password'] : '';
        $confirmation = trim(isset($input['confirmation']) ? (string) $input['confirmation'] : '');
        if ($schoolYear === '' || $schoolYear === (string) $this->config['app']['school_year']) {
            throw new HttpException(409, 'L’année active ne peut pas être clôturée. Activez d’abord la nouvelle année.');
        }
        $expected = 'CLOTURER ' . $schoolYear;
        if ($confirmation === '' || !hash_equals($expected, $confirmation)) {
            throw new HttpException(422, 'La phrase de confirmation ne correspond pas exactement.');
        }
        $this->auth->reauthenticate($password);
        $recovery = $this->requireRecovery();
        $recovery->acquireMutationLock(10);
        $snapshot = $recovery->createManual((int) $admin['id']);
        try {
            $result = $this->finalAdmin->closeYear(
                $schoolYear,
                (int) $admin['id'],
                isset($snapshot['id']) ? (int) $snapshot['id'] : null,
                function (PDO $pdo, string $action, string $entityType, int $entityId, array $metadata) use ($admin): void {
                    auditLog(
                        $this->database,
                        (int) $admin['id'],
                        $action,
                        $entityType,
                        $entityId,
                        $metadata,
                        $pdo
                    );
                }
            );
        } catch (PDOException $error) {
            throw new HttpException(500, 'La clôture n’a pas pu être appliquée. Aucune purge partielle n’a été conservée.');
        } catch (InvalidArgumentException $error) {
            throw new HttpException(422, $error->getMessage());
        } catch (RuntimeException $error) {
            throw new HttpException(409, $error->getMessage());
        }
        jsonResponse(['ok' => true, 'result' => $result]);
    }

    private function recoveryStatus(): void
    {
        requireMethod('GET');
        $this->auth->requireRoles(['admin']);
        $recovery = $this->requireRecovery();
        $recovery->createAutomaticIfDue();
        $status = $recovery->status();
        $configuredLimit = isset($this->config['recovery']['list_limit'])
            ? (int) $this->config['recovery']['list_limit']
            : 30;
        $status['snapshots'] = $recovery->listSnapshots(max(5, min($configuredLimit, 100)));
        $status['environment'] = $this->recoveryEnvironment();
        $status['purge_confirmation'] = $this->purgeConfirmation();
        $status['restore_confirmation_prefix'] = $this->restoreConfirmationPrefix();
        jsonResponse($status);
    }

    private function adminCreateSnapshot(): void
    {
        requireMethod('POST');
        $admin = $this->auth->requireRoles(['admin']);
        requireCsrf($this->auth);
        $snapshot = $this->requireRecovery()->createManual((int) $admin['id']);
        jsonResponse(array_merge(['ok' => true], $snapshot));
    }

    private function adminPurgeStudents(): void
    {
        requireMethod('POST');
        $admin = $this->auth->requireRoles(['admin']);
        requireCsrf($this->auth);
        $input = jsonInput();
        $confirmation = isset($input['confirmation']) ? trim((string) $input['confirmation']) : '';
        $password = isset($input['password']) ? (string) $input['password'] : '';
        $expected = $this->purgeConfirmation();
        if ($confirmation === '' || !hash_equals($expected, $confirmation)) {
            throw new HttpException(422, 'La phrase de confirmation ne correspond pas exactement.');
        }
        $this->auth->reauthenticate($password);
        $result = $this->requireRecovery()->purgeAll((int) $admin['id']);
        jsonResponse(array_merge(['ok' => true], $result));
    }

    private function adminRestoreSnapshot(): void
    {
        requireMethod('POST');
        $admin = $this->auth->requireRoles(['admin']);
        requireCsrf($this->auth);
        $input = jsonInput();
        $snapshotId = isset($input['snapshot_id']) ? (int) $input['snapshot_id'] : 0;
        $confirmation = isset($input['confirmation']) ? trim((string) $input['confirmation']) : '';
        $password = isset($input['password']) ? (string) $input['password'] : '';
        if ($snapshotId <= 0) {
            throw new HttpException(422, 'Point de récupération invalide.');
        }
        $expected = $this->restoreConfirmationPrefix() . ' ' . $snapshotId;
        if ($confirmation === '' || !hash_equals($expected, $confirmation)) {
            throw new HttpException(422, 'La phrase de confirmation ne correspond pas exactement.');
        }
        $this->auth->reauthenticate($password);
        $result = $this->requireRecovery()->restore($snapshotId, (int) $admin['id']);
        jsonResponse(array_merge(['ok' => true], $result));
    }

    private function requireRecovery(): RecoveryService
    {
        if ($this->recovery === null) {
            throw new HttpException(503, 'Les points de récupération ne sont pas disponibles sur cette installation.');
        }
        return $this->recovery;
    }

    private function tryCreateAutomaticRecovery(): void
    {
        if ($this->recovery === null) {
            return;
        }
        try {
            $this->recovery->createAutomaticIfDue();
        } catch (Throwable $error) {
            // Une sauvegarde automatique ne doit jamais interrompre la saisie
            // d’un personnel. L’ancien point reste disponible et la référence
            // permet de diagnostiquer l’échec sans exposer son détail au client.
            $reference = bin2hex(random_bytes(6));
            error_log(sprintf(
                '[Suivi récupération automatique %s] %s code=%d source=%s:%d',
                $reference,
                get_class($error),
                (int) $error->getCode(),
                basename($error->getFile()),
                $error->getLine()
            ));
        }
    }

    private function recoveryEnvironment(): string
    {
        $environment = isset($this->config['app']['environment'])
            ? strtolower((string) $this->config['app']['environment'])
            : 'production';
        return $environment === 'test' ? 'test' : 'production';
    }

    private function purgeConfirmation(): string
    {
        return 'VIDER ' . strtoupper($this->recoveryEnvironment())
            . ' ' . (string) $this->config['app']['school_year'];
    }

    private function restoreConfirmationPrefix(): string
    {
        return 'RESTAURER ' . strtoupper($this->recoveryEnvironment());
    }

    private function auditLogs(): void
    {
        requireMethod('GET');
        $this->auth->requireRoles(['admin']);
        $statement = $this->database->pdo()->query(
            'SELECT a.id, a.action, a.entity_type, a.entity_id, a.metadata, a.created_at,
                    u.ldap_uid, u.first_name, u.last_name
             FROM audit_logs a LEFT JOIN users u ON u.id = a.user_id
             ORDER BY a.created_at DESC, a.id DESC LIMIT 250'
        );
        $rows = [];
        foreach ($statement->fetchAll() as $row) {
            $row['metadata'] = $row['metadata'] !== null ? json_decode((string) $row['metadata'], true) : null;
            $rows[] = $row;
        }
        jsonResponse(['logs' => $rows]);
    }

    private function adminSyncStudents(): void
    {
        requireMethod('POST');
        $admin = $this->auth->requireRoles(['admin']);
        requireCsrf($this->auth);
        $input = jsonInput();
        $apply = !empty($input['apply']);
        $previewToken = isset($input['preview_token']) ? (string) $input['preview_token'] : '';
        $schoolYear = (string) $this->config['app']['school_year'];

        if ($this->ldap === null) {
            throw new HttpException(503, 'Annuaire LDAP indisponible.');
        }

        $ldapConfig = isset($this->config['ldap']) && is_array($this->config['ldap'])
            ? $this->config['ldap']
            : [];
        $patternSource = isset($ldapConfig['class_group_pattern']) && trim((string) $ldapConfig['class_group_pattern']) !== ''
            ? trim((string) $ldapConfig['class_group_pattern'])
            : '^c([3-6])g([0-9]{1,2})$';
        $pattern = '~' . str_replace('~', '\\~', $patternSource) . '~i';
        if (@preg_match($pattern, '') === false) {
            throw new HttpException(500, 'Le motif des groupes-classes LDAP est invalide dans la configuration.');
        }
        $labelFormat = isset($ldapConfig['class_label_format']) && trim((string) $ldapConfig['class_label_format']) !== ''
            ? trim((string) $ldapConfig['class_label_format'])
            : '{n}G{g}';

        try {
            $rows = $this->ldap->listStudentsByClassGroups($pattern);
        } catch (RuntimeException $error) {
            throw new HttpException(502, 'Synchronisation LDAP impossible : ' . $error->getMessage());
        }

        $studentsByRef = [];
        $classes = [];
        $conflicts = [];
        $skipped = 0;
        foreach ($rows as $row) {
            $uid = strtolower(trim(isset($row['uid']) ? (string) $row['uid'] : ''));
            $firstName = trim(isset($row['first_name']) ? (string) $row['first_name'] : '');
            $lastName = trim(isset($row['last_name']) ? (string) $row['last_name'] : '');
            $matches = isset($row['matches']) && is_array($row['matches']) ? $row['matches'] : [];
            if (!preg_match('/^[a-z0-9._-]{1,128}$/i', $uid)
                || $firstName === '' || $lastName === ''
                || $this->length($firstName) > 128 || $this->length($lastName) > 128
                || !isset($matches[0])) {
                $skipped++;
                continue;
            }
            $className = strtoupper(str_replace(
                ['{n}', '{g}', '{cn}'],
                [isset($matches[1]) ? (string) $matches[1] : '', isset($matches[2]) ? (string) $matches[2] : '', (string) $matches[0]],
                $labelFormat
            ));
            if (!preg_match('/^[A-Z0-9][A-Z0-9 ._-]{0,31}$/', $className)) {
                throw new HttpException(422, 'Le libellé de classe « ' . $className . ' » est invalide. Vérifiez class_label_format.');
            }
            if (isset($studentsByRef[$uid])) {
                $skipped++;
                continue;
            }
            $studentsByRef[$uid] = [
                'external_ref' => $uid,
                'first_name' => $firstName,
                'last_name' => $lastName,
                'class_name' => $className,
            ];
            $classes[$className] = isset($classes[$className]) ? $classes[$className] + 1 : 1;
            if (!empty($row['conflict_groups'])) {
                $conflicts[] = $lastName . ' ' . $firstName . ' (' . $uid . ') — classe retenue '
                    . $className . ', autre(s) groupe(s) : ' . implode(', ', (array) $row['conflict_groups']);
            }
        }
        ksort($studentsByRef);
        ksort($classes);
        $students = array_values($studentsByRef);

        if (count($students) < 20) {
            throw new HttpException(422, 'Seulement ' . count($students) . ' élève(s) trouvé(s) dans l’annuaire — '
                . 'synchronisation refusée par sécurité. Vérifiez le motif des groupes-classes ou utilisez l’import CSV.');
        }
        if (count($students) > 2000) {
            throw new HttpException(422, 'Plus de 2 000 comptes correspondent aux groupes-classes — synchronisation refusée par sécurité.');
        }

        $activeCountStatement = $this->database->pdo()->prepare(
            'SELECT COUNT(*) FROM students WHERE school_year = :school_year AND active = 1'
        );
        $activeCountStatement->execute(['school_year' => $schoolYear]);
        $activeBefore = (int) $activeCountStatement->fetchColumn();
        $minimumExpected = $activeBefore > 0 ? (int) ceil($activeBefore * 0.8) : 0;
        $safeToApply = $minimumExpected === 0 || count($students) >= $minimumExpected;

        $sourceJson = json_encode($students, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
        if (!is_string($sourceJson)) {
            throw new HttpException(500, 'Impossible de préparer l’aperçu LDAP.');
        }
        $sourceHash = hash('sha256', 'ldap:' . $sourceJson);
        $expectedToken = hash_hmac(
            'sha256',
            $schoolYear . '|' . $sourceHash,
            (string) $this->config['app']['key']
        );

        if (!$apply) {
            $suspicious = [];
            foreach ($students as $student) {
                if ($classes[$student['class_name']] <= 3) {
                    $suspicious[$student['class_name']][] = $student['last_name'] . ' ' . $student['first_name']
                        . ' (' . $student['external_ref'] . ')';
                }
            }
            ksort($suspicious);
            jsonResponse([
                'preview' => true,
                'preview_token' => $expectedToken,
                'safe_to_apply' => $safeToApply,
                'warning' => $safeToApply ? null : 'La liste trouvée représente moins de 80 % des ' . $activeBefore
                    . ' élèves actuellement actifs. L’application est bloquée pour éviter une désactivation massive.',
                'student_count' => count($students),
                'active_before' => $activeBefore,
                'class_count' => count($classes),
                'skipped' => $skipped,
                'classes' => array_map(static function (string $name, int $total): array {
                    return ['class_name' => $name, 'total' => $total];
                }, array_keys($classes), array_values($classes)),
                'suspicious' => array_map(static function (string $name, array $members): array {
                    return ['class_name' => $name, 'members' => $members];
                }, array_keys($suspicious), array_values($suspicious)),
                'conflicts' => $conflicts,
            ]);
        }

        if ($previewToken === '' || !hash_equals($expectedToken, $previewToken)) {
            throw new HttpException(409, 'L’annuaire a changé depuis l’aperçu ou l’aperçu a expiré. Relancez l’analyse avant d’appliquer.');
        }
        if (!$safeToApply) {
            throw new HttpException(409, 'Synchronisation bloquée : l’effectif LDAP trouvé est anormalement inférieur à la liste active.');
        }

        if ($this->recovery !== null) {
            $this->recovery->acquireMutationLock(5);
        }
        $this->database->transaction(function (PDO $pdo) use (
            $students,
            $sourceHash,
            $schoolYear,
            $admin,
            $classes,
            $activeBefore
        ): void {
            $deactivate = $pdo->prepare('UPDATE students SET active = 0 WHERE school_year = :school_year');
            $deactivate->execute(['school_year' => $schoolYear]);
            $upsert = $pdo->prepare(
                'INSERT INTO students (external_ref, school_year, first_name, last_name, class_name, active)
                 VALUES (:external_ref, :school_year, :first_name, :last_name, :class_name, 1)
                 ON DUPLICATE KEY UPDATE first_name = VALUES(first_name), last_name = VALUES(last_name),
                                         class_name = VALUES(class_name), active = 1'
            );
            foreach ($students as $student) {
                $upsert->execute([
                    'external_ref' => $student['external_ref'],
                    'school_year' => $schoolYear,
                    'first_name' => $student['first_name'],
                    'last_name' => $student['last_name'],
                    'class_name' => $student['class_name'],
                ]);
            }
            $import = $pdo->prepare(
                'INSERT INTO student_imports (imported_by, school_year, row_count, source_hash)
                 VALUES (:imported_by, :school_year, :row_count, :source_hash)'
            );
            $import->execute([
                'imported_by' => $admin['id'],
                'school_year' => $schoolYear,
                'row_count' => count($students),
                'source_hash' => $sourceHash,
            ]);
            auditLog($this->database, (int) $admin['id'], 'students.ldap_sync', 'student_import', null, [
                'school_year' => $schoolYear,
                'row_count' => count($students),
                'class_count' => count($classes),
                'previous_active' => $activeBefore,
            ], $pdo);
        });
        jsonResponse(['ok' => true, 'row_count' => count($students), 'class_count' => count($classes)], 201);
    }

    private function importStudents(): void
    {
        requireMethod('POST');
        $admin = $this->auth->requireRoles(['admin']);
        requireCsrf($this->auth);
        $apply = isset($_POST['apply']) && (string) $_POST['apply'] === '1';
        $previewToken = isset($_POST['preview_token']) ? trim((string) $_POST['preview_token']) : '';
        if (!isset($_FILES['students']) || !is_array($_FILES['students'])) {
            throw new HttpException(422, 'Sélectionnez un fichier CSV.');
        }
        $file = $_FILES['students'];
        if ((int) $file['error'] !== UPLOAD_ERR_OK || (int) $file['size'] <= 0 || (int) $file['size'] > 2 * 1024 * 1024) {
            throw new HttpException(422, 'Fichier CSV absent, trop volumineux ou invalide.');
        }
        $path = (string) $file['tmp_name'];
        if (!is_uploaded_file($path)) {
            throw new HttpException(422, 'Téléversement invalide.');
        }
        $students = $this->parseStudentsCsv($path);
        if (count($students) === 0) {
            throw new HttpException(422, 'Le fichier ne contient aucun élève exploitable.');
        }
        if (count($students) > 2000) {
            throw new HttpException(422, 'Le fichier contient trop de lignes.');
        }

        $sourceHash = hash_file('sha256', $path);
        if (!is_string($sourceHash) || !preg_match('/^[a-f0-9]{64}$/', $sourceHash)) {
            throw new HttpException(500, 'Impossible de vérifier le contenu du fichier CSV.');
        }
        $schoolYear = (string) $this->config['app']['school_year'];
        $classes = [];
        foreach ($students as $student) {
            $className = (string) $student['class_name'];
            $classes[$className] = isset($classes[$className]) ? $classes[$className] + 1 : 1;
        }
        ksort($classes);

        $activeState = $this->activeStudentsState($this->database->pdo(), $schoolYear, false);
        $activeBefore = $activeState['count'];
        $activeFingerprint = $activeState['fingerprint'];
        $minimumExpected = $activeBefore > 0 ? (int) ceil($activeBefore * 0.8) : 0;
        $safeToApply = $minimumExpected === 0 || count($students) >= $minimumExpected;

        if (!$apply) {
            $issuedAt = time();
            jsonResponse([
                'preview' => true,
                'preview_token' => $this->csvPreviewToken(
                    $schoolYear,
                    $sourceHash,
                    $activeBefore,
                    $activeFingerprint,
                    (int) $admin['id'],
                    $issuedAt
                ),
                'safe_to_apply' => $safeToApply,
                'warning' => $safeToApply ? null : 'Le fichier représente moins de 80 % des ' . $activeBefore
                    . ' élèves actuellement actifs. L’import est bloqué pour éviter une désactivation massive.',
                'student_count' => count($students),
                'active_before' => $activeBefore,
                'class_count' => count($classes),
                'classes' => array_map(static function (string $name, int $total): array {
                    return ['class_name' => $name, 'total' => $total];
                }, array_keys($classes), array_values($classes)),
            ]);
        }

        $this->requireValidCsvPreviewToken(
            $previewToken,
            $schoolYear,
            $sourceHash,
            $activeBefore,
            $activeFingerprint,
            (int) $admin['id']
        );
        if (!$safeToApply) {
            throw new HttpException(409, 'Import bloqué : l’effectif du fichier est anormalement inférieur à la liste active.');
        }

        $snapshotId = null;
        if ($this->recovery !== null) {
            // Le verrou de mutation acquis par dispatch() reste détenu pendant
            // la sauvegarde et l'import : aucun autre changement applicatif ne
            // peut s'intercaler entre l'instantané et la nouvelle liste.
            $snapshot = $this->recovery->createManual((int) $admin['id']);
            $snapshotId = isset($snapshot['id']) ? (int) $snapshot['id'] : null;
        }

        $this->database->transaction(function (PDO $pdo) use (
            $students,
            $sourceHash,
            $schoolYear,
            $admin,
            $classes,
            $activeBefore,
            $activeFingerprint,
            $snapshotId
        ): void {
            $currentState = $this->activeStudentsState($pdo, $schoolYear, true);
            if ($currentState['count'] !== $activeBefore
                || !hash_equals($activeFingerprint, $currentState['fingerprint'])) {
                throw new HttpException(409, 'La liste active a changé depuis l’aperçu. Analysez à nouveau le fichier CSV.');
            }
            $deactivate = $pdo->prepare('UPDATE students SET active = 0 WHERE school_year = :school_year');
            $deactivate->execute(['school_year' => $schoolYear]);
            $upsert = $pdo->prepare(
                'INSERT INTO students (external_ref, school_year, first_name, last_name, class_name, active)
                 VALUES (:external_ref, :school_year, :first_name, :last_name, :class_name, 1)
                 ON DUPLICATE KEY UPDATE first_name = VALUES(first_name), last_name = VALUES(last_name),
                                         class_name = VALUES(class_name), active = 1'
            );
            foreach ($students as $student) {
                $upsert->execute([
                    'external_ref' => $student['external_ref'],
                    'school_year' => $schoolYear,
                    'first_name' => $student['first_name'],
                    'last_name' => $student['last_name'],
                    'class_name' => $student['class_name'],
                ]);
            }
            $import = $pdo->prepare(
                'INSERT INTO student_imports (imported_by, school_year, row_count, source_hash)
                 VALUES (:imported_by, :school_year, :row_count, :source_hash)'
            );
            $import->execute([
                'imported_by' => $admin['id'],
                'school_year' => $schoolYear,
                'row_count' => count($students),
                'source_hash' => $sourceHash,
            ]);
            auditLog($this->database, (int) $admin['id'], 'students.import', 'student_import', null, [
                'school_year' => $schoolYear,
                'row_count' => count($students),
                'source_hash' => $sourceHash,
                'class_count' => count($classes),
                'previous_active' => $activeBefore,
                'snapshot_id' => $snapshotId,
            ], $pdo);
        });
        jsonResponse([
            'ok' => true,
            'row_count' => count($students),
            'class_count' => count($classes),
            'snapshot_id' => $snapshotId,
        ], 201);
    }

    private function csvPreviewToken(
        string $schoolYear,
        string $sourceHash,
        int $activeBefore,
        string $activeFingerprint,
        int $adminUserId,
        int $issuedAt
    ): string {
        $payload = implode('|', [
            'csv-preview-v1',
            $schoolYear,
            $sourceHash,
            (string) $activeBefore,
            $activeFingerprint,
            (string) $adminUserId,
            (string) $issuedAt,
        ]);
        return $issuedAt . '.' . hash_hmac('sha256', $payload, (string) $this->config['app']['key']);
    }

    private function requireValidCsvPreviewToken(
        string $token,
        string $schoolYear,
        string $sourceHash,
        int $activeBefore,
        string $activeFingerprint,
        int $adminUserId
    ): void {
        if (strlen($token) > 96 || !preg_match('/^([0-9]{10})\.([a-f0-9]{64})$/', $token, $matches)) {
            throw new HttpException(409, 'Aperçu CSV absent ou invalide. Analysez le fichier avant de l’appliquer.');
        }
        $issuedAt = (int) $matches[1];
        $now = time();
        if ($issuedAt > $now + 30 || $issuedAt < $now - 900) {
            throw new HttpException(409, 'L’aperçu CSV a expiré. Analysez à nouveau le fichier avant de l’appliquer.');
        }
        $expected = $this->csvPreviewToken(
            $schoolYear,
            $sourceHash,
            $activeBefore,
            $activeFingerprint,
            $adminUserId,
            $issuedAt
        );
        if (!hash_equals($expected, $token)) {
            throw new HttpException(409, 'Le fichier, l’année ou la liste active a changé depuis l’aperçu. Relancez l’analyse.');
        }
    }

    /** @return array{count:int,fingerprint:string} */
    private function activeStudentsState(PDO $pdo, string $schoolYear, bool $lockRows): array
    {
        $statement = $pdo->prepare(
            'SELECT external_ref FROM students
             WHERE school_year = :school_year AND active = 1
             ORDER BY external_ref' . ($lockRows ? ' FOR UPDATE' : '')
        );
        $statement->execute(['school_year' => $schoolYear]);
        $references = array_map(static function (array $row): string {
            return (string) $row['external_ref'];
        }, $statement->fetchAll());
        return [
            'count' => count($references),
            'fingerprint' => hash('sha256', implode("\n", $references)),
        ];
    }

    private function parseStudentsCsv(string $path): array
    {
        $handle = fopen($path, 'rb');
        if ($handle === false) {
            throw new HttpException(422, 'Lecture du fichier impossible.');
        }
        try {
            $firstLine = fgets($handle);
            if ($firstLine === false) {
                return [];
            }
            $delimiter = substr_count($firstLine, ';') >= substr_count($firstLine, ',') ? ';' : ',';
            rewind($handle);
            $headers = fgetcsv($handle, 0, $delimiter);
            if (!is_array($headers)) {
                return [];
            }
            $headerMap = [];
            foreach ($headers as $index => $header) {
                $headerMap[$this->normalizeHeader((string) $header)] = $index;
            }
            $lastIndex = $this->headerIndex($headerMap, ['nom', 'lastname', 'nomdefamille']);
            $firstIndex = $this->headerIndex($headerMap, ['prenom', 'firstname']);
            $classIndex = $this->headerIndex($headerMap, ['classe', 'class', 'division']);
            $refIndex = $this->headerIndex($headerMap, ['id', 'identifiant', 'eleveid', 'ine']);
            if ($lastIndex === null || $firstIndex === null || $classIndex === null || $refIndex === null) {
                throw new HttpException(422, 'Colonnes requises : ID, NOM, PRENOM et CLASSE.');
            }

            $students = [];
            $seenReferences = [];
            $rowNumber = 1;
            while (($row = fgetcsv($handle, 0, $delimiter)) !== false) {
                $rowNumber++;
                $lastName = $this->cleanCell(isset($row[$lastIndex]) ? (string) $row[$lastIndex] : '');
                $firstName = $this->cleanCell(isset($row[$firstIndex]) ? (string) $row[$firstIndex] : '');
                $className = $this->cleanCell(isset($row[$classIndex]) ? (string) $row[$classIndex] : '');
                if ($lastName === '' && $firstName === '' && $className === '') {
                    continue;
                }
                if ($lastName === '' || $firstName === '' || $className === '') {
                    throw new HttpException(422, 'Ligne ' . $rowNumber . ' incomplète.');
                }
                if ($this->length($lastName) > 128 || $this->length($firstName) > 128 || $this->length($className) > 32) {
                    throw new HttpException(422, 'Ligne ' . $rowNumber . ' trop longue.');
                }
                $externalRef = isset($row[$refIndex])
                    ? strtolower($this->cleanCell((string) $row[$refIndex]))
                    : '';
                // La colonne MySQL est insensible à la casse. Restreindre et
                // normaliser les identifiants garantit que l’aperçu PHP compte
                // exactement les mêmes élèves que l’UPSERT MySQL.
                if (!preg_match('/^(?=.*[a-z0-9])[a-z0-9._-]{1,128}$/', $externalRef)) {
                    throw new HttpException(422, 'Identifiant élève absent ou invalide à la ligne ' . $rowNumber . '.');
                }
                // Certaines collations Unicode minimisent également le poids
                // de la ponctuation. Cette clé volontairement conservatrice
                // empêche donc deux variantes de fusionner silencieusement.
                $referenceComparisonKey = str_replace(['.', '_', '-'], '', $externalRef);
                if (isset($seenReferences[$referenceComparisonKey])) {
                    throw new HttpException(422, 'Identifiant élève dupliqué à la ligne ' . $rowNumber . '.');
                }
                $seenReferences[$referenceComparisonKey] = true;
                $students[] = [
                    'external_ref' => $externalRef,
                    'first_name' => $firstName,
                    'last_name' => $lastName,
                    'class_name' => $className,
                ];
            }
            return $students;
        } finally {
            fclose($handle);
        }
    }

    private function headerIndex(array $headers, array $names, bool $required = true): ?int
    {
        foreach ($names as $name) {
            if (array_key_exists($name, $headers)) {
                return (int) $headers[$name];
            }
        }
        return null;
    }

    private function normalizeHeader(string $value): string
    {
        $value = preg_replace('/^\xEF\xBB\xBF/', '', trim($value));
        if (function_exists('iconv')) {
            $converted = @iconv('UTF-8', 'ASCII//TRANSLIT//IGNORE', $value);
            if (is_string($converted)) {
                $value = $converted;
            }
        }
        return preg_replace('/[^a-z0-9]/', '', strtolower($value)) ?: '';
    }

    private function cleanCell(string $value): string
    {
        $value = trim(str_replace("\0", '', $value));
        return preg_replace('/[\x00-\x08\x0B\x0C\x0E-\x1F\x7F]/u', '', $value) ?: '';
    }

    private function activeStudent(int $id): array
    {
        $statement = $this->database->pdo()->prepare(
            'SELECT id, first_name, last_name, class_name FROM students
             WHERE id = :id AND school_year = :school_year AND active = 1'
        );
        $statement->execute(['id' => $id, 'school_year' => $this->config['app']['school_year']]);
        $student = $statement->fetch();
        if (!$student) {
            throw new HttpException(404, 'Élève introuvable dans l’année scolaire active.');
        }
        return $student;
    }

    /** @return array<string,string>|null */
    private function digitalPassContextAt(PDO $pdo, int $studentId, string $occurredAt): ?array
    {
        $statement = $pdo->prepare(
            'SELECT destination, issued_at, expires_at
             FROM digital_passes
             WHERE student_id = ?
               AND school_year = ?
               AND issued_at <= ?
               AND expires_at > ?
               AND (revoked_at IS NULL OR revoked_at > ?)
             ORDER BY issued_at DESC, id DESC
             LIMIT 1
             FOR UPDATE'
        );
        $statement->execute([
            $studentId,
            (string) $this->config['app']['school_year'],
            $occurredAt,
            $occurredAt,
            $occurredAt,
        ]);
        $pass = $statement->fetch();
        if (!is_array($pass)) {
            return null;
        }
        return [
            'destination' => (string) $pass['destination'],
            'issued_at' => (string) $pass['issued_at'],
            'expires_at' => (string) $pass['expires_at'],
        ];
    }

    /** @param array<string,mixed> $observation */
    private function attachDigitalPassContext(array &$observation): void
    {
        $destination = $observation['digital_pass_destination'] ?? null;
        $issuedAt = $observation['digital_pass_issued_at'] ?? null;
        $expiresAt = $observation['digital_pass_expires_at'] ?? null;
        $observation['digital_pass_context'] = (
            is_string($destination) && $destination !== ''
            && is_string($issuedAt) && $issuedAt !== ''
            && is_string($expiresAt) && $expiresAt !== ''
        ) ? [
            'destination' => $destination,
            'issued_at' => $issuedAt,
            'expires_at' => $expiresAt,
        ] : null;
        unset(
            $observation['digital_pass_destination'],
            $observation['digital_pass_issued_at'],
            $observation['digital_pass_expires_at']
        );
    }

    /** @param array<string,mixed> $observation */
    private function assertClaimAvailable(array $observation, array $user): void
    {
        if (!isset($observation['claimed_by_user_id']) || $observation['claimed_by_user_id'] === null) {
            return;
        }
        if ((int) $observation['claimed_by_user_id'] === (int) $user['id']) {
            return;
        }
        if (isset($observation['claim_expires_at']) && $observation['claim_expires_at'] !== null
            && strtotime((string) $observation['claim_expires_at'] . ' UTC') <= time()) {
            return;
        }
        throw new HttpException(409, 'Ce signalement est pris en charge par un autre collègue.');
    }

    private function studentOutput(array $student): array
    {
        return [
            'id' => (int) $student['id'],
            'first_name' => (string) $student['first_name'],
            'last_name' => (string) $student['last_name'],
            'class_name' => (string) $student['class_name'],
        ];
    }

    private function permissions(array $user): array
    {
        $role = (string) $user['role'];
        $pointsEnabled = $this->pointsEnabled();
        $digitalPassesEnabled = $this->digitalPassesEnabled();
        return [
            'can_submit' => in_array($role, self::SUBMIT_ROLES, true),
            'can_validate' => in_array($role, self::VALIDATE_ROLES, true),
            'can_dashboard' => in_array($role, self::DASHBOARD_ROLES, true),
            'can_history' => in_array($role, self::DASHBOARD_ROLES, true),
            'can_pp' => !empty($user['pp_class']),
            'can_points' => $pointsEnabled
                && (in_array($role, self::DASHBOARD_ROLES, true) || !empty($user['pp_class'])),
            'can_digital_pass' => $digitalPassesEnabled
                && in_array($role, self::SUBMIT_ROLES, true),
            'can_anonymous_report' => in_array($role, self::DASHBOARD_ROLES, true),
            'can_admin' => $role === 'admin',
        ];
    }

    private function schoolTimeSlot(DateTimeImmutable $localDate): ?string
    {
        $minutes = ((int) $localDate->format('G') * 60) + (int) $localDate->format('i');
        if ($minutes < 8 * 60 + 5) {
            return 'Accueil';
        }
        if ($minutes < 9 * 60 + 3) {
            return 'M1';
        }
        if ($minutes < 9 * 60 + 58) {
            return 'M2';
        }
        if ($minutes < 10 * 60 + 17) {
            return 'Récréation matin';
        }
        if ($minutes < 11 * 60 + 15) {
            return 'M3';
        }
        if ($minutes < 12 * 60 + 10) {
            return 'M4';
        }
        if ($minutes < 13 * 60 + 35) {
            return 'Pause méridienne';
        }
        if ($minutes < 14 * 60 + 33) {
            return 'S1';
        }
        if ($minutes < 15 * 60 + 28) {
            return 'S2';
        }
        if ($minutes < 15 * 60 + 47) {
            return 'Récréation après-midi';
        }
        if ($minutes < 16 * 60 + 42) {
            return 'S3';
        }
        if ($minutes < 17 * 60 + 30) {
            return 'S4';
        }
        return null;
    }

    private function length(string $value): int
    {
        return function_exists('mb_strlen') ? mb_strlen($value, 'UTF-8') : strlen($value);
    }

    private function parseOptionalLocalDateTime(string $value): ?string
    {
        if ($value === '') {
            return null;
        }
        $timezone = new DateTimeZone('Europe/Paris');
        if (preg_match('/^\d{4}-\d{2}-\d{2}$/D', $value)) {
            $date = DateTimeImmutable::createFromFormat('!Y-m-d H:i:s', $value . ' 23:59:59', $timezone);
        } elseif (preg_match('/^\d{4}-\d{2}-\d{2}T\d{2}:\d{2}$/D', $value)) {
            $date = DateTimeImmutable::createFromFormat('!Y-m-d\TH:i', $value, $timezone);
        } else {
            throw new HttpException(422, 'Date d’expiration invalide.');
        }
        $errors = DateTimeImmutable::getLastErrors();
        if (!$date || (is_array($errors) && ($errors['warning_count'] > 0 || $errors['error_count'] > 0))) {
            throw new HttpException(422, 'Date d’expiration invalide.');
        }
        return $date->setTimezone(new DateTimeZone('UTC'))->format('Y-m-d H:i:s');
    }

    private function lower(string $value): string
    {
        return function_exists('mb_strtolower') ? mb_strtolower($value, 'UTF-8') : strtolower($value);
    }

    private function pointsEnabled(): bool
    {
        if ($this->pointsEnabledCache !== null) {
            return $this->pointsEnabledCache;
        }
        $statement = $this->database->pdo()->prepare(
            'SELECT setting_value FROM app_settings WHERE setting_key = :setting_key LIMIT 1'
        );
        $statement->execute(['setting_key' => 'points_enabled']);
        $row = $statement->fetch();
        if ($row) {
            $this->pointsEnabledCache = in_array(
                strtolower(trim((string) $row['setting_value'])),
                ['1', 'true', 'yes', 'on'],
                true
            );
        } else {
            // Nouvelle installation : l'installateur fournit explicitement
            // points.enabled=false. Ancienne installation : cette option
            // n'existe pas, donc le comportement historique reste activé.
            $pointsConfig = isset($this->config['points']) && is_array($this->config['points'])
                ? $this->config['points']
                : [];
            $this->pointsEnabledCache = array_key_exists('enabled', $pointsConfig)
                ? (bool) $pointsConfig['enabled']
                : true;
        }
        return $this->pointsEnabledCache;
    }

    private function requirePointsEnabled(): void
    {
        if (!$this->pointsEnabled()) {
            throw new HttpException(403, 'Le module permis à points est désactivé par l’administrateur.');
        }
    }

    private function digitalPassesEnabled(): bool
    {
        if ($this->digitalPassesEnabledCache !== null) {
            return $this->digitalPassesEnabledCache;
        }
        $statement = $this->database->pdo()->prepare(
            'SELECT setting_value FROM app_settings WHERE setting_key = :setting_key LIMIT 1'
        );
        $statement->execute(['setting_key' => 'digital_passes_enabled']);
        $value = $statement->fetchColumn();
        $this->digitalPassesEnabledCache = is_string($value)
            && in_array(strtolower(trim($value)), ['1', 'true', 'yes', 'on'], true);
        return $this->digitalPassesEnabledCache;
    }

    private function requireDigitalPassesEnabled(): void
    {
        if (!$this->digitalPassesEnabled()) {
            throw new HttpException(403, 'Le module billets numériques est désactivé par l’administrateur.');
        }
    }

    private function deferredSubmissionsEnabled(): bool
    {
        if ($this->deferredSubmissionsEnabledCache !== null) {
            return $this->deferredSubmissionsEnabledCache;
        }
        $statement = $this->database->pdo()->prepare(
            'SELECT setting_value FROM app_settings WHERE setting_key = :setting_key LIMIT 1'
        );
        $statement->execute(['setting_key' => 'deferred_submissions_enabled']);
        $value = $statement->fetchColumn();
        // Absence de réglage = désactivé. Même sans stockage persistant, la
        // conservation temporaire en mémoire doit résulter d'un choix explicite.
        $this->deferredSubmissionsEnabledCache = is_string($value)
            && in_array(strtolower(trim($value)), ['1', 'true', 'yes', 'on'], true);
        return $this->deferredSubmissionsEnabledCache;
    }

    private function pointsConfig(): array
    {
        $raw = isset($this->config['points']) && is_array($this->config['points']) ? $this->config['points'] : [];
        $trimesters = [];
        $source = isset($raw['trimesters']) && is_array($raw['trimesters']) ? $raw['trimesters'] : [];
        $activeStartYear = (int) substr((string) $this->config['app']['school_year'], 0, 4);
        $sourceStartYear = isset($source[0]['start']) ? (int) substr((string) $source[0]['start'], 0, 4) : $activeStartYear;
        $yearOffset = $activeStartYear - $sourceStartYear;
        foreach ($source as $trimester) {
            if (!isset($trimester['start'], $trimester['end'])) {
                continue;
            }
            $trimesters[] = [
                'label' => isset($trimester['label']) ? (string) $trimester['label'] : 'Trimestre',
                'start' => $this->shiftPointsDate((string) $trimester['start'], $yearOffset),
                'end' => $this->shiftPointsDate((string) $trimester['end'], $yearOffset),
            ];
        }
        if (count($trimesters) === 0) {
            $trimesters[] = ['label' => 'Année', 'start' => '2000-01-01', 'end' => '2099-12-31'];
        }
        $thresholds = [];
        $thresholdSource = isset($raw['action_thresholds']) && is_array($raw['action_thresholds'])
            ? $raw['action_thresholds']
            : [
                ['points' => 5, 'action' => 'Entretien CPE'],
                ['points' => 2, 'action' => 'Information de la famille'],
                ['points' => 0, 'action' => 'Commission éducative'],
            ];
        foreach ($thresholdSource as $threshold) {
            if (!isset($threshold['points'], $threshold['action'])) {
                continue;
            }
            $action = trim((string) $threshold['action']);
            if ($action === '' || $this->length($action) > 96) {
                continue;
            }
            $thresholds[] = [
                'points' => max(0, (int) $threshold['points']),
                'action' => $action,
            ];
        }
        usort($thresholds, static function (array $a, array $b): int {
            return $b['points'] <=> $a['points'];
        });
        $defaultLetter = "Objet : dispositif « permis à points » — information\n\nMadame, Monsieur,\n\n"
            . "Dans le cadre du dispositif « permis à points » prévu au règlement intérieur, nous vous informons que {ELEVE}, "
            . "élève de {CLASSE}, dispose ce jour de {POINTS} point(s) sur un capital de {CAPITAL} pour le {TRIMESTRE}.\n\n"
            . "Les faits suivants, vérifiés par la vie scolaire, ont conduit à ce décompte :\n{FAITS}\n\n"
            . "Nous vous invitons à évoquer cette situation avec votre enfant. La vie scolaire se tient à votre disposition pour tout échange.\n\n"
            . "{COLLEGE}, le {DATE}\nLa vie scolaire";
        return [
            'enabled' => $this->pointsEnabled(),
            'capital' => isset($raw['capital']) ? max(1, (int) $raw['capital']) : 10,
            'alert_threshold' => isset($raw['alert_threshold']) ? max(0, (int) $raw['alert_threshold']) : 5,
            'trimesters' => $trimesters,
            'action_thresholds' => $thresholds,
            'college_name' => isset($raw['college_name']) && trim((string) $raw['college_name']) !== ''
                ? trim((string) $raw['college_name'])
                : 'Collège Jean-Jaurès',
            'letter_template' => isset($raw['letter_template']) && trim((string) $raw['letter_template']) !== ''
                ? (string) $raw['letter_template']
                : $defaultLetter,
        ];
    }

    private function shiftPointsDate(string $date, int $yearOffset): string
    {
        if (!preg_match('/^(\d{4})(-\d{2}-\d{2})$/', $date, $matches)) {
            return $date;
        }
        return sprintf('%04d%s', (int) $matches[1] + $yearOffset, $matches[2]);
    }

    private function pointsUser(): array
    {
        $user = $this->auth->requireUser();
        $this->requirePointsEnabled();
        $isWide = in_array((string) $user['role'], self::DASHBOARD_ROLES, true);
        if (!$isWide && empty($user['pp_class'])) {
            throw new HttpException(403, 'Accès réservé aux CPE, à la direction et aux professeurs principaux.');
        }
        return [$user, $isWide];
    }

    private function trimesterWindow(array $config, int $requested = 0): array
    {
        $trimesters = $config['trimesters'];
        if ($requested <= 0) {
            $requested = isset($_GET['t']) ? (int) $_GET['t'] : 0;
        }
        $index = null;
        if ($requested >= 1 && $requested <= count($trimesters)) {
            $index = $requested - 1;
        } else {
            $today = gmdate('Y-m-d');
            foreach ($trimesters as $position => $trimester) {
                if ($today >= $trimester['start'] && $today <= $trimester['end']) {
                    $index = $position;
                    break;
                }
            }
            if ($index === null) {
                $index = 0;
            }
        }
        $trimester = $trimesters[$index];
        return [
            $index + 1,
            $trimester['start'] . ' 00:00:00',
            $trimester['end'] . ' 23:59:59',
        ];
    }

    private function pointsData(
        array $user,
        bool $isWide,
        array $config,
        int $trimesterNumber,
        string $windowStart,
        string $windowEnd
    ): array {
        $sql = "SELECT s.id, s.first_name, s.last_name, s.class_name,
                       COUNT(DISTINCT CASE
                           WHEN o.status = 'confirmed'
                           THEN CASE WHEN o.sequence_key IS NULL
                               THEN CONCAT('observation:', o.id)
                               ELSE CONCAT('sequence:', o.sequence_key)
                           END
                       END) AS confirmed,
                       COUNT(DISTINCT CASE
                           WHEN o.status = 'pending'
                            AND (
                                o.sequence_key IS NULL
                                OR NOT EXISTS (
                                    SELECT 1 FROM observations confirmed_peer
                                    WHERE confirmed_peer.student_id = o.student_id
                                      AND confirmed_peer.sequence_key = o.sequence_key
                                      AND confirmed_peer.status = 'confirmed'
                                      AND confirmed_peer.occurred_at BETWEEN :peer_window_start AND :peer_window_end
                                )
                            )
                           THEN CASE WHEN o.sequence_key IS NULL
                               THEN CONCAT('observation:', o.id)
                               ELSE CONCAT('sequence:', o.sequence_key)
                           END
                       END) AS pending,
                       MAX(CASE WHEN o.status = 'confirmed' THEN o.occurred_at END) AS last_confirmed_at,
                       COALESCE(MAX(adj.total), 0) AS restored
                FROM students s
                LEFT JOIN observations o
                       ON o.student_id = s.id
                      AND o.occurred_at BETWEEN :window_start AND :window_end
                LEFT JOIN (
                    SELECT student_id, SUM(points) AS total
                    FROM point_adjustments
                    WHERE created_at BETWEEN :adjust_start AND :adjust_end
                    GROUP BY student_id
                ) adj ON adj.student_id = s.id
                WHERE s.school_year = :school_year AND s.active = 1";
        $parameters = [
            'window_start' => $windowStart,
            'window_end' => $windowEnd,
            'adjust_start' => $windowStart,
            'adjust_end' => $windowEnd,
            'peer_window_start' => $windowStart,
            'peer_window_end' => $windowEnd,
            'school_year' => $this->config['app']['school_year'],
        ];
        if (!$isWide) {
            $sql .= ' AND s.class_name = :class_name';
            $parameters['class_name'] = (string) $user['pp_class'];
        }
        $sql .= ' GROUP BY s.id, s.first_name, s.last_name, s.class_name';
        $statement = $this->database->pdo()->prepare($sql);
        $statement->execute($parameters);

        $actionsDone = [];
        $actionsStatement = $this->database->pdo()->prepare(
            'SELECT student_id, threshold_points FROM action_records
             WHERE school_year = :school_year AND trimester = :trimester'
        );
        $actionsStatement->execute([
            'school_year' => $this->config['app']['school_year'],
            'trimester' => $trimesterNumber,
        ]);
        foreach ($actionsStatement->fetchAll() as $actionRow) {
            $actionsDone[(int) $actionRow['student_id']][(int) $actionRow['threshold_points']] = true;
        }

        $capital = $config['capital'];
        $students = [];
        foreach ($statement->fetchAll() as $row) {
            $confirmed = (int) $row['confirmed'];
            $restored = (int) $row['restored'];
            $points = max(0, min($capital, $capital - $confirmed + $restored));
            $studentId = (int) $row['id'];
            $pendingActions = 0;
            foreach ($config['action_thresholds'] as $threshold) {
                if ($points <= $threshold['points'] && empty($actionsDone[$studentId][$threshold['points']])) {
                    $pendingActions++;
                }
            }
            $students[] = [
                'id' => $studentId,
                'first_name' => (string) $row['first_name'],
                'last_name' => (string) $row['last_name'],
                'class_name' => (string) $row['class_name'],
                'confirmed' => $confirmed,
                'pending' => (int) $row['pending'],
                'restored' => $restored,
                'points' => $points,
                'pending_actions' => $pendingActions,
                'last_confirmed_at' => $row['last_confirmed_at'],
            ];
        }
        usort($students, static function (array $a, array $b): int {
            if ($a['points'] !== $b['points']) {
                return $a['points'] <=> $b['points'];
            }
            if ($a['pending'] !== $b['pending']) {
                return $b['pending'] <=> $a['pending'];
            }
            return strcmp($a['last_name'] . $a['first_name'], $b['last_name'] . $b['first_name']);
        });
        return $students;
    }

    private function alertCount(?array $user): ?int
    {
        if ($user === null || !$this->pointsEnabled()) {
            return null;
        }
        $isWide = in_array((string) $user['role'], self::DASHBOARD_ROLES, true);
        if (!$isWide && empty($user['pp_class'])) {
            return null;
        }
        try {
            $config = $this->pointsConfig();
            list($trimesterNumber, $windowStart, $windowEnd) = $this->trimesterWindow($config);
            $students = $this->pointsData($user, $isWide, $config, $trimesterNumber, $windowStart, $windowEnd);
            $count = 0;
            foreach ($students as $student) {
                if ($student['points'] <= $config['alert_threshold']) {
                    $count++;
                }
            }
            return $count;
        } catch (Throwable $error) {
            return null;
        }
    }

    private function notificationCount(?array $user): ?int
    {
        if ($user === null) {
            return null;
        }
        try {
            $statement = $this->database->pdo()->prepare(
                'SELECT COUNT(*) FROM user_notifications
                 WHERE user_id = :user_id AND read_at IS NULL'
            );
            $statement->execute(['user_id' => (int) $user['id']]);
            return (int) $statement->fetchColumn();
        } catch (Throwable $error) {
            return null;
        }
    }

    private function createObservationNotification(
        PDO $pdo,
        int $userId,
        int $observationId,
        string $eventType
    ): void {
        if (!in_array($eventType, ['confirmed', 'cancelled'], true)) {
            return;
        }
        $statement = $pdo->prepare(
            'INSERT IGNORE INTO user_notifications
                (user_id, observation_id, event_type, created_at)
             VALUES (:user_id, :observation_id, :event_type, UTC_TIMESTAMP())'
        );
        $statement->execute([
            'user_id' => $userId,
            'observation_id' => $observationId,
            'event_type' => $eventType,
        ]);
    }

    /** @param array<int,int> $observationIds */
    private function createObservationNotificationsForIds(
        PDO $pdo,
        array $observationIds,
        string $eventType
    ): void {
        foreach ($observationIds as $observationId) {
            $reporter = $pdo->prepare(
                'SELECT reporter_user_id FROM observations WHERE id = :id'
            );
            $reporter->execute(['id' => (int) $observationId]);
            $reporterId = (int) $reporter->fetchColumn();
            if ($reporterId > 0) {
                $this->createObservationNotification(
                    $pdo,
                    $reporterId,
                    (int) $observationId,
                    $eventType
                );
            }
        }
    }

    private function pendingCount(?array $user): ?int
    {
        if ($user === null || !in_array((string) $user['role'], self::VALIDATE_ROLES, true)) {
            return null;
        }
        try {
            $statement = $this->database->pdo()->prepare(
                "SELECT COUNT(*)
                 FROM observations o
                 JOIN students s ON s.id = o.student_id
                 WHERE o.status = 'pending' AND s.school_year = :school_year"
            );
            $statement->execute(['school_year' => $this->config['app']['school_year']]);
            return (int) $statement->fetchColumn();
        } catch (Throwable $error) {
            return null;
        }
    }

    private function points(): void
    {
        requireMethod('GET');
        list($user, $isWide) = $this->pointsUser();
        $config = $this->pointsConfig();
        list($trimesterNumber, $windowStart, $windowEnd) = $this->trimesterWindow($config);
        $students = $this->pointsData($user, $isWide, $config, $trimesterNumber, $windowStart, $windowEnd);

        $threshold = $config['alert_threshold'];
        $totals = ['confirmed' => 0, 'pending' => 0, 'restored' => 0, 'alert' => 0, 'zero' => 0, 'actions' => 0];
        foreach ($students as $student) {
            $totals['confirmed'] += $student['confirmed'];
            $totals['pending'] += $student['pending'];
            $totals['restored'] += $student['restored'];
            $totals['actions'] += $student['pending_actions'];
            if ($student['points'] === 0) {
                $totals['zero']++;
            } elseif ($student['points'] <= $threshold) {
                $totals['alert']++;
            }
        }

        jsonResponse([
            'trimester' => $trimesterNumber,
            'window_start' => substr($windowStart, 0, 10),
            'window_end' => substr($windowEnd, 0, 10),
            'capital' => $config['capital'],
            'alert_threshold' => $threshold,
            'scope_class' => $isWide ? null : (string) $user['pp_class'],
            'can_manage' => $isWide,
            'totals' => $totals,
            'students' => $students,
        ]);
    }

    private function pointsExport(): void
    {
        requireMethod('POST');
        list($user, $isWide) = $this->pointsUser();
        requireCsrf($this->auth);
        $config = $this->pointsConfig();
        list($trimesterNumber, $windowStart, $windowEnd) = $this->trimesterWindow($config);
        $students = $this->pointsData($user, $isWide, $config, $trimesterNumber, $windowStart, $windowEnd);

        auditLog($this->database, (int) $user['id'], 'points.export', 'points', null, [
            'trimester' => $trimesterNumber,
            'row_count' => count($students),
            'scope_class' => $isWide ? null : (string) $user['pp_class'],
        ]);
        header('Content-Type: text/csv; charset=utf-8');
        header('Content-Disposition: attachment; filename="permis-points-T' . $trimesterNumber . '-' . gmdate('Ymd') . '.csv"');
        header('Cache-Control: no-store');
        $output = fopen('php://output', 'wb');
        if ($output === false) {
            throw new HttpException(500, 'Création de l’export impossible.');
        }
        fwrite($output, "\xEF\xBB\xBF");
        fputcsv($output, ['Nom', 'Prénom', 'Classe', 'Points restants', 'Capital', 'Situations confirmées', 'Situations en attente', 'Points rendus', 'Actions à faire', 'Dernière confirmée'], ';');
        foreach ($students as $student) {
            fputcsv($output, [
                $this->safeCsvCell((string) $student['last_name']),
                $this->safeCsvCell((string) $student['first_name']),
                $this->safeCsvCell((string) $student['class_name']),
                $student['points'],
                $config['capital'],
                $student['confirmed'],
                $student['pending'],
                $student['restored'],
                $student['pending_actions'],
                $student['last_confirmed_at'] !== null ? (string) $student['last_confirmed_at'] : '',
            ], ';');
        }
        fclose($output);
        exit;
    }

    private function safeCsvCell(string $value): string
    {
        return preg_match('/^[=+\-@]/u', $value) === 1 ? "'" . $value : $value;
    }

    private function pointsBalance(PDO $pdo, int $studentId, string $windowStart, string $windowEnd, int $capital): array
    {
        $lost = $pdo->prepare(
            "SELECT COUNT(DISTINCT CASE
                        WHEN status = 'confirmed'
                        THEN CASE WHEN sequence_key IS NULL
                            THEN CONCAT('observation:', id)
                            ELSE CONCAT('sequence:', sequence_key)
                        END
                    END)
             FROM observations
             WHERE student_id = :student_id AND occurred_at BETWEEN :window_start AND :window_end"
        );
        $lost->execute(['student_id' => $studentId, 'window_start' => $windowStart, 'window_end' => $windowEnd]);
        $confirmed = (int) $lost->fetchColumn();
        $given = $pdo->prepare(
            'SELECT COALESCE(SUM(points), 0) FROM point_adjustments
             WHERE student_id = :student_id AND created_at BETWEEN :window_start AND :window_end'
        );
        $given->execute(['student_id' => $studentId, 'window_start' => $windowStart, 'window_end' => $windowEnd]);
        $restored = (int) $given->fetchColumn();
        return [
            'confirmed' => $confirmed,
            'restored' => $restored,
            'points' => max(0, min($capital, $capital - $confirmed + $restored)),
        ];
    }

    private function pointsRestore(): void
    {
        requireMethod('POST');
        $user = $this->auth->requireRoles(self::DASHBOARD_ROLES);
        $this->requirePointsEnabled();
        requireCsrf($this->auth);
        $input = jsonInput();
        $studentId = isset($input['student_id']) ? (int) $input['student_id'] : 0;
        $reason = trim(isset($input['reason']) ? (string) $input['reason'] : '');
        if ($studentId <= 0) {
            throw new HttpException(422, 'Élève invalide.');
        }
        if ($this->length($reason) < 3 || $this->length($reason) > 160) {
            throw new HttpException(422, 'Indiquez le motif du point rendu (3 à 160 caractères).');
        }
        $student = $this->activeStudent($studentId);
        $config = $this->pointsConfig();
        list($trimesterNumber, $windowStart, $windowEnd) = $this->trimesterWindow($config);

        $this->database->transaction(function (PDO $pdo) use (
            $studentId,
            $reason,
            $user,
            $config,
            $windowStart,
            $windowEnd,
            $trimesterNumber,
            $student
        ): void {
            $lock = $pdo->prepare('SELECT id FROM students WHERE id = :id FOR UPDATE');
            $lock->execute(['id' => $studentId]);
            if (!$lock->fetchColumn()) {
                throw new HttpException(404, 'Élève introuvable.');
            }
            $balance = $this->pointsBalance($pdo, $studentId, $windowStart, $windowEnd, $config['capital']);
            if ($balance['restored'] >= $balance['confirmed']) {
                throw new HttpException(422, 'Cet élève n’a pas de point à récupérer sur ce trimestre.');
            }
            $insert = $pdo->prepare(
                'INSERT INTO point_adjustments (student_id, granted_by, points, reason)
                 VALUES (:student_id, :granted_by, 1, :reason)'
            );
            $insert->execute(['student_id' => $studentId, 'granted_by' => $user['id'], 'reason' => $reason]);
            auditLog($this->database, (int) $user['id'], 'points.restore', 'student', $studentId, [
                'trimester' => $trimesterNumber,
                'reason' => $reason,
                'class_name' => $student['class_name'],
            ], $pdo);
        });
        jsonResponse(['ok' => true], 201);
    }

    private function pointsActionDone(): void
    {
        requireMethod('POST');
        $user = $this->auth->requireRoles(self::DASHBOARD_ROLES);
        $this->requirePointsEnabled();
        requireCsrf($this->auth);
        $input = jsonInput();
        $studentId = isset($input['student_id']) ? (int) $input['student_id'] : 0;
        $thresholdPoints = isset($input['threshold_points']) ? (int) $input['threshold_points'] : -1;
        $note = trim(isset($input['note']) ? (string) $input['note'] : '');
        if ($studentId <= 0 || $this->length($note) > 160) {
            throw new HttpException(422, 'Requête invalide.');
        }
        $config = $this->pointsConfig();
        $actionLabel = null;
        foreach ($config['action_thresholds'] as $threshold) {
            if ($threshold['points'] === $thresholdPoints) {
                $actionLabel = $threshold['action'];
                break;
            }
        }
        if ($actionLabel === null) {
            throw new HttpException(422, 'Seuil inconnu.');
        }
        $this->activeStudent($studentId);
        list($trimesterNumber, $windowStart, $windowEnd) = $this->trimesterWindow($config);

        try {
            $this->database->transaction(function (PDO $pdo) use (
                $studentId,
                $thresholdPoints,
                $actionLabel,
                $note,
                $user,
                $config,
                $trimesterNumber,
                $windowStart,
                $windowEnd
            ): void {
                $lock = $pdo->prepare('SELECT id FROM students WHERE id = :id FOR UPDATE');
                $lock->execute(['id' => $studentId]);
                if (!$lock->fetchColumn()) {
                    throw new HttpException(404, 'Élève introuvable.');
                }
                $balance = $this->pointsBalance($pdo, $studentId, $windowStart, $windowEnd, $config['capital']);
                if ($balance['points'] > $thresholdPoints) {
                    throw new HttpException(409, 'Ce seuil n’est pas encore franchi par cet élève.');
                }
                $insert = $pdo->prepare(
                    'INSERT INTO action_records
                     (student_id, school_year, trimester, threshold_points, action_label, note, done_by)
                     VALUES (:student_id, :school_year, :trimester, :threshold_points, :action_label, :note, :done_by)'
                );
                $insert->execute([
                    'student_id' => $studentId,
                    'school_year' => $this->config['app']['school_year'],
                    'trimester' => $trimesterNumber,
                    'threshold_points' => $thresholdPoints,
                    'action_label' => $actionLabel,
                    'note' => $note,
                    'done_by' => $user['id'],
                ]);
                auditLog($this->database, (int) $user['id'], 'points.action', 'student', $studentId, [
                    'trimester' => $trimesterNumber,
                    'threshold' => $thresholdPoints,
                    'action' => $actionLabel,
                ], $pdo);
            });
        } catch (PDOException $error) {
            if ((string) $error->getCode() === '23000') {
                throw new HttpException(409, 'Cette action est déjà enregistrée pour ce trimestre.');
            }
            throw $error;
        }
        jsonResponse(['ok' => true], 201);
    }

    private function pointsDetail(): void
    {
        requireMethod('GET');
        list($user, $isWide) = $this->pointsUser();
        $config = $this->pointsConfig();
        list($trimesterNumber, $windowStart, $windowEnd) = $this->trimesterWindow($config);
        $studentId = isset($_GET['student_id']) ? (int) $_GET['student_id'] : 0;
        if ($studentId <= 0) {
            throw new HttpException(422, 'Élève invalide.');
        }
        $student = $this->activeStudent($studentId);
        if (!$isWide && (string) $student['class_name'] !== (string) $user['pp_class']) {
            throw new HttpException(403, 'Cet élève n’appartient pas à votre classe.');
        }

        $statement = $this->database->pdo()->prepare(
            "SELECT o.id, o.occurred_at, o.location, o.reason, o.details, o.status,
                    o.sequence_key,
                    u.first_name AS reporter_first_name, u.last_name AS reporter_last_name
             FROM observations o
             JOIN users u ON u.id = o.reporter_user_id
             WHERE o.student_id = :student_id
               AND o.occurred_at BETWEEN :window_start AND :window_end
               AND o.status IN ('confirmed', 'pending')
             ORDER BY o.occurred_at DESC, o.id DESC"
        );
        $statement->execute([
            'student_id' => $studentId,
            'window_start' => $windowStart,
            'window_end' => $windowEnd,
        ]);
        $observations = [];
        $confirmedSituations = [];
        $pendingSituations = [];
        foreach ($statement->fetchAll() as $row) {
            $situationKey = $row['sequence_key'] === null
                ? 'observation:' . (int) $row['id']
                : 'sequence:' . (string) $row['sequence_key'];
            if ((string) $row['status'] === 'confirmed') {
                $confirmedSituations[$situationKey] = true;
            } elseif ((string) $row['status'] === 'pending') {
                $pendingSituations[$situationKey] = true;
            }
            $observations[] = [
                'id' => (int) $row['id'],
                'occurred_at' => (string) $row['occurred_at'],
                'location' => (string) $row['location'],
                'reason' => (string) $row['reason'],
                'details' => (string) $row['details'],
                'status' => (string) $row['status'],
                'part_of_path' => $row['sequence_key'] !== null,
                'situation_id' => $situationKey,
                'reporter' => $isWide
                    ? trim((string) $row['reporter_first_name'] . ' ' . (string) $row['reporter_last_name'])
                    : null,
            ];
        }
        $confirmed = count($confirmedSituations);
        foreach (array_keys($confirmedSituations) as $confirmedSituationKey) {
            unset($pendingSituations[$confirmedSituationKey]);
        }

        $adjustmentStatement = $this->database->pdo()->prepare(
            'SELECT a.id, a.points, a.reason, a.created_at,
                    u.first_name AS granted_first_name, u.last_name AS granted_last_name
             FROM point_adjustments a
             JOIN users u ON u.id = a.granted_by
             WHERE a.student_id = :student_id AND a.created_at BETWEEN :window_start AND :window_end
             ORDER BY a.created_at DESC, a.id DESC'
        );
        $adjustmentStatement->execute([
            'student_id' => $studentId,
            'window_start' => $windowStart,
            'window_end' => $windowEnd,
        ]);
        $adjustments = [];
        $restored = 0;
        foreach ($adjustmentStatement->fetchAll() as $row) {
            $restored += (int) $row['points'];
            $adjustments[] = [
                'id' => (int) $row['id'],
                'points' => (int) $row['points'],
                'reason' => (string) $row['reason'],
                'created_at' => (string) $row['created_at'],
                'granted_by' => trim((string) $row['granted_first_name'] . ' ' . (string) $row['granted_last_name']),
            ];
        }
        $points = max(0, min($config['capital'], $config['capital'] - $confirmed + $restored));

        $actionStatement = $this->database->pdo()->prepare(
            'SELECT a.threshold_points, a.action_label, a.note, a.done_at,
                    u.first_name AS done_first_name, u.last_name AS done_last_name
             FROM action_records a
             JOIN users u ON u.id = a.done_by
             WHERE a.student_id = :student_id AND a.school_year = :school_year AND a.trimester = :trimester'
        );
        $actionStatement->execute([
            'student_id' => $studentId,
            'school_year' => $this->config['app']['school_year'],
            'trimester' => $trimesterNumber,
        ]);
        $doneActions = [];
        foreach ($actionStatement->fetchAll() as $row) {
            $doneActions[(int) $row['threshold_points']] = [
                'note' => (string) $row['note'],
                'done_at' => (string) $row['done_at'],
                'done_by' => trim((string) $row['done_first_name'] . ' ' . (string) $row['done_last_name']),
            ];
        }
        $actions = [];
        foreach ($config['action_thresholds'] as $threshold) {
            $actions[] = [
                'threshold_points' => $threshold['points'],
                'action' => $threshold['action'],
                'crossed' => $points <= $threshold['points'],
                'done' => isset($doneActions[$threshold['points']]) ? $doneActions[$threshold['points']] : null,
            ];
        }

        jsonResponse([
            'trimester' => $trimesterNumber,
            'trimester_label' => $config['trimesters'][$trimesterNumber - 1]['label'],
            'student' => $this->studentOutput($student),
            'points' => $points,
            'capital' => $config['capital'],
            'restored' => $restored,
            'confirmed_situations' => $confirmed,
            'pending_situations' => count($pendingSituations),
            'can_manage' => $isWide && in_array((string) $user['role'], self::DASHBOARD_ROLES, true),
            'observations' => $observations,
            'adjustments' => $adjustments,
            'actions' => $actions,
        ]);
    }
}
