<?php

declare(strict_types=1);

/**
 * Vérification d'un déploiement : en-têtes de sécurité, protection des
 * dossiers sensibles (403 attendu) et extensions PHP du serveur.
 *
 * Usage, depuis le serveur Kwartz ou tout poste disposant de PHP :
 *     php tools/verifier-deploiement.php https://serveur/suivi/
 *
 * Ajouter --insecure UNIQUEMENT si le certificat HTTPS de Kwartz est
 * auto-signé : la vérification du certificat est alors désactivée pour ce
 * contrôle (jamais pour l'application elle-même).
 *
 * Code de sortie : 0 si tous les contrôles passent, 1 sinon.
 */

if (PHP_SAPI !== 'cli') {
    http_response_code(404);
    exit;
}

$arguments = array_slice(isset($argv) && is_array($argv) ? $argv : [], 1);
$insecure = in_array('--insecure', $arguments, true);
$urls = array_values(array_filter($arguments, static function (string $argument): bool {
    return strpos($argument, '--') !== 0;
}));
if (count($urls) !== 1 || !preg_match('#^https://[^\s]+$#', $urls[0])) {
    fwrite(STDERR, "Usage : php tools/verifier-deploiement.php https://serveur/suivi/ [--insecure]\n");
    fwrite(STDERR, "L'adresse doit être en HTTPS et pointer vers le dossier de l'installation.\n");
    exit(2);
}
$baseUrl = rtrim($urls[0], '/') . '/';

$failures = 0;

function verdict(bool $ok, string $label, string $detail = ''): void
{
    global $failures;
    if (!$ok) {
        $failures++;
    }
    echo '  ' . ($ok ? '✓' : '✗') . ' ' . $label . ($detail !== '' ? ' — ' . $detail : '') . "\n";
}

function recommendation(bool $ok, string $label, string $detail = ''): void
{
    echo '  ' . ($ok ? '✓' : '⚠') . ' ' . $label . ($detail !== '' ? ' — ' . $detail : '') . "\n";
}

/**
 * @return array{status:int,headers:array<string,string>}|null
 */
function fetchHead(string $url, bool $insecure): ?array
{
    $context = stream_context_create([
        'http' => [
            'method' => 'GET',
            'timeout' => 10,
            'ignore_errors' => true,
            'follow_location' => 0,
            'header' => "User-Agent: suivi-verification/1.0\r\n",
        ],
        'ssl' => $insecure
            ? ['verify_peer' => false, 'verify_peer_name' => false]
            : [],
    ]);
    $stream = @fopen($url, 'rb', false, $context);
    if ($stream === false) {
        return null;
    }
    $metadata = stream_get_meta_data($stream);
    fclose($stream);
    $responseHeaders = isset($metadata['wrapper_data']) && is_array($metadata['wrapper_data'])
        ? $metadata['wrapper_data']
        : [];
    if (count($responseHeaders) === 0) {
        return null;
    }
    $status = 0;
    $headers = [];
    foreach ($responseHeaders as $line) {
        if (preg_match('#^HTTP/\S+\s+(\d{3})#', $line, $matches)) {
            $status = (int) $matches[1];
            $headers = [];
            continue;
        }
        $separator = strpos($line, ':');
        if ($separator !== false) {
            $headers[strtolower(trim(substr($line, 0, $separator)))] = trim(substr($line, $separator + 1));
        }
    }
    return ['status' => $status, 'headers' => $headers];
}

echo "Vérification du déploiement : {$baseUrl}\n";
if ($insecure) {
    echo "(certificat HTTPS non vérifié pour ce contrôle : option --insecure)\n";
}

echo "\n1. En-têtes de sécurité sur la page d'accueil\n";
$home = fetchHead($baseUrl . 'index.html', $insecure);
if ($home === null) {
    verdict(false, 'Page d’accueil joignable', 'connexion impossible (adresse, HTTPS ou certificat — voir --insecure)');
} else {
    verdict($home['status'] === 200, 'Page d’accueil joignable', 'code HTTP ' . $home['status']);
    $expectedHeaders = [
        'content-security-policy' => 'Content-Security-Policy',
        'x-content-type-options' => 'X-Content-Type-Options',
        'x-frame-options' => 'X-Frame-Options',
        'referrer-policy' => 'Referrer-Policy',
        'strict-transport-security' => 'Strict-Transport-Security',
        'cache-control' => 'Cache-Control',
    ];
    foreach ($expectedHeaders as $key => $label) {
        verdict(
            isset($home['headers'][$key]),
            'En-tête ' . $label,
            isset($home['headers'][$key])
                ? substr($home['headers'][$key], 0, 60)
                : 'absent : vérifier mod_headers et AllowOverride dans Apache'
        );
    }
    if (isset($home['headers']['content-security-policy'])) {
        $csp = $home['headers']['content-security-policy'];
        verdict(
            strpos($csp, "script-src 'self'") !== false && strpos($csp, 'unsafe-inline') === false,
            'CSP stricte (script-src \'self\', pas de unsafe-inline)'
        );
    }
}

echo "\n2. Dossiers et fichiers sensibles (403 attendu)\n";
$protectedPaths = [
    'var/settings.php' => 'configuration (mots de passe MySQL)',
    'var/' => 'dossier var',
    'src/bootstrap.php' => 'code source',
    'database/schema.sql' => 'schéma MySQL',
    'donnees/eleves-fictifs-100.csv' => 'données de démonstration',
    'tools/cleanup.php' => 'outils d’administration',
    'tests/run-tests.php' => 'tests',
    '.htaccess' => 'configuration Apache',
    'README.md' => 'documentation interne',
];
foreach ($protectedPaths as $path => $label) {
    $result = fetchHead($baseUrl . $path, $insecure);
    if ($result === null) {
        verdict(false, $path, 'connexion impossible');
        continue;
    }
    $status = $result['status'];
    if ($status === 403) {
        verdict(true, $path, 'refusé (403) — ' . $label . ' protégé');
    } elseif ($status === 404) {
        verdict(true, $path, 'introuvable (404) — acceptable si le fichier est absent');
    } else {
        verdict(false, $path, 'code HTTP ' . $status . ' : ' . $label . ' EXPOSÉ, corriger .htaccess/AllowOverride');
    }
}

echo "\n3. Environnement PHP local (machine exécutant ce script)\n";
verdict(PHP_VERSION_ID >= 70400, 'PHP 7.4 minimum', 'version ' . PHP_VERSION);
$extensions = [
    'ldap' => 'obligatoire (authentification Kwartz)',
    'pdo_mysql' => 'obligatoire (base MySQL)',
    'mbstring' => 'recommandée (longueurs de texte accentué)',
    'zlib' => 'recommandée (compression des points de récupération)',
    'iconv' => 'recommandée (analyse des en-têtes CSV)',
];
foreach ($extensions as $extension => $label) {
    $loaded = extension_loaded($extension);
    if ($extension === 'ldap' || $extension === 'pdo_mysql') {
        verdict($loaded, 'Extension ' . $extension, $label);
    } else {
        recommendation($loaded, 'Extension ' . $extension, $label);
    }
}
echo "    NB : cette section décrit la machine qui exécute ce script. Pour vérifier\n";
echo "    le serveur web lui-même, lancer ce script directement sur le serveur.\n";

echo "\n" . ($failures === 0
    ? "TOUT EST CONFORME : aucun écart détecté.\n"
    : "ÉCARTS DÉTECTÉS : {$failures} contrôle(s) en échec, voir les lignes ✗ ci-dessus.\n");
exit($failures === 0 ? 0 : 1);
