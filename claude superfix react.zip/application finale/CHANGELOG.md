# Historique des versions

## 2.0.0-rc.1 — Frontend React

### Refonte complète de l’interface

- migration du frontend vers **Vite + React 18 + TypeScript + Tailwind CSS 4** ;
  le backend PHP est strictement inchangé et reste garant de la compatibilité
  Kwartz (PHP 7.4, MySQL 8) ;
- interface repensée « institution contemporaine » : hiérarchie plus nette,
  espacements généreux, composants raffinés, micro-transitions discrètes,
  thèmes clair et sombre conservés ;
- tous les écrans réécrits : connexion, saisie (avec curseur d’heure et envoi
  différé), file de vérification et parcours, billets numériques, tableau de
  bord et créneaux chauds, bilan hebdomadaire anonymisé, historique élève,
  permis à points et courrier famille, bilan PP, administration complète
  (comptes, modules, accès, synchro LDAP, import CSV, années, récupération,
  purge, audit) ;
- code source dans `frontend/`, build copié automatiquement à côté de
  `api.php` (voir `BUILD_MAC.md`) ; sortie sans script inline, chemins relatifs
  (fonctionne sous `/suivi2/` comme `/suivi/`), CSP stricte respectée ;
- service worker adapté au build (noms de fichiers hachés, cache dérivé de
  `VERSION`), PWA installable et bandeau de mise à jour conservés ;
- tests de non-régression de l’envoi différé portés en JS
  (`node tests/run-deferred-tests.mjs`) : mémoire volatile, isolation par
  installation/environnement/compte, expiration, nettoyage du stockage.


## 1.0.0-rc.4 — 19 juillet 2026

### Envoi différé sécurisé

- protection facultative, désactivée par défaut et activable depuis
  l’administration ;
- conservation uniquement d’une requête interrompue au moment de l’envoi : la
  recherche d’élèves reste volontairement dépendante du serveur ;
- isolation par dossier d’installation, environnement, identifiant MySQL et
  compte LDAP afin qu’une file de test ne puisse jamais partir en production ;
- dix envois et douze heures au maximum, uniquement dans la mémoire de la page
  ouverte : aucun détail n’est écrit dans le stockage persistant du navigateur ;
- suppression à l’actualisation, à la fermeture, à l’expiration de session, à la
  déconnexion ou au changement de compte et d’environnement ;
- détection d’un changement de compte dans un autre onglet avant toute reprise ;
- reprise automatique ou manuelle, avec conservation des refus demandant une
  vérification et clé d’envoi empêchant les doublons techniques ;
- bandeau d’attente adapté aux écrans mobiles sans débordement horizontal.

### Installation et exploitation

- administrateur de secours facultatif : les deux comptes doivent
  s’authentifier réellement par LDAP avant l’écriture de la configuration ;
- vérificateur de déploiement en ligne de commande pour les en-têtes HTTPS et la
  protection des dossiers sensibles ;
- 17 tests PHP des calculs critiques, compatibles PHP 7.4 à PHP 8.5, plus un
  contrôle JavaScript de la mémoire volatile, de l’isolation et de l’expiration
  de la file ;
- aucune purge planifiée ajoutée : les opérations destructives restent dans la
  WebUI avec aperçu, réauthentification et point de récupération préalable.

### Versions techniques

- schéma MySQL : `9` (inchangé) ;
- format des données de récupération : `10` (inchangé).

## 1.0.0-rc.3 — 17 juillet 2026

### Fiabilité et accompagnement

- prévention précise d’un même constat renvoyé par le même auteur dans un délai de deux minutes ;
- clé d’envoi conservée lors d’une coupure réseau afin qu’un nouvel essai ne crée pas de doublon ;
- états visibles « envoi », « enregistré » et « réessayer » dans le formulaire ;
- notifications internes lorsqu’un constat personnel est confirmé ou annulé ;
- guide de première connexion affiché une fois, puis accessible depuis le bouton d’aide ;
- page d’état enrichie pour MySQL, LDAP, le dossier `var` et la fraîcheur de la récupération ;
- parcours guidé pour activer une nouvelle année, importer les élèves et clôturer l’ancienne ;
- bilan hebdomadaire anonymisé proposé par défaut, avec périodes étendues toujours disponibles.

### Versions techniques

- schéma MySQL : `9` ;
- format des données de récupération : `10`, avec restauration compatible des instantanés antérieurs.

## 1.0.0-rc.2 — 16 juillet 2026

### Améliorations

- remplacement des quatre choix horaires par un curseur précis de 0 à 20 minutes ;
- affichage immédiat de l’heure du constat calculée depuis l’horloge du serveur ;
- conservation du contexte minimal du billet numérique valable au moment du constat ;
- affichage de ce billet dans la file CPE/AED et dans les parcours rapprochés ;
- reprise automatique du contexte pour les signalements déjà présents lors de
  la migration, lorsque le billet correspondant existe encore ;
- aucune confirmation ou annulation automatique liée au billet.

### Versions techniques

- schéma MySQL : `8` ;
- format des données de récupération : `9`, avec restauration compatible des
  instantanés antérieurs.

## 1.0.0-rc.1 — 16 juillet 2026

Première version candidate complète de **Suivi des circulations**.

### Principales fonctions

- signalements horodatés, modifiables et vérifiés par la vie scolaire ;
- suivi explicite des parcours rapprochés ;
- tableau de bord, créneaux chauds et rapport anonymisé ;
- rôles LDAP, bilan professeur principal et journal des actions ;
- permis à points facultatif ;
- billets numériques facultatifs, désactivés par défaut ;
- sauvegardes de récupération, purge contrôlée et clôture annuelle ;
- PWA installable avec thèmes clair et sombre.

### Statut

Version candidate destinée aux essais sur l’installation de test. Elle deviendra
`1.0.0` après validation sur Kwartz avec LDAP et MySQL.
