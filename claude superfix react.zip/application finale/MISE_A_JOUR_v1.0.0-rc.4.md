# Mise à jour vers 1.0.0-rc.4

Cette mise à jour conserve la base MySQL, les élèves, les observations et la
configuration existante. Le schéma reste en version 9.

## Avant la mise à jour

1. Dans l’administration, créer un point de récupération manuel.
2. Conserver une copie du fichier serveur `var/settings.php`.
3. Effectuer d’abord la mise à jour dans le dossier de test.

## Fichiers à téléverser

Le ZIP RC4 est prêt à être extrait directement dans le dossier Web existant :
ses fichiers commencent par `index.html`, `api.php`, `assets/`, etc. Fusionner
et remplacer les fichiers indiqués, mais ne pas supprimer le dossier Web avant
l’extraction.

- `index.html`
- `service-worker.js`
- `VERSION`
- `CHANGELOG.md`
- `MISE_A_JOUR_v1.0.0-rc.4.md`
- `MISE_A_JOUR_APPLICATION_FINALE.md`
- `README.md`
- `PRODUCT.md`
- `DESIGN.md`
- `INSTALLATION_3_ETAPES.md`
- `install.php`
- `assets/app.js`
- `assets/impeccable.css`
- `src/ApiController.php`
- le dossier `tests/`
- `tools/verifier-deploiement.php`

Ne remplacez pas le dossier `var/` du serveur et, surtout, ne remplacez jamais
`var/settings.php`.

## Après le téléversement

1. Ouvrir l’application et accepter l’actualisation de la PWA si elle apparaît.
2. Vérifier que la version affichée est `1.0.0-rc.4`.
3. Ouvrir **Administration → Santé de l’application** et contrôler MySQL, LDAP
   et le dossier `var`.
4. Depuis le serveur, si l’accès à la ligne de commande est disponible :

   ```text
   php tests/run-tests.php
   node tests/run-deferred-tests.mjs
   php tools/verifier-deploiement.php https://serveur/suivi/
   ```

   Le test Node est facultatif si Node.js n’est pas installé sur Kwartz ; il est
   déjà exécuté avant la création du ZIP.

5. Dans l’installation de test seulement, activer **Envoi différé**, couper le
   réseau au moment d’un envoi puis vérifier sa reprise sans fermer
   l’application. La fonction reste désactivée par défaut en production.

## Points importants

- Une attente reste liée à l’installation, à l’environnement et au compte qui
  l’a créée : elle ne peut pas partir depuis l’autre dossier ou un autre compte.
- Les détails restent uniquement en mémoire. Actualiser ou fermer la page,
  laisser la session expirer ou se déconnecter supprime les envois en attente.
- L’envoi différé ne rend pas la recherche d’élèves disponible hors connexion.
- Aucune tâche planifiée de purge n’est ajoutée. Les purges restent déclenchées
  depuis la WebUI avec les protections existantes.
- L’administrateur de secours concerne les nouvelles installations : son propre
  mot de passe LDAP doit être vérifié pendant l’installation.
