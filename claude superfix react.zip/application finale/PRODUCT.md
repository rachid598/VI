# Contexte produit

## Produit

Application interne de collège pour signaler, confirmer et analyser les circulations
d’élèves. Ce n’est pas un outil de sanction automatique : les personnels doivent
pouvoir saisir vite, vérifier avec discernement et lire des tendances agrégées.
Le permis à points est un module facultatif, désactivé par défaut jusqu’à validation
du cadre local. Lorsqu’il est activé, il reste un support de dialogue : seuls les
constats confirmés ont un effet, un point peut être rendu et chaque action éducative
est décidée par un adulte.
Un même constat peut concerner plusieurs élèves, mais chaque signalement créé reste
individuel. La synchronisation LDAP des élèves est une opération admin avec aperçu.
Le constat peut être antidaté précisément de 0 à 20 minutes, toujours à partir
de l’horloge MySQL du serveur. Une observation peut être prise en charge pendant
20 minutes et un parcours ne confirme que les observations explicitement cochées.
Le module de billets numériques est facultatif et désactivé par défaut. Il produit
uniquement une destination et une durée courte ; aucun QR code, appareil élève,
géolocalisation ou motif libre n’est utilisé.
Lorsqu’un billet était valable à l’heure déclarée du constat, l’observation en
conserve un contexte minimal et immuable (destination et créneau de validité),
visible uniquement par les personnels chargés de la vérification. Ce contexte
n’entraîne aucune décision automatique.
Le même paquet applicatif peut servir à deux installations totalement séparées :
test avec données fictives et production avec données réelles.
Chaque installation peut conserver pendant sept jours des points de récupération
de ses données élèves, créés à l’activité au plus toutes les 30 minutes. Cette
récupération locale protège contre une erreur commise dans l’application ; elle ne
doit jamais être présentée comme une sauvegarde du serveur ou de MySQL.
Un envoi de signalement possède une clé technique temporaire : une reprise après
une coupure réseau renvoie le résultat déjà créé au lieu de dupliquer les données.
L'administrateur peut activer une protection d'envoi différé, désactivée par
défaut. Elle ne permet pas de rechercher un élève hors connexion : elle conserve
uniquement une requête déjà prête lorsque le réseau se coupe exactement au moment
de l'envoi. La file est isolée par installation, environnement et compte LDAP,
limitée à dix entrées et à douze heures. Elle reste uniquement dans la mémoire de
la page ouverte : aucun détail n'est écrit dans le stockage persistant du
navigateur, et l'actualisation, la fermeture, l'expiration de session ou la
déconnexion la supprime. Aucun nom d'élève n'est affiché dans son résumé.
L'alerte métier de doublon ne concerne que le même auteur, le même élève, le même
lieu et le même motif dans une fenêtre de deux minutes.
L'auteur reçoit une notification interne lorsque son propre constat est confirmé
ou annulé. Aucune notification externe n'est envoyée.
Le premier démarrage présente un guide court mémorisé dans le navigateur. Le bilan
anonymisé s'ouvre sur sept jours et l'administration réunit l'état des services et
un parcours guidé de changement d'année.

## Utilisateurs

- enseignants et personnels de service, souvent sur téléphone et pressés ;
- AED et CPE qui traitent une file chronologique ;
- direction et administrateur qui lisent les indicateurs et gèrent les accès ;
- professeurs principaux qui consultent leur classe.

## Registre

Interface produit, pas page marketing. Le ton doit être calme, institutionnel,
direct et rassurant. La densité est utile si la hiérarchie reste immédiate.

## Sensation recherchée

Institution contemporaine : une interface élégante, calme et assurée, inspirée par
les couleurs du collège sans devenir décorative. Le formulaire de signalement est
le point focal. Les thèmes clair et sombre conservent la même hiérarchie et les
mêmes contrastes. Le logo est fort à la connexion, puis discret dans l’outil.

## À éviter

- gradients décoratifs, verre dépoli et effets lumineux ;
- cartes imbriquées, ombres diffuses et arrondis excessifs ;
- gros titres promotionnels, microtextes redondants et couleurs criardes ;
- animations décoratives ou éléments qui ralentissent la saisie ;
- mise en cache de données personnelles dans la PWA, hors protection d'envoi
  différé explicitement activée et strictement encadrée ci-dessus.
- seuils transformés en sanctions ou courriers envoyés automatiquement.
- remplacement silencieux de la liste d’élèves sans aperçu ni garde-fou d’effectif.
- purge ou restauration déclenchée sans aperçu, réauthentification LDAP, phrase
  explicite et point de récupération préalable.
- promesse d’une sauvegarde exacte toutes les 30 minutes : sans activité WebUI,
  aucun point ne peut être créé.
- restauration de comptes, rôles, réglages, audit ou configuration depuis un état
  de données élèves.
- validation implicite de toutes les observations proches lors de la création
  d’un parcours.
- rapport nominatif présenté comme un indicateur d’organisation ; le rapport
  hebdomadaire conserve des agrégats et masque les effectifs inférieurs à trois.
- clôture de l’année active, ou d’une ancienne année sans aperçu, mot de passe,
  phrase exacte et point de récupération préalable.
