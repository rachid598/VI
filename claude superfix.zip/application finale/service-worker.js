"use strict";

function scopeFingerprint(value) {
  let hash = 2166136261;
  for (let index = 0; index < value.length; index++) {
    hash ^= value.charCodeAt(index);
    hash = Math.imul(hash, 16777619);
  }
  return (hash >>> 0).toString(36);
}

const CACHE_PREFIX = `suivi-circulations-${scopeFingerprint(self.registration.scope)}-`;
const CACHE_NAME = `${CACHE_PREFIX}shell-v25`;
const REQUIRED_SHELL_ASSETS = [
  "./index.html",
  "./manifest.json?v=5",
  "./assets/app.css?v=2e",
  "./assets/impeccable.css?v=21",
  "./assets/url-sanitizer.js?v=1",
  "./assets/app.js?v=26",
];
const OPTIONAL_SHELL_ASSETS = [
  "./assets/app-icon.svg?v=1",
  "./assets/app-icon-192.png?v=1",
  "./assets/app-icon-512.png?v=1",
  "./assets/logo-college.jpeg?v=3",
];

self.addEventListener("install", (event) => {
  event.waitUntil(
    caches.open(CACHE_NAME)
      .then(async (cache) => {
        await cache.addAll(REQUIRED_SHELL_ASSETS);
        await Promise.allSettled(OPTIONAL_SHELL_ASSETS.map((asset) => cache.add(asset)));
      }),
  );
});

self.addEventListener("activate", (event) => {
  event.waitUntil(
    caches.keys()
      .then((names) => Promise.all(names.filter((name) => name.startsWith(CACHE_PREFIX) && name !== CACHE_NAME).map((name) => caches.delete(name))))
      .then(() => self.clients.claim()),
  );
});

self.addEventListener("message", (event) => {
  if (event.data && event.data.type === "SKIP_WAITING") {
    self.skipWaiting();
  }
});

self.addEventListener("fetch", (event) => {
  const request = event.request;
  if (request.method !== "GET") return;

  const url = new URL(request.url);
  if (url.origin !== self.location.origin) return;
  if (!url.href.startsWith(self.registration.scope)) return;

  const sensitivePath = /\/(api\.php|install\.php)(?:$|\?)/.test(url.pathname)
    || /\/(var|database|src|tools|donnees)(?:\/|$)/.test(url.pathname);
  if (sensitivePath) {
    event.respondWith(fetch(request, { cache: "no-store", credentials: "same-origin" }));
    return;
  }

  if (request.mode === "navigate") {
    event.respondWith(
      fetch(request, { cache: "no-store", credentials: "same-origin" })
        .catch(() => caches.open(CACHE_NAME).then((cache) => cache.match("./index.html"))),
    );
    return;
  }

  const staticDestination = ["style", "script", "image", "manifest"].includes(request.destination)
    || url.pathname.endsWith(".webmanifest")
    || url.pathname.endsWith("manifest.json");
  if (staticDestination) {
    const network = fetch(request).then(async (response) => {
      if (response.ok) {
        const cache = await caches.open(CACHE_NAME);
        await cache.put(request, response.clone());
      }
      return response;
    });
    event.waitUntil(network.then(() => undefined).catch(() => undefined));
    event.respondWith(caches.open(CACHE_NAME).then((cache) => cache.match(request)).then((cached) => cached || network));
  }
});
