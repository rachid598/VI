<?php

declare(strict_types=1);

/**
 * Indicateurs administratifs, rapport anonyme et clôture d'une année scolaire.
 *
 * Cette classe ne décide d'aucun droit et ne crée aucun instantané : le
 * contrôleur doit vérifier l'administrateur, acquérir le verrou métier et créer
 * le point de récupération avant d'appeler closeYear().
 */
final class FinalAdminService
{
    private const REPORT_DAYS = [7, 28, 90];
    private const PRIVACY_THRESHOLD = 3;

    /** @var PDO */
    private $pdo;

    public function __construct(PDO $pdo)
    {
        $this->pdo = $pdo;
    }

    /** @return array<string,mixed> */
    public function health(string $schoolYear): array
    {
        $schoolYear = $this->validatedSchoolYear($schoolYear);

        $students = $this->pdo->prepare(
            'SELECT COUNT(*) AS active_students,
                    COUNT(DISTINCT class_name) AS active_classes
             FROM students
             WHERE school_year = :school_year AND active = 1'
        );
        $students->execute(['school_year' => $schoolYear]);
        $studentCounts = $students->fetch() ?: [];

        $lastImport = $this->pdo->prepare(
            'SELECT id, row_count, created_at
             FROM student_imports
             WHERE school_year = :school_year
             ORDER BY created_at DESC, id DESC
             LIMIT 1'
        );
        $lastImport->execute(['school_year' => $schoolYear]);

        $lastSync = $this->pdo->prepare(
            "SELECT id, created_at
             FROM audit_logs
             WHERE action = 'students.ldap_sync'
               AND JSON_UNQUOTE(JSON_EXTRACT(metadata, '$.school_year')) = :school_year
             ORDER BY created_at DESC, id DESC
             LIMIT 1"
        );
        $lastSync->execute(['school_year' => $schoolYear]);

        $lastConnection = $this->pdo->query(
            'SELECT id, ldap_uid, first_name, last_name, role, last_login_at
             FROM users
             WHERE last_login_at IS NOT NULL
             ORDER BY last_login_at DESC, id DESC
             LIMIT 1'
        );

        $lastSnapshot = $this->pdo->prepare(
            'SELECT id, kind, school_year, payload_bytes, created_at, expires_at
             FROM recovery_snapshots
             WHERE school_year = :school_year OR school_year IS NULL
             ORDER BY created_at DESC, id DESC
             LIMIT 1'
        );
        $lastSnapshot->execute(['school_year' => $schoolYear]);

        $pending = $this->pdo->prepare(
            "SELECT COUNT(*)
             FROM observations o
             INNER JOIN students s ON s.id = o.student_id
             WHERE s.school_year = :school_year
               AND o.status = 'pending'
               AND o.occurred_at < UTC_TIMESTAMP() - INTERVAL 24 HOUR"
        );
        $pending->execute(['school_year' => $schoolYear]);

        $inactiveAccounts = $this->pdo->query(
            "SELECT id, ldap_uid, first_name, last_name, role, last_login_at,
                    CASE WHEN last_login_at IS NULL THEN 'never'
                         ELSE 'over_90_days' END AS inactivity_reason
             FROM users
             WHERE active = 1
               AND (last_login_at IS NULL
                    OR last_login_at < UTC_TIMESTAMP() - INTERVAL 90 DAY)
             ORDER BY last_login_at IS NULL DESC, last_login_at ASC,
                      last_name ASC, first_name ASC, ldap_uid ASC"
        );
        $inactiveRows = $inactiveAccounts->fetchAll();

        return [
            'school_year' => $schoolYear,
            'active_students' => (int) ($studentCounts['active_students'] ?? 0),
            'active_classes' => (int) ($studentCounts['active_classes'] ?? 0),
            'last_import' => $this->importOutput($lastImport->fetch() ?: null),
            'last_ldap_sync' => $this->simpleDatedOutput($lastSync->fetch() ?: null),
            'last_connection' => $this->accountOutput($lastConnection->fetch() ?: null),
            'last_backup' => $this->snapshotOutput($lastSnapshot->fetch() ?: null),
            'pending_over_24h' => (int) $pending->fetchColumn(),
            'inactive_accounts_count' => count($inactiveRows),
            'inactive_accounts' => array_map([$this, 'accountOutput'], $inactiveRows),
            'generated_at' => gmdate('Y-m-d H:i:s'),
        ];
    }

    /** @return array<string,mixed> */
    public function anonymousReport(string $schoolYear, int $days): array
    {
        $schoolYear = $this->validatedSchoolYear($schoolYear);
        if (!in_array($days, self::REPORT_DAYS, true)) {
            throw new InvalidArgumentException('La période du rapport doit être de 7, 28 ou 90 jours.');
        }

        $now = new DateTimeImmutable('now', new DateTimeZone('UTC'));
        $currentStart = $now->modify('-' . $days . ' days');
        $previousStart = $now->modify('-' . ($days * 2) . ' days');

        $statement = $this->pdo->prepare(
            "SELECT o.occurred_at, o.location
             FROM observations o
             INNER JOIN students s ON s.id = o.student_id
             WHERE s.school_year = :school_year
               AND o.status = 'confirmed'
               AND o.occurred_at >= :previous_start
               AND o.occurred_at < :period_end
             ORDER BY o.occurred_at ASC, o.id ASC"
        );
        $statement->execute([
            'school_year' => $schoolYear,
            'previous_start' => $previousStart->format('Y-m-d H:i:s'),
            'period_end' => $now->format('Y-m-d H:i:s'),
        ]);

        $locations = [];
        $weekdays = [];
        $slots = [];
        $daily = [];
        $currentTotal = 0;
        $previousTotal = 0;
        $utc = new DateTimeZone('UTC');
        $paris = new DateTimeZone('Europe/Paris');

        foreach ($statement->fetchAll() as $row) {
            try {
                $occurredAt = new DateTimeImmutable((string) $row['occurred_at'], $utc);
            } catch (Exception $error) {
                continue;
            }
            if ($occurredAt < $currentStart) {
                $previousTotal++;
                continue;
            }

            $currentTotal++;
            $localDate = $occurredAt->setTimezone($paris);
            $location = (string) $row['location'];
            $weekday = (int) $localDate->format('N');
            $slot = $this->schoolTimeSlot($localDate);
            $date = $localDate->format('Y-m-d');

            $locations[$location] = ($locations[$location] ?? 0) + 1;
            $weekdays[$weekday] = ($weekdays[$weekday] ?? 0) + 1;
            $daily[$date] = ($daily[$date] ?? 0) + 1;
            if ($slot !== null) {
                $slots[$slot] = ($slots[$slot] ?? 0) + 1;
            }
        }

        ksort($locations, SORT_NATURAL | SORT_FLAG_CASE);
        ksort($weekdays, SORT_NUMERIC);
        $slots = $this->orderedSlotCounts($slots);
        ksort($daily, SORT_STRING);

        $currentMasked = $this->maskedCount($currentTotal);
        $previousMasked = $this->maskedCount($previousTotal);
        $changePercent = null;
        if (!$currentMasked['suppressed'] && !$previousMasked['suppressed'] && $previousTotal > 0) {
            $changePercent = round((($currentTotal - $previousTotal) / $previousTotal) * 100, 1);
        }

        return [
            'school_year' => $schoolYear,
            'days' => $days,
            'period' => [
                'start_utc' => $currentStart->format('Y-m-d H:i:s'),
                'end_utc' => $now->format('Y-m-d H:i:s'),
            ],
            'privacy_threshold' => self::PRIVACY_THRESHOLD,
            'confirmed_total' => $currentMasked,
            'previous_period_total' => $previousMasked,
            'change_percent' => $changePercent,
            'by_location' => $this->dimensionOutput($locations),
            'by_weekday' => $this->weekdayOutput($weekdays),
            'by_school_slot' => $this->dimensionOutput($slots),
            'evolution' => $this->datedOutput($daily),
            'generated_at' => $now->format('Y-m-d H:i:s'),
        ];
    }

    /** @return array<string,mixed> */
    public function closurePreview(string $schoolYear): array
    {
        $schoolYear = $this->validatedSchoolYear($schoolYear);
        return $this->buildClosureData($schoolYear);
    }

    /** @return array<string,mixed> */
    public function closeYear(
        string $schoolYear,
        int $actorId,
        ?int $snapshotId,
        callable $audit
    ): array {
        $schoolYear = $this->validatedSchoolYear($schoolYear);
        if ($actorId <= 0) {
            throw new InvalidArgumentException('Administrateur de clôture invalide.');
        }
        if ($snapshotId !== null && $snapshotId <= 0) {
            throw new InvalidArgumentException('Identifiant de sauvegarde invalide.');
        }
        if ($this->pdo->inTransaction()) {
            throw new LogicException('La clôture doit gérer sa propre transaction.');
        }

        $this->pdo->beginTransaction();
        try {
            // Verrouille la même ligne que le changement d'année active : la
            // décision ne dépend donc jamais d'une valeur lue avant la transaction.
            $activeSetting = $this->pdo->prepare(
                'SELECT setting_value FROM app_settings
                 WHERE setting_key = :setting_key FOR UPDATE'
            );
            $activeSetting->execute(['setting_key' => 'active_school_year']);
            $activeYear = $activeSetting->fetchColumn();
            if (!is_string($activeYear) || $activeYear === '') {
                throw new RuntimeException('L’année scolaire active est indisponible.');
            }
            if (hash_equals($activeYear, $schoolYear)) {
                throw new RuntimeException('L’année scolaire active ne peut pas être clôturée.');
            }

            $existing = $this->pdo->prepare(
                'SELECT id FROM year_closures WHERE school_year = :school_year FOR UPDATE'
            );
            $existing->execute(['school_year' => $schoolYear]);
            if ($existing->fetchColumn() !== false) {
                throw new RuntimeException('Cette année scolaire est déjà clôturée.');
            }

            // Bloque les élèves de l'année : les insertions dans les tables
            // enfants ne peuvent ainsi pas courir en parallèle de la purge.
            $studentLock = $this->pdo->prepare(
                'SELECT id FROM students WHERE school_year = :school_year FOR UPDATE'
            );
            $studentLock->execute(['school_year' => $schoolYear]);
            $studentLock->fetchAll();

            $data = $this->buildClosureData($schoolYear);
            if ((int) $data['counts']['students'] === 0) {
                throw new RuntimeException('Cette année scolaire ne contient aucun élève à clôturer.');
            }
            $hashPayload = [
                'school_year' => $schoolYear,
                'counts' => $data['counts'],
                'aggregates' => $data['aggregates'],
            ];
            $encodedPayload = json_encode(
                $hashPayload,
                JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES | JSON_PRESERVE_ZERO_FRACTION
            );
            if (!is_string($encodedPayload)) {
                throw new RuntimeException('Impossible de calculer l’empreinte de clôture.');
            }
            $aggregateHash = hash('sha256', $encodedPayload);

            $insertClosure = $this->pdo->prepare(
                'INSERT INTO year_closures
                    (school_year, closed_by_user_id, closed_at, student_count,
                     observation_count, aggregate_sha256)
                 VALUES
                    (:school_year, :actor_id, UTC_TIMESTAMP(), :student_count,
                     :observation_count, :aggregate_sha256)'
            );
            $insertClosure->execute([
                'school_year' => $schoolYear,
                'actor_id' => $actorId,
                'student_count' => (int) $data['counts']['students'],
                'observation_count' => (int) $data['counts']['observations'],
                'aggregate_sha256' => $aggregateHash,
            ]);
            $closureId = (int) $this->pdo->lastInsertId();

            $insertAggregate = $this->pdo->prepare(
                'INSERT INTO annual_aggregates
                    (closure_id, school_year, metric_key, dimension_key,
                     dimension_value, metric_value)
                 VALUES
                    (:closure_id, :school_year, :metric_key, :dimension_key,
                     :dimension_value, :metric_value)'
            );
            foreach ($data['aggregates'] as $aggregate) {
                $insertAggregate->execute([
                    'closure_id' => $closureId,
                    'school_year' => $schoolYear,
                    'metric_key' => (string) $aggregate['metric_key'],
                    'dimension_key' => (string) $aggregate['dimension_key'],
                    'dimension_value' => (string) $aggregate['dimension_value'],
                    'metric_value' => (int) $aggregate['metric_value'],
                ]);
            }

            $this->deleteYearData($schoolYear);

            $metadata = [
                'school_year' => $schoolYear,
                'student_count' => (int) $data['counts']['students'],
                'observation_count' => (int) $data['counts']['observations'],
                'point_adjustment_count' => (int) $data['counts']['point_adjustments'],
                'digital_pass_count' => (int) $data['counts']['digital_passes'],
                'aggregate_count' => count($data['aggregates']),
                'aggregate_sha256' => $aggregateHash,
                'snapshot_id' => $snapshotId,
            ];
            $audit($this->pdo, 'school_year.close', 'year_closure', $closureId, $metadata);

            $this->pdo->commit();
            return [
                'closure_id' => $closureId,
                'school_year' => $schoolYear,
                'snapshot_id' => $snapshotId,
                'counts' => $data['counts'],
                'aggregate_count' => count($data['aggregates']),
                'aggregate_sha256' => $aggregateHash,
            ];
        } catch (Throwable $error) {
            if ($this->pdo->inTransaction()) {
                $this->pdo->rollBack();
            }
            throw $error;
        }
    }

    /** @return array<string,mixed> */
    private function buildClosureData(string $schoolYear): array
    {
        $counts = $this->yearCounts($schoolYear);
        $aggregates = [];

        $statusCounts = $this->groupedCount(
            "SELECT o.status AS dimension_value, COUNT(*) AS metric_value
             FROM observations o
             INNER JOIN students s ON s.id = o.student_id
             WHERE s.school_year = :school_year
             GROUP BY o.status",
            $schoolYear
        );
        $this->appendPrivateAggregates($aggregates, 'observations_count', 'status', $statusCounts);

        $locationCounts = $this->groupedCount(
            "SELECT o.location AS dimension_value, COUNT(*) AS metric_value
             FROM observations o
             INNER JOIN students s ON s.id = o.student_id
             WHERE s.school_year = :school_year AND o.status = 'confirmed'
             GROUP BY o.location",
            $schoolYear
        );
        $this->appendPrivateAggregates($aggregates, 'confirmed_observations', 'location', $locationCounts);

        $confirmedDates = $this->pdo->prepare(
            "SELECT o.occurred_at
             FROM observations o
             INNER JOIN students s ON s.id = o.student_id
             WHERE s.school_year = :school_year AND o.status = 'confirmed'
             ORDER BY o.occurred_at ASC, o.id ASC"
        );
        $confirmedDates->execute(['school_year' => $schoolYear]);
        $weekdayCounts = [];
        $slotCounts = [];
        $utc = new DateTimeZone('UTC');
        $paris = new DateTimeZone('Europe/Paris');
        foreach ($confirmedDates->fetchAll() as $row) {
            try {
                $localDate = (new DateTimeImmutable((string) $row['occurred_at'], $utc))
                    ->setTimezone($paris);
            } catch (Exception $error) {
                continue;
            }
            $weekday = (string) $localDate->format('N');
            $weekdayCounts[$weekday] = ($weekdayCounts[$weekday] ?? 0) + 1;
            $slot = $this->schoolTimeSlot($localDate);
            if ($slot !== null) {
                $slotCounts[$slot] = ($slotCounts[$slot] ?? 0) + 1;
            }
        }
        ksort($weekdayCounts, SORT_NUMERIC);
        $slotCounts = $this->orderedSlotCounts($slotCounts);
        $this->appendPrivateAggregates($aggregates, 'confirmed_observations', 'weekday', $weekdayCounts);
        $this->appendPrivateAggregates($aggregates, 'confirmed_observations', 'school_slot', $slotCounts);

        // Même les totaux globaux ne sont conservés que si au moins trois
        // enregistrements y contribuent. Le total de points seul pourrait
        // sinon révéler l'unique ajustement d'une petite cohorte.
        if ((int) $counts['point_adjustments'] >= self::PRIVACY_THRESHOLD) {
            $aggregates[] = $this->aggregate('point_adjustments_count', 'overall', 'all', (int) $counts['point_adjustments']);
            $aggregates[] = $this->aggregate('points_granted', 'overall', 'all', (int) $counts['points_granted']);
        }
        if ((int) $counts['digital_passes'] >= self::PRIVACY_THRESHOLD) {
            $aggregates[] = $this->aggregate('digital_passes_count', 'overall', 'all', (int) $counts['digital_passes']);
        }

        usort($aggregates, static function (array $left, array $right): int {
            return [$left['metric_key'], $left['dimension_key'], $left['dimension_value']]
                <=> [$right['metric_key'], $right['dimension_key'], $right['dimension_value']];
        });

        return [
            'school_year' => $schoolYear,
            'privacy_threshold' => self::PRIVACY_THRESHOLD,
            'counts' => $counts,
            'aggregates' => $aggregates,
        ];
    }

    /** @return array<string,int> */
    private function yearCounts(string $schoolYear): array
    {
        $students = $this->pdo->prepare(
            'SELECT COUNT(*) FROM students WHERE school_year = :school_year'
        );
        $students->execute(['school_year' => $schoolYear]);

        $observations = $this->pdo->prepare(
            'SELECT COUNT(*) FROM observations o
             INNER JOIN students s ON s.id = o.student_id
             WHERE s.school_year = :school_year'
        );
        $observations->execute(['school_year' => $schoolYear]);

        $points = $this->pdo->prepare(
            'SELECT COUNT(*) AS adjustment_count, COALESCE(SUM(pa.points), 0) AS granted_points
             FROM point_adjustments pa
             INNER JOIN students s ON s.id = pa.student_id
             WHERE s.school_year = :school_year'
        );
        $points->execute(['school_year' => $schoolYear]);
        $pointCounts = $points->fetch() ?: [];

        $actions = $this->pdo->prepare(
            'SELECT COUNT(*) FROM action_records WHERE school_year = :school_year'
        );
        $actions->execute(['school_year' => $schoolYear]);

        $passes = $this->pdo->prepare(
            'SELECT COUNT(*) FROM digital_passes WHERE school_year = :school_year'
        );
        $passes->execute(['school_year' => $schoolYear]);

        $imports = $this->pdo->prepare(
            'SELECT COUNT(*) FROM student_imports WHERE school_year = :school_year'
        );
        $imports->execute(['school_year' => $schoolYear]);

        return [
            'students' => (int) $students->fetchColumn(),
            'observations' => (int) $observations->fetchColumn(),
            'point_adjustments' => (int) ($pointCounts['adjustment_count'] ?? 0),
            'points_granted' => (int) ($pointCounts['granted_points'] ?? 0),
            'action_records' => (int) $actions->fetchColumn(),
            'digital_passes' => (int) $passes->fetchColumn(),
            'student_imports' => (int) $imports->fetchColumn(),
        ];
    }

    /** @return array<string,int> */
    private function groupedCount(string $sql, string $schoolYear): array
    {
        $statement = $this->pdo->prepare($sql);
        $statement->execute(['school_year' => $schoolYear]);
        $counts = [];
        foreach ($statement->fetchAll() as $row) {
            $counts[(string) $row['dimension_value']] = (int) $row['metric_value'];
        }
        ksort($counts, SORT_NATURAL | SORT_FLAG_CASE);
        return $counts;
    }

    /**
     * @param array<int,array<string,mixed>> $target
     * @param array<string,int> $counts
     */
    private function appendPrivateAggregates(array &$target, string $metricKey, string $dimensionKey, array $counts): void
    {
        foreach ($counts as $value => $count) {
            if ($count < self::PRIVACY_THRESHOLD) {
                continue;
            }
            $target[] = $this->aggregate($metricKey, $dimensionKey, (string) $value, $count);
        }
    }

    /** @return array<string,mixed> */
    private function aggregate(string $metricKey, string $dimensionKey, string $dimensionValue, int $metricValue): array
    {
        return [
            'metric_key' => $metricKey,
            'dimension_key' => $dimensionKey,
            'dimension_value' => $dimensionValue,
            'metric_value' => $metricValue,
        ];
    }

    private function deleteYearData(string $schoolYear): void
    {
        $studentSubquery = 'SELECT id FROM students WHERE school_year = :school_year';
        $queries = [
            'DELETE FROM digital_passes WHERE school_year = :school_year',
            "DELETE FROM action_records WHERE school_year = :school_year",
            "DELETE FROM point_adjustments WHERE student_id IN ($studentSubquery)",
            "DELETE FROM observations WHERE student_id IN ($studentSubquery)",
            'DELETE FROM students WHERE school_year = :school_year',
            'DELETE FROM student_imports WHERE school_year = :school_year',
        ];
        foreach ($queries as $sql) {
            $statement = $this->pdo->prepare($sql);
            $statement->execute(['school_year' => $schoolYear]);
        }
    }

    private function validatedSchoolYear(string $schoolYear): string
    {
        $schoolYear = trim($schoolYear);
        if ($schoolYear === '') {
            throw new InvalidArgumentException('L’année scolaire est obligatoire.');
        }
        if (!preg_match('/^(20\d{2})-(20\d{2})$/D', $schoolYear, $matches)
            || (int) $matches[2] !== (int) $matches[1] + 1) {
            throw new InvalidArgumentException('L’année scolaire doit être au format 2026-2027.');
        }
        return $schoolYear;
    }

    private function schoolTimeSlot(DateTimeImmutable $localDate): ?string
    {
        $minutes = ((int) $localDate->format('G') * 60) + (int) $localDate->format('i');
        if ($minutes < 8 * 60 + 5) {
            return 'Accueil';
        }
        if ($minutes < 9 * 60 + 3) {
            return 'M1';
        }
        if ($minutes < 9 * 60 + 58) {
            return 'M2';
        }
        if ($minutes < 10 * 60 + 17) {
            return 'Récréation matin';
        }
        if ($minutes < 11 * 60 + 15) {
            return 'M3';
        }
        if ($minutes < 12 * 60 + 10) {
            return 'M4';
        }
        if ($minutes < 13 * 60 + 35) {
            return 'Pause méridienne';
        }
        if ($minutes < 14 * 60 + 33) {
            return 'S1';
        }
        if ($minutes < 15 * 60 + 28) {
            return 'S2';
        }
        if ($minutes < 15 * 60 + 47) {
            return 'Récréation après-midi';
        }
        if ($minutes < 16 * 60 + 42) {
            return 'S3';
        }
        if ($minutes < 17 * 60 + 30) {
            return 'S4';
        }
        return null;
    }

    /** @param array<string,int> $counts @return array<string,int> */
    private function orderedSlotCounts(array $counts): array
    {
        $order = [
            'Accueil', 'M1', 'M2', 'Récréation matin', 'M3', 'M4',
            'Pause méridienne', 'S1', 'S2', 'Récréation après-midi', 'S3', 'S4',
        ];
        $ordered = [];
        foreach ($order as $slot) {
            if (isset($counts[$slot])) {
                $ordered[$slot] = $counts[$slot];
            }
        }
        return $ordered;
    }

    /** @return array<string,mixed> */
    private function maskedCount(int $count): array
    {
        if ($count > 0 && $count < self::PRIVACY_THRESHOLD) {
            return ['total' => null, 'suppressed' => true, 'display' => '< 3'];
        }
        return ['total' => $count, 'suppressed' => false, 'display' => (string) $count];
    }

    /** @param array<string,int> $counts @return array<int,array<string,mixed>> */
    private function dimensionOutput(array $counts): array
    {
        $output = [];
        foreach ($counts as $label => $count) {
            $output[] = ['label' => (string) $label] + $this->maskedCount($count);
        }
        return $output;
    }

    /** @param array<int|string,int> $counts @return array<int,array<string,mixed>> */
    private function weekdayOutput(array $counts): array
    {
        $labels = [
            1 => 'Lundi', 2 => 'Mardi', 3 => 'Mercredi', 4 => 'Jeudi',
            5 => 'Vendredi', 6 => 'Samedi', 7 => 'Dimanche',
        ];
        $output = [];
        foreach ($counts as $weekday => $count) {
            $number = (int) $weekday;
            $output[] = [
                'weekday' => $number,
                'label' => $labels[$number] ?? (string) $number,
            ] + $this->maskedCount($count);
        }
        return $output;
    }

    /** @param array<string,int> $counts @return array<int,array<string,mixed>> */
    private function datedOutput(array $counts): array
    {
        $output = [];
        foreach ($counts as $date => $count) {
            $output[] = ['date' => $date] + $this->maskedCount($count);
        }
        return $output;
    }

    /** @param array<string,mixed>|null $row @return array<string,mixed>|null */
    private function importOutput(?array $row): ?array
    {
        if ($row === null) {
            return null;
        }
        return [
            'id' => (int) $row['id'],
            'row_count' => (int) $row['row_count'],
            'created_at' => (string) $row['created_at'],
        ];
    }

    /** @param array<string,mixed>|null $row @return array<string,mixed>|null */
    private function simpleDatedOutput(?array $row): ?array
    {
        if ($row === null) {
            return null;
        }
        return ['id' => (int) $row['id'], 'created_at' => (string) $row['created_at']];
    }

    /** @param array<string,mixed>|null $row @return array<string,mixed>|null */
    private function accountOutput(?array $row): ?array
    {
        if ($row === null) {
            return null;
        }
        $output = [
            'id' => (int) $row['id'],
            'uid' => (string) $row['ldap_uid'],
            'first_name' => (string) $row['first_name'],
            'last_name' => (string) $row['last_name'],
            'role' => (string) $row['role'],
            'last_login_at' => $row['last_login_at'] === null ? null : (string) $row['last_login_at'],
        ];
        if (isset($row['inactivity_reason'])) {
            $output['inactivity_reason'] = (string) $row['inactivity_reason'];
        }
        return $output;
    }

    /** @param array<string,mixed>|null $row @return array<string,mixed>|null */
    private function snapshotOutput(?array $row): ?array
    {
        if ($row === null) {
            return null;
        }
        return [
            'id' => (int) $row['id'],
            'kind' => (string) $row['kind'],
            'school_year' => $row['school_year'] === null ? null : (string) $row['school_year'],
            'size_bytes' => (int) $row['payload_bytes'],
            'created_at' => (string) $row['created_at'],
            'expires_at' => (string) $row['expires_at'],
        ];
    }
}
