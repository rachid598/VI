<?php

declare(strict_types=1);

// Défense en profondeur : même si un autre point d'entrée charge directement
// le bootstrap, les arguments (dont les mots de passe LDAP) restent absents
// des traces d'exception et aucune erreur brute n'est envoyée au navigateur.
ini_set('display_errors', '0');
ini_set('log_errors', '1');
ini_set('zend.exception_ignore_args', '1');

final class HttpException extends RuntimeException
{
    /** @var int */
    private $status;

    public function __construct(int $status, string $message)
    {
        parent::__construct($message);
        $this->status = $status;
    }

    public function status(): int
    {
        return $this->status;
    }
}

define('SC_ROOT', dirname(__DIR__));

$appVersionPath = SC_ROOT . '/VERSION';
$appVersion = is_readable($appVersionPath)
    ? trim((string) file_get_contents($appVersionPath))
    : '';
if (!preg_match('/^\d+\.\d+\.\d+(?:-[0-9A-Za-z.-]+)?$/', $appVersion)) {
    $appVersion = '0.0.0-dev';
}
define('SC_APP_VERSION', $appVersion);

if (PHP_VERSION_ID < 70400) {
    throw new RuntimeException('PHP 7.4 minimum est requis.');
}

$configPath = SC_ROOT . '/var/settings.php';
if (!is_file($configPath)) {
    throw new HttpException(503, 'Installation requise.');
}
$config = require $configPath;

$configuredEnvironment = isset($config['app']['environment'])
    ? strtolower(trim((string) $config['app']['environment']))
    : '';
if (!in_array($configuredEnvironment, ['test', 'production'], true)) {
    // Compatibilité des installations antérieures : avec l’architecture
    // documentée, `suivi-test` est le test et `suivi` la production. Tout autre
    // nom est traité comme production afin d’afficher les avertissements les
    // plus stricts pour les opérations destructives.
    $folderName = strtolower((string) basename(SC_ROOT));
    $configuredEnvironment = strpos($folderName, 'test') !== false
        || strpos($folderName, 'demo') !== false
        || strpos($folderName, 'démo') !== false
        ? 'test'
        : 'production';
}
$config['app']['environment'] = $configuredEnvironment;

// Les nouvelles installations possèdent un identifiant aléatoire explicite.
// Pour les settings.php antérieurs, un identifiant stable est dérivé de la
// clé secrète existante : aucune réinstallation ni modification manuelle du
// fichier n'est nécessaire.
$configuredInstallationId = isset($config['app']['installation_id'])
    ? strtolower(trim((string) $config['app']['installation_id']))
    : '';
if (!preg_match('/^[a-f0-9]{32,64}$/', $configuredInstallationId)) {
    $legacyAppKey = isset($config['app']['key']) ? (string) $config['app']['key'] : '';
    if ($legacyAppKey === '') {
        throw new RuntimeException('Clé de configuration absente.');
    }
    $configuredInstallationId = hash_hmac(
        'sha256',
        'suivi-installation-id-v1',
        $legacyAppKey
    );
}
$config['app']['installation_id'] = $configuredInstallationId;

require_once SC_ROOT . '/src/Database.php';
require_once SC_ROOT . '/src/SchemaMigrator.php';
require_once SC_ROOT . '/src/RecoveryService.php';
require_once SC_ROOT . '/src/LdapAuthenticator.php';
require_once SC_ROOT . '/src/AuthService.php';
require_once SC_ROOT . '/src/DigitalPassService.php';
require_once SC_ROOT . '/src/FinalAdminService.php';

$currentInstallationScopeHash = SchemaMigrator::installationScopeHash(
    SC_ROOT,
    (string) $config['app']['installation_id']
);
$configuredScopeHash = isset($config['app']['installation_scope_hash'])
    ? strtolower(trim((string) $config['app']['installation_scope_hash']))
    : '';
if ($configuredScopeHash !== ''
    && (!preg_match('/^[a-f0-9]{64}$/', $configuredScopeHash)
        || !hash_equals($configuredScopeHash, $currentInstallationScopeHash))) {
    throw new InstallationBindingException(
        'Ce fichier settings.php appartient à un autre dossier d’installation.'
    );
}
$config['app']['installation_scope_hash'] = $currentInstallationScopeHash;

header('X-Content-Type-Options: nosniff');
header('X-Frame-Options: DENY');
header('Referrer-Policy: no-referrer');
header("Permissions-Policy: camera=(), microphone=(), geolocation=()");
header('X-Suivi-Version: ' . SC_APP_VERSION);

$isHttps = (!empty($_SERVER['HTTPS']) && strtolower((string) $_SERVER['HTTPS']) !== 'off');
// Fail closed : seule la valeur booléenne explicite false autorise un usage
// sans TLS (cas de développement local). Une clé absente, une chaîne "false"
// ou toute autre valeur invalide continue donc d'imposer HTTPS.
$forceHttps = true;
if (isset($config['security'])
    && is_array($config['security'])
    && array_key_exists('force_https', $config['security'])
    && is_bool($config['security']['force_https'])) {
    $forceHttps = $config['security']['force_https'];
}
if (!isset($config['security']) || !is_array($config['security'])) {
    $config['security'] = [];
}
$config['security']['force_https'] = $forceHttps;
if ($forceHttps && !$isHttps && PHP_SAPI !== 'cli') {
    throw new HttpException(400, 'Cette application doit être utilisée en HTTPS.');
}
if ($isHttps) {
    header('Strict-Transport-Security: max-age=31536000');
}

$scriptName = isset($_SERVER['SCRIPT_NAME']) ? str_replace('\\', '/', (string) $_SERVER['SCRIPT_NAME']) : '/api.php';
$scriptDirectory = str_replace('\\', '/', dirname($scriptName));
$sessionCookiePath = rtrim($scriptDirectory, '/');
if ($sessionCookiePath === '' || $sessionCookiePath === '.') {
    $sessionCookiePath = '/';
} else {
    $sessionCookiePath .= '/';
}
$sessionLifetime = max(300, (int) $config['app']['session_lifetime']);
$config['app']['session_cookie_path'] = $sessionCookiePath;

session_name($config['app']['session_name']);
session_set_cookie_params([
    'lifetime' => $sessionLifetime,
    'path' => $sessionCookiePath,
    'domain' => '',
    'secure' => $forceHttps || $isHttps,
    'httponly' => true,
    'samesite' => 'Lax',
]);
ini_set('session.use_strict_mode', '1');
ini_set('session.use_only_cookies', '1');
ini_set('session.cookie_httponly', '1');
ini_set('session.gc_maxlifetime', (string) $sessionLifetime);
session_start();

$database = new Database($config['database']);
SchemaMigrator::bindInstallation(
    $database->pdo(),
    (string) $config['app']['installation_id'],
    (string) $config['app']['environment'],
    (string) $config['app']['installation_scope_hash']
);
SchemaMigrator::migrate($database->pdo(), (string) $config['app']['school_year']);

$recoverySettings = isset($config['recovery']) && is_array($config['recovery'])
    ? $config['recovery']
    : [];
$recoveryEnabled = !array_key_exists('enabled', $recoverySettings)
    || (bool) $recoverySettings['enabled'];
$recoveryService = $recoveryEnabled
    ? new RecoveryService(
        $database->pdo(),
        (string) $config['app']['key'],
        (string) $config['app']['environment'],
        isset($recoverySettings['retention_days']) ? (int) $recoverySettings['retention_days'] : 7,
        isset($recoverySettings['interval_seconds']) ? (int) $recoverySettings['interval_seconds'] : 1800
    )
    : null;

$allowlistImport = $database->pdo()->prepare(
    'SELECT setting_value FROM app_settings WHERE setting_key = :setting_key LIMIT 1'
);
$allowlistImport->execute(['setting_key' => 'config_allowlist_imported']);
if (!$allowlistImport->fetchColumn()) {
    $database->transaction(function (PDO $pdo) use ($config): void {
        $insertAllowed = $pdo->prepare(
            'INSERT IGNORE INTO authorized_users (ldap_uid, label, active)
             VALUES (:ldap_uid, :label, 1)'
        );
        foreach ($config['ldap']['allowed_users'] as $uid) {
            $insertAllowed->execute(['ldap_uid' => strtolower((string) $uid), 'label' => 'Importé de la configuration']);
        }
        $marker = $pdo->prepare(
            'INSERT INTO app_settings (setting_key, setting_value) VALUES (:setting_key, :setting_value)
             ON DUPLICATE KEY UPDATE setting_value = VALUES(setting_value)'
        );
        $marker->execute(['setting_key' => 'config_allowlist_imported', 'setting_value' => '1']);
    });
}

$schoolYearStatement = $database->pdo()->prepare(
    'SELECT setting_value FROM app_settings WHERE setting_key = :setting_key LIMIT 1'
);
$schoolYearStatement->execute(['setting_key' => 'active_school_year']);
$activeSchoolYear = $schoolYearStatement->fetchColumn();
if (is_string($activeSchoolYear) && $activeSchoolYear !== '') {
    $config['app']['school_year'] = $activeSchoolYear;
}

$authorizedStatement = $database->pdo()->query(
    'SELECT ldap_uid FROM authorized_users
     WHERE active = 1
       AND (access_expires_at IS NULL OR access_expires_at > UTC_TIMESTAMP())
     ORDER BY ldap_uid'
);
$databaseAllowedUsers = array_map('strtolower', array_column($authorizedStatement->fetchAll(), 'ldap_uid'));
$config['ldap']['allowed_users'] = array_values(array_unique($databaseAllowedUsers));

$ldapAuthenticator = new LdapAuthenticator($config['ldap']);
$auth = new AuthService($database, $ldapAuthenticator, $config);
$digitalPassService = new DigitalPassService($database->pdo());
$finalAdminService = new FinalAdminService($database->pdo());

function jsonResponse(array $payload, int $status = 200): void
{
    http_response_code($status);
    header('Content-Type: application/json; charset=utf-8');
    header('Cache-Control: no-store');
    echo json_encode($payload, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
    exit;
}

function jsonInput(): array
{
    $maximumBytes = 262144;
    $contentLength = isset($_SERVER['CONTENT_LENGTH'])
        ? trim((string) $_SERVER['CONTENT_LENGTH'])
        : '';
    if ($contentLength !== ''
        && preg_match('/^\d+$/D', $contentLength)
        && (int) $contentLength > $maximumBytes) {
        throw new HttpException(413, 'Corps JSON trop volumineux.');
    }

    // La limite de lecture reste indispensable si Content-Length est absent
    // ou mensonger (par exemple avec un transfert segmenté).
    $raw = file_get_contents('php://input', false, null, 0, $maximumBytes + 1);
    if ($raw === false || $raw === '') {
        return [];
    }
    if (strlen($raw) > $maximumBytes) {
        throw new HttpException(413, 'Corps JSON trop volumineux.');
    }
    $decoded = json_decode($raw, true);
    if (!is_array($decoded)) {
        throw new HttpException(400, 'Corps JSON invalide.');
    }
    return $decoded;
}

function requireMethod(string $expected): void
{
    if (strtoupper((string) $_SERVER['REQUEST_METHOD']) !== strtoupper($expected)) {
        header('Allow: ' . strtoupper($expected));
        throw new HttpException(405, 'Méthode non autorisée.');
    }
}

function requireCsrf(AuthService $auth): void
{
    $token = isset($_SERVER['HTTP_X_CSRF_TOKEN']) ? (string) $_SERVER['HTTP_X_CSRF_TOKEN'] : '';
    $auth->verifyCsrf($token);
}

function auditLog(
    Database $database,
    ?int $userId,
    string $action,
    string $entityType,
    ?int $entityId,
    array $metadata = [],
    ?PDO $transactionPdo = null
): void
{
    // Passer le PDO de la transaction rend explicite que l'action métier et
    // sa trace d'audit doivent être validées ou annulées ensemble.
    $pdo = $transactionPdo !== null ? $transactionPdo : $database->pdo();
    $statement = $pdo->prepare(
        'INSERT INTO audit_logs (user_id, action, entity_type, entity_id, metadata)
         VALUES (:user_id, :action, :entity_type, :entity_id, :metadata)'
    );
    $statement->execute([
        'user_id' => $userId,
        'action' => $action,
        'entity_type' => $entityType,
        'entity_id' => $entityId,
        'metadata' => count($metadata) > 0 ? json_encode($metadata, JSON_UNESCAPED_UNICODE) : null,
    ]);
}
