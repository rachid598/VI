<?php
declare(strict_types=1);

/**
 * Gestion des billets numériques temporaires.
 *
 * Le service ne transmet aucune note libre et ne suppose ni QR code ni
 * appareil possédé par l'élève. Toutes les dates sont calculées par MySQL
 * en UTC afin de rester indépendantes de l'horloge du navigateur.
 */
/** @internal Exception de contrôle, toujours convertie avant de sortir du service. */
final class DigitalPassBusinessException extends RuntimeException
{
}

final class DigitalPassService
{
    /** @var int[] */
    private const ALLOWED_DURATIONS = [5, 10, 15, 20, 30, 45, 60];

    /** @var PDO */
    private $pdo;

    public function __construct(PDO $pdo)
    {
        $this->pdo = $pdo;
    }

    /**
     * Supprime les billets expirés depuis plus de 24 heures.
     */
    public function cleanupExpired(): int
    {
        try {
            $statement = $this->pdo->prepare(
                'DELETE FROM digital_passes
                 WHERE expires_at < DATE_SUB(UTC_TIMESTAMP(), INTERVAL 24 HOUR)'
            );
            $statement->execute();

            return $statement->rowCount();
        } catch (Throwable $error) {
            throw new RuntimeException('Impossible de nettoyer les billets.');
        }
    }

    /**
     * @return array<int,array<string,mixed>>
     */
    public function listActive(string $schoolYear, ?int $issuerId = null): array
    {
        $schoolYear = $this->validateSchoolYear($schoolYear);
        if ($issuerId !== null && $issuerId <= 0) {
            throw new RuntimeException('Émetteur indisponible.');
        }

        try {
            $sql =
                'SELECT dp.id, dp.student_id, dp.issuer_user_id, dp.school_year,
                        dp.destination, dp.issued_at, dp.expires_at,
                        s.first_name AS student_first_name,
                        s.last_name AS student_last_name,
                        s.class_name,
                        u.first_name AS issuer_first_name,
                        u.last_name AS issuer_last_name,
                        u.role AS issuer_role
                 FROM digital_passes dp
                 JOIN students s ON s.id = dp.student_id
                 JOIN users u ON u.id = dp.issuer_user_id
                 WHERE dp.school_year = :school_year
                   AND dp.revoked_at IS NULL
                   AND dp.expires_at > UTC_TIMESTAMP()
                   AND s.active = 1';
            $parameters = ['school_year' => $schoolYear];
            if ($issuerId !== null) {
                $sql .= ' AND dp.issuer_user_id = :issuer_user_id';
                $parameters['issuer_user_id'] = $issuerId;
            }
            $sql .= ' ORDER BY dp.expires_at ASC, dp.id ASC';
            $statement = $this->pdo->prepare($sql);
            $statement->execute($parameters);

            return $statement->fetchAll(PDO::FETCH_ASSOC);
        } catch (Throwable $error) {
            throw new RuntimeException('Impossible de charger les billets.');
        }
    }

    /**
     * @return array<string,mixed>|null
     */
    public function activeForStudent(int $studentId, string $schoolYear): ?array
    {
        if ($studentId <= 0) {
            throw new RuntimeException('Élève indisponible.');
        }
        $schoolYear = $this->validateSchoolYear($schoolYear);

        try {
            $statement = $this->pdo->prepare(
                'SELECT dp.id, dp.student_id, dp.issuer_user_id, dp.school_year,
                        dp.destination, dp.issued_at, dp.expires_at,
                        s.first_name AS student_first_name,
                        s.last_name AS student_last_name,
                        s.class_name,
                        u.first_name AS issuer_first_name,
                        u.last_name AS issuer_last_name,
                        u.role AS issuer_role
                 FROM digital_passes dp
                 JOIN students s ON s.id = dp.student_id
                 JOIN users u ON u.id = dp.issuer_user_id
                 WHERE dp.student_id = :student_id
                   AND dp.school_year = :school_year
                   AND dp.revoked_at IS NULL
                   AND dp.expires_at > UTC_TIMESTAMP()
                   AND s.active = 1
                 ORDER BY dp.expires_at DESC, dp.id DESC
                 LIMIT 1'
            );
            $statement->execute([
                'student_id' => $studentId,
                'school_year' => $schoolYear,
            ]);
            $pass = $statement->fetch(PDO::FETCH_ASSOC);

            return is_array($pass) ? $pass : null;
        } catch (Throwable $error) {
            throw new RuntimeException('Impossible de charger le billet.');
        }
    }

    /**
     * Le callback reçoit : PDO, action, type d'entité, identifiant, métadonnées.
     *
     * @param callable $audit function(PDO,string,string,int,array): void
     * @return array<string,mixed>
     */
    public function issue(
        int $studentId,
        int $issuerId,
        string $schoolYear,
        string $destination,
        int $durationMinutes,
        callable $audit
    ): array {
        if ($studentId <= 0 || $issuerId <= 0) {
            throw new RuntimeException('Billet impossible à créer.');
        }
        $schoolYear = $this->validateSchoolYear($schoolYear);
        $destination = $this->validateDestination($destination);
        if (!in_array($durationMinutes, self::ALLOWED_DURATIONS, true)) {
            throw new RuntimeException('Durée de billet invalide.');
        }
        if ($this->pdo->inTransaction()) {
            throw new RuntimeException('Billet impossible à créer.');
        }

        try {
            if (!$this->pdo->beginTransaction()) {
                throw new DigitalPassBusinessException('Billet impossible à créer.');
            }

            // Sérialise l'émission avec le bouton d'activation du module.
            // Une requête ayant chargé l'ancien état ne peut ainsi pas créer
            // un billet juste après la désactivation.
            $moduleStatement = $this->pdo->prepare(
                'SELECT setting_value FROM app_settings
                 WHERE setting_key = :setting_key FOR UPDATE'
            );
            $moduleStatement->execute(['setting_key' => 'digital_passes_enabled']);
            $moduleValue = $moduleStatement->fetchColumn();
            if (!is_string($moduleValue)
                || !in_array(strtolower(trim($moduleValue)), ['1', 'true', 'yes', 'on'], true)) {
                throw new DigitalPassBusinessException('Le module billets numériques est désactivé.');
            }

            // Le verrou sur l'élève sérialise deux créations concurrentes,
            // même lorsqu'aucun billet n'existe encore.
            $studentStatement = $this->pdo->prepare(
                'SELECT id
                 FROM students
                 WHERE id = :student_id
                   AND school_year = :school_year
                   AND active = 1
                 FOR UPDATE'
            );
            $studentStatement->execute([
                'student_id' => $studentId,
                'school_year' => $schoolYear,
            ]);
            if ($studentStatement->fetchColumn() === false) {
                throw new DigitalPassBusinessException('Élève indisponible.');
            }

            $existingStatement = $this->pdo->prepare(
                'SELECT id
                 FROM digital_passes
                 WHERE student_id = :student_id
                   AND school_year = :school_year
                   AND revoked_at IS NULL
                   AND expires_at > UTC_TIMESTAMP()
                 LIMIT 1
                 FOR UPDATE'
            );
            $existingStatement->execute([
                'student_id' => $studentId,
                'school_year' => $schoolYear,
            ]);
            if ($existingStatement->fetchColumn() !== false) {
                throw new DigitalPassBusinessException('Un billet est déjà actif pour cet élève.');
            }

            $insertStatement = $this->pdo->prepare(
                'INSERT INTO digital_passes
                    (student_id, issuer_user_id, school_year, destination, issued_at, expires_at)
                 VALUES
                    (:student_id, :issuer_user_id, :school_year, :destination,
                     UTC_TIMESTAMP(), TIMESTAMPADD(MINUTE, :duration_minutes, UTC_TIMESTAMP()))'
            );
            $insertStatement->execute([
                'student_id' => $studentId,
                'issuer_user_id' => $issuerId,
                'school_year' => $schoolYear,
                'destination' => $destination,
                'duration_minutes' => $durationMinutes,
            ]);
            $passId = (int) $this->pdo->lastInsertId();

            $audit($this->pdo, 'digital_pass.issue', 'digital_pass', $passId, [
                'student_id' => $studentId,
                'duration_minutes' => $durationMinutes,
                'destination' => $destination,
            ]);

            $pass = $this->fetchById($passId);
            if ($pass === null) {
                throw new DigitalPassBusinessException('Billet impossible à créer.');
            }

            if (!$this->pdo->commit()) {
                throw new DigitalPassBusinessException('Billet impossible à créer.');
            }

            return $pass;
        } catch (DigitalPassBusinessException $error) {
            $this->rollbackIfNeeded();
            throw new RuntimeException($error->getMessage());
        } catch (Throwable $error) {
            $this->rollbackIfNeeded();
            throw new RuntimeException('Billet impossible à créer.');
        }
    }

    /**
     * Le callback reçoit : PDO, action, type d'entité, identifiant, métadonnées.
     *
     * @param callable $audit function(PDO,string,string,int,array): void
     */
    public function revoke(
        int $passId,
        int $actorId,
        bool $canRevokeAny,
        callable $audit
    ): void {
        if ($passId <= 0 || $actorId <= 0) {
            throw new RuntimeException('Billet indisponible.');
        }
        if ($this->pdo->inTransaction()) {
            throw new RuntimeException('Impossible de révoquer le billet.');
        }

        try {
            if (!$this->pdo->beginTransaction()) {
                throw new DigitalPassBusinessException('Impossible de révoquer le billet.');
            }

            $statement = $this->pdo->prepare(
                'SELECT id, student_id, issuer_user_id,
                        CASE WHEN expires_at > UTC_TIMESTAMP() THEN 1 ELSE 0 END AS is_active
                 FROM digital_passes
                 WHERE id = :id
                   AND revoked_at IS NULL
                 FOR UPDATE'
            );
            $statement->execute(['id' => $passId]);
            $pass = $statement->fetch(PDO::FETCH_ASSOC);
            if (!is_array($pass) || (int) $pass['is_active'] !== 1) {
                throw new DigitalPassBusinessException('Billet indisponible.');
            }
            if (!$canRevokeAny && (int) $pass['issuer_user_id'] !== $actorId) {
                throw new DigitalPassBusinessException('Action non autorisée.');
            }

            $updateStatement = $this->pdo->prepare(
                'UPDATE digital_passes
                 SET revoked_at = UTC_TIMESTAMP(), revoked_by_user_id = :actor_id
                 WHERE id = :id AND revoked_at IS NULL'
            );
            $updateStatement->execute([
                'actor_id' => $actorId,
                'id' => $passId,
            ]);
            if ($updateStatement->rowCount() !== 1) {
                throw new DigitalPassBusinessException('Billet indisponible.');
            }

            $audit($this->pdo, 'digital_pass.revoke', 'digital_pass', $passId, [
                'student_id' => (int) $pass['student_id'],
                'issued_by_actor' => (int) $pass['issuer_user_id'] === $actorId,
            ]);

            if (!$this->pdo->commit()) {
                throw new DigitalPassBusinessException('Impossible de révoquer le billet.');
            }
        } catch (DigitalPassBusinessException $error) {
            $this->rollbackIfNeeded();
            throw new RuntimeException($error->getMessage());
        } catch (Throwable $error) {
            $this->rollbackIfNeeded();
            throw new RuntimeException('Impossible de révoquer le billet.');
        }
    }

    /** @return array<string,mixed>|null */
    private function fetchById(int $passId): ?array
    {
        $statement = $this->pdo->prepare(
            'SELECT dp.id, dp.student_id, dp.issuer_user_id, dp.school_year,
                    dp.destination, dp.issued_at, dp.expires_at,
                    s.first_name AS student_first_name,
                    s.last_name AS student_last_name,
                    s.class_name,
                    u.first_name AS issuer_first_name,
                    u.last_name AS issuer_last_name,
                    u.role AS issuer_role
             FROM digital_passes dp
             JOIN students s ON s.id = dp.student_id
             JOIN users u ON u.id = dp.issuer_user_id
             WHERE dp.id = :id
             LIMIT 1'
        );
        $statement->execute(['id' => $passId]);
        $pass = $statement->fetch(PDO::FETCH_ASSOC);

        return is_array($pass) ? $pass : null;
    }

    private function validateSchoolYear(string $schoolYear): string
    {
        $schoolYear = trim($schoolYear);
        if (!preg_match('/^\\d{4}-\\d{4}$/', $schoolYear)) {
            throw new RuntimeException('Année scolaire invalide.');
        }

        return $schoolYear;
    }

    private function validateDestination(string $destination): string
    {
        $destination = trim($destination);
        if ($destination === '' || strlen($destination) > 64 || preg_match('/[\\x00-\\x1F\\x7F]/', $destination)) {
            throw new RuntimeException('Destination invalide.');
        }

        return $destination;
    }

    private function rollbackIfNeeded(): void
    {
        try {
            if ($this->pdo->inTransaction()) {
                $this->pdo->rollBack();
            }
        } catch (Throwable $error) {
            // L'erreur d'origine reste volontairement masquée à l'appelant.
        }
    }
}
