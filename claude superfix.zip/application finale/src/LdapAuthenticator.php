<?php

declare(strict_types=1);

final class LdapAuthenticationException extends RuntimeException
{
}

final class LdapAuthenticator
{
    /** @var array */
    private $config;

    public function __construct(array $config)
    {
        $this->config = $config;
    }

    /** @return array<string,mixed> */
    public function healthCheck(): array
    {
        $startedAt = microtime(true);
        if (!extension_loaded('ldap')) {
            return [
                'ok' => false,
                'latency_ms' => null,
                'message' => 'Extension PHP LDAP absente.',
            ];
        }
        $connection = null;
        try {
            $connection = $this->connect();
            if (!@ldap_bind($connection)) {
                throw new RuntimeException('Connexion anonyme refusée.');
            }
            $read = @ldap_read(
                $connection,
                $this->config['base_dn'],
                '(objectClass=*)',
                ['dn'],
                0,
                1,
                3
            );
            if ($read === false) {
                throw new RuntimeException('Lecture de l’annuaire impossible.');
            }
            return [
                'ok' => true,
                'latency_ms' => (int) round((microtime(true) - $startedAt) * 1000),
                'message' => 'Annuaire joignable.',
            ];
        } catch (Throwable $error) {
            return [
                'ok' => false,
                'latency_ms' => (int) round((microtime(true) - $startedAt) * 1000),
                'message' => $error->getMessage(),
            ];
        } finally {
            if ($connection !== null) {
                @ldap_unbind($connection);
            }
        }
    }

    public function authenticate(string $username, string $password): array
    {
        if (!extension_loaded('ldap')) {
            throw new RuntimeException('L’extension PHP LDAP n’est pas activée.');
        }
        if ($password === '') {
            throw new LdapAuthenticationException('Identifiant ou mot de passe incorrect.');
        }

        $searchConnection = $this->connect();
        if (!@ldap_bind($searchConnection)) {
            @ldap_unbind($searchConnection);
            throw new RuntimeException('Connexion anonyme à l’annuaire impossible.');
        }

        $escapedUsername = $this->escapeFilterValue($username);
        $filter = str_replace('{username}', $escapedUsername, $this->config['user_filter']);
        $attributes = array_values(array_unique([
            $this->config['uid_attribute'],
            $this->config['first_name_attribute'],
            $this->config['last_name_attribute'],
            $this->config['email_attribute'],
            'memberOf',
            'gidNumber',
        ]));
        $search = @ldap_search($searchConnection, $this->config['base_dn'], $filter, $attributes, 0, 2, 5);
        if ($search === false) {
            @ldap_unbind($searchConnection);
            throw new RuntimeException('Recherche LDAP impossible.');
        }
        $entries = ldap_get_entries($searchConnection, $search);
        if (!is_array($entries) || (int) $entries['count'] !== 1) {
            @ldap_unbind($searchConnection);
            throw new LdapAuthenticationException('Identifiant ou mot de passe incorrect.');
        }

        $entry = $entries[0];
        $userDn = (string) $entry['dn'];
        $authConnection = $this->connect();
        $authenticated = @ldap_bind($authConnection, $userDn, $password);
        @ldap_unbind($authConnection);
        if (!$authenticated) {
            @ldap_unbind($searchConnection);
            throw new LdapAuthenticationException('Identifiant ou mot de passe incorrect.');
        }

        $matchedGroups = $this->matchedAllowedGroups($searchConnection, $entry, $userDn, $username);
        @ldap_unbind($searchConnection);

        $normalizedUsername = strtolower($username);
        $bootstrapAdmins = array_map('strtolower', $this->config['bootstrap_admins']);
        $allowedUsers = array_map('strtolower', $this->config['allowed_users']);
        $isBootstrapAdmin = in_array($normalizedUsername, $bootstrapAdmins, true);
        $isExplicitlyAllowed = in_array($normalizedUsername, $allowedUsers, true);
        if (!$isBootstrapAdmin && !$isExplicitlyAllowed && count($matchedGroups) === 0) {
            throw new LdapAuthenticationException('Ce compte n’est pas autorisé à utiliser cette application.');
        }

        return [
            'uid' => $this->firstValue($entry, $this->config['uid_attribute']) ?: $username,
            'first_name' => $this->firstValue($entry, $this->config['first_name_attribute']),
            'last_name' => $this->firstValue($entry, $this->config['last_name_attribute']),
            'email' => $this->firstValue($entry, $this->config['email_attribute']),
            'groups' => $matchedGroups,
            'bootstrap_admin' => $isBootstrapAdmin,
        ];
    }

    public function listStudentsByClassGroups(string $pattern): array
    {
        if (!extension_loaded('ldap')) {
            throw new RuntimeException('L’extension PHP LDAP n’est pas activée.');
        }
        if (@preg_match($pattern, '') === false) {
            throw new RuntimeException('Le motif des groupes-classes LDAP est invalide.');
        }

        $connection = $this->connect();
        if (!@ldap_bind($connection)) {
            @ldap_unbind($connection);
            throw new RuntimeException('Connexion anonyme à l’annuaire impossible.');
        }

        $groupSearch = @ldap_search(
            $connection,
            $this->config['base_dn'],
            '(objectClass=posixGroup)',
            ['cn', 'gidNumber', 'memberUid'],
            0,
            0,
            20
        );
        if ($groupSearch === false || ldap_errno($connection) !== 0) {
            @ldap_unbind($connection);
            throw new RuntimeException('Lecture des groupes LDAP impossible.');
        }
        $groups = ldap_get_entries($connection, $groupSearch);
        $classByGid = [];
        $classesByUid = [];
        $classMatches = [];
        for ($index = 0; is_array($groups) && $index < (int) $groups['count']; $index++) {
            $entry = $groups[$index];
            $name = $this->firstValue($entry, 'cn');
            if ($name === '' || !preg_match($pattern, $name, $matches)) {
                continue;
            }
            $classMatches[$name] = $matches;
            $gid = $this->firstValue($entry, 'gidNumber');
            if ($gid !== '') {
                $classByGid[$gid] = $name;
            }
            foreach ($this->values($entry, 'memberUid') as $memberUid) {
                $classesByUid[strtolower($memberUid)][] = $name;
            }
        }
        if (count($classMatches) === 0) {
            @ldap_unbind($connection);
            throw new RuntimeException('Aucun groupe-classe ne correspond au motif configuré.');
        }
        ksort($classMatches, SORT_NATURAL | SORT_FLAG_CASE);
        foreach ($classesByUid as &$classNames) {
            $classNames = array_values(array_unique($classNames));
            sort($classNames, SORT_NATURAL | SORT_FLAG_CASE);
        }
        unset($classNames);

        $userSearch = @ldap_search(
            $connection,
            $this->config['base_dn'],
            '(&(objectClass=posixAccount)(uid=*))',
            [
                $this->config['uid_attribute'],
                $this->config['first_name_attribute'],
                $this->config['last_name_attribute'],
                'gidNumber',
            ],
            0,
            0,
            30
        );
        if ($userSearch === false || ldap_errno($connection) !== 0) {
            @ldap_unbind($connection);
            throw new RuntimeException('Lecture des comptes LDAP impossible.');
        }
        $users = ldap_get_entries($connection, $userSearch);
        @ldap_unbind($connection);

        $students = [];
        for ($index = 0; is_array($users) && $index < (int) $users['count']; $index++) {
            $entry = $users[$index];
            $uid = strtolower($this->firstValue($entry, $this->config['uid_attribute']));
            if ($uid === '') {
                continue;
            }
            $gid = $this->firstValue($entry, 'gidNumber');
            $primaryGroup = ($gid !== '' && isset($classByGid[$gid])) ? $classByGid[$gid] : null;
            $secondaryGroups = isset($classesByUid[$uid]) ? $classesByUid[$uid] : [];
            $group = $primaryGroup !== null ? $primaryGroup : (isset($secondaryGroups[0]) ? $secondaryGroups[0] : null);
            if ($group === null || !isset($classMatches[$group])) {
                continue;
            }
            $allGroups = array_values(array_unique(array_merge($secondaryGroups, $primaryGroup !== null ? [$primaryGroup] : [])));
            sort($allGroups, SORT_NATURAL | SORT_FLAG_CASE);
            $students[] = [
                'uid' => $uid,
                'first_name' => $this->firstValue($entry, $this->config['first_name_attribute']),
                'last_name' => $this->firstValue($entry, $this->config['last_name_attribute']),
                'group' => $group,
                'matches' => $classMatches[$group],
                'conflict_groups' => array_values(array_diff($allGroups, [$group])),
            ];
        }
        usort($students, static function (array $left, array $right): int {
            return strcmp((string) $left['uid'], (string) $right['uid']);
        });
        return $students;
    }

    private function connect()
    {
        $connection = @ldap_connect($this->config['uri']);
        if ($connection === false) {
            throw new RuntimeException('Serveur LDAP indisponible.');
        }
        ldap_set_option($connection, LDAP_OPT_PROTOCOL_VERSION, 3);
        ldap_set_option($connection, LDAP_OPT_REFERRALS, 0);
        if (defined('LDAP_OPT_NETWORK_TIMEOUT')) {
            ldap_set_option($connection, LDAP_OPT_NETWORK_TIMEOUT, (int) $this->config['network_timeout']);
        }
        if (!empty($this->config['use_starttls']) && !@ldap_start_tls($connection)) {
            @ldap_unbind($connection);
            throw new RuntimeException('La connexion StartTLS à LDAP a échoué.');
        }
        return $connection;
    }

    private function matchedAllowedGroups($connection, array $userEntry, string $userDn, string $username): array
    {
        $matched = [];
        $userMemberOf = array_map('strtolower', $this->values($userEntry, 'memberOf'));
        $userGid = $this->firstValue($userEntry, 'gidNumber');

        foreach ($this->config['allowed_groups'] as $group) {
            $groupLower = strtolower((string) $group);
            foreach ($userMemberOf as $memberDn) {
                if (strpos($memberDn, 'cn=' . $groupLower . ',') === 0) {
                    $matched[] = (string) $group;
                    continue 2;
                }
            }

            $filter = str_replace('{group}', $this->escapeFilterValue((string) $group), $this->config['group_filter']);
            $search = @ldap_search(
                $connection,
                $this->config['base_dn'],
                $filter,
                ['memberUid', 'member', 'uniqueMember', 'gidNumber'],
                0,
                5,
                5
            );
            if ($search === false) {
                continue;
            }
            $groups = ldap_get_entries($connection, $search);
            for ($index = 0; is_array($groups) && $index < (int) $groups['count']; $index++) {
                $groupEntry = $groups[$index];
                $memberUids = array_map('strtolower', $this->values($groupEntry, 'memberUid'));
                $memberDns = array_map('strtolower', array_merge(
                    $this->values($groupEntry, 'member'),
                    $this->values($groupEntry, 'uniqueMember')
                ));
                $groupGid = $this->firstValue($groupEntry, 'gidNumber');
                if (
                    in_array(strtolower($username), $memberUids, true)
                    || in_array(strtolower($userDn), $memberDns, true)
                    || ($userGid !== '' && $groupGid !== '' && $userGid === $groupGid)
                ) {
                    $matched[] = (string) $group;
                    continue 2;
                }
            }
        }
        return array_values(array_unique($matched));
    }

    private function firstValue(array $entry, string $attribute): string
    {
        $values = $this->values($entry, $attribute);
        return isset($values[0]) ? $values[0] : '';
    }

    private function values(array $entry, string $attribute): array
    {
        $key = strtolower($attribute);
        if (!isset($entry[$key]) || !is_array($entry[$key])) {
            return [];
        }
        $values = [];
        $count = isset($entry[$key]['count']) ? (int) $entry[$key]['count'] : 0;
        for ($index = 0; $index < $count; $index++) {
            $values[] = (string) $entry[$key][$index];
        }
        return $values;
    }

    private function escapeFilterValue(string $value): string
    {
        if (function_exists('ldap_escape')) {
            return ldap_escape($value, '', LDAP_ESCAPE_FILTER);
        }
        return strtr($value, [
            '\\' => '\\5c',
            '*' => '\\2a',
            '(' => '\\28',
            ')' => '\\29',
            "\x00" => '\\00',
        ]);
    }
}
