<?php

declare(strict_types=1);

final class AuthService
{
    /** @var Database */
    private $database;
    /** @var LdapAuthenticator */
    private $ldap;
    /** @var array */
    private $config;
    /** @var array|null */
    private $cachedUser;

    public function __construct(Database $database, LdapAuthenticator $ldap, array $config)
    {
        $this->database = $database;
        $this->ldap = $ldap;
        $this->config = $config;
    }

    public function login(string $username, string $password): array
    {
        $username = strtolower(trim($username));
        if (!preg_match('/^[a-z0-9._-]{1,64}$/i', $username) || $password === '' || strlen($password) > 1024) {
            throw new LdapAuthenticationException('Identifiant ou mot de passe incorrect.');
        }

        $identifierHash = $this->identifierHash($username);
        $ipHash = $this->ipHash();
        $this->pruneOldLoginAttempts();
        $this->assertNotRateLimited($identifierHash, $ipHash);
        try {
            $identity = $this->ldap->authenticate($username, $password);
            $user = $this->synchronizeUser($identity);
            $this->recordLoginAttempt($identifierHash, true);
            $this->recordLoginAttempt($ipHash, true);
        } catch (Throwable $error) {
            $this->recordLoginAttempt($identifierHash, false);
            $this->recordLoginAttempt($ipHash, false);
            throw $error;
        }

        session_regenerate_id(true);
        $now = time();
        $expiresAt = $now + $this->sessionLifetime();
        $_SESSION['user_id'] = (int) $user['id'];
        $_SESSION['authenticated_at'] = $now;
        $_SESSION['session_expires_at'] = $expiresAt;
        $_SESSION['session_rotated_at'] = $now;
        $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
        $this->writeSessionCookie($expiresAt);
        $this->cachedUser = $user;
        return $user;
    }

    public function logout(): void
    {
        $_SESSION = [];
        if (ini_get('session.use_cookies')) {
            $params = session_get_cookie_params();
            setcookie(session_name(), '', [
                'expires' => time() - 42000,
                'path' => (string) $params['path'],
                'domain' => (string) $params['domain'],
                'secure' => (bool) $params['secure'],
                'httponly' => (bool) $params['httponly'],
                'samesite' => isset($params['samesite']) ? (string) $params['samesite'] : 'Lax',
            ]);
        }
        if (session_status() === PHP_SESSION_ACTIVE) {
            session_destroy();
        }
        $this->cachedUser = null;
    }

    public function user(): ?array
    {
        if (empty($_SESSION['user_id'])) {
            return null;
        }
        if (!$this->validateAuthenticatedSession()) {
            return null;
        }
        if ($this->cachedUser !== null) {
            return $this->cachedUser;
        }
        $statement = $this->database->pdo()->prepare(
            'SELECT u.id, u.ldap_uid, u.first_name, u.last_name, u.email,
                    u.role, u.pp_class, u.active, au.access_expires_at
             FROM users u
             LEFT JOIN authorized_users au
               ON au.ldap_uid = u.ldap_uid AND au.active = 1
             WHERE u.id = :id LIMIT 1'
        );
        $statement->execute(['id' => (int) $_SESSION['user_id']]);
        $user = $statement->fetch();
        if (!$user || !(bool) $user['active']) {
            $this->logout();
            return null;
        }
        $bootstrapAdmins = array_map(
            'strtolower',
            isset($this->config['ldap']['bootstrap_admins'])
                && is_array($this->config['ldap']['bootstrap_admins'])
                ? $this->config['ldap']['bootstrap_admins']
                : []
        );
        $isBootstrapAdmin = in_array(strtolower((string) $user['ldap_uid']), $bootstrapAdmins, true);
        if ((string) $user['role'] === 'admin' && !$isBootstrapAdmin) {
            // Le rôle administrateur est un compte de secours explicitement
            // déclaré dans settings.php, jamais un rôle délégable depuis
            // la WebUI. Cette vérification neutralise aussi une ancienne
            // attribution devenue invalide après mise à jour.
            $this->logout();
            return null;
        }
        if (!$isBootstrapAdmin
            && $user['access_expires_at'] !== null
            && strtotime((string) $user['access_expires_at'] . ' UTC') <= time()) {
            $this->logout();
            return null;
        }
        $this->cachedUser = $this->normalizeUser($user);
        return $this->cachedUser;
    }

    public function requireUser(): array
    {
        $user = $this->user();
        if ($user === null) {
            throw new HttpException(401, 'Authentification requise.');
        }
        return $user;
    }

    public function requireRoles(array $roles): array
    {
        $user = $this->requireUser();
        if (!in_array($user['role'], $roles, true)) {
            throw new HttpException(403, 'Accès non autorisé.');
        }
        return $user;
    }

    public function csrfToken(): string
    {
        if (session_status() !== PHP_SESSION_ACTIVE) {
            session_start();
        }
        if (empty($_SESSION['csrf_token'])) {
            $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
        }
        return (string) $_SESSION['csrf_token'];
    }

    public function verifyCsrf(string $token): void
    {
        if ($token === '' || !hash_equals($this->csrfToken(), $token)) {
            throw new HttpException(419, 'Jeton de sécurité invalide. Rechargez la page.');
        }
    }

    /**
     * Revérifie le mot de passe LDAP du compte actuellement connecté avant une
     * opération irréversible. Le mot de passe n'est ni conservé ni journalisé.
     */
    public function reauthenticate(string $password): void
    {
        $user = $this->requireUser();
        $identifierHash = $this->identifierHash('reauth:' . (string) $user['uid']);
        $ipHash = $this->ipHash();
        $this->pruneOldLoginAttempts();
        $this->assertNotRateLimited($identifierHash, $ipHash);

        try {
            if ($password === '' || strlen($password) > 1024) {
                throw new LdapAuthenticationException('Identifiant ou mot de passe incorrect.');
            }
            $identity = $this->ldap->authenticate((string) $user['uid'], $password);
            if (strtolower((string) $identity['uid']) !== strtolower((string) $user['uid'])) {
                throw new LdapAuthenticationException('Identifiant ou mot de passe incorrect.');
            }
            $this->recordLoginAttempt($identifierHash, true);
            $this->recordLoginAttempt($ipHash, true);
        } catch (Throwable $error) {
            $this->recordLoginAttempt($identifierHash, false);
            $this->recordLoginAttempt($ipHash, false);
            throw $error;
        }
    }

    private function synchronizeUser(array $identity): array
    {
        $pdo = $this->database->pdo();
        $normalizedUid = strtolower((string) $identity['uid']);
        $statement = $pdo->prepare('SELECT * FROM users WHERE ldap_uid = :uid LIMIT 1');
        $statement->execute(['uid' => $normalizedUid]);
        $existing = $statement->fetch();
        $isBootstrapAdmin = !empty($identity['bootstrap_admin']);

        // Une autorisation individuelle peut préparer le bon rôle avant la
        // première connexion (AED, CPE, PP…) et, si besoin, expirer. Le rôle
        // administrateur reste réservé au compte de secours configuré.
        $authorization = $pdo->prepare(
            'SELECT preassigned_role, preassigned_pp_class, access_expires_at
             FROM authorized_users
             WHERE ldap_uid = :uid AND active = 1
             LIMIT 1'
        );
        $authorization->execute(['uid' => $normalizedUid]);
        $preassignment = $authorization->fetch();
        if (!$isBootstrapAdmin && $preassignment
            && $preassignment['access_expires_at'] !== null
            && strtotime((string) $preassignment['access_expires_at'] . ' UTC') <= time()) {
            throw new LdapAuthenticationException('Cette autorisation d’accès a expiré.');
        }
        $preassignedRole = $preassignment && $preassignment['preassigned_role'] !== null
            ? (string) $preassignment['preassigned_role']
            : 'teacher';
        if (!in_array($preassignedRole, ['teacher', 'aed', 'cpe', 'direction', 'pp', 'service'], true)) {
            $preassignedRole = 'teacher';
        }
        $preassignedPpClass = $preassignment && $preassignment['preassigned_pp_class'] !== null
            ? trim((string) $preassignment['preassigned_pp_class'])
            : '';
        if ($preassignedRole !== 'pp') {
            $preassignedPpClass = '';
        }
        if ($existing && !(bool) $existing['active']) {
            throw new LdapAuthenticationException('Ce compte a été désactivé dans l’application.');
        }
        if ($existing && !$isBootstrapAdmin && (string) $existing['role'] === 'admin') {
            throw new LdapAuthenticationException('Ce compte ne dispose pas d’une autorisation administrateur valide.');
        }

        if ($existing) {
            // Une connexion ordinaire actualise uniquement l'identité LDAP :
            // elle ne doit jamais pouvoir rétablir un ancien rôle pendant
            // qu'un administrateur modifie les droits du compte.
            $updateSql = 'UPDATE users SET first_name = :first_name, last_name = :last_name,
                          email = :email, last_login_at = UTC_TIMESTAMP()';
            if ($isBootstrapAdmin) {
                // Le compte de secours défini dans la configuration conserve
                // toujours le rôle administrateur.
                $updateSql .= ", role = 'admin'";
            }
            $updateSql .= ' WHERE id = :id';
            $update = $pdo->prepare($updateSql);
            $update->execute([
                'first_name' => $identity['first_name'],
                'last_name' => $identity['last_name'],
                'email' => $identity['email'],
                'id' => $existing['id'],
            ]);
            $id = (int) $existing['id'];
        } else {
            $role = $isBootstrapAdmin ? 'admin' : $preassignedRole;
            $insert = $pdo->prepare(
                'INSERT INTO users (ldap_uid, first_name, last_name, email, role, pp_class, last_login_at)
                 VALUES (:uid, :first_name, :last_name, :email, :role, :pp_class, UTC_TIMESTAMP())'
            );
            $insert->execute([
                'uid' => $normalizedUid,
                'first_name' => $identity['first_name'],
                'last_name' => $identity['last_name'],
                'email' => $identity['email'],
                'role' => $role,
                'pp_class' => $preassignedPpClass !== '' ? $preassignedPpClass : null,
            ]);
            $id = (int) $pdo->lastInsertId();
        }

        $reload = $pdo->prepare(
            'SELECT id, ldap_uid, first_name, last_name, email, role, pp_class, active
             FROM users WHERE id = :id'
        );
        $reload->execute(['id' => $id]);
        $reloadedUser = $reload->fetch();
        if (!$reloadedUser || !(bool) $reloadedUser['active']) {
            // Un administrateur a pu désactiver ce compte pendant la requête
            // LDAP. Ne jamais créer de session dans cette fenêtre de course.
            throw new LdapAuthenticationException('Ce compte a été désactivé dans l’application.');
        }
        return $this->normalizeUser($reloadedUser);
    }

    private function normalizeUser(array $user): array
    {
        return [
            'id' => (int) $user['id'],
            'uid' => (string) $user['ldap_uid'],
            'first_name' => (string) $user['first_name'],
            'last_name' => (string) $user['last_name'],
            'email' => (string) $user['email'],
            'role' => (string) $user['role'],
            'pp_class' => $user['pp_class'] !== null ? (string) $user['pp_class'] : null,
            'active' => (bool) $user['active'],
        ];
    }

    private function identifierHash(string $username): string
    {
        return hash_hmac(
            'sha256',
            'account|' . strtolower($username) . '|ip|' . $this->remoteAddress(),
            $this->config['app']['key']
        );
    }

    private function ipHash(): string
    {
        return hash_hmac(
            'sha256',
            'all-accounts|ip|' . $this->remoteAddress(),
            $this->config['app']['key']
        );
    }

    private function remoteAddress(): string
    {
        // REMOTE_ADDR provient du serveur Web. Ne pas faire confiance à
        // X-Forwarded-For sans proxy explicitement configuré.
        $address = isset($_SERVER['REMOTE_ADDR']) ? trim((string) $_SERVER['REMOTE_ADDR']) : '';
        return $address !== '' && strlen($address) <= 64 ? $address : 'unknown';
    }

    private function assertNotRateLimited(string $identifierHash, string $ipHash): void
    {
        $window = max(60, min(86400, (int) $this->config['security']['login_window_seconds']));
        $maximum = max(1, min(100, (int) $this->config['security']['login_max_attempts']));
        $ipMaximum = isset($this->config['security']['login_ip_max_attempts'])
            ? (int) $this->config['security']['login_ip_max_attempts']
            : max(20, $maximum * 6);
        $ipMaximum = max($maximum, min(500, $ipMaximum));
        $cutoff = gmdate('Y-m-d H:i:s', time() - $window);
        $statement = $this->database->pdo()->prepare(
            'SELECT identifier_hash, COUNT(*) AS failed_count
             FROM login_attempts
             WHERE identifier_hash IN (:identifier, :ip_identifier)
               AND success = 0 AND attempted_at >= :cutoff
             GROUP BY identifier_hash'
        );
        $statement->execute([
            'identifier' => $identifierHash,
            'ip_identifier' => $ipHash,
            'cutoff' => $cutoff,
        ]);
        $counts = [];
        foreach ($statement->fetchAll() as $row) {
            $counts[(string) $row['identifier_hash']] = (int) $row['failed_count'];
        }
        if (($counts[$identifierHash] ?? 0) >= $maximum
            || ($counts[$ipHash] ?? 0) >= $ipMaximum) {
            throw new HttpException(429, 'Trop de tentatives. Réessayez dans quelques minutes.');
        }
    }

    private function pruneOldLoginAttempts(): void
    {
        $retentionDays = 30;
        if (isset($this->config['privacy']) && is_array($this->config['privacy'])
            && isset($this->config['privacy']['login_attempt_retention_days'])) {
            $configured = (int) $this->config['privacy']['login_attempt_retention_days'];
            if ($configured >= 1 && $configured <= 3650) {
                $retentionDays = $configured;
            }
        }
        $cutoff = gmdate('Y-m-d H:i:s', time() - ($retentionDays * 86400));
        // Suppression bornée : une requête d'authentification ne peut pas
        // monopoliser MySQL, mais chaque passage fait progresser l'entretien.
        $statement = $this->database->pdo()->prepare(
            'DELETE FROM login_attempts
             WHERE attempted_at < :cutoff
             ORDER BY attempted_at ASC, id ASC
             LIMIT 500'
        );
        $statement->execute(['cutoff' => $cutoff]);
    }

    private function recordLoginAttempt(string $identifierHash, bool $success): void
    {
        $statement = $this->database->pdo()->prepare(
            'INSERT INTO login_attempts (identifier_hash, success) VALUES (:identifier, :success)'
        );
        $statement->execute(['identifier' => $identifierHash, 'success' => $success ? 1 : 0]);
    }

    private function validateAuthenticatedSession(): bool
    {
        $authenticatedAt = isset($_SESSION['authenticated_at']) ? (int) $_SESSION['authenticated_at'] : 0;
        if ($authenticatedAt <= 0) {
            $this->logout();
            return false;
        }

        $expiresAt = isset($_SESSION['session_expires_at'])
            ? (int) $_SESSION['session_expires_at']
            : $authenticatedAt + $this->sessionLifetime();
        $now = time();
        if ($expiresAt <= $now || $expiresAt <= $authenticatedAt) {
            $this->logout();
            return false;
        }
        // Compatibilité avec les sessions créées avant l'ajout de
        // l'expiration absolue : elles conservent leur heure de connexion.
        $_SESSION['session_expires_at'] = $expiresAt;

        $rotatedAt = isset($_SESSION['session_rotated_at'])
            ? (int) $_SESSION['session_rotated_at']
            : $authenticatedAt;
        if ($now - $rotatedAt >= $this->sessionRotationInterval()) {
            if (session_regenerate_id(true)) {
                $_SESSION['session_rotated_at'] = $now;
            }
        }

        // session_regenerate_id() et certains réglages PHP peuvent recalculer
        // la durée du cookie. On la ramène toujours à l'échéance absolue
        // de la connexion, sans déconnexion sur simple inactivité.
        $this->writeSessionCookie($expiresAt);
        return true;
    }

    private function sessionLifetime(): int
    {
        return max(300, (int) $this->config['app']['session_lifetime']);
    }

    private function sessionRotationInterval(): int
    {
        if (isset($this->config['app']['session_rotation_interval'])) {
            $configured = (int) $this->config['app']['session_rotation_interval'];
        } elseif (isset($this->config['app']['session_regeneration_seconds'])) {
            // Compatibilité avec les settings.php générés par la
            // première version de l'installateur.
            $configured = (int) $this->config['app']['session_regeneration_seconds'];
        } else {
            $configured = 900;
        }
        return max(60, min($configured, max(60, intdiv($this->sessionLifetime(), 2))));
    }

    private function writeSessionCookie(int $expiresAt): void
    {
        if (headers_sent() || session_status() !== PHP_SESSION_ACTIVE || session_id() === '') {
            return;
        }
        $params = session_get_cookie_params();
        setcookie(session_name(), session_id(), [
            'expires' => $expiresAt,
            'path' => (string) $params['path'],
            'domain' => (string) $params['domain'],
            'secure' => (bool) $params['secure'],
            'httponly' => (bool) $params['httponly'],
            'samesite' => isset($params['samesite']) ? (string) $params['samesite'] : 'Lax',
        ]);
    }
}
