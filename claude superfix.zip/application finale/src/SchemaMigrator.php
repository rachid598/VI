<?php

declare(strict_types=1);

final class InstallationBindingException extends RuntimeException
{
}

final class SchemaMigrator
{
    private const VERSION = 9;

    /**
     * Lie une base MySQL à une seule copie de l'application.
     *
     * Le verrou MySQL rend la première revendication atomique, y compris si
     * deux dossiers sont ouverts simultanément après une mise à jour. La
     * valeur de retour indique si cet appel a créé la liaison ; l'installateur
     * peut alors l'annuler proprement si une étape ultérieure échoue.
     */
    public static function bindInstallation(
        PDO $pdo,
        string $installationId,
        string $environment,
        string $scopeHash
    ): bool {
        if (!preg_match('/^[a-f0-9]{32,64}$/', $installationId)) {
            throw new RuntimeException('Identifiant d’installation invalide.');
        }
        if (!in_array($environment, ['test', 'production'], true)) {
            throw new RuntimeException('Environnement d’installation invalide.');
        }
        if (!preg_match('/^[a-f0-9]{64}$/', $scopeHash)) {
            throw new RuntimeException('Empreinte du dossier d’installation invalide.');
        }

        self::ensureAppSettingsTable($pdo);
        $lockName = self::installationLockName($pdo);
        self::acquireInstallationLock($pdo, $lockName);
        $startedTransaction = false;

        try {
            if ($pdo->inTransaction()) {
                throw new RuntimeException(
                    'La liaison de l’installation doit être vérifiée hors transaction.'
                );
            }
            $pdo->beginTransaction();
            $startedTransaction = true;
            $statement = $pdo->query(
                "SELECT setting_key, setting_value FROM app_settings
                 WHERE setting_key IN (
                    'installation_id',
                    'installation_environment',
                    'installation_scope_hash'
                 )"
            );
            $values = [];
            foreach ($statement->fetchAll() as $row) {
                $values[(string) $row['setting_key']] = (string) $row['setting_value'];
            }

            $storedId = isset($values['installation_id']) ? $values['installation_id'] : '';
            $storedEnvironment = isset($values['installation_environment'])
                ? $values['installation_environment']
                : '';
            $storedScopeHash = isset($values['installation_scope_hash'])
                ? $values['installation_scope_hash']
                : '';
            if ($storedId !== '' && !hash_equals($storedId, $installationId)) {
                throw new InstallationBindingException(
                    'Cette base MySQL est déjà liée à une autre installation.'
                );
            }
            if ($storedEnvironment !== '' && $storedEnvironment !== $environment) {
                throw new InstallationBindingException(
                    'Cette base MySQL est déjà liée à un autre environnement.'
                );
            }
            if ($storedScopeHash !== '' && !hash_equals($storedScopeHash, $scopeHash)) {
                throw new InstallationBindingException(
                    'Cette base MySQL est déjà liée à un autre dossier.'
                );
            }

            $claimed = $storedId === '';
            $upsert = $pdo->prepare(
                'INSERT INTO app_settings (setting_key, setting_value)
                 VALUES (:setting_key, :setting_value)
                 ON DUPLICATE KEY UPDATE setting_value = VALUES(setting_value)'
            );
            if ($claimed) {
                $upsert->execute([
                    'setting_key' => 'installation_id',
                    'setting_value' => $installationId,
                ]);
            }
            if ($storedEnvironment === '') {
                $upsert->execute([
                    'setting_key' => 'installation_environment',
                    'setting_value' => $environment,
                ]);
            }
            if ($storedScopeHash === '') {
                $upsert->execute([
                    'setting_key' => 'installation_scope_hash',
                    'setting_value' => $scopeHash,
                ]);
            }

            if ($startedTransaction) {
                $pdo->commit();
            }

            return $claimed;
        } catch (Throwable $error) {
            if ($startedTransaction && $pdo->inTransaction()) {
                $pdo->rollBack();
            }
            throw $error;
        } finally {
            self::releaseInstallationLock($pdo, $lockName);
        }
    }

    /**
     * Annule uniquement une liaison que l'installateur vient de créer.
     */
    public static function releaseInstallationBinding(PDO $pdo, string $installationId): void
    {
        if (!preg_match('/^[a-f0-9]{32,64}$/', $installationId)) {
            return;
        }

        self::ensureAppSettingsTable($pdo);
        $lockName = self::installationLockName($pdo);
        self::acquireInstallationLock($pdo, $lockName);
        try {
            $statement = $pdo->prepare(
                "SELECT setting_value FROM app_settings
                 WHERE setting_key = 'installation_id' LIMIT 1"
            );
            $statement->execute();
            $storedId = $statement->fetchColumn();
            if (is_string($storedId) && hash_equals($storedId, $installationId)) {
                $pdo->exec(
                    "DELETE FROM app_settings
                     WHERE setting_key IN (
                        'installation_id',
                        'installation_environment',
                        'installation_scope_hash'
                     )"
                );
            }
        } finally {
            self::releaseInstallationLock($pdo, $lockName);
        }
    }

    /**
     * Empreinte stable du dossier réel, liée à l'identité de l'instance.
     * Copier settings.php dans un autre dossier ne copie donc pas son droit
     * d'utiliser la même base.
     */
    public static function installationScopeHash(string $root, string $installationId): string
    {
        if (!preg_match('/^[a-f0-9]{32,64}$/', $installationId)) {
            throw new RuntimeException('Identifiant d’installation invalide.');
        }
        $resolvedRoot = realpath($root);
        if ($resolvedRoot === false) {
            $resolvedRoot = $root;
        }
        $normalizedRoot = rtrim(str_replace('\\', '/', $resolvedRoot), '/');
        return hash_hmac('sha256', $normalizedRoot, $installationId);
    }

    public static function migrate(PDO $pdo, string $defaultSchoolYear): void
    {
        $currentVersion = self::schemaVersion($pdo);
        if ($currentVersion !== null
            && $currentVersion >= self::VERSION
            && self::recoverySnapshotSchemaCurrent($pdo)
            && self::observationSequenceSchemaCurrent($pdo)
            && self::finalFeatureSchemaCurrent($pdo)) {
            return;
        }

        $databaseName = (string) $pdo->query('SELECT DATABASE()')->fetchColumn();
        $lockName = 'suivi_schema_' . substr(hash('sha256', $databaseName), 0, 32);
        $lockStatement = $pdo->prepare('SELECT GET_LOCK(:lock_name, 10)');
        $lockStatement->execute(['lock_name' => $lockName]);
        if ((int) $lockStatement->fetchColumn() !== 1) {
            throw new RuntimeException('Mise à jour de la base temporairement indisponible. Réessayez.');
        }

        try {
            self::runMigrations($pdo, $defaultSchoolYear);
        } finally {
            $release = $pdo->prepare('SELECT RELEASE_LOCK(:lock_name)');
            $release->execute(['lock_name' => $lockName]);
        }
    }

    private static function runMigrations(PDO $pdo, string $defaultSchoolYear): void
    {
        self::ensureAppSettingsTable($pdo);

        $currentVersion = self::schemaVersion($pdo);
        if ($currentVersion >= self::VERSION) {
            self::ensureRecoverySnapshotSchema($pdo);
            self::ensureObservationSequenceSchema($pdo);
            self::ensureObservationClaimSchema($pdo);
            self::ensureAuthorizedUserPreassignmentSchema($pdo);
            self::ensureDigitalPassSchema($pdo);
            self::ensureObservationDigitalPassContextSchema($pdo);
            self::ensureAnnualClosureSchema($pdo);
            self::ensureReliableSubmissionSchema($pdo);
            self::ensureNotificationSchema($pdo);
            self::ensureDigitalPassSetting($pdo);
            self::ensureLoginAttemptDateIndex($pdo);
            return;
        }

        $pdo->exec(
            "CREATE TABLE IF NOT EXISTS authorized_users (
                id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
                ldap_uid VARCHAR(64) NOT NULL,
                label VARCHAR(128) NOT NULL DEFAULT '',
                active TINYINT(1) NOT NULL DEFAULT 1,
                created_by BIGINT UNSIGNED NULL,
                created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
                updated_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
                PRIMARY KEY (id),
                UNIQUE KEY uq_authorized_users_uid (ldap_uid),
                CONSTRAINT fk_authorized_user_creator FOREIGN KEY (created_by) REFERENCES users(id),
                KEY idx_authorized_users_active (active)
             ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci"
        );
        self::ensureAuthorizedUserPreassignmentSchema($pdo);

        if (!self::columnExists($pdo, 'observations', 'cancellation_reason')) {
            $pdo->exec('ALTER TABLE observations ADD cancellation_reason VARCHAR(96) NULL AFTER status');
        }
        if (!self::columnExists($pdo, 'observations', 'withdrawn_at')) {
            $pdo->exec('ALTER TABLE observations ADD withdrawn_at DATETIME NULL AFTER validated_at');
        }
        $pdo->exec(
            "ALTER TABLE observations
             MODIFY status ENUM('pending','confirmed','cancelled','withdrawn') NOT NULL DEFAULT 'pending'"
        );
        self::ensureObservationSequenceSchema($pdo);
        self::ensureObservationClaimSchema($pdo);

        $pdo->exec(
            'CREATE TABLE IF NOT EXISTS point_adjustments (
                id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
                student_id BIGINT UNSIGNED NOT NULL,
                granted_by BIGINT UNSIGNED NOT NULL,
                points TINYINT UNSIGNED NOT NULL DEFAULT 1,
                reason VARCHAR(160) NOT NULL,
                created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
                PRIMARY KEY (id),
                CONSTRAINT fk_adjustment_student FOREIGN KEY (student_id) REFERENCES students(id),
                CONSTRAINT fk_adjustment_user FOREIGN KEY (granted_by) REFERENCES users(id),
                KEY idx_adjustments_student_date (student_id, created_at)
             ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci'
        );

        $pdo->exec(
            'CREATE TABLE IF NOT EXISTS action_records (
                id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
                student_id BIGINT UNSIGNED NOT NULL,
                school_year VARCHAR(16) NOT NULL,
                trimester TINYINT UNSIGNED NOT NULL,
                threshold_points INT NOT NULL,
                action_label VARCHAR(96) NOT NULL,
                note VARCHAR(160) NOT NULL DEFAULT \'\',
                done_by BIGINT UNSIGNED NOT NULL,
                done_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
                PRIMARY KEY (id),
                UNIQUE KEY uq_action (student_id, school_year, trimester, threshold_points),
                CONSTRAINT fk_action_student FOREIGN KEY (student_id) REFERENCES students(id),
                CONSTRAINT fk_action_user FOREIGN KEY (done_by) REFERENCES users(id),
                KEY idx_actions_period (school_year, trimester, threshold_points)
             ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci'
        );

        self::ensureRecoverySnapshotSchema($pdo);
        self::ensureDigitalPassSchema($pdo);
        self::ensureObservationDigitalPassContextSchema($pdo);
        self::ensureAnnualClosureSchema($pdo);
        self::ensureReliableSubmissionSchema($pdo);
        self::ensureNotificationSchema($pdo);
        self::ensureLoginAttemptDateIndex($pdo);

        $setting = $pdo->prepare(
            'INSERT INTO app_settings (setting_key, setting_value)
             VALUES (:setting_key, :setting_value)
             ON DUPLICATE KEY UPDATE setting_key = VALUES(setting_key)'
        );
        $setting->execute(['setting_key' => 'active_school_year', 'setting_value' => $defaultSchoolYear]);
        self::ensureDigitalPassSetting($pdo);

        $version = $pdo->prepare(
            'INSERT INTO app_settings (setting_key, setting_value)
             VALUES (:setting_key, :setting_value)
             ON DUPLICATE KEY UPDATE setting_value = VALUES(setting_value)'
        );
        $version->execute(['setting_key' => 'schema_version', 'setting_value' => (string) self::VERSION]);
    }

    private static function ensureAppSettingsTable(PDO $pdo): void
    {
        $pdo->exec(
            'CREATE TABLE IF NOT EXISTS app_settings (
                setting_key VARCHAR(64) NOT NULL,
                setting_value VARCHAR(255) NOT NULL,
                updated_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
                PRIMARY KEY (setting_key)
             ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci'
        );
    }

    private static function installationLockName(PDO $pdo): string
    {
        $databaseName = (string) $pdo->query('SELECT DATABASE()')->fetchColumn();
        return 'suivi_install_' . substr(hash('sha256', $databaseName), 0, 32);
    }

    private static function acquireInstallationLock(PDO $pdo, string $lockName): void
    {
        $statement = $pdo->prepare('SELECT GET_LOCK(:lock_name, 10)');
        $statement->execute(['lock_name' => $lockName]);
        if ((int) $statement->fetchColumn() !== 1) {
            throw new RuntimeException('Vérification de la base temporairement indisponible. Réessayez.');
        }
    }

    private static function releaseInstallationLock(PDO $pdo, string $lockName): void
    {
        $statement = $pdo->prepare('SELECT RELEASE_LOCK(:lock_name)');
        $statement->execute(['lock_name' => $lockName]);
    }

    private static function ensureRecoverySnapshotSchema(PDO $pdo): void
    {
        $pdo->exec(
            "CREATE TABLE IF NOT EXISTS recovery_snapshots (
                id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
                kind ENUM('automatic','manual','before_purge','before_restore') NOT NULL,
                environment VARCHAR(16) NOT NULL,
                school_year VARCHAR(16) NULL,
                format_version SMALLINT UNSIGNED NOT NULL,
                schema_version INT UNSIGNED NOT NULL,
                payload_encoding VARCHAR(16) NOT NULL,
                payload LONGBLOB NOT NULL,
                payload_sha256 CHAR(64) NOT NULL,
                payload_hmac CHAR(64) NOT NULL,
                payload_bytes BIGINT UNSIGNED NOT NULL,
                uncompressed_bytes BIGINT UNSIGNED NOT NULL,
                counts JSON NOT NULL,
                created_by BIGINT UNSIGNED NULL,
                created_at DATETIME NOT NULL,
                expires_at DATETIME NOT NULL,
                PRIMARY KEY (id),
                KEY idx_recovery_created (created_at),
                KEY idx_recovery_kind_created (kind, created_at),
                KEY idx_recovery_expires (expires_at),
                KEY idx_recovery_environment_created (environment, created_at),
                KEY idx_recovery_environment_kind_created (environment, kind, created_at),
                KEY idx_recovery_environment_school_year (environment, school_year)
             ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci"
        );

        // Correctif compatible avec les toutes premières installations v5,
        // créées avant l'ajout de la métadonnée d'année scolaire.
        if (!self::columnExists($pdo, 'recovery_snapshots', 'school_year')) {
            $pdo->exec('ALTER TABLE recovery_snapshots ADD school_year VARCHAR(16) NULL AFTER environment');
        }
        $indexes = [
            'idx_recovery_environment_created' =>
                'ALTER TABLE recovery_snapshots ADD KEY idx_recovery_environment_created (environment, created_at)',
            'idx_recovery_environment_kind_created' =>
                'ALTER TABLE recovery_snapshots ADD KEY idx_recovery_environment_kind_created (environment, kind, created_at)',
            'idx_recovery_environment_school_year' =>
                'ALTER TABLE recovery_snapshots ADD KEY idx_recovery_environment_school_year (environment, school_year)',
        ];
        foreach ($indexes as $index => $sql) {
            if (!self::indexExists($pdo, 'recovery_snapshots', $index)) {
                $pdo->exec($sql);
            }
        }
    }

    private static function ensureObservationSequenceSchema(PDO $pdo): void
    {
        if (!self::columnExists($pdo, 'observations', 'sequence_key')) {
            $pdo->exec('ALTER TABLE observations ADD sequence_key CHAR(32) NULL AFTER details');
        }
        if (!self::indexExists($pdo, 'observations', 'idx_observations_sequence')) {
            $pdo->exec('ALTER TABLE observations ADD KEY idx_observations_sequence (sequence_key)');
        }
    }

    private static function ensureObservationClaimSchema(PDO $pdo): void
    {
        if (!self::columnExists($pdo, 'observations', 'claimed_by_user_id')) {
            $pdo->exec(
                'ALTER TABLE observations
                 ADD claimed_by_user_id BIGINT UNSIGNED NULL AFTER status'
            );
        }
        if (!self::columnExists($pdo, 'observations', 'claimed_at')) {
            $pdo->exec(
                'ALTER TABLE observations
                 ADD claimed_at DATETIME NULL AFTER claimed_by_user_id'
            );
        }
        if (!self::columnExists($pdo, 'observations', 'claim_expires_at')) {
            $pdo->exec(
                'ALTER TABLE observations
                 ADD claim_expires_at DATETIME NULL AFTER claimed_at'
            );
        }
        if (!self::foreignKeyExists($pdo, 'observations', 'fk_observation_claimed_by')) {
            $pdo->exec(
                'ALTER TABLE observations
                 ADD CONSTRAINT fk_observation_claimed_by
                 FOREIGN KEY (claimed_by_user_id) REFERENCES users(id)'
            );
        }
        if (!self::indexExists($pdo, 'observations', 'idx_observations_claim')) {
            $pdo->exec(
                'ALTER TABLE observations
                 ADD KEY idx_observations_claim (status, claim_expires_at, claimed_by_user_id)'
            );
        }
    }

    private static function ensureObservationDigitalPassContextSchema(PDO $pdo): void
    {
        if (!self::columnExists($pdo, 'observations', 'digital_pass_destination')) {
            $pdo->exec(
                'ALTER TABLE observations
                 ADD digital_pass_destination VARCHAR(96) NULL AFTER details'
            );
        }
        if (!self::columnExists($pdo, 'observations', 'digital_pass_issued_at')) {
            $pdo->exec(
                'ALTER TABLE observations
                 ADD digital_pass_issued_at DATETIME NULL AFTER digital_pass_destination'
            );
        }
        if (!self::columnExists($pdo, 'observations', 'digital_pass_expires_at')) {
            $pdo->exec(
                'ALTER TABLE observations
                 ADD digital_pass_expires_at DATETIME NULL AFTER digital_pass_issued_at'
            );
        }
        if (!self::tableExists($pdo, 'digital_passes')) {
            return;
        }

        // Renseigne aussi les signalements encore présents lors du passage à
        // cette version. Le billet retenu est celui qui était valable à
        // l'heure du constat, jamais celui qui est actif au moment de la lecture.
        $pdo->exec(
            'UPDATE observations o
             JOIN students s ON s.id = o.student_id
             JOIN digital_passes dp
               ON dp.student_id = o.student_id
              AND dp.school_year = s.school_year
              AND dp.issued_at <= o.occurred_at
              AND dp.expires_at > o.occurred_at
              AND (dp.revoked_at IS NULL OR dp.revoked_at > o.occurred_at)
             LEFT JOIN digital_passes newer_dp
               ON newer_dp.student_id = dp.student_id
              AND newer_dp.school_year = dp.school_year
              AND newer_dp.issued_at <= o.occurred_at
              AND newer_dp.expires_at > o.occurred_at
              AND (newer_dp.revoked_at IS NULL OR newer_dp.revoked_at > o.occurred_at)
              AND (newer_dp.issued_at > dp.issued_at
                   OR (newer_dp.issued_at = dp.issued_at AND newer_dp.id > dp.id))
             SET o.digital_pass_destination = dp.destination,
                 o.digital_pass_issued_at = dp.issued_at,
                 o.digital_pass_expires_at = dp.expires_at
             WHERE o.digital_pass_destination IS NULL
               AND newer_dp.id IS NULL'
        );
    }

    private static function ensureAuthorizedUserPreassignmentSchema(PDO $pdo): void
    {
        if (!self::columnExists($pdo, 'authorized_users', 'preassigned_role')) {
            $pdo->exec(
                "ALTER TABLE authorized_users
                 ADD preassigned_role
                 ENUM('teacher','aed','cpe','direction','pp','service','admin') NULL
                 AFTER label"
            );
        }
        if (!self::columnExists($pdo, 'authorized_users', 'preassigned_pp_class')) {
            $pdo->exec(
                'ALTER TABLE authorized_users
                 ADD preassigned_pp_class VARCHAR(32) NULL AFTER preassigned_role'
            );
        }
        if (!self::columnExists($pdo, 'authorized_users', 'access_expires_at')) {
            $pdo->exec(
                'ALTER TABLE authorized_users
                 ADD access_expires_at DATETIME NULL AFTER active'
            );
        }
        if (!self::indexExists($pdo, 'authorized_users', 'idx_authorized_users_expiry')) {
            $pdo->exec(
                'ALTER TABLE authorized_users
                 ADD KEY idx_authorized_users_expiry (active, access_expires_at)'
            );
        }
    }

    private static function ensureDigitalPassSchema(PDO $pdo): void
    {
        $pdo->exec(
            'CREATE TABLE IF NOT EXISTS digital_passes (
                id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
                student_id BIGINT UNSIGNED NOT NULL,
                school_year VARCHAR(16) NOT NULL,
                issuer_user_id BIGINT UNSIGNED NOT NULL,
                destination VARCHAR(96) NOT NULL,
                issued_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
                expires_at DATETIME NOT NULL,
                revoked_at DATETIME NULL,
                revoked_by_user_id BIGINT UNSIGNED NULL,
                PRIMARY KEY (id),
                CONSTRAINT fk_digital_pass_student
                    FOREIGN KEY (student_id) REFERENCES students(id),
                CONSTRAINT fk_digital_pass_issuer
                    FOREIGN KEY (issuer_user_id) REFERENCES users(id),
                CONSTRAINT fk_digital_pass_revoker
                    FOREIGN KEY (revoked_by_user_id) REFERENCES users(id),
                KEY idx_digital_pass_student_active
                    (student_id, school_year, revoked_at, expires_at),
                KEY idx_digital_pass_student_period
                    (student_id, school_year, issued_at, expires_at),
                KEY idx_digital_pass_year_issued (school_year, issued_at),
                KEY idx_digital_pass_issuer_issued (issuer_user_id, issued_at)
             ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci'
        );
        if (!self::indexExists($pdo, 'digital_passes', 'idx_digital_pass_student_period')) {
            $pdo->exec(
                'ALTER TABLE digital_passes
                 ADD KEY idx_digital_pass_student_period
                    (student_id, school_year, issued_at, expires_at)'
            );
        }
    }

    private static function ensureAnnualClosureSchema(PDO $pdo): void
    {
        $pdo->exec(
            'CREATE TABLE IF NOT EXISTS year_closures (
                id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
                school_year VARCHAR(16) NOT NULL,
                closed_by_user_id BIGINT UNSIGNED NOT NULL,
                closed_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
                student_count INT UNSIGNED NOT NULL DEFAULT 0,
                observation_count INT UNSIGNED NOT NULL DEFAULT 0,
                aggregate_sha256 CHAR(64) NOT NULL,
                PRIMARY KEY (id),
                UNIQUE KEY uq_year_closures_school_year (school_year),
                CONSTRAINT fk_year_closure_user
                    FOREIGN KEY (closed_by_user_id) REFERENCES users(id),
                KEY idx_year_closures_closed_at (closed_at)
             ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci'
        );

        $pdo->exec(
            'CREATE TABLE IF NOT EXISTS annual_aggregates (
                id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
                closure_id BIGINT UNSIGNED NOT NULL,
                school_year VARCHAR(16) NOT NULL,
                metric_key VARCHAR(64) NOT NULL,
                dimension_key VARCHAR(64) NOT NULL DEFAULT \'\',
                dimension_value VARCHAR(128) NOT NULL DEFAULT \'\',
                metric_value BIGINT UNSIGNED NOT NULL DEFAULT 0,
                created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
                PRIMARY KEY (id),
                UNIQUE KEY uq_annual_aggregate_dimension
                    (school_year, metric_key, dimension_key, dimension_value),
                CONSTRAINT fk_annual_aggregate_closure
                    FOREIGN KEY (closure_id) REFERENCES year_closures(id) ON DELETE CASCADE,
                KEY idx_annual_aggregates_closure (closure_id),
                KEY idx_annual_aggregates_metric (school_year, metric_key)
             ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci'
        );
    }

    private static function ensureReliableSubmissionSchema(PDO $pdo): void
    {
        if (!self::columnExists($pdo, 'observations', 'submission_key')) {
            $pdo->exec(
                'ALTER TABLE observations
                 ADD submission_key CHAR(36) NULL AFTER details'
            );
        }
        if (!self::indexExists($pdo, 'observations', 'uq_observations_submission')) {
            $pdo->exec(
                'ALTER TABLE observations
                 ADD UNIQUE KEY uq_observations_submission
                    (reporter_user_id, student_id, submission_key)'
            );
        }
    }

    private static function ensureNotificationSchema(PDO $pdo): void
    {
        $pdo->exec(
            "CREATE TABLE IF NOT EXISTS user_notifications (
                id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
                user_id BIGINT UNSIGNED NOT NULL,
                observation_id BIGINT UNSIGNED NOT NULL,
                event_type ENUM('confirmed','cancelled') NOT NULL,
                created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
                read_at DATETIME NULL,
                PRIMARY KEY (id),
                UNIQUE KEY uq_user_notification_event (user_id, observation_id, event_type),
                CONSTRAINT fk_notification_user
                    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
                CONSTRAINT fk_notification_observation
                    FOREIGN KEY (observation_id) REFERENCES observations(id) ON DELETE CASCADE,
                KEY idx_notifications_user_read (user_id, read_at, created_at)
             ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci"
        );
    }

    private static function ensureDigitalPassSetting(PDO $pdo): void
    {
        $statement = $pdo->prepare(
            'INSERT INTO app_settings (setting_key, setting_value)
             VALUES (:setting_key, :setting_value)
             ON DUPLICATE KEY UPDATE setting_key = VALUES(setting_key)'
        );
        $statement->execute([
            'setting_key' => 'digital_passes_enabled',
            'setting_value' => 'false',
        ]);
    }

    private static function ensureLoginAttemptDateIndex(PDO $pdo): void
    {
        if (!self::indexExists($pdo, 'login_attempts', 'idx_login_attempts_date')) {
            $pdo->exec(
                'ALTER TABLE login_attempts
                 ADD KEY idx_login_attempts_date (attempted_at, id)'
            );
        }
    }

    private static function indexExists(PDO $pdo, string $table, string $index): bool
    {
        $statement = $pdo->prepare(
            'SELECT COUNT(*) FROM INFORMATION_SCHEMA.STATISTICS
             WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = :table_name AND INDEX_NAME = :index_name'
        );
        $statement->execute(['table_name' => $table, 'index_name' => $index]);
        return (int) $statement->fetchColumn() > 0;
    }

    private static function foreignKeyExists(PDO $pdo, string $table, string $constraint): bool
    {
        $statement = $pdo->prepare(
            'SELECT COUNT(*) FROM INFORMATION_SCHEMA.TABLE_CONSTRAINTS
             WHERE CONSTRAINT_SCHEMA = DATABASE()
               AND TABLE_NAME = :table_name
               AND CONSTRAINT_NAME = :constraint_name
               AND CONSTRAINT_TYPE = \'FOREIGN KEY\''
        );
        $statement->execute([
            'table_name' => $table,
            'constraint_name' => $constraint,
        ]);
        return (int) $statement->fetchColumn() > 0;
    }

    private static function recoverySnapshotSchemaCurrent(PDO $pdo): bool
    {
        return self::columnExists($pdo, 'recovery_snapshots', 'school_year')
            && self::indexExists($pdo, 'recovery_snapshots', 'idx_recovery_environment_created')
            && self::indexExists($pdo, 'recovery_snapshots', 'idx_recovery_environment_kind_created')
            && self::indexExists($pdo, 'recovery_snapshots', 'idx_recovery_environment_school_year');
    }

    private static function observationSequenceSchemaCurrent(PDO $pdo): bool
    {
        return self::columnExists($pdo, 'observations', 'sequence_key')
            && self::indexExists($pdo, 'observations', 'idx_observations_sequence');
    }

    private static function finalFeatureSchemaCurrent(PDO $pdo): bool
    {
        return self::columnExists($pdo, 'observations', 'claimed_by_user_id')
            && self::columnExists($pdo, 'observations', 'claimed_at')
            && self::columnExists($pdo, 'observations', 'claim_expires_at')
            && self::foreignKeyExists($pdo, 'observations', 'fk_observation_claimed_by')
            && self::indexExists($pdo, 'observations', 'idx_observations_claim')
            && self::columnExists($pdo, 'observations', 'digital_pass_destination')
            && self::columnExists($pdo, 'observations', 'digital_pass_issued_at')
            && self::columnExists($pdo, 'observations', 'digital_pass_expires_at')
            && self::columnExists($pdo, 'authorized_users', 'preassigned_role')
            && self::columnExists($pdo, 'authorized_users', 'preassigned_pp_class')
            && self::columnExists($pdo, 'authorized_users', 'access_expires_at')
            && self::indexExists($pdo, 'authorized_users', 'idx_authorized_users_expiry')
            && self::tableExists($pdo, 'digital_passes')
            && self::indexExists($pdo, 'digital_passes', 'idx_digital_pass_student_period')
            && self::tableExists($pdo, 'annual_aggregates')
            && self::tableExists($pdo, 'year_closures')
            && self::columnExists($pdo, 'observations', 'submission_key')
            && self::indexExists($pdo, 'observations', 'uq_observations_submission')
            && self::tableExists($pdo, 'user_notifications')
            && self::indexExists($pdo, 'user_notifications', 'idx_notifications_user_read')
            && self::indexExists($pdo, 'login_attempts', 'idx_login_attempts_date')
            && self::settingExists($pdo, 'digital_passes_enabled');
    }

    private static function schemaVersion(PDO $pdo): ?int
    {
        try {
            $statement = $pdo->prepare(
                'SELECT setting_value FROM app_settings WHERE setting_key = :setting_key LIMIT 1'
            );
            $statement->execute(['setting_key' => 'schema_version']);
            $value = $statement->fetchColumn();
            return $value === false ? 0 : (int) $value;
        } catch (PDOException $error) {
            // Une installation antérieure peut ne pas encore avoir app_settings.
            // Toute autre erreur (droits, connexion, SQL) doit rester visible.
            if ((string) $error->getCode() === '42S02') {
                return null;
            }
            throw $error;
        }
    }

    private static function columnExists(PDO $pdo, string $table, string $column): bool
    {
        $statement = $pdo->prepare(
            'SELECT COUNT(*) FROM INFORMATION_SCHEMA.COLUMNS
             WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = :table_name AND COLUMN_NAME = :column_name'
        );
        $statement->execute(['table_name' => $table, 'column_name' => $column]);
        return (int) $statement->fetchColumn() > 0;
    }

    private static function tableExists(PDO $pdo, string $table): bool
    {
        $statement = $pdo->prepare(
            'SELECT COUNT(*) FROM INFORMATION_SCHEMA.TABLES
             WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = :table_name'
        );
        $statement->execute(['table_name' => $table]);
        return (int) $statement->fetchColumn() > 0;
    }

    private static function settingExists(PDO $pdo, string $settingKey): bool
    {
        $statement = $pdo->prepare(
            'SELECT COUNT(*) FROM app_settings WHERE setting_key = :setting_key'
        );
        $statement->execute(['setting_key' => $settingKey]);
        return (int) $statement->fetchColumn() > 0;
    }
}
