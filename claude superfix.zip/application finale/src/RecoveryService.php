<?php

declare(strict_types=1);

final class RecoveryBusyException extends RuntimeException
{
}

final class RecoveryValidationException extends RuntimeException
{
}

/**
 * Instantanés applicatifs authentifiés par HMAC, destinés à la récupération
 * après une purge ou une mauvaise manipulation. Le HMAC ne chiffre pas les
 * données : la confidentialité dépend toujours de la protection de MySQL.
 *
 * Les comptes, droits, réglages et journaux d'audit sont volontairement hors
 * du périmètre. Le contenu des instantanés ne doit jamais être renvoyé à la
 * WebUI : seules les métadonnées produites par cette classe sont exposables.
 */
final class RecoveryService
{
    private const FORMAT_VERSION = 1;
    private const DATA_SCHEMA_VERSION = 10;
    private const MAX_SNAPSHOTS_PER_ENVIRONMENT = 400;
    private const MAX_STORAGE_BYTES_PER_ENVIRONMENT = 536870912; // 512 Mio cumulés.
    private const ABSOLUTE_MAX_PAYLOAD_BYTES = 67108864; // 64 Mio compressés.
    private const MAX_UNCOMPRESSED_BYTES = 268435456; // Protection anti-bombe : 256 Mio.

    private const KINDS = ['automatic', 'manual', 'before_purge', 'before_restore'];

    private const TABLE_COLUMNS = [
        'students' => [
            'id', 'external_ref', 'school_year', 'first_name', 'last_name',
            'class_name', 'active', 'created_at', 'updated_at',
        ],
        'observations' => [
            'id', 'student_id', 'reporter_user_id', 'occurred_at', 'location',
            'reason', 'details', 'submission_key', 'digital_pass_destination',
            'digital_pass_issued_at', 'digital_pass_expires_at',
            'sequence_key', 'status', 'cancellation_reason',
            'claimed_by_user_id', 'claimed_at', 'claim_expires_at',
            'validator_user_id', 'validated_at', 'withdrawn_at', 'created_at', 'updated_at',
        ],
        'student_imports' => [
            'id', 'imported_by', 'school_year', 'row_count', 'source_hash',
            'created_at',
        ],
        'point_adjustments' => [
            'id', 'student_id', 'granted_by', 'points', 'reason', 'created_at',
        ],
        'action_records' => [
            'id', 'student_id', 'school_year', 'trimester', 'threshold_points',
            'action_label', 'note', 'done_by', 'done_at',
        ],
        'digital_passes' => [
            'id', 'student_id', 'school_year', 'issuer_user_id', 'destination',
            'issued_at', 'expires_at', 'revoked_at', 'revoked_by_user_id',
        ],
        'year_closures' => [
            'id', 'school_year', 'closed_by_user_id', 'closed_at',
            'student_count', 'observation_count', 'aggregate_sha256',
        ],
        'annual_aggregates' => [
            'id', 'closure_id', 'school_year', 'metric_key', 'dimension_key',
            'dimension_value', 'metric_value', 'created_at',
        ],
    ];

    /** @var PDO */
    private $pdo;
    /** @var string */
    private $appKey;
    /** @var string */
    private $environment;
    /** @var int */
    private $retentionDays;
    /** @var int */
    private $automaticIntervalSeconds;
    /** @var string */
    private $lockName;
    /** @var bool */
    private $mutationLockHeld = false;

    public function __construct(
        PDO $pdo,
        string $appKey,
        string $environment = 'production',
        int $retentionDays = 7,
        int $automaticIntervalSeconds = 1800
    ) {
        if (strlen($appKey) < 32) {
            throw new InvalidArgumentException('La clé applicative de récupération est trop courte.');
        }
        if (!in_array($environment, ['test', 'production'], true)) {
            throw new InvalidArgumentException('Environnement de récupération invalide.');
        }
        if ($retentionDays < 1 || $retentionDays > 30) {
            throw new InvalidArgumentException('La rétention des instantanés doit être comprise entre 1 et 30 jours.');
        }
        if ($automaticIntervalSeconds < 60 || $automaticIntervalSeconds > 86400) {
            throw new InvalidArgumentException('L’intervalle automatique doit être compris entre 60 secondes et 24 heures.');
        }

        $this->pdo = $pdo;
        $this->appKey = $appKey;
        $this->environment = $environment;
        $this->retentionDays = $retentionDays;
        $this->automaticIntervalSeconds = $automaticIntervalSeconds;

        $databaseName = (string) $pdo->query('SELECT DATABASE()')->fetchColumn();
        $this->lockName = 'suivi_recovery_' . substr(
            hash('sha256', $databaseName . '|' . $environment),
            0,
            32
        );
    }

    /**
     * Verrou partagé par toutes les écritures métier et les récupérations.
     * Il est volontairement conservé jusqu'à la fermeture de la connexion PDO
     * (donc la fin de la requête Web) afin de couvrir la transaction appelante.
     */
    public function acquireMutationLock(int $timeoutSeconds = 5): void
    {
        if ($this->mutationLockHeld) {
            return;
        }
        if ($timeoutSeconds < 0 || $timeoutSeconds > 30) {
            throw new InvalidArgumentException('Délai de verrouillage invalide.');
        }
        if (!$this->tryAcquireLock($timeoutSeconds)) {
            throw new RecoveryBusyException(
                'Une sauvegarde ou une restauration est en cours. Réessayez dans quelques secondes.'
            );
        }
        $this->mutationLockHeld = true;
    }

    /** @return array<string,mixed> */
    public function status(): array
    {
        $this->pruneAndCap();

        $totalsStatement = $this->pdo->prepare(
            'SELECT COUNT(*) AS snapshot_count,
                    COALESCE(SUM(payload_bytes), 0) AS storage_bytes
             FROM recovery_snapshots
             WHERE environment = :environment'
        );
        $totalsStatement->execute(['environment' => $this->environment]);
        $totals = $totalsStatement->fetch();
        $lastSnapshot = $this->fetchLatestMetadata(null);
        $lastAutomatic = $this->fetchLatestMetadata('automatic');

        $nextAutomaticAt = null;
        $automaticDue = true;
        if ($lastSnapshot !== null) {
            $lastAt = new DateTimeImmutable(
                (string) $lastSnapshot['created_at'],
                new DateTimeZone('UTC')
            );
            $next = $lastAt->add(new DateInterval('PT' . $this->automaticIntervalSeconds . 'S'));
            $nextAutomaticAt = $next->format('Y-m-d H:i:s');
            $automaticDue = $next->getTimestamp() <= time();
        }

        return [
            'environment' => $this->environment,
            'school_year' => $this->activeSchoolYear($this->pdo),
            'snapshot_count' => (int) $totals['snapshot_count'],
            'storage_bytes' => (int) $totals['storage_bytes'],
            'storage_limit_bytes' => self::MAX_STORAGE_BYTES_PER_ENVIRONMENT,
            'counts' => $this->currentCounts(),
            'retention_days' => $this->retentionDays,
            'automatic_interval_seconds' => $this->automaticIntervalSeconds,
            'interval_minutes' => (int) ceil($this->automaticIntervalSeconds / 60),
            'automatic_due' => $automaticDue,
            'next_automatic_at' => $nextAutomaticAt,
            'last_snapshot' => $lastSnapshot,
            'last_automatic' => $lastAutomatic,
        ];
    }

    /** @return array<int,array<string,mixed>> */
    public function listSnapshots(int $limit = 100): array
    {
        if ($limit < 1 || $limit > 200) {
            throw new InvalidArgumentException('La liste doit contenir entre 1 et 200 instantanés.');
        }
        $this->pruneAndCap();
        $statement = $this->pdo->prepare(
            'SELECT id, kind, environment, format_version, schema_version,
                    school_year, payload_encoding, payload_bytes, uncompressed_bytes, counts,
                    created_by, created_at, expires_at
             FROM recovery_snapshots
             WHERE environment = :environment
             ORDER BY created_at DESC, id DESC
             LIMIT ' . $limit
        );
        $statement->execute(['environment' => $this->environment]);

        return array_map([$this, 'normalizeMetadata'], $statement->fetchAll());
    }

    /** @return array<string,mixed> */
    public function createManual(int $userId): array
    {
        $this->assertUserId($userId);
        $ownsLock = $this->acquireEphemeralLock(5);
        try {
            return $this->transaction(function (PDO $pdo) use ($userId): array {
                $snapshot = $this->createSnapshotInTransaction($pdo, 'manual', $userId, false);
                $this->insertAudit($pdo, $userId, 'recovery.snapshot_manual', (int) $snapshot['id'], [
                    'snapshot_id' => (int) $snapshot['id'],
                    'counts' => $snapshot['counts'],
                    'environment' => $this->environment,
                ]);
                $this->pruneAndCap($pdo, [(int) $snapshot['id']]);
                return $snapshot;
            });
        } finally {
            if ($ownsLock) {
                $this->releaseLock();
            }
        }
    }

    /**
     * Crée un instantané automatique seulement si aucun instantané, quel que
     * soit son type, n'a été pris pendant l'intervalle. Retourne null si le
     * point n'est pas encore dû ou si une mutation détient le verrou.
     *
     * @return array<string,mixed>|null
     */
    public function createAutomaticIfDue(): ?array
    {
        $ownsLock = false;
        if (!$this->mutationLockHeld) {
            if (!$this->tryAcquireLock(0)) {
                return null;
            }
            $ownsLock = true;
        }

        try {
            return $this->transaction(function (PDO $pdo): ?array {
                $this->pruneAndCap($pdo);
                $lastStatement = $pdo->prepare(
                    "SELECT created_at FROM recovery_snapshots
                     WHERE environment = :environment
                     ORDER BY created_at DESC, id DESC LIMIT 1"
                );
                $lastStatement->execute(['environment' => $this->environment]);
                $last = $lastStatement->fetchColumn();
                if (is_string($last) && $last !== '') {
                    $lastAt = new DateTimeImmutable($last, new DateTimeZone('UTC'));
                    if ($lastAt->getTimestamp() + $this->automaticIntervalSeconds > time()) {
                        return null;
                    }
                }
                $snapshot = $this->createSnapshotInTransaction($pdo, 'automatic', null, false);
                $this->pruneAndCap($pdo, [(int) $snapshot['id']]);
                return $snapshot;
            });
        } finally {
            if ($ownsLock) {
                $this->releaseLock();
            }
        }
    }

    /**
     * Sauvegarde puis vide toutes les données élèves dans une seule transaction.
     *
     * @return array<string,mixed>
     */
    public function purgeAll(int $adminUserId): array
    {
        $this->assertUserId($adminUserId);
        $this->acquireMutationLock(5);

        return $this->transaction(function (PDO $pdo) use ($adminUserId): array {
            $snapshot = $this->createSnapshotInTransaction(
                $pdo,
                'before_purge',
                $adminUserId,
                true
            );
            // « Vider les données élèves » conserve l’historique annuel
            // anonymisé. Celui-ci n’est remplacé que par une restauration
            // complète d’un point de récupération.
            $deletedCounts = $this->deleteRecoverableData($pdo, false);
            $expectedDeletedCounts = $snapshot['counts'];
            $expectedDeletedCounts['year_closures'] = 0;
            $expectedDeletedCounts['annual_aggregates'] = 0;
            if ($deletedCounts !== $expectedDeletedCounts) {
                throw new RuntimeException(
                    'Les volumes ont changé pendant la purge. Transaction annulée par sécurité.'
                );
            }
            $this->insertAudit($pdo, $adminUserId, 'recovery.purge', (int) $snapshot['id'], [
                'snapshot_id' => (int) $snapshot['id'],
                'counts' => $deletedCounts,
                'environment' => $this->environment,
            ]);
            $this->pruneAndCap($pdo, [(int) $snapshot['id']]);

            return ['snapshot' => $snapshot, 'counts' => $deletedCounts];
        });
    }

    /**
     * Remplace l'état élève courant par un instantané valide. Un instantané de
     * sécurité de l'état remplacé est créé dans la même transaction.
     *
     * @return array<string,mixed>
     */
    public function restore(int $snapshotId, int $adminUserId): array
    {
        if ($snapshotId < 1) {
            throw new RecoveryValidationException('Identifiant d’instantané invalide.');
        }
        $this->assertUserId($adminUserId);
        $this->acquireMutationLock(5);

        return $this->transaction(function (PDO $pdo) use ($snapshotId, $adminUserId): array {
            $targetStatement = $pdo->prepare(
                'SELECT * FROM recovery_snapshots
                 WHERE id = :id AND environment = :environment
                   AND expires_at > UTC_TIMESTAMP()
                 LIMIT 1 FOR UPDATE'
            );
            $targetStatement->execute(['id' => $snapshotId, 'environment' => $this->environment]);
            $targetRow = $targetStatement->fetch();
            if (!$targetRow) {
                throw new RecoveryValidationException('Instantané introuvable ou arrivé à expiration.');
            }
            $targetData = $this->decodeAndValidateSnapshot($targetRow);
            $this->assertReferencedUsersExist($pdo, $targetData['tables']);

            $safetySnapshot = $this->createSnapshotInTransaction(
                $pdo,
                'before_restore',
                $adminUserId,
                true
            );
            $this->deleteRecoverableData($pdo);
            $restoredCounts = $this->insertRecoverableData($pdo, $targetData['tables']);
            if ((int) $targetRow['schema_version'] <= 8) {
                $this->backfillDigitalPassContext($pdo);
            }

            $targetMetadata = $this->normalizeMetadata($targetRow);
            if ($restoredCounts !== $targetMetadata['counts']) {
                throw new RecoveryValidationException('Contrôle des volumes restaurés invalide. Transaction annulée.');
            }

            $this->insertAudit($pdo, $adminUserId, 'recovery.restore', $snapshotId, [
                'snapshot_id' => $snapshotId,
                'before_restore_snapshot_id' => (int) $safetySnapshot['id'],
                'counts' => $restoredCounts,
                'environment' => $this->environment,
            ]);
            $this->pruneAndCap($pdo, [$snapshotId, (int) $safetySnapshot['id']]);

            return [
                'restored_snapshot' => $targetMetadata,
                'safety_snapshot' => $safetySnapshot,
                'counts' => $restoredCounts,
            ];
        });
    }

    /** @return array<string,mixed> */
    private function createSnapshotInTransaction(
        PDO $pdo,
        string $kind,
        ?int $createdBy,
        bool $lockRows
    ): array {
        if (!in_array($kind, self::KINDS, true)) {
            throw new InvalidArgumentException('Type d’instantané invalide.');
        }
        $createdAt = gmdate('Y-m-d H:i:s');
        $expiresAt = gmdate('Y-m-d H:i:s', time() + ($this->retentionDays * 86400));
        $schoolYear = $this->activeSchoolYear($pdo);
        $tables = $this->readRecoverableData($pdo, $lockRows);
        $counts = $this->countsForTables($tables);
        $document = [
            'format_version' => self::FORMAT_VERSION,
            'schema_version' => self::DATA_SCHEMA_VERSION,
            'environment' => $this->environment,
            'school_year' => $schoolYear,
            'captured_at' => $createdAt,
            'tables' => $tables,
        ];

        try {
            $json = json_encode(
                $document,
                JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES | JSON_THROW_ON_ERROR
            );
        } catch (JsonException $error) {
            throw new RuntimeException('Création de l’instantané impossible : JSON invalide.', 0, $error);
        }
        if (!is_string($json) || strlen($json) > self::MAX_UNCOMPRESSED_BYTES) {
            throw new RecoveryValidationException('Instantané trop volumineux avant compression (limite : 256 Mio).');
        }

        $encoding = 'json';
        $payload = $json;
        if (function_exists('gzencode')) {
            $compressed = gzencode($json, 6, ZLIB_ENCODING_GZIP);
            if (is_string($compressed)) {
                $encoding = 'gzip';
                $payload = $compressed;
            }
        }
        $this->assertPayloadSize(strlen($payload));

        $countsJson = $this->encodeCounts($counts);
        $checksum = hash('sha256', $payload);
        $signatureData = [
            'kind' => $kind,
            'environment' => $this->environment,
            'school_year' => $schoolYear,
            'format_version' => self::FORMAT_VERSION,
            'schema_version' => self::DATA_SCHEMA_VERSION,
            'payload_encoding' => $encoding,
            'payload_sha256' => $checksum,
            'counts' => $counts,
            'created_by' => $createdBy,
            'created_at' => $createdAt,
            'expires_at' => $expiresAt,
        ];
        $hmac = $this->payloadHmac($signatureData, $payload);

        $insert = $pdo->prepare(
            'INSERT INTO recovery_snapshots
                (kind, environment, school_year, format_version, schema_version,
                 payload_encoding, payload, payload_sha256, payload_hmac,
                 payload_bytes, uncompressed_bytes, counts, created_by,
                 created_at, expires_at)
             VALUES
                (:kind, :environment, :school_year, :format_version, :schema_version,
                 :payload_encoding, :payload, :payload_sha256, :payload_hmac,
                 :payload_bytes, :uncompressed_bytes, :counts, :created_by,
                 :created_at, :expires_at)'
        );
        $insert->bindValue(':kind', $kind);
        $insert->bindValue(':environment', $this->environment);
        if ($schoolYear === null) {
            $insert->bindValue(':school_year', null, PDO::PARAM_NULL);
        } else {
            $insert->bindValue(':school_year', $schoolYear);
        }
        $insert->bindValue(':format_version', self::FORMAT_VERSION, PDO::PARAM_INT);
        $insert->bindValue(':schema_version', self::DATA_SCHEMA_VERSION, PDO::PARAM_INT);
        $insert->bindValue(':payload_encoding', $encoding);
        $insert->bindValue(':payload', $payload, PDO::PARAM_LOB);
        $insert->bindValue(':payload_sha256', $checksum);
        $insert->bindValue(':payload_hmac', $hmac);
        $insert->bindValue(':payload_bytes', strlen($payload), PDO::PARAM_INT);
        $insert->bindValue(':uncompressed_bytes', strlen($json), PDO::PARAM_INT);
        $insert->bindValue(':counts', $countsJson);
        if ($createdBy === null) {
            $insert->bindValue(':created_by', null, PDO::PARAM_NULL);
        } else {
            $insert->bindValue(':created_by', $createdBy, PDO::PARAM_INT);
        }
        $insert->bindValue(':created_at', $createdAt);
        $insert->bindValue(':expires_at', $expiresAt);
        $insert->execute();

        return [
            'id' => (int) $pdo->lastInsertId(),
            'kind' => $kind,
            'environment' => $this->environment,
            'school_year' => $schoolYear,
            'format_version' => self::FORMAT_VERSION,
            'schema_version' => self::DATA_SCHEMA_VERSION,
            'payload_encoding' => $encoding,
            'size_bytes' => strlen($payload),
            'uncompressed_bytes' => strlen($json),
            'counts' => $counts,
            'created_by' => $createdBy,
            'created_at' => $createdAt,
            'expires_at' => $expiresAt,
        ];
    }

    /** @return array<string,array<int,array<string,mixed>>> */
    private function readRecoverableData(PDO $pdo, bool $lockRows): array
    {
        $tables = [];
        foreach (self::TABLE_COLUMNS as $table => $columns) {
            $sql = 'SELECT ' . implode(', ', $columns) . ' FROM ' . $table . ' ORDER BY id';
            if ($lockRows) {
                $sql .= ' FOR UPDATE';
            }
            $tables[$table] = $pdo->query($sql)->fetchAll();
        }
        return $tables;
    }

    /** @return array<string,int> */
    private function deleteRecoverableData(PDO $pdo, bool $includeAnnualState = true): array
    {
        $counts = $this->emptyCounts();
        $tables = [
            'digital_passes', 'observations', 'point_adjustments',
            'action_records', 'student_imports', 'students',
        ];
        if ($includeAnnualState) {
            $tables = array_merge(['annual_aggregates', 'year_closures'], $tables);
        }
        foreach ($tables as $table) {
            $counts[$table] = $pdo->exec('DELETE FROM ' . $table);
        }
        return $counts;
    }

    /**
     * @param array<string,array<int,array<string,mixed>>> $tables
     * @return array<string,int>
     */
    private function insertRecoverableData(PDO $pdo, array $tables): array
    {
        $counts = $this->emptyCounts();
        foreach ([
            'students', 'student_imports', 'observations', 'digital_passes',
            'point_adjustments', 'action_records', 'year_closures', 'annual_aggregates',
        ] as $table) {
            $columns = self::TABLE_COLUMNS[$table];
            $placeholders = array_map(static function (string $column): string {
                return ':' . $column;
            }, $columns);
            $insert = $pdo->prepare(
                'INSERT INTO ' . $table . ' (' . implode(', ', $columns) . ')
                 VALUES (' . implode(', ', $placeholders) . ')'
            );
            foreach ($tables[$table] as $row) {
                foreach ($columns as $column) {
                    $value = $row[$column];
                    $insert->bindValue(
                        ':' . $column,
                        $value,
                        $value === null ? PDO::PARAM_NULL : PDO::PARAM_STR
                    );
                }
                $insert->execute();
                $counts[$table]++;
            }
        }
        return $counts;
    }

    /**
     * Les instantanés antérieurs à la v9 contiennent déjà les billets, mais
     * pas leur contexte figé dans les observations. Après insertion de toutes
     * les tables, on reconstruit ce contexte avec la même règle temporelle que
     * lors d'un signalement : émission incluse, expiration/révocation exclues.
     */
    private function backfillDigitalPassContext(PDO $pdo): void
    {
        $pdo->exec(
            'UPDATE observations o
             JOIN students s ON s.id = o.student_id
             JOIN digital_passes dp
               ON dp.student_id = o.student_id
              AND dp.school_year = s.school_year
              AND dp.issued_at <= o.occurred_at
              AND dp.expires_at > o.occurred_at
              AND (dp.revoked_at IS NULL OR dp.revoked_at > o.occurred_at)
             LEFT JOIN digital_passes newer_dp
               ON newer_dp.student_id = dp.student_id
              AND newer_dp.school_year = dp.school_year
              AND newer_dp.issued_at <= o.occurred_at
              AND newer_dp.expires_at > o.occurred_at
              AND (newer_dp.revoked_at IS NULL OR newer_dp.revoked_at > o.occurred_at)
              AND (newer_dp.issued_at > dp.issued_at
                   OR (newer_dp.issued_at = dp.issued_at AND newer_dp.id > dp.id))
             SET o.digital_pass_destination = dp.destination,
                 o.digital_pass_issued_at = dp.issued_at,
                 o.digital_pass_expires_at = dp.expires_at
             WHERE o.digital_pass_destination IS NULL
               AND newer_dp.id IS NULL'
        );
    }

    /** @return array<string,mixed> */
    private function decodeAndValidateSnapshot(array $row): array
    {
        if ((string) $row['environment'] !== $this->environment) {
            throw new RecoveryValidationException('Cet instantané appartient à un autre environnement.');
        }
        if ((int) $row['format_version'] !== self::FORMAT_VERSION) {
            throw new RecoveryValidationException('Format d’instantané incompatible.');
        }
        $snapshotSchemaVersion = (int) $row['schema_version'];
        if (!in_array($snapshotSchemaVersion, [5, 6, 7, 8, 9, self::DATA_SCHEMA_VERSION], true)) {
            throw new RecoveryValidationException('Version de schéma de l’instantané incompatible.');
        }
        if (!in_array((string) $row['kind'], self::KINDS, true)) {
            throw new RecoveryValidationException('Type d’instantané invalide.');
        }
        if (!in_array((string) $row['payload_encoding'], ['json', 'gzip'], true)) {
            throw new RecoveryValidationException('Encodage d’instantané invalide.');
        }

        $payload = (string) $row['payload'];
        if (strlen($payload) !== (int) $row['payload_bytes']) {
            throw new RecoveryValidationException('Taille compressée de l’instantané invalide.');
        }
        $checksum = hash('sha256', $payload);
        if (!hash_equals((string) $row['payload_sha256'], $checksum)) {
            throw new RecoveryValidationException('Somme de contrôle de l’instantané invalide.');
        }
        $predatesDigitalPasses = $snapshotSchemaVersion <= 6;
        $predatesAnnualClosures = $snapshotSchemaVersion <= 7;
        $predatesDigitalPassContext = $snapshotSchemaVersion <= 8;
        $counts = $this->decodeCounts($row['counts'], $snapshotSchemaVersion);
        // La forme exacte des volumes fait partie de la signature. Il faut
        // reconstruire exactement les clés connues au moment de sa création.
        $signedCounts = $counts;
        if ($predatesDigitalPasses) {
            unset($signedCounts['digital_passes']);
        }
        if ($predatesAnnualClosures) {
            unset($signedCounts['year_closures'], $signedCounts['annual_aggregates']);
        }
        $signatureData = [
            'kind' => (string) $row['kind'],
            'environment' => (string) $row['environment'],
            'school_year' => $row['school_year'] === null ? null : (string) $row['school_year'],
            'format_version' => (int) $row['format_version'],
            'schema_version' => (int) $row['schema_version'],
            'payload_encoding' => (string) $row['payload_encoding'],
            'payload_sha256' => (string) $row['payload_sha256'],
            'counts' => $signedCounts,
            'created_by' => $row['created_by'] === null ? null : (int) $row['created_by'],
            'created_at' => (string) $row['created_at'],
            'expires_at' => (string) $row['expires_at'],
        ];
        $expectedHmac = $this->payloadHmac($signatureData, $payload);
        $validHmac = hash_equals((string) $row['payload_hmac'], $expectedHmac);
        // Compatibilité avec les instantanés v5 créés juste avant l'ajout de
        // school_year à la métadonnée signée.
        if (!$validHmac && $row['school_year'] === null) {
            unset($signatureData['school_year']);
            $validHmac = hash_equals(
                (string) $row['payload_hmac'],
                $this->payloadHmac($signatureData, $payload)
            );
        }
        if (!$validHmac) {
            throw new RecoveryValidationException('Signature de sécurité de l’instantané invalide.');
        }

        if ((string) $row['payload_encoding'] === 'gzip') {
            if (!function_exists('gzdecode')) {
                throw new RecoveryValidationException('Extension gzip requise pour restaurer cet instantané.');
            }
            $json = gzdecode($payload, self::MAX_UNCOMPRESSED_BYTES + 1);
            if (!is_string($json)) {
                throw new RecoveryValidationException('Décompression de l’instantané impossible.');
            }
        } else {
            $json = $payload;
        }
        if (strlen($json) > self::MAX_UNCOMPRESSED_BYTES
            || strlen($json) !== (int) $row['uncompressed_bytes']) {
            throw new RecoveryValidationException('Taille décompressée de l’instantané invalide.');
        }

        try {
            $document = json_decode($json, true, 512, JSON_THROW_ON_ERROR);
        } catch (JsonException $error) {
            throw new RecoveryValidationException('Contenu JSON de l’instantané invalide.', 0, $error);
        }
        if (!is_array($document)
            || (int) ($document['format_version'] ?? 0) !== self::FORMAT_VERSION
            || (int) ($document['schema_version'] ?? 0) !== $snapshotSchemaVersion
            || (string) ($document['environment'] ?? '') !== $this->environment
            || (($document['school_year'] ?? null) !== ($row['school_year'] === null
                ? null
                : (string) $row['school_year']))
            || !isset($document['tables'])
            || !is_array($document['tables'])) {
            throw new RecoveryValidationException('En-tête de l’instantané invalide.');
        }

        $tables = $document['tables'];
        $expectedColumns = self::TABLE_COLUMNS;
        if ($predatesDigitalPasses) {
            $expectedColumns['observations'] = array_values(array_filter(
                $expectedColumns['observations'],
                static function (string $column): bool {
                    return !in_array($column, [
                        'claimed_by_user_id', 'claimed_at', 'claim_expires_at',
                    ], true);
                }
            ));
            unset($expectedColumns['digital_passes']);
        }
        if ($predatesAnnualClosures) {
            unset($expectedColumns['year_closures'], $expectedColumns['annual_aggregates']);
        }
        if ($predatesDigitalPassContext) {
            $expectedColumns['observations'] = array_values(array_filter(
                $expectedColumns['observations'],
                static function (string $column): bool {
                    return !in_array($column, [
                        'digital_pass_destination',
                        'digital_pass_issued_at',
                        'digital_pass_expires_at',
                    ], true);
                }
            ));
        }
        if ($snapshotSchemaVersion <= 9) {
            $expectedColumns['observations'] = array_values(array_filter(
                $expectedColumns['observations'],
                static function (string $column): bool {
                    return $column !== 'submission_key';
                }
            ));
        }
        if ($snapshotSchemaVersion === 5) {
            $expectedColumns['observations'] = array_values(array_filter(
                $expectedColumns['observations'],
                static function (string $column): bool {
                    return $column !== 'sequence_key';
                }
            ));
        }
        $expectedTableNames = array_keys($expectedColumns);
        $actualTableNames = array_keys($tables);
        sort($expectedTableNames);
        sort($actualTableNames);
        if ($actualTableNames !== $expectedTableNames) {
            throw new RecoveryValidationException('Liste des tables de l’instantané invalide.');
        }
        foreach ($expectedColumns as $table => $columns) {
            if (!isset($tables[$table]) || !is_array($tables[$table])) {
                throw new RecoveryValidationException('Table manquante dans l’instantané : ' . $table . '.');
            }
            foreach ($tables[$table] as $rowData) {
                if (!is_array($rowData) || !$this->hasExactColumns($rowData, $columns)) {
                    throw new RecoveryValidationException('Structure invalide pour la table ' . $table . '.');
                }
            }
        }
        if ($this->countsForTables($tables) !== $counts) {
            throw new RecoveryValidationException('Volumes déclarés par l’instantané invalides.');
        }

        // Les points de récupération v5 ne connaissaient pas les liaisons
        // manuelles. Ils restent restaurables, sans séquence liée.
        if ($snapshotSchemaVersion === 5) {
            foreach ($tables['observations'] as &$observation) {
                $observation['sequence_key'] = null;
            }
            unset($observation);
        }

        // Les v5/v6 précèdent la prise en charge d'une validation et les
        // billets numériques. Leur restauration initialise donc ces données
        // de manière neutre et explicite.
        if ($predatesDigitalPasses) {
            foreach ($tables['observations'] as &$observation) {
                $observation['claimed_by_user_id'] = null;
                $observation['claimed_at'] = null;
                $observation['claim_expires_at'] = null;
            }
            unset($observation);
            $tables['digital_passes'] = [];
        }

        // La v7 contient déjà les billets et prises en charge, mais précède
        // l'archivage annuel. Les versions antérieures sont normalisées de la
        // même manière pour permettre une restauration globale cohérente.
        if ($predatesAnnualClosures) {
            $tables['year_closures'] = [];
            $tables['annual_aggregates'] = [];
        }

        // Les instantanés v8 et antérieurs ne connaissaient pas le contexte
        // minimal du billet valable à l'heure du constat.
        if ($predatesDigitalPassContext) {
            foreach ($tables['observations'] as &$observation) {
                $observation['digital_pass_destination'] = null;
                $observation['digital_pass_issued_at'] = null;
                $observation['digital_pass_expires_at'] = null;
            }
            unset($observation);
        }

        // Les instantanés v9 et antérieurs précèdent la protection contre les
        // doubles envois. Une clé vide est volontaire : elle ne doit jamais
        // fusionner deux observations historiques lors d'une restauration.
        if ($snapshotSchemaVersion <= 9) {
            foreach ($tables['observations'] as &$observation) {
                $observation['submission_key'] = null;
            }
            unset($observation);
        }

        $this->assertAnnualAggregateReferences($tables);

        return ['tables' => $tables, 'counts' => $counts];
    }

    /** @param array<string,array<int,array<string,mixed>>> $tables */
    private function assertAnnualAggregateReferences(array $tables): void
    {
        $closureYears = [];
        foreach ($tables['year_closures'] as $closure) {
            $closureId = (int) $closure['id'];
            if ($closureId < 1 || isset($closureYears[$closureId])) {
                throw new RecoveryValidationException('Clôture annuelle invalide dans l’instantané.');
            }
            $closureYears[$closureId] = (string) $closure['school_year'];
        }
        foreach ($tables['annual_aggregates'] as $aggregate) {
            $closureId = (int) $aggregate['closure_id'];
            if (!isset($closureYears[$closureId])
                || $closureYears[$closureId] !== (string) $aggregate['school_year']) {
                throw new RecoveryValidationException(
                    'Agrégat annuel sans clôture correspondante dans l’instantané.'
                );
            }
        }
    }

    /** @param array<string,array<int,array<string,mixed>>> $tables */
    private function assertReferencedUsersExist(PDO $pdo, array $tables): void
    {
        $userIds = [];
        foreach ($tables['observations'] as $row) {
            $userIds[] = (int) $row['reporter_user_id'];
            if ($row['validator_user_id'] !== null) {
                $userIds[] = (int) $row['validator_user_id'];
            }
            if ($row['claimed_by_user_id'] !== null) {
                $userIds[] = (int) $row['claimed_by_user_id'];
            }
        }
        foreach ($tables['student_imports'] as $row) {
            $userIds[] = (int) $row['imported_by'];
        }
        foreach ($tables['point_adjustments'] as $row) {
            $userIds[] = (int) $row['granted_by'];
        }
        foreach ($tables['action_records'] as $row) {
            $userIds[] = (int) $row['done_by'];
        }
        foreach ($tables['digital_passes'] as $row) {
            $userIds[] = (int) $row['issuer_user_id'];
            if ($row['revoked_by_user_id'] !== null) {
                $userIds[] = (int) $row['revoked_by_user_id'];
            }
        }
        foreach ($tables['year_closures'] as $row) {
            $userIds[] = (int) $row['closed_by_user_id'];
        }
        $userIds = array_values(array_unique(array_filter($userIds, static function (int $id): bool {
            return $id > 0;
        })));
        if (count($userIds) === 0) {
            return;
        }

        $placeholders = implode(',', array_fill(0, count($userIds), '?'));
        $statement = $pdo->prepare('SELECT id FROM users WHERE id IN (' . $placeholders . ')');
        $statement->execute($userIds);
        $existing = array_map('intval', array_column($statement->fetchAll(), 'id'));
        if (count(array_diff($userIds, $existing)) > 0) {
            throw new RecoveryValidationException(
                'Restauration impossible : un compte utilisateur référencé n’existe plus.'
            );
        }
    }

    /** @return array<string,mixed>|null */
    private function fetchLatestMetadata(?string $kind): ?array
    {
        $sql = 'SELECT id, kind, environment, format_version, schema_version,
                       school_year, payload_encoding, payload_bytes, uncompressed_bytes, counts,
                       created_by, created_at, expires_at
                FROM recovery_snapshots
                WHERE environment = :environment';
        $parameters = ['environment' => $this->environment];
        if ($kind !== null) {
            $sql .= ' AND kind = :kind';
            $parameters['kind'] = $kind;
        }
        $sql .= ' ORDER BY created_at DESC, id DESC LIMIT 1';
        $statement = $this->pdo->prepare($sql);
        $statement->execute($parameters);
        $row = $statement->fetch();
        return $row ? $this->normalizeMetadata($row) : null;
    }

    /** @return array<string,mixed> */
    private function normalizeMetadata(array $row): array
    {
        return [
            'id' => (int) $row['id'],
            'kind' => (string) $row['kind'],
            'environment' => (string) $row['environment'],
            'school_year' => $row['school_year'] === null ? null : (string) $row['school_year'],
            'format_version' => (int) $row['format_version'],
            'schema_version' => (int) $row['schema_version'],
            'payload_encoding' => (string) $row['payload_encoding'],
            'size_bytes' => (int) $row['payload_bytes'],
            'uncompressed_bytes' => (int) $row['uncompressed_bytes'],
            'counts' => $this->decodeCounts(
                $row['counts'],
                (int) $row['schema_version']
            ),
            'created_by' => $row['created_by'] === null ? null : (int) $row['created_by'],
            'created_at' => (string) $row['created_at'],
            'expires_at' => (string) $row['expires_at'],
        ];
    }

    /** @param array<string,array<int,array<string,mixed>>> $tables
     *  @return array<string,int>
     */
    private function countsForTables(array $tables): array
    {
        $counts = $this->emptyCounts();
        foreach (array_keys($counts) as $table) {
            $counts[$table] = isset($tables[$table]) && is_array($tables[$table])
                ? count($tables[$table])
                : 0;
        }
        return $counts;
    }

    /** @return array<string,int> */
    private function emptyCounts(): array
    {
        return [
            'students' => 0,
            'observations' => 0,
            'student_imports' => 0,
            'point_adjustments' => 0,
            'action_records' => 0,
            'digital_passes' => 0,
            'year_closures' => 0,
            'annual_aggregates' => 0,
        ];
    }

    /** @param mixed $value
     *  @return array<string,int>
     */
    private function decodeCounts($value, int $snapshotSchemaVersion): array
    {
        if (!in_array($snapshotSchemaVersion, [5, 6, 7, 8, 9, self::DATA_SCHEMA_VERSION], true)) {
            throw new RecoveryValidationException('Version des volumes incompatible.');
        }
        if (is_string($value)) {
            try {
                $value = json_decode($value, true, 32, JSON_THROW_ON_ERROR);
            } catch (JsonException $error) {
                throw new RecoveryValidationException('Métadonnées de volumes invalides.', 0, $error);
            }
        }
        if (!is_array($value)) {
            throw new RecoveryValidationException('Métadonnées de volumes invalides.');
        }
        $counts = $this->emptyCounts();
        $expectedTables = array_keys($counts);
        if ($snapshotSchemaVersion <= 6) {
            $expectedTables = array_values(array_filter(
                $expectedTables,
                static function (string $table): bool {
                    return $table !== 'digital_passes';
                }
            ));
        }
        if ($snapshotSchemaVersion <= 7) {
            $expectedTables = array_values(array_filter(
                $expectedTables,
                static function (string $table): bool {
                    return !in_array($table, ['year_closures', 'annual_aggregates'], true);
                }
            ));
        }
        $actualTables = array_keys($value);
        sort($expectedTables);
        sort($actualTables);
        if ($actualTables !== $expectedTables) {
            throw new RecoveryValidationException('Tables de volumes invalides.');
        }
        foreach ($counts as $table => $_) {
            if (!array_key_exists($table, $value)) {
                $counts[$table] = 0;
                continue;
            }
            if (!array_key_exists($table, $value) || !is_numeric($value[$table]) || (int) $value[$table] < 0) {
                throw new RecoveryValidationException('Volume invalide pour ' . $table . '.');
            }
            $counts[$table] = (int) $value[$table];
        }
        return $counts;
    }

    /** @param array<string,int> $counts */
    private function encodeCounts(array $counts): string
    {
        try {
            return json_encode(
                $counts,
                JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES | JSON_THROW_ON_ERROR
            );
        } catch (JsonException $error) {
            throw new RuntimeException('Encodage des volumes impossible.', 0, $error);
        }
    }

    /** @param array<string,mixed> $signatureData */
    private function payloadHmac(array $signatureData, string $payload): string
    {
        try {
            $context = json_encode(
                $signatureData,
                JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES | JSON_THROW_ON_ERROR
            );
        } catch (JsonException $error) {
            throw new RuntimeException('Signature de l’instantané impossible.', 0, $error);
        }
        return hash_hmac('sha256', $context . "\0" . $payload, $this->appKey);
    }

    private function assertPayloadSize(int $payloadBytes): void
    {
        $packet = (int) $this->pdo->query('SELECT @@max_allowed_packet')->fetchColumn();
        if ($packet <= 0) {
            $packet = 16777216;
        }
        $packetLimit = max(262144, (int) floor($packet * 0.75));
        $limit = min(self::ABSOLUTE_MAX_PAYLOAD_BYTES, $packetLimit);
        if ($payloadBytes > $limit) {
            throw new RecoveryValidationException(
                'Instantané compressé trop volumineux (' . $payloadBytes
                . ' octets ; limite sûre MySQL : ' . $limit . ' octets).'
            );
        }
    }

    /** @param array<string,mixed> $row
     *  @param array<int,string> $columns
     */
    private function hasExactColumns(array $row, array $columns): bool
    {
        $actual = array_keys($row);
        sort($actual);
        $expected = $columns;
        sort($expected);
        return $actual === $expected;
    }

    /** @return array<string,int> */
    private function currentCounts(): array
    {
        $counts = $this->emptyCounts();
        foreach (array_keys($counts) as $table) {
            $counts[$table] = (int) $this->pdo->query(
                'SELECT COUNT(*) FROM ' . $table
            )->fetchColumn();
        }
        return $counts;
    }

    private function activeSchoolYear(PDO $pdo): ?string
    {
        $statement = $pdo->prepare(
            'SELECT setting_value FROM app_settings WHERE setting_key = :setting_key LIMIT 1'
        );
        $statement->execute(['setting_key' => 'active_school_year']);
        $value = $statement->fetchColumn();
        if (!is_string($value) || trim($value) === '') {
            return null;
        }
        $value = trim($value);
        if (strlen($value) > 16) {
            throw new RecoveryValidationException('Année scolaire active invalide pour la sauvegarde.');
        }
        return $value;
    }

    /** @param array<int,int> $protectedIds */
    private function pruneAndCap(?PDO $pdo = null, array $protectedIds = []): void
    {
        $connection = $pdo !== null ? $pdo : $this->pdo;
        $deleteExpired = $connection->prepare(
            'DELETE FROM recovery_snapshots
             WHERE environment = :environment AND expires_at <= UTC_TIMESTAMP()'
        );
        $deleteExpired->execute(['environment' => $this->environment]);

        $totalsStatement = $connection->prepare(
            'SELECT COUNT(*) AS snapshot_count,
                    COALESCE(SUM(payload_bytes), 0) AS storage_bytes
             FROM recovery_snapshots WHERE environment = :environment'
        );
        $totalsStatement->execute(['environment' => $this->environment]);
        $totals = $totalsStatement->fetch();
        $currentCount = (int) $totals['snapshot_count'];
        $currentBytes = (int) $totals['storage_bytes'];
        if ($currentCount <= self::MAX_SNAPSHOTS_PER_ENVIRONMENT
            && $currentBytes <= self::MAX_STORAGE_BYTES_PER_ENVIRONMENT) {
            return;
        }

        $protectedIds = array_values(array_unique(array_filter(
            array_map('intval', $protectedIds),
            static function (int $id): bool { return $id > 0; }
        )));
        $parameters = ['environment' => $this->environment];
        $sql = 'SELECT id, payload_bytes FROM recovery_snapshots WHERE environment = :environment';
        if (count($protectedIds) > 0) {
            $placeholders = [];
            foreach ($protectedIds as $index => $id) {
                $name = 'protected_' . $index;
                $placeholders[] = ':' . $name;
                $parameters[$name] = $id;
            }
            $sql .= ' AND id NOT IN (' . implode(', ', $placeholders) . ')';
        }
        $sql .= ' ORDER BY created_at ASC, id ASC';
        $candidates = $connection->prepare($sql);
        $candidates->execute($parameters);

        $deleteIds = [];
        foreach ($candidates->fetchAll() as $candidate) {
            if ($currentCount <= self::MAX_SNAPSHOTS_PER_ENVIRONMENT
                && $currentBytes <= self::MAX_STORAGE_BYTES_PER_ENVIRONMENT) {
                break;
            }
            $deleteIds[] = (int) $candidate['id'];
            $currentCount--;
            $currentBytes = max(0, $currentBytes - (int) $candidate['payload_bytes']);
        }
        if ($currentCount > self::MAX_SNAPSHOTS_PER_ENVIRONMENT
            || $currentBytes > self::MAX_STORAGE_BYTES_PER_ENVIRONMENT) {
            throw new RecoveryValidationException(
                'Le stockage des points de récupération dépasse la limite sûre de 512 Mio.'
            );
        }
        if (count($deleteIds) === 0) {
            return;
        }

        $deleteParameters = ['environment' => $this->environment];
        $deletePlaceholders = [];
        foreach ($deleteIds as $index => $id) {
            $name = 'delete_' . $index;
            $deletePlaceholders[] = ':' . $name;
            $deleteParameters[$name] = $id;
        }
        $deleteOldest = $connection->prepare(
            'DELETE FROM recovery_snapshots
             WHERE environment = :environment
               AND id IN (' . implode(', ', $deletePlaceholders) . ')'
        );
        $deleteOldest->execute($deleteParameters);
    }

    private function tryAcquireLock(int $timeoutSeconds): bool
    {
        $statement = $this->pdo->prepare('SELECT GET_LOCK(:lock_name, :timeout_seconds)');
        $statement->bindValue(':lock_name', $this->lockName);
        $statement->bindValue(':timeout_seconds', $timeoutSeconds, PDO::PARAM_INT);
        $statement->execute();
        return (int) $statement->fetchColumn() === 1;
    }

    /**
     * Retourne true uniquement si cette méthode a acquis un verrou éphémère
     * qu'elle devra relâcher ; false signifie que le verrou public est déjà tenu.
     */
    private function acquireEphemeralLock(int $timeoutSeconds): bool
    {
        if ($this->mutationLockHeld) {
            return false;
        }
        if (!$this->tryAcquireLock($timeoutSeconds)) {
            throw new RecoveryBusyException(
                'Une sauvegarde ou une restauration est en cours. Réessayez dans quelques secondes.'
            );
        }
        return true;
    }

    private function releaseLock(): void
    {
        $statement = $this->pdo->prepare('SELECT RELEASE_LOCK(:lock_name)');
        $statement->execute(['lock_name' => $this->lockName]);
    }

    /** @return mixed */
    private function transaction(callable $callback)
    {
        if ($this->pdo->inTransaction()) {
            throw new RuntimeException('Une transaction de récupération est déjà active.');
        }
        $this->pdo->beginTransaction();
        try {
            $result = $callback($this->pdo);
            $this->pdo->commit();
            return $result;
        } catch (Throwable $error) {
            if ($this->pdo->inTransaction()) {
                $this->pdo->rollBack();
            }
            throw $error;
        }
    }

    /** @param array<string,mixed> $metadata */
    private function insertAudit(
        PDO $pdo,
        int $userId,
        string $action,
        int $snapshotId,
        array $metadata
    ): void {
        try {
            $metadataJson = json_encode(
                $metadata,
                JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES | JSON_THROW_ON_ERROR
            );
        } catch (JsonException $error) {
            throw new RuntimeException('Journalisation de la récupération impossible.', 0, $error);
        }
        $statement = $pdo->prepare(
            'INSERT INTO audit_logs (user_id, action, entity_type, entity_id, metadata)
             VALUES (:user_id, :action, :entity_type, :entity_id, :metadata)'
        );
        $statement->execute([
            'user_id' => $userId,
            'action' => $action,
            'entity_type' => 'recovery_snapshot',
            'entity_id' => $snapshotId,
            'metadata' => $metadataJson,
        ]);
    }

    private function assertUserId(int $userId): void
    {
        if ($userId < 1) {
            throw new InvalidArgumentException('Identifiant utilisateur invalide.');
        }
    }
}
