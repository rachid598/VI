# Mise à jour vers 1.0.0-rc.3

Cette mise à jour conserve la base MySQL et la configuration existantes.

## Avant la mise à jour

1. Créer un point de récupération depuis l’administration.
2. Conserver une copie du fichier `var/settings.php` présent sur le serveur.

## Fichiers à téléverser

- `index.html`
- `service-worker.js`
- `VERSION`
- `CHANGELOG.md`
- `assets/app.js`
- `assets/impeccable.css`
- `database/schema.sql`
- `src/ApiController.php`
- `src/LdapAuthenticator.php`
- `src/RecoveryService.php`
- `src/SchemaMigrator.php`

Il est également possible de remplacer tout le dossier par le contenu du ZIP,
à condition de conserver le fichier `var/settings.php` déjà installé.

## Après le téléversement

1. Ouvrir l’application une fois : le schéma MySQL passe automatiquement en version 9.
2. Si le bandeau « nouvelle version » apparaît, choisir **Actualiser**.
3. Vérifier dans **Administration → État du système** que MySQL, LDAP et le dossier `var` sont indiqués comme opérationnels.
4. Effectuer un signalement fictif sur l’installation de test, puis le confirmer avec un compte CPE/AED afin de contrôler la notification.

Le fichier `var/settings.php` ne doit jamais être remplacé par un fichier provenant du ZIP.
