"use strict";

(() => {
  const url = new URL(window.location.href);
  const sensitiveParameters = ["username", "password"];
  const containsSensitiveParameter = sensitiveParameters.some((name) => url.searchParams.has(name));

  if (!containsSensitiveParameter) return;

  sensitiveParameters.forEach((name) => url.searchParams.delete(name));
  const remainingQuery = url.searchParams.toString();
  const cleanUrl = `${url.pathname}${remainingQuery ? `?${remainingQuery}` : ""}${url.hash}`;
  window.history.replaceState(window.history.state, document.title, cleanUrl);
})();
