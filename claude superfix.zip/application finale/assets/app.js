"use strict";

const THEME_STORAGE_KEY = "suivi-theme";

function preferredTheme() {
  try {
    const saved = window.localStorage.getItem(THEME_STORAGE_KEY);
    if (saved === "light" || saved === "dark") return saved;
  } catch (_) {}
  return window.matchMedia && window.matchMedia("(prefers-color-scheme: dark)").matches ? "dark" : "light";
}

function applyTheme(theme, persist = false) {
  document.documentElement.dataset.theme = theme;
  document.documentElement.style.colorScheme = theme;
  const isDark = theme === "dark";
  document.querySelectorAll("[data-theme-toggle]").forEach((button) => {
    button.setAttribute("aria-label", isDark ? "Activer le thème clair" : "Activer le thème sombre");
    button.setAttribute("aria-pressed", String(isDark));
  });
  const themeColor = document.querySelector("#theme-color");
  if (themeColor) themeColor.setAttribute("content", isDark ? "#0b171c" : "#102f3a");
  if (persist) {
    try { window.localStorage.setItem(THEME_STORAGE_KEY, theme); } catch (_) {}
  }
}

applyTheme(preferredTheme());

const roleLabels = {
  teacher: "Enseignant",
  aed: "AED",
  cpe: "CPE",
  direction: "Direction",
  pp: "Professeur principal",
  service: "Service médico-social",
  admin: "Administrateur",
};

const views = {
  new: { label: "Nouvelle observation", icon: "+" },
  validation: { label: "À vérifier", icon: "✓" },
  passes: { label: "Billets numériques", icon: "↗" },
  dashboard: { label: "Tableau de bord", icon: "▥" },
  report: { label: "Bilan hebdomadaire", icon: "▤" },
  history: { label: "Historique élève", icon: "⌕" },
  points: { label: "Permis à points", icon: "◎" },
  pp: { label: "Bilan de ma classe", icon: "◇" },
  admin: { label: "Administration", icon: "⚙" },
  about: { label: "Cadre du pilote", icon: "i" },
};

const auditCategoryDefinitions = [
  { value: "all", label: "Toutes les actions" },
  { value: "auth", label: "Connexions / déconnexions" },
  { value: "observations", label: "Signalements" },
  { value: "students", label: "Élèves et annuaire" },
  { value: "accounts", label: "Comptes et accès" },
  { value: "points", label: "Permis à points" },
  { value: "passes", label: "Billets numériques" },
  { value: "recovery", label: "Récupération et purge" },
  { value: "settings", label: "Réglages" },
  { value: "other", label: "Autres actions" },
];

let session = null;
let csrfToken = "";
let currentView = "new";
let selectedStudents = [];
let editingObservationId = null;
let searchTimer = null;
let toastTimer = null;
let dashboardLocation = "";
let badgeTimer = null;
let studentSearchController = null;
let studentSearchSequence = 0;
let activeAutocompleteIndex = -1;
let historySearchController = null;
let historySearchSequence = 0;
let activeHistoryAutocompleteIndex = -1;
let deferredInstallPrompt = null;
let serviceWorkerRegistration = null;
let serviceWorkerRegistrationError = "";
let pendingServiceWorker = null;
let reloadForServiceWorkerUpdate = false;
let recoveryRefreshTimer = null;
let auditCategoryFilter = "all";
let auditSortOrder = "newest";
let myObservationFilter = "all";
let validationFilters = { level: "", class_name: "", location: "", age: "all", path: "all" };
let passSearchController = null;
let passSearchSequence = 0;
let activePassAutocompleteIndex = -1;
let selectedPassStudent = null;
let digitalPassRefreshTimer = null;
let reportPeriodDays = 7;
let currentAnonymousReport = null;
let observationSubmissionKey = null;
let serverClockBaseUtcMs = Number.NaN;
let serverClockBaseMonotonicMs = 0;
let occurrenceClockTimer = null;
let offlineFlushInProgress = false;

// File d'attente hors connexion : petite, bornée dans le temps, propre à chaque
// utilisateur et vidée dès l'envoi. Aucune donnée n'y survit plus de 12 heures.
const OFFLINE_QUEUE_LIMIT = 10;
const OFFLINE_QUEUE_TTL_MS = 12 * 60 * 60 * 1000;

const loginScreen = document.querySelector("#login-screen");
const loginForm = document.querySelector("#login-form");
const loginError = document.querySelector("#login-error");
const shell = document.querySelector("#app-shell");
const app = document.querySelector("#app");
const nav = document.querySelector("#main-nav");
const authArea = document.querySelector("#auth-area");
const pageTitle = document.querySelector("#page-title");
const toast = document.querySelector("#toast");
const mobileMenu = document.querySelector("#mobile-menu");
const sidebar = document.querySelector("#app-sidebar");
const mobileMenuBackdrop = document.querySelector("#mobile-menu-backdrop");
const environmentBanner = document.querySelector("#environment-banner");
const environmentLabel = document.querySelector("#environment-label");
const updateNotice = document.querySelector("#update-notice");
const pwaHelpDialog = document.querySelector("#pwa-help-dialog");
const onboardingDialog = document.querySelector("#onboarding-dialog");
const notificationsDialog = document.querySelector("#notifications-dialog");
const mobileViewport = window.matchMedia("(max-width: 960px)");

window.addEventListener("beforeinstallprompt", (event) => {
  event.preventDefault();
  deferredInstallPrompt = event;
  updatePwaInstallControls();
});

window.addEventListener("appinstalled", () => {
  deferredInstallPrompt = null;
  updatePwaInstallControls();
  showToast("Application installée sur cet appareil.");
});

window.addEventListener("afterprint", () => {
  document.querySelector("#letter-sheet")?.remove();
  document.querySelector("#report-sheet")?.remove();
});

window.addEventListener("online", () => {
  flushOfflineQueue();
});

document.addEventListener("DOMContentLoaded", () => {
  document.querySelectorAll("[data-theme-toggle]").forEach((button) => {
    button.addEventListener("click", () => {
      const nextTheme = document.documentElement.dataset.theme === "dark" ? "light" : "dark";
      applyTheme(nextTheme, true);
    });
  });
  document.querySelectorAll("[data-pwa-install]").forEach((button) => {
    button.addEventListener("click", handlePwaInstall);
  });
  document.querySelector("#pwa-help-close").addEventListener("click", () => pwaHelpDialog.close());
  document.querySelector("#pwa-help-done").addEventListener("click", () => pwaHelpDialog.close());
  document.querySelector("#app-help").addEventListener("click", () => openOnboarding(true));
  document.querySelector("#onboarding-close").addEventListener("click", closeOnboarding);
  document.querySelector("#onboarding-done").addEventListener("click", closeOnboarding);
  document.querySelector("#notifications-close").addEventListener("click", () => notificationsDialog.close());
  document.querySelector("#notifications-done").addEventListener("click", () => notificationsDialog.close());
  document.querySelector("#notifications-read").addEventListener("click", markNotificationsRead);
  document.querySelector("#update-app").addEventListener("click", applyServiceWorkerUpdate);
  document.querySelector("#dismiss-update").addEventListener("click", () => { updateNotice.hidden = true; });
  updatePwaInstallControls();
  syncMobileMenuState();
  initialise();
  registerServiceWorker();
});
loginForm.addEventListener("submit", handleLogin);
function setLoginReady(ready) {
  const loginButton = loginForm.querySelector('button[type="submit"]');
  if (loginButton) loginButton.disabled = !ready;
}
mobileMenu.addEventListener("click", () => setMobileMenu(!sidebar.classList.contains("open")));
mobileMenuBackdrop.addEventListener("click", () => setMobileMenu(false, true));
if (typeof mobileViewport.addEventListener === "function") {
  mobileViewport.addEventListener("change", syncMobileMenuState);
} else {
  mobileViewport.addListener(syncMobileMenuState);
}
document.addEventListener("keydown", (event) => {
  if (event.key === "Escape" && mobileViewport.matches && sidebar.classList.contains("open")) {
    event.preventDefault();
    setMobileMenu(false, true);
  }
});

async function initialise() {
  try {
    const data = await api("session");
    csrfToken = data.csrf_token;
    session = data;
    synchroniseServerClock(data.server_now_utc);
    updateAppVersion(data.app_version);
    setLoginReady(true);
    updateEnvironmentBanner();
    if (data.authenticated) showApplication();
  } catch (error) {
    if (error.installationRequired) {
      window.location.replace("install.php");
      return;
    }
    loginError.textContent = error.message;
  }
}

async function registerServiceWorker() {
  if (!("serviceWorker" in navigator)) {
    serviceWorkerRegistrationError = "Ce navigateur ne prend pas en charge le mode application.";
    return;
  }
  if (!window.isSecureContext) {
    serviceWorkerRegistrationError = "La page doit être ouverte avec une connexion HTTPS reconnue par le téléphone.";
    return;
  }
  try {
    serviceWorkerRegistration = await navigator.serviceWorker.register("./service-worker.js", { scope: "./" });
    serviceWorkerRegistrationError = "";
    if (serviceWorkerRegistration.waiting) showServiceWorkerUpdate(serviceWorkerRegistration.waiting);
    serviceWorkerRegistration.addEventListener("updatefound", () => {
      const worker = serviceWorkerRegistration.installing;
      if (!worker) return;
      worker.addEventListener("statechange", () => {
        if (worker.state === "installed" && navigator.serviceWorker.controller) {
          showServiceWorkerUpdate(worker);
        }
      });
    });
    navigator.serviceWorker.addEventListener("controllerchange", () => {
      if (reloadForServiceWorkerUpdate) window.location.reload();
    });
    window.setInterval(() => serviceWorkerRegistration.update().catch(() => {}), 60 * 60 * 1000);
    document.addEventListener("visibilitychange", () => {
      if (document.visibilityState === "visible") serviceWorkerRegistration.update().catch(() => {});
    });
  } catch (_) {
    serviceWorkerRegistrationError = "Le composant hors connexion n’a pas pu démarrer. Rechargez la page puis réessayez.";
  }
}

function showServiceWorkerUpdate(worker) {
  pendingServiceWorker = worker;
  updateNotice.hidden = false;
}

function applyServiceWorkerUpdate() {
  if (!pendingServiceWorker) return;
  reloadForServiceWorkerUpdate = true;
  document.querySelector("#update-app").disabled = true;
  document.querySelector("#update-app").textContent = "Mise à jour…";
  pendingServiceWorker.postMessage({ type: "SKIP_WAITING" });
}

function isPwaInstalled() {
  return window.matchMedia("(display-mode: standalone)").matches
    || window.navigator.standalone === true;
}

function updatePwaInstallControls() {
  const installed = isPwaInstalled();
  document.querySelectorAll("[data-pwa-install]").forEach((button) => {
    const label = button.querySelector("[data-pwa-label]");
    button.disabled = installed;
    button.classList.toggle("installed", installed);
    if (label) label.textContent = installed
      ? "Application installée"
      : (deferredInstallPrompt ? "Installer l’application" : "Ajouter sur cet appareil");
  });
}

async function handlePwaInstall() {
  if (isPwaInstalled()) return;
  if (deferredInstallPrompt) {
    const prompt = deferredInstallPrompt;
    deferredInstallPrompt = null;
    await prompt.prompt();
    await prompt.userChoice.catch(() => null);
    updatePwaInstallControls();
    return;
  }
  const isIos = /iphone|ipad|ipod/i.test(navigator.userAgent);
  const isAndroid = /android/i.test(navigator.userAgent);
  const isSafari = /^((?!chrome|android|crios|fxios|edgios).)*safari/i.test(navigator.userAgent) || isIos;
  const content = document.querySelector("#pwa-help-content");
  const diagnostic = serviceWorkerRegistrationError
    ? `<p><strong>Point à vérifier :</strong> ${serviceWorkerRegistrationError}</p>`
    : "";
  content.innerHTML = isIos
    ? `<ol><li>Dans Safari, ouvrez le menu <strong>Partager</strong>.</li><li>Choisissez <strong>Sur l’écran d’accueil</strong>.</li><li>Confirmez avec <strong>Ajouter</strong>.</li></ol><p>Sur iPhone ou iPad, l’ajout doit être lancé depuis Safari.</p>`
    : (isAndroid
      ? `<ol><li>Restez environ <strong>30 secondes</strong> sur cette page et touchez-la une fois.</li><li>Rechargez la page.</li><li>Si le bouton n’affiche pas encore <strong>Installer l’application</strong>, ouvrez le menu <strong>⋮</strong> de Chrome puis choisissez <strong>Installer l’application</strong> ou <strong>Ajouter à l’écran d’accueil</strong>.</li></ol>${diagnostic}`
      : (isSafari
      ? `<ol><li>Dans Safari, ouvrez le menu <strong>Fichier</strong>.</li><li>Choisissez <strong>Ajouter au Dock</strong>.</li><li>Confirmez l’ajout.</li></ol><p>Si cette commande n’est pas proposée, utilisez le bouton de partage ou le menu du navigateur.</p>`
      : `<ol><li>Ouvrez le menu du navigateur.</li><li>Choisissez <strong>Installer l’application</strong> ou <strong>Ajouter à l’écran d’accueil</strong>.</li><li>Confirmez l’ajout.</li></ol><p>Si l’option n’apparaît pas encore, restez 30 secondes sur la page puis rechargez-la.</p>${diagnostic}`));
  if (typeof pwaHelpDialog.showModal === "function") {
    pwaHelpDialog.showModal();
  } else {
    window.alert(content.textContent.trim());
  }
}

function updateEnvironmentBanner() {
  const isTest = !session || session.environment !== "production";
  environmentBanner.hidden = !isTest;
  document.body.classList.toggle("has-demo-banner", isTest);
  document.body.dataset.environment = isTest ? "test" : "production";
  if (isTest) environmentLabel.textContent = "Mode démo — données fictives uniquement";
}

function updateAppVersion(version) {
  const value = String(version || "").trim();
  document.querySelectorAll("[data-app-version]").forEach((element) => {
    element.textContent = value ? `v${value}` : "";
    element.hidden = value === "";
  });
}

function synchroniseServerClock(value) {
  const serverDate = parseUtcDate(value);
  if (Number.isNaN(serverDate.getTime())) return;
  serverClockBaseUtcMs = serverDate.getTime();
  serverClockBaseMonotonicMs = performance.now();
}

function estimatedServerNow() {
  if (!Number.isFinite(serverClockBaseUtcMs)) return null;
  return new Date(serverClockBaseUtcMs + Math.max(0, performance.now() - serverClockBaseMonotonicMs));
}

function updateOccurrenceSlider() {
  const range = document.querySelector("#occurred-offset");
  const relativeLabel = document.querySelector("#occurrence-relative");
  const exactLabel = document.querySelector("#occurrence-exact");
  if (!range || !relativeLabel || !exactLabel) return;
  const offsetMinutes = Math.min(20, Math.max(0, Number(range.value) || 0));
  const relativeText = offsetMinutes === 0
    ? "Maintenant"
    : `Il y a ${offsetMinutes} min`;
  const serverNow = estimatedServerNow();
  const occurredAt = serverNow
    ? new Date(serverNow.getTime() - offsetMinutes * 60000)
    : null;
  const exactText = occurredAt
    ? `Heure enregistrée : ${new Intl.DateTimeFormat("fr-FR", {
      hour: "2-digit",
      minute: "2-digit",
      timeZone: "Europe/Paris",
    }).format(occurredAt)}`
    : "Heure calculée par le serveur à l’enregistrement";
  relativeLabel.textContent = relativeText;
  exactLabel.textContent = exactText;
  range.style.setProperty("--range-progress", `${offsetMinutes * 5}%`);
  range.setAttribute("aria-valuetext", `${relativeText}. ${exactText}.`);
}

function syncMobileMenuState() {
  if (!mobileViewport.matches) {
    sidebar.classList.remove("open");
    sidebar.removeAttribute("aria-hidden");
    sidebar.inert = false;
    document.querySelector(".main-content").inert = false;
    mobileMenuBackdrop.hidden = true;
    mobileMenu.setAttribute("aria-expanded", "false");
    document.body.classList.remove("mobile-menu-open");
    return;
  }
  setMobileMenu(false, false);
}

function setMobileMenu(open, returnFocus = false) {
  if (!mobileViewport.matches) return;
  sidebar.classList.toggle("open", open);
  sidebar.setAttribute("aria-hidden", String(!open));
  sidebar.inert = !open;
  document.querySelector(".main-content").inert = open;
  mobileMenuBackdrop.hidden = !open;
  mobileMenu.setAttribute("aria-expanded", String(open));
  mobileMenu.setAttribute("aria-label", open ? "Fermer le menu" : "Ouvrir le menu");
  document.body.classList.toggle("mobile-menu-open", open);
  if (open) {
    window.requestAnimationFrame(() => (nav.querySelector(".nav-button.active") || nav.querySelector(".nav-button"))?.focus());
  } else if (returnFocus) {
    window.requestAnimationFrame(() => mobileMenu.focus());
  }
}

async function api(action, options = {}) {
  const requestSession = session;
  const method = options.method || "GET";
  const headers = { Accept: "application/json" };
  let body;
  if (method !== "GET") headers["X-CSRF-Token"] = csrfToken;
  if (options.formData) {
    body = options.formData;
  } else if (options.body !== undefined) {
    headers["Content-Type"] = "application/json";
    body = JSON.stringify(options.body);
  }
  const suffix = options.query ? `&${new URLSearchParams(options.query)}` : "";
  const response = await fetch(`api.php?action=${encodeURIComponent(action)}${suffix}`, {
    method,
    headers,
    body,
    credentials: "same-origin",
    signal: options.signal,
  });
  let data;
  try {
    data = await response.json();
  } catch (_) {
    throw new Error("Réponse technique illisible.");
  }
  // Neutraliser aussi les erreurs provenant d’une ancienne session. Certaines
  // réponses 4xx contiennent un contexte métier qui ne doit jamais réapparaître
  // après une déconnexion ou une reconnexion.
  if (requestSession && session !== requestSession && action !== "login") {
    const error = new Error("La session a été fermée.");
    error.status = 401;
    throw error;
  }
  if (!response.ok) {
    const reauthenticationActions = ["admin_purge_students", "admin_restore_snapshot", "admin_close_year"];
    if (response.status === 401 && action !== "login" && action !== "session" && !reauthenticationActions.includes(action)) showLogin();
    const error = new Error(data.error || "Une erreur est survenue.");
    error.status = response.status;
    error.installationRequired = Boolean(data.installation_required);
    error.code = data.code || null;
    error.previousAt = data.previous_at || null;
    throw error;
  }
  return data;
}

async function handleLogin(event) {
  event.preventDefault();
  loginError.textContent = "";
  const button = loginForm.querySelector("button");
  const buttonLabel = button.innerHTML;
  button.disabled = true;
  button.textContent = "Connexion…";
  try {
    const form = new FormData(loginForm);
    const data = await api("login", {
      method: "POST",
      body: { username: form.get("username"), password: form.get("password") },
    });
    csrfToken = data.csrf_token;
    // Recharge toujours la session complète : après une expiration, l’écran
    // de connexion ne possède plus les listes et réglages nécessaires à l’app.
    session = await api("session");
    csrfToken = session.csrf_token;
    synchroniseServerClock(session.server_now_utc);
    updateAppVersion(session.app_version);
    updateEnvironmentBanner();
    loginForm.reset();
    showApplication();
  } catch (error) {
    if (error.status === 419) {
      const refreshed = await refreshLoginSecurity();
      if (refreshed) loginError.textContent = "La sécurité de la session a été actualisée. Vous pouvez réessayer.";
    } else {
      loginError.textContent = error.message;
    }
  } finally {
    button.disabled = csrfToken === "";
    button.innerHTML = buttonLabel;
  }
}

function showLogin(message = "Votre session a expiré. Reconnectez-vous.") {
  clearInterval(badgeTimer);
  badgeTimer = null;
  clearInterval(recoveryRefreshTimer);
  recoveryRefreshTimer = null;
  clearTimeout(searchTimer);
  searchTimer = null;
  clearTimeout(toastTimer);
  toastTimer = null;
  if (studentSearchController) studentSearchController.abort();
  studentSearchController = null;
  studentSearchSequence++;
  if (historySearchController) historySearchController.abort();
  historySearchController = null;
  historySearchSequence++;
  if (passSearchController) passSearchController.abort();
  passSearchController = null;
  passSearchSequence++;
  clearTimeout(digitalPassRefreshTimer);
  digitalPassRefreshTimer = null;
  clearInterval(occurrenceClockTimer);
  occurrenceClockTimer = null;

  session = null;
  csrfToken = "";
  currentView = "new";
  selectedStudents = [];
  editingObservationId = null;
  dashboardLocation = "";
  activeAutocompleteIndex = -1;
  activeHistoryAutocompleteIndex = -1;
  auditCategoryFilter = "all";
  auditSortOrder = "newest";
  myObservationFilter = "all";
  validationFilters = { level: "", class_name: "", location: "", age: "all", path: "all" };
  selectedPassStudent = null;
  activePassAutocompleteIndex = -1;
  reportPeriodDays = 7;
  currentAnonymousReport = null;
  observationSubmissionKey = null;
  pointsTrimester = 0;
  pointsSearchFilter = "";
  pointsLevelFilter = "";
  pointsClassFilter = "";

  // Fermer et supprimer tous les panneaux contenant des données de l'élève ou
  // un mot de passe de réauthentification avant d'afficher la connexion.
  app.querySelectorAll("dialog[open]").forEach((dialog) => dialog.close());
  [onboardingDialog, notificationsDialog, pwaHelpDialog].forEach((dialog) => {
    if (dialog?.open) dialog.close();
  });
  document.querySelector("#letter-sheet")?.remove();
  app.replaceChildren();
  nav.replaceChildren();
  authArea.replaceChildren();
  pageTitle.textContent = "";
  const schoolYear = document.querySelector("#school-year");
  if (schoolYear) schoolYear.textContent = "";
  toast.textContent = "";
  toast.classList.remove("show");
  loginForm.reset();
  loginError.textContent = message;
  shell.hidden = true;
  loginScreen.hidden = false;
  setMobileMenu(false, false);
  setLoginReady(false);
  refreshLoginSecurity();
}

async function refreshLoginSecurity() {
  setLoginReady(false);
  csrfToken = "";
  try {
    const data = await api("session");
    csrfToken = data.csrf_token;
    synchroniseServerClock(data.server_now_utc);
    updateAppVersion(data.app_version);
    setLoginReady(true);
    return true;
  } catch (error) {
    loginError.textContent = error.message;
    return false;
  }
}

function showApplication() {
  loginScreen.hidden = true;
  shell.hidden = false;
  updateEnvironmentBanner();
  updateAppVersion(session.app_version);
  updatePwaInstallControls();
  document.querySelector("#school-year").textContent = session.school_year || "";
  renderAuthArea();
  document.querySelector("#logout").addEventListener("click", logout);
  currentView = availableViews()[0];
  renderNavigation();
  renderCurrentView();
  clearInterval(badgeTimer);
  badgeTimer = setInterval(refreshNavigationCounts, 60000);
  window.requestAnimationFrame(showOnboardingIfNeeded);
  flushOfflineQueue();
}

function renderAuthArea() {
  const count = Number(session?.notification_count || 0);
  authArea.innerHTML = `
    <button id="notifications-button" class="notification-button" type="button" aria-label="Ouvrir mes notifications${count ? `, ${count} non lue${count > 1 ? "s" : ""}` : ""}" title="Mes notifications">
      <span aria-hidden="true">●</span>${count ? `<b>${count > 99 ? "99+" : count}</b>` : ""}
    </button>
    <div class="auth-card">
      <div><strong>${escapeHtml(displayUser(session.user))}</strong><span class="user-role">${escapeHtml(roleLabels[session.user.role] || session.user.role)}</span></div>
      <button id="logout" class="auth-button logout" type="button">Déconnexion</button>
    </div>`;
  document.querySelector("#notifications-button").addEventListener("click", openNotifications);
}

function updateNotificationButton() {
  const button = document.querySelector("#notifications-button");
  if (!button) return;
  const count = Number(session?.notification_count || 0);
  button.setAttribute("aria-label", `Ouvrir mes notifications${count ? `, ${count} non lue${count > 1 ? "s" : ""}` : ""}`);
  const badge = button.querySelector("b");
  if (count > 0) {
    if (badge) badge.textContent = count > 99 ? "99+" : String(count);
    else button.insertAdjacentHTML("beforeend", `<b>${count > 99 ? "99+" : count}</b>`);
  } else if (badge) {
    badge.remove();
  }
}

function onboardingStorageKey() {
  const userId = Number(session?.user?.id || 0);
  return `suivi:onboarding:v1:${userId}`;
}

function showOnboardingIfNeeded() {
  if (!session?.authenticated || !onboardingDialog || onboardingDialog.open) return;
  let alreadySeen = false;
  try {
    alreadySeen = localStorage.getItem(onboardingStorageKey()) === "seen";
  } catch (_) {
    alreadySeen = false;
  }
  if (!alreadySeen) openOnboarding(false);
}

function openOnboarding(manual = false) {
  if (!session?.authenticated || !onboardingDialog) return;
  const permissions = session.permissions || {};
  const roleStep = permissions.can_validate
    ? `<li><strong>Vérifier</strong><span>La file « À vérifier » permet de confirmer, annuler ou rapprocher un même parcours.</span></li>`
    : (permissions.can_pp
      ? `<li><strong>Suivre sa classe</strong><span>Le bilan PP affiche uniquement les constats confirmés de votre classe.</span></li>`
      : `<li><strong>Suivre</strong><span>La zone « Mes signalements » indique ensuite si votre constat est confirmé ou annulé.</span></li>`);
  document.querySelector("#onboarding-subtitle").textContent = manual
    ? "Les repères essentiels restent disponibles ici à tout moment."
    : "Trois repères avant votre première utilisation.";
  document.querySelector("#onboarding-content").innerHTML = `
    <ol class="onboarding-steps">
      <li><strong>Choisir l’élève</strong><span>Recherchez par nom, prénom ou classe, puis sélectionnez le bon résultat.</span></li>
      <li><strong>Décrire le constat</strong><span>Indiquez le lieu, le motif et l’heure. La précision reste courte et factuelle.</span></li>
      <li><strong>Envoyer pour vérification</strong><span>L’enregistrement est transmis à la vie scolaire ; aucune décision n’est automatique.</span></li>
      ${roleStep}
    </ol>`;
  document.querySelector("#onboarding-done").textContent = manual ? "Fermer" : "Commencer";
  onboardingDialog.showModal();
}

function closeOnboarding() {
  try {
    localStorage.setItem(onboardingStorageKey(), "seen");
  } catch (_) {
    /* Le guide reste simplement proposé au prochain démarrage. */
  }
  onboardingDialog.close();
}

async function openNotifications() {
  const content = document.querySelector("#notifications-content");
  const readButton = document.querySelector("#notifications-read");
  content.innerHTML = `<div class="notification-empty">Chargement…</div>`;
  readButton.disabled = true;
  notificationsDialog.showModal();
  try {
    const data = await api("notifications");
    const rows = Array.isArray(data.notifications) ? data.notifications : [];
    session.notification_count = Number(data.unread_count || 0);
    updateNotificationButton();
    readButton.disabled = session.notification_count === 0;
    content.innerHTML = rows.length
      ? `<div class="notification-list">${rows.map(notificationRowHtml).join("")}</div>`
      : `<div class="notification-empty"><strong>Aucune notification</strong><span>Les changements de statut de vos signalements apparaîtront ici.</span></div>`;
  } catch (error) {
    content.innerHTML = `<div class="notification-empty error"><strong>Chargement impossible</strong><span>${escapeHtml(error.message)}</span></div>`;
  }
}

function notificationRowHtml(item) {
  const confirmed = item.event_type === "confirmed";
  const label = confirmed ? "Confirmé" : "Annulé";
  const reason = !confirmed && item.cancellation_reason
    ? `<span>Motif : ${escapeHtml(item.cancellation_reason)}</span>`
    : "";
  return `<article class="notification-row ${item.read_at ? "read" : "unread"}">
    <span class="notification-state ${confirmed ? "confirmed" : "cancelled"}" aria-hidden="true">${confirmed ? "✓" : "×"}</span>
    <div><div><strong>${escapeHtml(item.first_name)} ${escapeHtml(item.last_name)} · ${escapeHtml(item.class_name)}</strong><span class="badge ${confirmed ? "confirmed" : "cancelled"}">${label}</span></div><p>${escapeHtml(item.reason)} — ${escapeHtml(item.location)}</p><small>Constat du ${escapeHtml(formatDate(item.occurred_at))} · traité le ${escapeHtml(formatDate(item.created_at))}</small>${reason}</div>
  </article>`;
}

async function markNotificationsRead() {
  const button = document.querySelector("#notifications-read");
  button.disabled = true;
  button.textContent = "Mise à jour…";
  try {
    await api("notifications_read", { method: "POST", body: {} });
    session.notification_count = 0;
    updateNotificationButton();
    document.querySelectorAll(".notification-row.unread").forEach((row) => {
      row.classList.remove("unread");
      row.classList.add("read");
    });
    button.textContent = "Tout est lu";
  } catch (error) {
    button.disabled = false;
    button.textContent = "Tout marquer comme lu";
    showToast(error.message);
  }
}

async function refreshNavigationCounts() {
  if (!session || !session.authenticated) return;
  if (!offlineFlushInProgress && loadOfflineQueue().length > 0) {
    // Filet de sécurité : certains navigateurs n'émettent pas l'événement
    // « online » de façon fiable ; la minuterie des badges sert alors de relance.
    flushOfflineQueue();
  }
  try {
    const data = await api("session");
    if (!data.authenticated) {
      showLogin();
      return;
    }
    csrfToken = data.csrf_token;
    const previousCount = Number(session.alert_count || 0);
    const previousPendingCount = Number(session.pending_count || 0);
    const previousCanPoints = Boolean(session.permissions && session.permissions.can_points);
    const previousCanPass = Boolean(session.permissions && session.permissions.can_digital_pass && session.digital_passes && session.digital_passes.enabled);
    const previousCanReport = Boolean(session.permissions && session.permissions.can_anonymous_report);
    const previousNotificationCount = Number(session.notification_count || 0);
    const nextCount = Number(data.alert_count || 0);
    const nextPendingCount = Number(data.pending_count || 0);
    session.alert_count = data.alert_count;
    session.pending_count = data.pending_count;
    session.notification_count = data.notification_count;
    session.points = data.points;
    session.digital_passes = data.digital_passes;
    session.permissions = data.permissions;
    session.environment = data.environment;
    session.app_version = data.app_version;
    session.server_now_utc = data.server_now_utc;
    synchroniseServerClock(data.server_now_utc);
    updateAppVersion(session.app_version);
    updateEnvironmentBanner();
    updateNotificationButton();
    if (Number(data.notification_count || 0) > previousNotificationCount) {
      showToast("Un de vos signalements vient d’être traité.");
    }
    if (!availableViews().includes(currentView)) {
      currentView = availableViews()[0];
      renderCurrentView();
    }
    if (previousCount !== nextCount
        || previousPendingCount !== nextPendingCount
        || previousCanPoints !== Boolean(session.permissions.can_points)
        || previousCanPass !== Boolean(session.permissions.can_digital_pass && session.digital_passes && session.digital_passes.enabled)
        || previousCanReport !== Boolean(session.permissions.can_anonymous_report)) {
      renderNavigation();
    }
  } catch (_) {
    /* Une nouvelle tentative silencieuse aura lieu au prochain intervalle. */
  }
}

async function logout() {
  clearInterval(recoveryRefreshTimer);
  recoveryRefreshTimer = null;
  try {
    await api("logout", { method: "POST", body: {} });
  } finally {
    location.reload();
  }
}

function availableViews() {
  const allowed = [];
  const permissions = session.permissions;
  if (permissions.can_submit) allowed.push("new");
  if (permissions.can_validate) allowed.push("validation");
  if (permissions.can_digital_pass && session.digital_passes && session.digital_passes.enabled) allowed.push("passes");
  if (permissions.can_dashboard) allowed.push("dashboard");
  if (permissions.can_anonymous_report) allowed.push("report");
  if (permissions.can_history) allowed.push("history");
  if (permissions.can_points) allowed.push("points");
  if (permissions.can_pp) allowed.push("pp");
  if (permissions.can_admin) allowed.push("admin");
  allowed.push("about");
  return allowed;
}

function renderNavigation() {
  nav.innerHTML = availableViews().map((key) => {
    const count = key === "validation"
      ? Number(session.pending_count || 0)
      : (key === "points" ? Number(session.alert_count || 0) : 0);
    const countLabel = key === "validation"
      ? `${count} signalement${count > 1 ? "s" : ""} en attente`
      : `${count} élève${count > 1 ? "s" : ""} en alerte`;
    const countClass = key === "validation" ? "pending-count" : "points-count";
    return `
      <button class="nav-button ${currentView === key ? "active" : ""}" type="button" data-view="${key}" ${currentView === key ? 'aria-current="page"' : ""}>
        <span class="nav-icon" aria-hidden="true">${views[key].icon}</span><span class="nav-label">${views[key].label}</span>${count > 0 ? `<span class="nav-count ${countClass}" aria-label="${countLabel}">${count > 99 ? "99+" : count}</span>` : ""}
      </button>`;
  }).join("");
  nav.querySelectorAll("[data-view]").forEach((button) => {
    button.addEventListener("click", () => {
      currentView = button.dataset.view;
      selectedStudents = [];
      setMobileMenu(false, false);
      renderNavigation();
      renderCurrentView().finally(() => {
        if (!mobileViewport.matches) return;
        pageTitle.setAttribute("tabindex", "-1");
        pageTitle.focus();
      });
    });
  });
}

async function renderCurrentView() {
  if (currentView !== "admin") {
    clearInterval(recoveryRefreshTimer);
    recoveryRefreshTimer = null;
  }
  if (currentView !== "new") {
    clearInterval(occurrenceClockTimer);
    occurrenceClockTimer = null;
    clearTimeout(searchTimer);
    studentSearchSequence++;
    if (studentSearchController) studentSearchController.abort();
    studentSearchController = null;
  }
  if (currentView !== "history") {
    historySearchSequence++;
    if (historySearchController) historySearchController.abort();
    historySearchController = null;
  }
  if (currentView !== "passes") {
    clearTimeout(digitalPassRefreshTimer);
    digitalPassRefreshTimer = null;
    passSearchSequence++;
    if (passSearchController) passSearchController.abort();
    passSearchController = null;
    selectedPassStudent = null;
  }
  const definition = views[currentView];
  pageTitle.textContent = definition.label;
  app.innerHTML = `<div class="empty-state"><div><span class="empty-icon">…</span><p>Chargement</p></div></div>`;
  try {
    if (currentView === "new") await renderNewObservation();
    if (currentView === "validation") await renderValidation();
    if (currentView === "passes") await renderDigitalPasses();
    if (currentView === "dashboard") await renderDashboard();
    if (currentView === "report") await renderAnonymousReport();
    if (currentView === "history") await renderStudentHistory();
    if (currentView === "points") await renderPoints();
    if (currentView === "pp") await renderPpReport();
    if (currentView === "admin") await renderAdmin();
    if (currentView === "about") renderAbout();
  } catch (error) {
    app.innerHTML = `<div class="error-card">${escapeHtml(error.message)}</div>`;
  }
}

async function renderNewObservation() {
  pageTitle.textContent = views.new.label;
  clearInterval(occurrenceClockTimer);
  occurrenceClockTimer = null;
  studentSearchSequence++;
  if (studentSearchController) studentSearchController.abort();
  studentSearchController = null;
  editingObservationId = null;
  observationSubmissionKey = null;
  selectedStudents = [];
  let myObservations = [];
  let recentUnavailable = false;
  try {
    const recent = await api("my_observations", { query: { status: "all" } });
    myObservations = Array.isArray(recent.observations) ? recent.observations : [];
  } catch (error) {
    if (Number(error.status || 0)) throw error;
    // Hors connexion : le formulaire reste utilisable, seule la liste
    // « Mes signalements » est momentanément indisponible.
    recentUnavailable = true;
  }
  app.innerHTML = `
    <div id="offline-queue-banner">${renderOfflineQueueBanner()}</div>
    <section class="card form-card form-card-plain observation-card">
      <div class="card-body">
        <form id="observation-form" class="observation-form" novalidate>
          <div class="field full"><label for="student-search">Élèves concernés <span id="students-count" class="optional" aria-live="polite">0/8 sélectionné</span></label><div class="student-picker"><span class="search-icon">⌕</span><input id="student-search" class="input search-input" autocomplete="off" placeholder="Nom, prénom ou classe" role="combobox" aria-autocomplete="list" aria-controls="autocomplete" aria-expanded="false" aria-describedby="students-hint student-error"><div id="autocomplete" class="autocomplete" role="listbox" aria-label="Résultats de recherche"></div></div><div id="selected-students" class="selected-students" aria-live="polite"></div><p class="students-hint muted" id="students-hint" hidden>Un signalement identique sera créé pour chaque élève sélectionné.</p><p id="student-error" class="field-error" role="alert"></p></div>
          <div class="field"><label for="location">Lieu</label><select id="location" class="select" required aria-describedby="location-error"><option value="">Choisir…</option>${session.locations.map(optionHtml).join("")}</select><p id="location-error" class="field-error" role="alert"></p></div>
          <div class="field"><label for="reason">Motif</label><select id="reason" class="select" required aria-describedby="reason-error"><option value="">Choisir…</option>${session.reasons.map(optionHtml).join("")}</select><p id="reason-error" class="field-error" role="alert"></p></div>
          <fieldset class="field full occurrence-fieldset"><legend>Heure du constat</legend><div class="occurrence-slider"><output class="occurrence-readout" for="occurred-offset"><strong id="occurrence-relative">Maintenant</strong><span id="occurrence-exact">Heure calculée par le serveur</span></output><input id="occurred-offset" class="occurrence-range" name="occurred-offset" type="range" min="0" max="20" step="1" value="0" aria-label="Décalage de l’heure du constat en minutes" aria-describedby="occurrence-help"><div class="occurrence-scale" aria-hidden="true"><span>Maintenant</span><span>5 min</span><span>10 min</span><span>15 min</span><span>20 min</span></div><p id="occurrence-help" class="occurrence-help">Réglage précis, de maintenant à 20 minutes auparavant.</p></div></fieldset>
          <div class="field full"><label for="details">Précision factuelle <span class="optional">facultatif · 160 caractères</span></label><textarea id="details" class="textarea" maxlength="160" placeholder="Ex. aucun billet présenté, cinq minutes après la sonnerie…"></textarea></div>
          <p id="observation-form-error" class="field-error form-wide-error" role="alert"></p>
          <div class="form-guidance"><span>i</span><div>Transmis à la vie scolaire pour vérification — aucune sanction automatique.</div></div>
          <div class="form-actions"><p id="observation-submit-status" class="submission-status" role="status" aria-live="polite"></p><button id="cancel-edit" class="button secondary" type="button" hidden>Annuler la modification</button><button id="submit-observation" class="button primary" type="submit">Enregistrer le signalement</button></div>
        </form>
      </div>
    </section>
    <section class="card recent-block my-observations-block"><div class="card-header"><div><h3>Mes signalements</h3><p>Retrouvez l’état de vos constats de l’année scolaire.</p></div></div>${recentUnavailable ? `<div class="card-body recent-list"><p class="muted">Liste momentanément indisponible hors connexion. La saisie reste possible.</p></div>` : renderMyObservationPanel(myObservations)}</section>`;

  bindOfflineQueueBanner();
  const searchInput = document.querySelector("#student-search");
  const autocomplete = document.querySelector("#autocomplete");
  searchInput.addEventListener("input", () => {
    clearTimeout(searchTimer);
    searchTimer = setTimeout(() => searchStudents(searchInput.value, autocomplete), 220);
  });
  searchInput.addEventListener("keydown", handleAutocompleteKeydown);
  searchInput.addEventListener("blur", () => window.setTimeout(() => {
    if (!autocomplete.contains(document.activeElement)) closeAutocomplete(searchInput, autocomplete);
  }, 120));
  document.querySelector("#location").addEventListener("change", () => clearFieldError("location"));
  document.querySelector("#reason").addEventListener("change", () => clearFieldError("reason"));
  document.querySelector("#occurred-offset").addEventListener("input", updateOccurrenceSlider);
  updateOccurrenceSlider();
  occurrenceClockTimer = window.setInterval(updateOccurrenceSlider, 30000);
  document.querySelector("#cancel-edit").addEventListener("click", renderNewObservation);
  document.querySelector("#observation-form").addEventListener("submit", submitObservation);
  bindMyObservationPanel(myObservations);
}

function observationFilterMatches(item, filter) {
  if (filter === "all") return true;
  if (filter === "cancelled") return item.status === "cancelled" || item.status === "withdrawn";
  return item.status === filter;
}

function observationFilterCount(rows, filter) {
  return rows.filter((item) => observationFilterMatches(item, filter)).length;
}

function renderMyObservationPanel(rows) {
  const filters = [
    ["all", "Tous"],
    ["pending", "À vérifier"],
    ["confirmed", "Confirmés"],
    ["cancelled", "Annulés"],
  ];
  if (!filters.some(([value]) => value === myObservationFilter)) myObservationFilter = "all";
  const visibleRows = rows.filter((item) => observationFilterMatches(item, myObservationFilter));
  return `<div class="status-tabs" role="tablist" aria-label="Filtrer mes signalements">${filters.map(([value, label]) => `<button class="status-tab ${myObservationFilter === value ? "active" : ""}" type="button" role="tab" aria-selected="${myObservationFilter === value}" data-my-filter="${value}"><span>${label}</span><b>${observationFilterCount(rows, value)}</b></button>`).join("")}</div><div id="my-observation-results" class="card-body recent-list" role="tabpanel">${renderRecent(visibleRows)}</div>`;
}

function bindMyObservationPanel(rows) {
  app.querySelectorAll("[data-my-filter]").forEach((tab) => {
    tab.addEventListener("click", () => {
      myObservationFilter = tab.dataset.myFilter;
      const block = document.querySelector(".my-observations-block");
      if (!block) return;
      block.innerHTML = `<div class="card-header"><div><h3>Mes signalements</h3><p>Retrouvez l’état de vos constats de l’année scolaire.</p></div></div>${renderMyObservationPanel(rows)}`;
      bindMyObservationPanel(rows);
    });
  });
  rows.forEach((observation) => {
    const button = document.querySelector(`[data-edit-observation="${observation.id}"]`);
    if (button) button.addEventListener("click", () => startEditingObservation(observation));
    const withdrawButton = document.querySelector(`[data-withdraw-observation="${observation.id}"]`);
    if (withdrawButton) withdrawButton.addEventListener("click", () => withdrawObservation(observation));
  });
}

async function searchStudents(query, container) {
  const normalizedQuery = query.trim();
  const searchInput = document.querySelector("#student-search");
  const requestSequence = ++studentSearchSequence;
  if (studentSearchController) studentSearchController.abort();
  studentSearchController = null;
  if (normalizedQuery.length < 2) {
    closeAutocomplete(searchInput, container);
    return;
  }
  studentSearchController = new AbortController();
  try {
    const data = await api("students", {
      query: { q: normalizedQuery },
      signal: studentSearchController.signal,
    });
    if (requestSequence !== studentSearchSequence
      || !searchInput
      || searchInput.value.trim() !== normalizedQuery
      || !container.isConnected) return;
    if (!data.students.length) {
      container.innerHTML = `<div class="student-option muted" role="option" aria-disabled="true">Aucun élève trouvé</div>`;
    } else {
      container.innerHTML = data.students.map((student, index) => `
        <button id="student-option-${requestSequence}-${index}" type="button" class="student-option" data-index="${index}" role="option" aria-selected="false" tabindex="-1">
          <span class="avatar">${escapeHtml(initials(student))}</span><span><strong>${escapeHtml(student.first_name)} ${escapeHtml(student.last_name)}</strong><span>${escapeHtml(student.class_name)}</span>${studentActivePassHtml(student)}</span>
        </button>`).join("");
      container.querySelectorAll("[data-index]").forEach((button) => {
        button.addEventListener("click", () => {
          const student = data.students[Number(button.dataset.index)];
          if (editingObservationId !== null) {
            selectedStudents = [student];
          } else if (!selectedStudents.some((item) => Number(item.id) === Number(student.id))) {
            if (selectedStudents.length >= 8) {
              showToast("Huit élèves maximum par signalement groupé.");
              return;
            }
            selectedStudents.push(student);
          }
          searchInput.value = "";
          closeAutocomplete(searchInput, container);
          updateSelectedStudents();
          searchInput.focus();
        });
      });
    }
    container.classList.add("open");
    searchInput.setAttribute("aria-expanded", "true");
    activeAutocompleteIndex = -1;
  } catch (error) {
    if (error.name === "AbortError" || requestSequence !== studentSearchSequence) return;
    showToast(error.message);
  }
}

function closeAutocomplete(input = document.querySelector("#student-search"), container = document.querySelector("#autocomplete")) {
  if (!input || !container) return;
  container.classList.remove("open");
  container.innerHTML = "";
  input.setAttribute("aria-expanded", "false");
  input.removeAttribute("aria-activedescendant");
  activeAutocompleteIndex = -1;
}

function handleAutocompleteKeydown(event) {
  const input = event.currentTarget;
  const container = document.querySelector("#autocomplete");
  const options = [...container.querySelectorAll("[role=option]:not([aria-disabled=true])")];
  if (event.key === "Escape") {
    if (container.classList.contains("open")) {
      event.preventDefault();
      closeAutocomplete(input, container);
    }
    return;
  }
  if (!options.length || !["ArrowDown", "ArrowUp", "Enter"].includes(event.key)) return;
  if (event.key === "Enter") {
    if (activeAutocompleteIndex >= 0) {
      event.preventDefault();
      options[activeAutocompleteIndex].click();
    }
    return;
  }
  event.preventDefault();
  const direction = event.key === "ArrowDown" ? 1 : -1;
  activeAutocompleteIndex = (activeAutocompleteIndex + direction + options.length) % options.length;
  options.forEach((option, index) => option.setAttribute("aria-selected", String(index === activeAutocompleteIndex)));
  input.setAttribute("aria-activedescendant", options[activeAutocompleteIndex].id);
  options[activeAutocompleteIndex].scrollIntoView({ block: "nearest" });
}

function updateSelectedStudents() {
  const target = document.querySelector("#selected-students");
  const hint = document.querySelector("#students-hint");
  const count = document.querySelector("#students-count");
  if (!target) return;
  if (selectedStudents.length > 0) clearFieldError("student-search", "student-error");
  if (hint) hint.hidden = selectedStudents.length < 2;
  if (count) count.textContent = `${selectedStudents.length}/8 sélectionné${selectedStudents.length > 1 ? "s" : ""}`;
  target.innerHTML = selectedStudents.map((student, index) => `
    <span class="selected-student visible student-chip"><span class="avatar">${escapeHtml(initials(student))}</span><div><strong>${escapeHtml(student.first_name)} ${escapeHtml(student.last_name)}</strong> ${escapeHtml(student.class_name)}${studentActivePassHtml(student, true)}</div><button type="button" aria-label="Retirer ${escapeHtml(student.first_name)} ${escapeHtml(student.last_name)}" data-remove-student="${index}">×</button></span>`).join("");
  target.querySelectorAll("[data-remove-student]").forEach((button) => {
    button.addEventListener("click", () => {
      selectedStudents.splice(Number(button.dataset.removeStudent), 1);
      updateSelectedStudents();
    });
  });
}

function activePassForStudent(student) {
  if (!student || typeof student !== "object") return null;
  return student.active_pass || student.digital_pass || null;
}

function studentActivePassHtml(student, compact = false) {
  const pass = activePassForStudent(student);
  if (!pass) return "";
  if (!pass.destination && !pass.expires_at) {
    return `<span class="active-pass-hint ${compact ? "compact" : ""}"><span aria-hidden="true">↗</span> Billet actif</span>`;
  }
  const destination = pass.destination || "déplacement autorisé";
  const expiry = pass.expires_at ? ` jusqu’à ${formatTime(pass.expires_at)}` : "";
  return `<span class="active-pass-hint ${compact ? "compact" : ""}"><span aria-hidden="true">↗</span> Billet vers ${escapeHtml(destination)}${escapeHtml(expiry)}</span>`;
}

function clearFieldError(fieldId, errorId = `${fieldId}-error`) {
  const field = document.querySelector(`#${fieldId}`);
  const error = document.querySelector(`#${errorId}`);
  if (field) field.removeAttribute("aria-invalid");
  if (error) error.textContent = "";
}

function setFieldError(fieldId, message, errorId = `${fieldId}-error`) {
  const field = document.querySelector(`#${fieldId}`);
  const error = document.querySelector(`#${errorId}`);
  if (field) field.setAttribute("aria-invalid", "true");
  if (error) error.textContent = message;
  return field;
}

function clearObservationErrors() {
  clearFieldError("student-search", "student-error");
  clearFieldError("location");
  clearFieldError("reason");
  const general = document.querySelector("#observation-form-error");
  if (general) general.textContent = "";
}

function validateObservationForm() {
  clearObservationErrors();
  const invalidFields = [];
  if (selectedStudents.length === 0) {
    invalidFields.push(setFieldError("student-search", "Recherchez puis choisissez au moins un élève dans la liste.", "student-error"));
  }
  if (!document.querySelector("#location").value) {
    invalidFields.push(setFieldError("location", "Choisissez le lieu du constat."));
  }
  if (!document.querySelector("#reason").value) {
    invalidFields.push(setFieldError("reason", "Choisissez le motif à vérifier."));
  }
  const firstInvalid = invalidFields.find(Boolean);
  if (firstInvalid) firstInvalid.focus();
  return invalidFields.length === 0;
}

async function submitObservation(event) {
  event.preventDefault();
  if (!validateObservationForm()) return;
  const button = event.currentTarget.querySelector("button[type=submit]");
  const status = document.querySelector("#observation-submit-status");
  const buttonLabel = button.textContent;
  const isEditing = editingObservationId !== null;
  let retrySuggested = false;
  const body = {
    location: document.querySelector("#location").value,
    reason: document.querySelector("#reason").value,
    details: document.querySelector("#details").value,
  };
  if (isEditing) {
    body.id = editingObservationId;
    body.student_id = selectedStudents[0].id;
  } else {
    body.student_ids = selectedStudents.map((student) => student.id);
    body.occurred_offset_minutes = Number(document.querySelector("#occurred-offset")?.value || 0);
    observationSubmissionKey = observationSubmissionKey || createSubmissionKey();
    body.submission_key = observationSubmissionKey;
  }
  const successMessage = (count) => count > 1
    ? `${count} signalements enregistrés et transmis pour vérification.`
    : "Signalement enregistré et transmis pour vérification.";
  button.disabled = true;
  button.textContent = isEditing ? "Modification…" : "Enregistrement…";
  if (status) {
    status.className = "submission-status sending";
    status.textContent = isEditing ? "Enregistrement des modifications…" : "Envoi au serveur…";
  }
  try {
    const result = await api(isEditing ? "update_own_observation" : "observations", {
      method: "POST",
      body,
    });
    const created = isEditing ? 1 : Number(result.created || 1);
    observationSubmissionKey = null;
    selectedStudents = [];
    editingObservationId = null;
    showToast(isEditing
      ? "Signalement modifié."
      : (result.idempotent ? "Signalement déjà enregistré : aucun doublon créé." : successMessage(created)));
    await renderNewObservation();
    refreshNavigationCounts();
  } catch (error) {
    if (!isEditing && error.code === "possible_duplicate" && window.confirm(`${error.message}\n\nEnregistrer quand même ?`)) {
      try {
        const result = await api("observations", { method: "POST", body: { ...body, allow_duplicate: true } });
        observationSubmissionKey = null;
        selectedStudents = [];
        showToast(result.idempotent
          ? "Signalement déjà enregistré : aucun doublon créé."
          : `${successMessage(Number(result.created || 1))} Doublon possible confirmé.`);
        await renderNewObservation();
        refreshNavigationCounts();
        return;
      } catch (confirmationError) {
        document.querySelector("#observation-form-error").textContent = confirmationError.message;
        if (status) {
          status.className = "submission-status error";
          status.textContent = "Envoi non confirmé. Vous pouvez réessayer sans créer de doublon.";
        }
        return;
      }
    }
    retrySuggested = !Number(error.status || 0);
    if (retrySuggested && !isEditing && enqueueOfflineObservation(body, selectedStudents)) {
      // Coupure réseau : le constat est conservé sur l'appareil avec sa clé
      // d'envoi, puis transmis automatiquement sans risque de doublon.
      observationSubmissionKey = null;
      selectedStudents = [];
      retrySuggested = false;
      showToast("Réseau indisponible : constat conservé sur cet appareil, envoi automatique à la reconnexion.");
      await renderNewObservation();
      return;
    }
    document.querySelector("#observation-form-error").textContent = error.message;
    if (status) {
      status.className = "submission-status error";
      status.textContent = retrySuggested
        ? "Connexion interrompue. Réessayez : le même envoi ne sera pas enregistré deux fois."
        : "Envoi refusé. Corrigez les informations indiquées puis réessayez.";
    }
  } finally {
    button.disabled = false;
    button.textContent = retrySuggested ? "Réessayer l’envoi" : buttonLabel;
  }
}

function createSubmissionKey() {
  if (window.crypto && typeof window.crypto.randomUUID === "function") {
    return window.crypto.randomUUID();
  }
  const random = window.crypto && typeof window.crypto.getRandomValues === "function"
    ? Array.from(window.crypto.getRandomValues(new Uint32Array(4)), (value) => value.toString(36)).join("")
    : `${Date.now().toString(36)}${Math.random().toString(36).slice(2)}`;
  return `obs_${random}`.slice(0, 64);
}

function offlineQueueKey() {
  const userId = Number(session?.user?.id || 0);
  return userId > 0 ? `suivi:offline-queue:v1:${userId}` : null;
}

function loadOfflineQueue() {
  const key = offlineQueueKey();
  if (!key) return [];
  let entries = [];
  try {
    entries = JSON.parse(localStorage.getItem(key) || "[]");
  } catch (_) {
    entries = [];
  }
  if (!Array.isArray(entries)) entries = [];
  const now = Date.now();
  const fresh = entries.filter((entry) => entry
    && entry.body
    && typeof entry.body.submission_key === "string"
    && now - Number(entry.captured_at || 0) < OFFLINE_QUEUE_TTL_MS);
  if (fresh.length !== entries.length) saveOfflineQueue(fresh);
  return fresh;
}

function saveOfflineQueue(entries) {
  const key = offlineQueueKey();
  if (!key) return;
  try {
    if (entries.length === 0) localStorage.removeItem(key);
    else localStorage.setItem(key, JSON.stringify(entries));
  } catch (_) {
    /* Stockage local indisponible : l'utilisateur garde le bouton Réessayer. */
  }
}

function enqueueOfflineObservation(body, students) {
  const key = offlineQueueKey();
  if (!key) return false;
  const entries = loadOfflineQueue();
  if (entries.length >= OFFLINE_QUEUE_LIMIT) return false;
  // Étiquette volontairement discrète : prénom et initiale seulement.
  const label = `${students.map((student) => `${student.first_name} ${String(student.last_name || "").charAt(0)}.`).join(", ")} — ${body.location}`;
  entries.push({ body, label, captured_at: Date.now() });
  try {
    localStorage.setItem(key, JSON.stringify(entries));
  } catch (_) {
    return false;
  }
  return true;
}

async function flushOfflineQueue(manual = false) {
  if (offlineFlushInProgress || !session?.authenticated) return;
  let entries = loadOfflineQueue();
  if (entries.length === 0) return;
  offlineFlushInProgress = true;
  let sent = 0;
  let capped = false;
  const rejected = [];
  try {
    while (entries.length > 0) {
      const entry = entries[0];
      const elapsedMinutes = Math.max(0, Math.round((Date.now() - Number(entry.captured_at || Date.now())) / 60000));
      const originalOffset = Number(entry.body.occurred_offset_minutes || 0);
      const adjustedOffset = Math.min(20, originalOffset + elapsedMinutes);
      try {
        await api("observations", {
          method: "POST",
          body: { ...entry.body, occurred_offset_minutes: adjustedOffset },
        });
        sent++;
        if (originalOffset + elapsedMinutes > 20) capped = true;
        entries.shift();
        saveOfflineQueue(entries);
      } catch (error) {
        const status = Number(error.status || 0);
        if (!status || status === 401 || status === 419 || status >= 500) {
          // Réseau toujours coupé, session à rétablir ou serveur en difficulté :
          // la file est conservée telle quelle pour un prochain essai.
          break;
        }
        // Refus définitif du serveur (constat similaire déjà présent, données
        // invalides…) : l'entrée est retirée et signalée, jamais forcée.
        rejected.push(`${entry.label} : ${error.message}`);
        entries.shift();
        saveOfflineQueue(entries);
      }
    }
  } finally {
    offlineFlushInProgress = false;
  }
  refreshOfflineQueueBanner();
  if (sent > 0) {
    showToast(`${sent > 1 ? `${sent} constats saisis` : "Constat saisi"} hors connexion transmis pour vérification.${capped ? " Heure du constat plafonnée à 20 minutes en arrière." : ""}`);
    refreshNavigationCounts();
  } else if (rejected.length > 0) {
    showToast(`Envoi différé abandonné — ${rejected[0]}`);
  } else if (manual) {
    showToast("Réseau toujours indisponible. La file sera renvoyée automatiquement.");
  }
  if (rejected.length > 0 && sent > 0) {
    window.setTimeout(() => showToast(`Envoi différé abandonné — ${rejected[0]}`), 3600);
  }
}

function renderOfflineQueueBanner() {
  const entries = loadOfflineQueue();
  if (entries.length === 0) return "";
  return `<section class="card offline-queue" role="status" aria-live="polite">
    <div class="offline-queue-head"><strong>${entries.length > 1 ? `${entries.length} constats en attente` : "1 constat en attente"} de réseau</strong><span>Conservés uniquement sur cet appareil (12 h maximum) et envoyés automatiquement dès la reconnexion, sans doublon.</span></div>
    <ul class="offline-queue-list">${entries.map((entry, index) => `<li><span>${escapeHtml(entry.label)}</span><time>${escapeHtml(new Date(Number(entry.captured_at)).toLocaleTimeString("fr-FR", { hour: "2-digit", minute: "2-digit" }))}</time><button type="button" class="button secondary small" data-offline-discard="${index}">Abandonner</button></li>`).join("")}</ul>
    <div class="offline-queue-actions"><button type="button" id="offline-send-now" class="button primary small">Envoyer maintenant</button></div>
  </section>`;
}

function bindOfflineQueueBanner() {
  const banner = document.querySelector("#offline-queue-banner");
  if (!banner) return;
  banner.querySelectorAll("[data-offline-discard]").forEach((button) => {
    button.addEventListener("click", () => {
      const entries = loadOfflineQueue();
      const index = Number(button.dataset.offlineDiscard);
      const entry = entries[index];
      if (!entry || !window.confirm(`Abandonner définitivement le constat hors connexion « ${entry.label} » ? Il ne sera jamais transmis.`)) return;
      entries.splice(index, 1);
      saveOfflineQueue(entries);
      refreshOfflineQueueBanner();
      showToast("Constat hors connexion abandonné.");
    });
  });
  const sendNow = banner.querySelector("#offline-send-now");
  if (sendNow) sendNow.addEventListener("click", () => flushOfflineQueue(true));
}

function refreshOfflineQueueBanner() {
  const banner = document.querySelector("#offline-queue-banner");
  if (!banner) return;
  banner.innerHTML = renderOfflineQueueBanner();
  bindOfflineQueueBanner();
}

function startEditingObservation(observation) {
  editingObservationId = Number(observation.id);
  selectedStudents = [{
    id: Number(observation.student_id),
    first_name: observation.first_name,
    last_name: observation.last_name,
    class_name: observation.class_name,
  }];
  document.querySelector("#location").value = observation.location;
  document.querySelector("#reason").value = observation.reason;
  document.querySelector("#details").value = observation.details || "";
  const occurrenceField = document.querySelector(".occurrence-fieldset");
  if (occurrenceField) occurrenceField.hidden = true;
  pageTitle.textContent = "Modifier mon signalement";
  document.querySelector("#submit-observation").textContent = "Enregistrer les modifications";
  document.querySelector("#cancel-edit").hidden = false;
  updateSelectedStudents();
  document.querySelector(".form-card").scrollIntoView({ behavior: "smooth", block: "start" });
}

async function withdrawObservation(observation) {
  const studentName = `${observation.first_name} ${observation.last_name}`;
  if (!window.confirm(`Retirer votre signalement concernant ${studentName} ?`)) return;
  try {
    await api("withdraw_own_observation", { method: "POST", body: { id: Number(observation.id) } });
    showToast("Signalement retiré.");
    await renderNewObservation();
    refreshNavigationCounts();
  } catch (error) {
    showToast(error.message);
  }
}

async function renderValidation() {
  const data = await api("pending_observations", { query: validationFilters });
  const totalPending = Number(data.total_pending ?? data.observations.length);
  const displayedPending = data.observations.length;
  session.pending_count = totalPending;
  renderNavigation();
  const filterData = data.filters || {};
  const levels = normaliseFilterValues(filterData.levels || data.levels || [], "level");
  const allClasses = normaliseFilterValues(filterData.classes || data.classes || [], "class_name");
  const availableClasses = validationFilters.level
    ? allClasses.filter((className) => classLevel(className) === validationFilters.level)
    : allClasses;
  if (validationFilters.class_name && !availableClasses.includes(validationFilters.class_name)) validationFilters.class_name = "";
  const locations = normaliseFilterValues(filterData.locations || data.locations || session.locations || [], "location");
  const pendingLabel = totalPending > displayedPending
    ? `${totalPending} en attente · ${displayedPending} premiers affichés`
    : `${totalPending} en attente`;
  app.innerHTML = `
    <section class="validation-filters" aria-label="Filtres de la file à vérifier">
      <div class="filter-heading"><div><strong>Affiner la file</strong><span>Plus anciens d’abord</span></div><span class="badge pending">${pendingLabel}</span></div>
      <div class="filter-controls">
        <label><span>Niveau</span><select id="validation-level" class="compact-select"><option value="">Tous les niveaux</option>${levels.map((value) => `<option value="${escapeHtml(value)}" ${validationFilters.level === value ? "selected" : ""}>Niveau ${escapeHtml(value)}e</option>`).join("")}</select></label>
        <label><span>Classe</span><select id="validation-class" class="compact-select"><option value="">${validationFilters.level ? `Toutes les classes de ${escapeHtml(validationFilters.level)}e` : "Toutes les classes"}</option>${availableClasses.map((value) => `<option value="${escapeHtml(value)}" ${validationFilters.class_name === value ? "selected" : ""}>${escapeHtml(value)}</option>`).join("")}</select></label>
        <label><span>Lieu</span><select id="validation-location" class="compact-select"><option value="">Tous les lieux</option>${locations.map((value) => `<option value="${escapeHtml(value)}" ${validationFilters.location === value ? "selected" : ""}>${escapeHtml(value)}</option>`).join("")}</select></label>
        <label><span>Ancienneté</span><select id="validation-age" class="compact-select"><option value="all" ${validationFilters.age === "all" ? "selected" : ""}>Toutes</option><option value="today" ${validationFilters.age === "today" ? "selected" : ""}>Aujourd’hui</option><option value="over24" ${validationFilters.age === "over24" ? "selected" : ""}>Plus de 24 h</option><option value="over48" ${validationFilters.age === "over48" ? "selected" : ""}>Plus de 48 h</option></select></label>
        <label><span>Parcours</span><select id="validation-path" class="compact-select"><option value="all" ${validationFilters.path === "all" ? "selected" : ""}>Tous</option><option value="with" ${validationFilters.path === "with" ? "selected" : ""}>Parcours possible</option><option value="without" ${validationFilters.path === "without" ? "selected" : ""}>Sans parcours rapproché</option></select></label>
      </div>
      <button id="validation-reset" class="filter-reset" type="button" ${Object.values(validationFilters).every((value) => !value || value === "all") ? "hidden" : ""}>Effacer les filtres</button>
    </section>
    <div class="validation-list">${data.observations.length ? data.observations.map(validationItem).join("") : emptyState("✓", "Aucun signalement en attente", "")}</div>`;
  bindValidationFilters();
  app.querySelectorAll("[data-decision]").forEach((button) => {
    button.addEventListener("click", () => decideObservation(Number(button.dataset.id), button.dataset.decision));
  });
  app.querySelectorAll("[data-confirm-path]").forEach((button) => {
    button.addEventListener("click", () => confirmObservationPath(Number(button.dataset.id), button));
  });
  app.querySelectorAll("[data-sequence-member]").forEach((checkbox) => {
    checkbox.addEventListener("change", () => updateSequenceSelection(Number(checkbox.dataset.anchor)));
  });
  app.querySelectorAll("[data-claim]").forEach((button) => {
    button.addEventListener("click", () => claimObservation(Number(button.dataset.claim), button.dataset.claimed !== "true", button));
  });
  app.querySelectorAll("[data-confirm-path]").forEach((button) => updateSequenceSelection(Number(button.dataset.id)));
}

function normaliseFilterValues(values, preferredKey = "") {
  const output = (Array.isArray(values) ? values : []).map((value) => {
    if (value && typeof value === "object") return value[preferredKey] ?? value.value ?? value.label ?? "";
    return value;
  }).map((value) => String(value || "").trim()).filter(Boolean);
  const unique = [...new Set(output)];
  if (preferredKey === "level") return unique.sort((left, right) => ["6", "5", "4", "3"].indexOf(left) - ["6", "5", "4", "3"].indexOf(right));
  return unique.sort((left, right) => left.localeCompare(right, "fr", { numeric: true }));
}

function bindValidationFilters() {
  const fields = [
    ["#validation-level", "level"],
    ["#validation-class", "class_name"],
    ["#validation-location", "location"],
    ["#validation-age", "age"],
    ["#validation-path", "path"],
  ];
  fields.forEach(([selector, key]) => document.querySelector(selector)?.addEventListener("change", async (event) => {
    validationFilters[key] = event.currentTarget.value;
    if (key === "level" && validationFilters.class_name && classLevel(validationFilters.class_name) !== validationFilters.level) validationFilters.class_name = "";
    await renderValidation();
  }));
  document.querySelector("#validation-reset")?.addEventListener("click", async () => {
    validationFilters = { level: "", class_name: "", location: "", age: "all", path: "all" };
    await renderValidation();
  });
}

function digitalPassContextHtml(context, compact = false) {
  if (!context || !context.destination || !context.issued_at || !context.expires_at) return "";
  const destination = escapeHtml(context.destination);
  const issuedAt = escapeHtml(formatTime(context.issued_at));
  const expiresAt = escapeHtml(formatTime(context.expires_at));
  if (compact) {
    return `<div class="sequence-pass-context"><span aria-hidden="true">↗</span><span>Billet numérique · ${destination} · ${issuedAt}–${expiresAt}</span></div>`;
  }
  return `<div class="observation-pass-context" role="note"><span class="pass-context-icon" aria-hidden="true">↗</span><div><strong>Billet numérique valable au moment du constat</strong><span>${destination} · de ${issuedAt} à ${expiresAt}</span></div></div>`;
}

function validationItem(item) {
  const cancellationOptions = session.cancellation_reasons.map((reason) => `<option value="${escapeHtml(reason)}">${escapeHtml(reason)}</option>`).join("");
  const nearby = Array.isArray(item.nearby_observations) ? item.nearby_observations : [];
  const timeline = [{
    id: item.id,
    occurred_at: item.occurred_at,
    location: item.location,
    reason: item.reason,
    details: item.details,
    status: item.status,
    reporter_first_name: item.reporter_first_name,
    reporter_last_name: item.reporter_last_name,
    digital_pass_context: item.digital_pass_context,
    current: true,
  }, ...nearby.map((observation) => ({ ...observation, current: false }))]
    .sort((left, right) => String(left.occurred_at).localeCompare(String(right.occurred_at)) || Number(left.id) - Number(right.id));
  const claimantId = Number(item.claimed_by_user_id || item.claimant_user_id || 0);
  const claimedByMe = Boolean(item.claimed_by_current_user) || (claimantId > 0 && claimantId === Number(session.user.id || 0));
  const claimedByOther = Boolean(item.claim_locked) || (claimantId > 0 && !claimedByMe);
  const claimantName = item.claimant_name || item.claimed_by_name || displayName(item.claimant_first_name || item.claimed_by_first_name, item.claimant_last_name || item.claimed_by_last_name) || "un autre membre de la vie scolaire";
  const claimControl = claimantId
    ? `<div class="claim-state ${claimedByMe ? "mine" : "other"}"><span>${claimedByMe ? "Vous traitez ce signalement" : `Pris en charge par ${escapeHtml(claimantName)}`}</span>${claimedByMe ? `<button class="button secondary small" type="button" data-claim="${item.id}" data-claimed="true">Libérer</button>` : ""}</div>`
    : `<button class="button secondary small claim-button" type="button" data-claim="${item.id}" data-claimed="false">Je prends en charge</button>`;
  const nearbyPanel = nearby.length ? `
    <details class="nearby-observations">
      <summary><span>Parcours observé</span><span class="badge neutral">${timeline.length} observations</span></summary>
      <p class="sequence-instruction">Cochez uniquement les observations qui appartiennent au même déplacement.</p>
      <ol class="sequence-timeline">${timeline.map((observation) => sequenceTimelineItem(observation, Number(item.id), claimedByOther)).join("")}</ol>
      <div class="sequence-actions">
        <span>Les observations non cochées resteront inchangées.</span>
        <button class="button success small" type="button" data-id="${item.id}" data-confirm-path disabled>Confirmer le parcours</button>
      </div>
    </details>` : "";
  const individualConfirm = item.sequence_linked
    ? ""
    : `<button class="button success small" type="button" data-id="${item.id}" data-decision="confirmed" ${claimedByOther ? "disabled" : ""}>Confirmer seulement ce constat</button>`;
  return `<article class="validation-item ${claimedByOther ? "claimed-by-other" : ""}"><div class="validation-main"><h3>${escapeHtml(item.first_name)} ${escapeHtml(item.last_name)} · ${escapeHtml(item.class_name)}</h3><p>${escapeHtml(item.reason)} — ${escapeHtml(item.location)}</p><div class="validation-meta"><span>${formatDate(item.occurred_at)}</span><span>Signalé par ${escapeHtml(displayName(item.reporter_first_name, item.reporter_last_name))}</span>${item.details ? `<span>${escapeHtml(item.details)}</span>` : ""}</div>${digitalPassContextHtml(item.digital_pass_context)}${claimControl}</div><div class="validation-actions"><select class="compact-select cancel-reason" data-cancel-reason="${item.id}" ${claimedByOther ? "disabled" : ""}><option value="">Motif si annulation…</option>${cancellationOptions}</select><div>${individualConfirm}<button class="button danger small" type="button" data-id="${item.id}" data-decision="cancelled" ${claimedByOther ? "disabled" : ""}>Annuler</button></div></div>${nearbyPanel}</article>`;
}

function sequenceTimelineItem(observation, anchorId, claimedByOther) {
  const reporter = displayName(observation.reporter_first_name, observation.reporter_last_name);
  const selectable = observation.current || ["pending", "confirmed"].includes(observation.status);
  const alreadyLinked = Boolean(observation.current || observation.same_sequence);
  return `<li class="sequence-event ${observation.current ? "current" : ""}" ${observation.current ? 'aria-current="true"' : ""}>
    <div class="sequence-time"><input type="checkbox" data-sequence-member="${Number(observation.id)}" data-anchor="${anchorId}" ${alreadyLinked ? "checked" : ""} ${alreadyLinked || !selectable || claimedByOther ? "disabled" : ""} aria-label="Inclure l’observation de ${formatDate(observation.occurred_at)}"><time datetime="${escapeHtml(String(observation.occurred_at).replace(" ", "T") + "Z")}">${formatDate(observation.occurred_at)}</time></div>
    <div class="sequence-event-body">
      <div class="sequence-event-heading"><strong>${escapeHtml(observation.location)}</strong>${statusBadge(observation.status)}</div>
      <span>${escapeHtml(observation.reason)}</span>
      <small>${reporter ? `Signalé par ${escapeHtml(reporter)}` : ""}${reporter && observation.details ? " · " : ""}${observation.details ? escapeHtml(observation.details) : ""}</small>
      ${digitalPassContextHtml(observation.digital_pass_context, true)}
    </div>
  </li>`;
}

function updateSequenceSelection(anchorId) {
  const button = document.querySelector(`[data-confirm-path][data-id="${anchorId}"]`);
  if (!button) return;
  const selectedIds = [...document.querySelectorAll(`[data-sequence-member][data-anchor="${anchorId}"]`)]
    .filter((checkbox) => checkbox.checked)
    .map((checkbox) => Number(checkbox.dataset.sequenceMember));
  if (!selectedIds.includes(anchorId)) selectedIds.unshift(anchorId);
  button.dataset.observationIds = selectedIds.join(",");
  button.disabled = selectedIds.length < 2 || Boolean(button.closest(".claimed-by-other"));
  button.textContent = selectedIds.length < 2
    ? "Sélectionnez au moins 2 observations"
    : `Confirmer le parcours — ${selectedIds.length} observations`;
}

async function confirmObservationPath(id, button) {
  const previousLabel = button.textContent;
  button.disabled = true;
  button.textContent = "Confirmation du parcours…";
  try {
    const observationIds = String(button.dataset.observationIds || "").split(",").map(Number).filter((value) => value > 0);
    if (observationIds.length < 2) {
      showToast("Sélectionnez au moins deux observations du même déplacement.");
      return;
    }
    const result = await api("observation_sequence", { method: "POST", body: { id, linked: true, observation_ids: observationIds } });
    const confirmedCount = Number(result.confirmed_count || 0);
    const pathCount = Number(result.path_count || result.count || 0);
    showToast(`Parcours confirmé : ${confirmedCount} observation${confirmedCount > 1 ? "s" : ""} traitée${confirmedCount > 1 ? "s" : ""}, 1 situation comptabilisée (${pathCount} passage${pathCount > 1 ? "s" : ""}).`);
    await renderValidation();
    refreshNavigationCounts();
  } catch (error) {
    button.disabled = false;
    button.textContent = previousLabel;
    showToast(error.message);
  }
}

async function claimObservation(id, claimed, button) {
  const previous = button.textContent;
  button.disabled = true;
  button.textContent = claimed ? "Prise en charge…" : "Libération…";
  try {
    await api("observation_claim", { method: "POST", body: { id, claimed } });
    showToast(claimed ? "Signalement pris en charge pendant 20 minutes." : "Signalement libéré.");
    await renderValidation();
  } catch (error) {
    button.disabled = false;
    button.textContent = previous;
    showToast(error.message);
  }
}

async function decideObservation(id, status) {
  const cancellationReason = status === "cancelled"
    ? document.querySelector(`[data-cancel-reason="${id}"]`).value
    : "";
  if (status === "cancelled" && !cancellationReason) {
    showToast("Choisissez d’abord le motif d’annulation.");
    return;
  }
  try {
    await api("observation_status", { method: "POST", body: { id, status, cancellation_reason: cancellationReason } });
    showToast(status === "confirmed" ? "Signalement confirmé." : "Signalement annulé.");
    await renderValidation();
    refreshNavigationCounts();
  } catch (error) {
    showToast(error.message);
  }
}

async function renderDigitalPasses() {
  selectedPassStudent = null;
  passSearchSequence++;
  if (passSearchController) passSearchController.abort();
  passSearchController = null;
  const data = await api("digital_passes");
  const passes = Array.isArray(data) ? data : (data.passes || data.digital_passes || []);
  const config = session.digital_passes || {};
  const canViewAllPasses = Boolean(session.permissions.can_validate);
  const destinations = Array.isArray(config.destinations) ? config.destinations : [];
  const durations = Array.isArray(config.durations) && config.durations.length ? config.durations : [5, 10, 15, 20, 30, 45, 60];
  app.innerHTML = `
    <div class="pass-layout">
      <section class="card pass-issue-card">
        <div class="card-header"><div><h3>Émettre un billet</h3><p>Autorisation temporaire, sans motif libre ni donnée sur l’appareil de l’élève.</p></div></div>
        <div class="card-body">
          <form id="pass-form" class="pass-form" novalidate>
            <div class="field full"><label for="pass-student-search">Élève</label><div class="student-picker"><span class="search-icon">⌕</span><input id="pass-student-search" class="input search-input" autocomplete="off" placeholder="Nom, prénom ou classe" role="combobox" aria-autocomplete="list" aria-controls="pass-autocomplete" aria-expanded="false"><div id="pass-autocomplete" class="autocomplete" role="listbox" aria-label="Résultats de recherche"></div></div><div id="pass-selected-student" class="selected-students" aria-live="polite"></div><p id="pass-student-error" class="field-error" role="alert"></p></div>
            <div class="field"><label for="pass-destination">Destination</label><select id="pass-destination" class="select" required><option value="">Choisir…</option>${destinations.map(optionHtml).join("")}</select></div>
            <div class="field"><label for="pass-duration">Durée</label><select id="pass-duration" class="select" required>${durations.map((duration) => `<option value="${Number(duration)}" ${Number(duration) === 15 ? "selected" : ""}>${Number(duration)} minutes</option>`).join("")}</select></div>
            <p id="pass-form-error" class="field-error form-wide-error" role="alert"></p>
            <div class="form-actions"><button class="button primary" type="submit">Créer le billet</button></div>
          </form>
        </div>
      </section>
      <section class="card active-passes-card">
        <div class="card-header"><div><h3>${canViewAllPasses ? "Billets actifs" : "Mes billets actifs"}</h3><p>${canViewAllPasses ? "Billets en cours dans le collège" : "Billets que vous avez émis"} · disparition automatique à l’expiration.</p></div><span class="badge neutral">${passes.length}</span></div>
        <div id="active-pass-list" class="active-pass-list">${renderActivePasses(passes)}</div>
      </section>
    </div>`;
  bindPassStudentSearch();
  document.querySelector("#pass-form").addEventListener("submit", issueDigitalPass);
  bindPassRevokeButtons();
  scheduleDigitalPassRefresh();
}

function scheduleDigitalPassRefresh() {
  clearTimeout(digitalPassRefreshTimer);
  digitalPassRefreshTimer = window.setTimeout(refreshDigitalPassList, 45000);
}

async function refreshDigitalPassList() {
  digitalPassRefreshTimer = null;
  if (currentView !== "passes" || document.hidden) {
    if (currentView === "passes") scheduleDigitalPassRefresh();
    return;
  }
  try {
    const data = await api("digital_passes");
    if (currentView !== "passes") return;
    const passes = Array.isArray(data) ? data : (data.passes || data.digital_passes || []);
    const list = document.querySelector("#active-pass-list");
    const badge = document.querySelector(".active-passes-card .badge");
    if (list) list.innerHTML = renderActivePasses(passes);
    if (badge) badge.textContent = String(passes.length);
    bindPassRevokeButtons();
  } catch (_) {
    // Une coupure passagère ne remplace pas la liste visible par une erreur.
  } finally {
    if (currentView === "passes") scheduleDigitalPassRefresh();
  }
}

function renderActivePasses(passes) {
  if (!passes.length) return emptyState("↗", "Aucun billet actif", "Les billets créés apparaîtront ici jusqu’à leur expiration.");
  return passes.map((pass) => {
    const studentFirst = pass.student_first_name || pass.first_name || "";
    const studentLast = pass.student_last_name || pass.last_name || "";
    const issuer = displayName(pass.issuer_first_name, pass.issuer_last_name) || pass.issuer_name || "Personnel";
    const canRevoke = Boolean(pass.can_revoke) || Boolean(session.permissions.can_validate)
      || ["direction", "admin"].includes(session.user.role)
      || Number(pass.issuer_user_id) === Number(session.user.id || 0);
    return `<article class="active-pass-row"><div class="pass-student"><span class="avatar">${escapeHtml(initials({ first_name: studentFirst, last_name: studentLast }))}</span><div><strong>${escapeHtml(studentFirst)} ${escapeHtml(studentLast)}</strong><span>${escapeHtml(pass.class_name || "")}</span></div></div><div class="pass-route"><strong>${escapeHtml(pass.destination || "Déplacement autorisé")}</strong><span>Jusqu’à ${escapeHtml(formatTime(pass.expires_at))} · par ${escapeHtml(issuer)}</span></div>${canRevoke ? `<button class="button danger small" type="button" data-revoke-pass="${Number(pass.id)}">Révoquer</button>` : ""}</article>`;
  }).join("");
}

function bindPassStudentSearch() {
  const input = document.querySelector("#pass-student-search");
  const results = document.querySelector("#pass-autocomplete");
  input.addEventListener("input", () => {
    clearTimeout(searchTimer);
    searchTimer = setTimeout(() => searchPassStudents(input.value, results), 220);
  });
  input.addEventListener("keydown", handlePassAutocompleteKeydown);
  input.addEventListener("blur", () => window.setTimeout(() => {
    if (!results.contains(document.activeElement)) closePassAutocomplete(input, results);
  }, 120));
}

async function searchPassStudents(query, container) {
  const normalizedQuery = query.trim();
  const input = document.querySelector("#pass-student-search");
  const sequence = ++passSearchSequence;
  if (passSearchController) passSearchController.abort();
  passSearchController = null;
  if (normalizedQuery.length < 2) {
    closePassAutocomplete(input, container);
    return;
  }
  passSearchController = new AbortController();
  try {
    const data = await api("students", { query: { q: normalizedQuery }, signal: passSearchController.signal });
    if (sequence !== passSearchSequence || !input || input.value.trim() !== normalizedQuery || !container.isConnected) return;
    container.innerHTML = data.students.length ? data.students.map((student, index) => `<button type="button" class="student-option" data-pass-student="${index}" role="option" aria-selected="false" tabindex="-1"><span class="avatar">${escapeHtml(initials(student))}</span><span><strong>${escapeHtml(student.first_name)} ${escapeHtml(student.last_name)}</strong><span>${escapeHtml(student.class_name)}</span>${studentActivePassHtml(student)}</span></button>`).join("") : `<div class="student-option muted" role="option" aria-disabled="true">Aucun élève trouvé</div>`;
    container.querySelectorAll("[data-pass-student]").forEach((button) => button.addEventListener("click", () => {
      selectedPassStudent = data.students[Number(button.dataset.passStudent)];
      input.value = "";
      closePassAutocomplete(input, container);
      renderSelectedPassStudent();
      document.querySelector("#pass-destination").focus();
    }));
    container.classList.add("open");
    input.setAttribute("aria-expanded", "true");
    activePassAutocompleteIndex = -1;
  } catch (error) {
    if (error.name !== "AbortError" && sequence === passSearchSequence) showToast(error.message);
  }
}

function closePassAutocomplete(input, container) {
  if (!input || !container) return;
  container.classList.remove("open");
  container.innerHTML = "";
  input.setAttribute("aria-expanded", "false");
  input.removeAttribute("aria-activedescendant");
  activePassAutocompleteIndex = -1;
}

function handlePassAutocompleteKeydown(event) {
  const input = event.currentTarget;
  const container = document.querySelector("#pass-autocomplete");
  const options = [...container.querySelectorAll("[role=option]:not([aria-disabled=true])")];
  if (event.key === "Escape") {
    if (container.classList.contains("open")) {
      event.preventDefault();
      closePassAutocomplete(input, container);
    }
    return;
  }
  if (!options.length || !["ArrowDown", "ArrowUp", "Enter"].includes(event.key)) return;
  if (event.key === "Enter") {
    if (activePassAutocompleteIndex >= 0) {
      event.preventDefault();
      options[activePassAutocompleteIndex].click();
    }
    return;
  }
  event.preventDefault();
  const direction = event.key === "ArrowDown" ? 1 : -1;
  activePassAutocompleteIndex = (activePassAutocompleteIndex + direction + options.length) % options.length;
  options.forEach((option, index) => option.setAttribute("aria-selected", String(index === activePassAutocompleteIndex)));
  const activeOption = options[activePassAutocompleteIndex];
  if (!activeOption.id) activeOption.id = `pass-option-${passSearchSequence}-${activePassAutocompleteIndex}`;
  input.setAttribute("aria-activedescendant", activeOption.id);
  activeOption.scrollIntoView({ block: "nearest" });
}

function renderSelectedPassStudent() {
  const target = document.querySelector("#pass-selected-student");
  if (!target) return;
  const submitButton = document.querySelector("#pass-form button[type=submit]");
  const errorTarget = document.querySelector("#pass-student-error");
  if (!selectedPassStudent) {
    target.innerHTML = "";
    if (submitButton) submitButton.disabled = false;
    if (errorTarget) errorTarget.textContent = "";
    return;
  }
  const activePass = activePassForStudent(selectedPassStudent);
  target.innerHTML = `<span class="selected-student visible student-chip"><span class="avatar">${escapeHtml(initials(selectedPassStudent))}</span><div><strong>${escapeHtml(selectedPassStudent.first_name)} ${escapeHtml(selectedPassStudent.last_name)}</strong> ${escapeHtml(selectedPassStudent.class_name)}${studentActivePassHtml(selectedPassStudent, true)}</div><button type="button" id="clear-pass-student" aria-label="Retirer cet élève">×</button></span>`;
  if (submitButton) submitButton.disabled = Boolean(activePass);
  if (errorTarget) {
    errorTarget.textContent = !activePass
      ? ""
      : (activePass.destination || activePass.expires_at)
        ? `Un billet est déjà actif vers ${activePass.destination || "la destination indiquée"}${activePass.expires_at ? ` jusqu’à ${formatTime(activePass.expires_at)}` : ""}.`
        : "Un billet est déjà actif pour cet élève.";
  }
  document.querySelector("#clear-pass-student").addEventListener("click", () => {
    selectedPassStudent = null;
    renderSelectedPassStudent();
    document.querySelector("#pass-student-search").focus();
  });
}

async function issueDigitalPass(event) {
  event.preventDefault();
  const errorTarget = document.querySelector("#pass-form-error");
  errorTarget.textContent = "";
  if (!selectedPassStudent) {
    document.querySelector("#pass-student-error").textContent = "Choisissez un élève dans la liste.";
    document.querySelector("#pass-student-search").focus();
    return;
  }
  if (activePassForStudent(selectedPassStudent)) {
    document.querySelector("#pass-student-error").textContent = "Cet élève possède déjà un billet actif.";
    return;
  }
  const destination = document.querySelector("#pass-destination").value;
  if (!destination) {
    errorTarget.textContent = "Choisissez une destination.";
    document.querySelector("#pass-destination").focus();
    return;
  }
  const button = event.currentTarget.querySelector("button[type=submit]");
  button.disabled = true;
  button.textContent = "Création…";
  try {
    await api("digital_pass_issue", { method: "POST", body: { student_id: Number(selectedPassStudent.id), destination, duration_minutes: Number(document.querySelector("#pass-duration").value) } });
    showToast("Billet créé.");
    await renderDigitalPasses();
  } catch (error) {
    errorTarget.textContent = error.message;
    button.disabled = false;
    button.textContent = "Créer le billet";
  }
}

function bindPassRevokeButtons() {
  app.querySelectorAll("[data-revoke-pass]").forEach((button) => button.addEventListener("click", async () => {
    if (!window.confirm("Révoquer ce billet avant son expiration ?")) return;
    button.disabled = true;
    try {
      await api("digital_pass_revoke", { method: "POST", body: { id: Number(button.dataset.revokePass) } });
      showToast("Billet révoqué.");
      await renderDigitalPasses();
    } catch (error) {
      button.disabled = false;
      showToast(error.message);
    }
  }));
}

async function renderDashboard() {
  const data = await api("dashboard");
  const confirmed = Number(data.totals.confirmed || 0);
  const pending = Number(data.totals.pending || 0);
  const studentCount = Number(data.totals.students || 0);
  const previousConfirmed = Number(data.totals.previous_confirmed || 0);
  const repetitionCount = Number(data.repetition_count ?? data.repetitions.filter((item) => Number(item.total) >= 2).length);
  const comparison = data.totals.comparison_percent === null ? null : Number(data.totals.comparison_percent);
  const maxLocation = Math.max(1, ...data.locations.map((row) => Number(row.total)));
  app.innerHTML = `
    <div class="comparison-banner"><strong>${comparison === null ? "Première période comparable" : `${comparison > 0 ? "+" : ""}${comparison}% par rapport à la semaine précédente`}</strong><span>${confirmed} situation(s) confirmée(s) cette semaine · ${previousConfirmed} la semaine précédente</span></div>
    <div class="stats-grid">
      ${statCard("Situations confirmées", confirmed, "sur les 7 derniers jours", "green")}
      ${statCard("À vérifier", pending, "sur les 7 derniers jours", "amber")}
      ${statCard("Élèves concernés", studentCount, "au moins une situation confirmée", "")}
      ${statCard("Répétitions", repetitionCount, "élèves avec au moins 2 situations", "")}
    </div>
    <div class="dashboard-grid">
      <section class="card chart-card"><div class="card-header"><div><h3>Lieux observés</h3><p>Passages confirmés, 7 derniers jours</p></div></div><div class="card-body chart-list">${data.locations.length ? data.locations.map((row) => `<div class="bar-row"><span class="bar-label">${escapeHtml(row.location)}</span><span class="bar-track"><span class="bar-fill ${widthPercentClass(Number(row.total) / maxLocation * 100, 5)}"></span></span><span class="bar-count">${Number(row.total)}</span></div>`).join("") : `<p class="muted">Aucune donnée confirmée.</p>`}</div></section>
      <section class="card table-card repetition-card"><div class="card-header"><div><h3>Parcours et situations répétées</h3><p>Ouvrir un élève pour voir la chronologie</p></div></div>${renderRepetitions(data.repetitions)}</section>
    </div>
    <section class="card heatmap-card"><div class="card-header"><div><h3>Lieux et créneaux</h3><p>Répartition des observations confirmées sur les 7 derniers jours</p></div></div>${renderHeatmap(data.heatmap)}</section>
    <section class="card heatmap-card hot-slots-card">
      <div class="card-header hot-slots-header"><div><h3>Créneaux chauds</h3><p>${Number(data.hot_period_days)} derniers jours</p></div>
        <label class="heatmap-filter" for="hot-location"><span>Lieu</span><select id="hot-location" class="compact-select"><option value="">Tous les lieux</option>${session.locations.map((location) => `<option value="${escapeHtml(location)}" ${dashboardLocation === location ? "selected" : ""}>${escapeHtml(location)}</option>`).join("")}</select></label>
      </div>
      <div id="hot-slots-grid">${renderHotSlots(data.hot_slots, dashboardLocation)}</div>
    </section>`;
  document.querySelector("#hot-location").addEventListener("change", (event) => {
    dashboardLocation = event.currentTarget.value;
    document.querySelector("#hot-slots-grid").innerHTML = renderHotSlots(data.hot_slots, dashboardLocation);
  });
}

function renderHeatmap(rows) {
  const slots = schoolTimeSlots();
  const locations = [...new Set(rows.map((row) => row.location))];
  const values = new Map(rows.map((row) => [`${row.location}|${row.time_slot}`, Number(row.total)]));
  if (!locations.length) return `<div class="card-body"><p class="muted">Aucune donnée confirmée sur cette période.</p></div>`;
  return `<div class="data-table-wrapper"><table class="data-table heatmap-table school-slots-table"><thead><tr><th>Lieu</th>${slots.map((slot) => `<th class="${slot.break ? "break-column" : ""}"><span class="slot-name">${slot.label}</span><span class="slot-time">${slot.time}</span></th>`).join("")}</tr></thead><tbody>${locations.map((location) => `<tr><td><strong>${escapeHtml(location)}</strong></td>${slots.map((slot) => { const count = values.get(`${location}|${slot.label}`) || 0; return `<td class="heat-cell heat-${heatLevel(count)} ${slot.break ? "break-column" : ""}">${count || "—"}</td>`; }).join("")}</tr>`).join("")}</tbody></table></div>${renderHeatLegend()}`;
}

function schoolTimeSlots() {
  return [
    { label: "Accueil", time: "avant 8h05" },
    { label: "M1", time: "8h05–9h03" },
    { label: "M2", time: "9h03–9h58" },
    { label: "Récréation matin", time: "9h58–10h17", break: true },
    { label: "M3", time: "10h17–11h15" },
    { label: "M4", time: "11h15–12h10" },
    { label: "Pause méridienne", time: "12h10–13h35", break: true },
    { label: "S1", time: "13h35–14h33" },
    { label: "S2", time: "14h33–15h28" },
    { label: "Récréation après-midi", time: "15h28–15h47", break: true },
    { label: "S3", time: "15h47–16h42" },
    { label: "S4", time: "16h42–17h30" },
  ];
}

function renderHotSlots(rows, locationFilter = "") {
  const slots = schoolTimeSlots();
  const days = [[1, "Lundi"], [2, "Mardi"], [3, "Mercredi"], [4, "Jeudi"], [5, "Vendredi"], [6, "Samedi"], [7, "Dimanche"]];
  const filteredRows = locationFilter ? rows.filter((row) => row.location === locationFilter) : rows;
  const values = new Map();
  filteredRows.forEach((row) => {
    const key = `${Number(row.day_number)}|${row.time_slot}`;
    values.set(key, (values.get(key) || 0) + Number(row.total));
  });
  if (!filteredRows.length) {
    return `<div class="card-body"><p class="muted">Aucune observation confirmée pour ce lieu sur cette période.</p></div>`;
  }
  return `<div class="data-table-wrapper"><table class="data-table heatmap-table hot-slots-table"><thead><tr><th>Jour</th>${slots.map((slot) => `<th class="${slot.break ? "break-column" : ""}"><span class="slot-name">${slot.label}</span><span class="slot-time">${slot.time}</span></th>`).join("")}</tr></thead><tbody>${days.map(([dayNumber, dayLabel]) => `<tr><td><strong>${dayLabel}</strong></td>${slots.map((slot) => { const count = values.get(`${dayNumber}|${slot.label}`) || 0; return `<td class="heat-cell heat-${heatLevel(count)} ${slot.break ? "break-column" : ""}" aria-label="${dayLabel}, ${slot.label} (${slot.time}) : ${count} observation${count > 1 ? "s" : ""}">${count || "—"}</td>`; }).join("")}</tr>`).join("")}</tbody></table></div>${renderHeatLegend()}`;
}

function heatLevel(count) {
  const value = Math.max(0, Number(count) || 0);
  if (value === 0) return 0;
  if (value === 1) return 1;
  if (value <= 3) return 2;
  if (value <= 5) return 4;
  return 5;
}

function renderHeatLegend() {
  return `<div class="heat-legend" aria-label="Légende de l’intensité"><span><i class="heat-1"></i>1</span><span><i class="heat-2"></i>2–3</span><span><i class="heat-4"></i>4–5</span><span><i class="heat-5"></i>6 et plus</span></div>`;
}

async function renderAnonymousReport() {
  const response = await api("anonymous_report", { query: { days: reportPeriodDays } });
  const data = response.report || response;
  currentAnonymousReport = data;
  const total = data.confirmed_total || { display: String(data.total || 0), suppressed: false };
  const previous = data.previous_period_total || { display: "—", suppressed: false };
  const change = data.change_percent === null || data.change_percent === undefined
    ? "Comparaison indisponible"
    : `${Number(data.change_percent) > 0 ? "+" : ""}${Number(data.change_percent).toLocaleString("fr-FR")}% par rapport à la période précédente`;
  app.innerHTML = `
    <div class="report-toolbar">
      <label for="report-period"><span>Période</span><select id="report-period" class="compact-select"><option value="7" ${reportPeriodDays === 7 ? "selected" : ""}>7 jours</option><option value="28" ${reportPeriodDays === 28 ? "selected" : ""}>28 jours</option><option value="90" ${reportPeriodDays === 90 ? "selected" : ""}>90 jours</option></select></label>
      <div><button id="report-export" class="button secondary" type="button">Exporter en CSV</button><button id="report-print" class="button primary" type="button">Imprimer / PDF</button></div>
    </div>
    <div id="anonymous-report-content" class="anonymous-report-content">
      <section class="report-summary" aria-labelledby="report-summary-title"><div><h2 id="report-summary-title">Synthèse du ${escapeHtml(formatDateOnly(data.period?.start_utc))} au ${escapeHtml(formatDateOnly(data.period?.end_utc))}</h2><p>Données confirmées · année ${escapeHtml(data.school_year || session.school_year)}</p></div><div class="report-total"><strong>${escapeHtml(total.display ?? "—")}</strong><span>observations confirmées</span></div><div class="report-comparison"><strong>${escapeHtml(change)}</strong><span>Période précédente : ${escapeHtml(previous.display ?? "—")}</span></div></section>
      <p class="report-privacy-note">Les cellules contenant moins de ${Number(data.privacy_threshold || 3)} observations sont affichées «&nbsp;&lt; ${Number(data.privacy_threshold || 3)}&nbsp;».</p>
      <div class="report-dimensions">
        ${renderAnonymousDimension("Par lieu", data.by_location || [])}
        ${renderAnonymousDimension("Par jour", data.by_weekday || [])}
        ${renderAnonymousDimension("Par créneau", data.by_school_slot || [])}
      </div>
      ${renderAnonymousEvolution(data.evolution || [])}
    </div>`;
  document.querySelector("#report-period").addEventListener("change", (event) => {
    reportPeriodDays = Number(event.currentTarget.value);
    renderAnonymousReport();
  });
  document.querySelector("#report-export").addEventListener("click", exportAnonymousReportCsv);
  document.querySelector("#report-print").addEventListener("click", printAnonymousReport);
}

function renderAnonymousDimension(title, rows) {
  return `<section class="report-dimension"><h3>${escapeHtml(title)}</h3>${rows.length ? `<div class="report-value-list">${rows.map((row) => `<div><span>${escapeHtml(row.label || row.dimension_value || "—")}</span><strong>${escapeHtml(row.display ?? (row.total ?? "—"))}</strong></div>`).join("")}</div>` : `<p class="muted">Aucune donnée sur cette période.</p>`}</section>`;
}

function renderAnonymousEvolution(rows) {
  if (!rows.length) return "";
  return `<section class="card report-evolution"><div class="card-header"><div><h3>Évolution quotidienne</h3><p>Valeurs agrégées, sans donnée nominative</p></div></div><div class="data-table-wrapper"><table class="data-table"><thead><tr><th>Date</th><th>Observations confirmées</th></tr></thead><tbody>${rows.map((row) => `<tr><td>${escapeHtml(formatDateOnly(row.date || row.label))}</td><td>${escapeHtml(row.display ?? (row.total ?? "—"))}</td></tr>`).join("")}</tbody></table></div></section>`;
}

function reportCsvRows(data) {
  const rows = [["Rapport anonymisé", data.school_year || session.school_year], ["Période", `${formatDateOnly(data.period?.start_utc)} - ${formatDateOnly(data.period?.end_utc)}`], ["Indicateur", "Valeur"]];
  rows.push(["Observations confirmées", data.confirmed_total?.display ?? "—"]);
  rows.push(["Période précédente", data.previous_period_total?.display ?? "—"]);
  [["Lieu", data.by_location], ["Jour", data.by_weekday], ["Créneau", data.by_school_slot]].forEach(([dimension, values]) => {
    (values || []).forEach((row) => rows.push([`${dimension} : ${row.label || "—"}`, row.display ?? (row.total ?? "—")]));
  });
  (data.evolution || []).forEach((row) => rows.push([`Date : ${formatDateOnly(row.date || row.label)}`, row.display ?? (row.total ?? "—")]));
  return rows;
}

function exportAnonymousReportCsv() {
  if (!currentAnonymousReport) return;
  const csv = reportCsvRows(currentAnonymousReport).map((row) => row.map(csvCell).join(";")).join("\r\n");
  const blob = new Blob(["\ufeff", csv], { type: "text/csv;charset=utf-8" });
  const url = URL.createObjectURL(blob);
  const link = document.createElement("a");
  link.href = url;
  link.download = `rapport-anonymise-${currentAnonymousReport.school_year || session.school_year}-${reportPeriodDays}j.csv`;
  document.body.appendChild(link);
  link.click();
  link.remove();
  window.setTimeout(() => URL.revokeObjectURL(url), 1000);
}

function csvCell(value) {
  const source = String(value ?? "");
  const text = /^[=+\-@]/.test(source) ? `'${source}` : source;
  return `"${text.replaceAll('"', '""')}"`;
}

function printAnonymousReport() {
  const source = document.querySelector("#anonymous-report-content");
  if (!source) return;
  const sheet = document.createElement("div");
  sheet.id = "report-sheet";
  sheet.className = "report-sheet";
  sheet.innerHTML = `<header><strong>Suivi des circulations</strong><span>Rapport anonymisé</span></header>${source.innerHTML}`;
  document.body.appendChild(sheet);
  window.print();
}

async function renderStudentHistory() {
  historySearchSequence++;
  if (historySearchController) historySearchController.abort();
  historySearchController = null;
  app.innerHTML = `
    <section class="card form-card form-card-plain history-search-card"><div class="card-body"><div class="field"><label for="history-search">Rechercher un élève</label><div class="student-picker"><span class="search-icon">⌕</span><input id="history-search" class="input search-input" autocomplete="off" placeholder="Nom, prénom ou classe" role="combobox" aria-autocomplete="list" aria-controls="history-autocomplete" aria-expanded="false"><div id="history-autocomplete" class="autocomplete" role="listbox" aria-label="Résultats de recherche"></div></div></div></div></section>
    <div id="history-result" class="history-result"></div>`;
  const input = document.querySelector("#history-search");
  const results = document.querySelector("#history-autocomplete");
  input.addEventListener("input", () => {
    clearTimeout(searchTimer);
    searchTimer = setTimeout(() => searchHistoryStudents(input.value, results), 220);
  });
  input.addEventListener("keydown", handleHistoryAutocompleteKeydown);
  input.addEventListener("blur", () => window.setTimeout(() => {
    if (!results.contains(document.activeElement)) closeHistoryAutocomplete(input, results);
  }, 120));
}

async function searchHistoryStudents(query, container) {
  const normalizedQuery = query.trim();
  const input = document.querySelector("#history-search");
  const requestSequence = ++historySearchSequence;
  if (historySearchController) historySearchController.abort();
  historySearchController = null;
  if (normalizedQuery.length < 2) {
    closeHistoryAutocomplete(input, container);
    return;
  }
  historySearchController = new AbortController();
  try {
    const data = await api("students", {
      query: { q: normalizedQuery },
      signal: historySearchController.signal,
    });
    if (requestSequence !== historySearchSequence
      || !input
      || input.value.trim() !== normalizedQuery
      || !container.isConnected) return;
    container.innerHTML = data.students.length ? data.students.map((student, index) => `<button id="history-option-${requestSequence}-${index}" type="button" class="student-option" data-history-index="${index}" role="option" aria-selected="false" tabindex="-1"><span class="avatar">${escapeHtml(initials(student))}</span><span><strong>${escapeHtml(student.first_name)} ${escapeHtml(student.last_name)}</strong><span>${escapeHtml(student.class_name)}</span></span></button>`).join("") : `<div class="student-option muted" role="option" aria-disabled="true">Aucun élève trouvé</div>`;
    container.classList.add("open");
    input.setAttribute("aria-expanded", "true");
    activeHistoryAutocompleteIndex = -1;
    container.querySelectorAll("[data-history-index]").forEach((button) => {
      button.addEventListener("click", () => {
        const student = data.students[Number(button.dataset.historyIndex)];
        input.value = `${student.first_name} ${student.last_name}`;
        closeHistoryAutocomplete(input, container);
        loadStudentHistory(student);
      });
    });
  } catch (error) {
    if (error.name === "AbortError" || requestSequence !== historySearchSequence) return;
    showToast(error.message);
  }
}

function closeHistoryAutocomplete(input = document.querySelector("#history-search"), container = document.querySelector("#history-autocomplete")) {
  if (!input || !container) return;
  container.classList.remove("open");
  container.innerHTML = "";
  input.setAttribute("aria-expanded", "false");
  input.removeAttribute("aria-activedescendant");
  activeHistoryAutocompleteIndex = -1;
}

function handleHistoryAutocompleteKeydown(event) {
  const input = event.currentTarget;
  const container = document.querySelector("#history-autocomplete");
  const options = [...container.querySelectorAll("[role=option]:not([aria-disabled=true])")];
  if (event.key === "Escape") {
    if (container.classList.contains("open")) {
      event.preventDefault();
      closeHistoryAutocomplete(input, container);
    }
    return;
  }
  if (!options.length || !["ArrowDown", "ArrowUp", "Enter"].includes(event.key)) return;
  if (event.key === "Enter") {
    if (activeHistoryAutocompleteIndex >= 0) {
      event.preventDefault();
      options[activeHistoryAutocompleteIndex].click();
    }
    return;
  }
  event.preventDefault();
  const direction = event.key === "ArrowDown" ? 1 : -1;
  activeHistoryAutocompleteIndex = (activeHistoryAutocompleteIndex + direction + options.length) % options.length;
  options.forEach((option, index) => option.setAttribute("aria-selected", String(index === activeHistoryAutocompleteIndex)));
  input.setAttribute("aria-activedescendant", options[activeHistoryAutocompleteIndex].id);
  options[activeHistoryAutocompleteIndex].scrollIntoView({ block: "nearest" });
}

async function loadStudentHistory(student) {
  const target = document.querySelector("#history-result");
  target.innerHTML = `<div class="empty-state"><div><span class="empty-icon">…</span><p>Chargement</p></div></div>`;
  try {
    const data = await api("student_history", { query: { student_id: student.id } });
    target.innerHTML = `<section class="card table-card"><div class="card-header"><div><h3>${escapeHtml(data.student.first_name)} ${escapeHtml(data.student.last_name)}</h3><p>${escapeHtml(data.student.class_name)} · uniquement les signalements confirmés</p></div><span class="badge neutral">${data.observations.length}</span></div>${renderHistoryTable(data.observations)}</section>`;
  } catch (error) {
    target.innerHTML = `<div class="error-card">${escapeHtml(error.message)}</div>`;
  }
}

function renderHistoryTable(rows) {
  if (!rows.length) return `<div class="card-body"><p class="muted">Aucun signalement confirmé pour cet élève.</p></div>`;
  return `<div class="data-table-wrapper"><table class="data-table"><thead><tr><th>Date</th><th>Lieu</th><th>Motif</th><th>Précision</th></tr></thead><tbody>${rows.map((row) => `<tr><td>${formatDate(row.occurred_at)}</td><td>${escapeHtml(row.location)}</td><td>${escapeHtml(row.reason)}</td><td>${escapeHtml(row.details || "—")}</td></tr>`).join("")}</tbody></table></div>`;
}

async function renderPpReport() {
  const data = await api("pp_report");
  app.innerHTML = `
    <div class="weekly-banner"><div><strong>Classe ${escapeHtml(data.class_name)}</strong><span>7 derniers jours · déclarant masqué</span></div><span class="badge neutral">${data.observations.length} observation(s)</span></div>
    <section class="card table-card">${renderObservationTable(data.observations)}</section>`;
}

function nextSchoolYear(schoolYear) {
  const match = /^(\d{4})-(\d{4})$/.exec(String(schoolYear || ""));
  if (!match) return schoolYear || "";
  return `${Number(match[1]) + 1}-${Number(match[2]) + 1}`;
}

function renderYearRolloverAssistant(activeSchoolYear, health = {}) {
  const suggestedYear = nextSchoolYear(activeSchoolYear);
  const hasStudents = Number(health.active_students || 0) > 0;
  return `<section class="card year-rollover-card">
    <div class="card-header"><div><h3>Passage à l’année suivante</h3><p>Un parcours guidé, sans modifier les anciennes données par surprise</p></div><span class="badge neutral">Année active : ${escapeHtml(activeSchoolYear)}</span></div>
    <div class="year-rollover-steps">
      <div class="year-rollover-step"><span>1</span><div><strong>Activer la nouvelle année</strong><p>À faire uniquement quand vous êtes prêt à importer sa liste d’élèves.</p><form id="school-year-form" class="inline-controls"><input id="school-year-input" class="input compact-input" value="${escapeHtml(suggestedYear)}" pattern="[0-9]{4}-[0-9]{4}" aria-label="Nouvelle année scolaire" required><button class="button secondary" type="submit">Activer ${escapeHtml(suggestedYear)}</button></form></div></div>
      <div class="year-rollover-step"><span>2</span><div><strong>Importer ou synchroniser les élèves</strong><p>${hasStudents ? `${Number(health.active_students)} élèves sont actuellement actifs. Vérifiez bien l’année affichée avant l’import.` : "Aucun élève actif : utilisez la synchronisation LDAP ou l’import CSV ci-dessous."}</p></div></div>
      <div class="year-rollover-step"><span>3</span><div><strong>Contrôler puis clôturer l’ancienne année</strong><p>La clôture reste séparée et demande un aperçu, votre mot de passe et une phrase de confirmation.</p></div></div>
    </div>
  </section>`;
}

async function renderAdmin() {
  const recoveryRequest = api("recovery_status").catch((error) => ({
    unavailable: true,
    error: error && error.message ? error.message : "Service de récupération indisponible.",
  }));
  const healthRequest = api("admin_health")
    .then((result) => result.health || result)
    .catch((error) => ({ unavailable: true, error: error.message }));
  const [data, audit, recovery, health] = await Promise.all([api("admin_users"), api("audit_logs"), recoveryRequest, healthRequest]);
  const classOptions = data.classes.map((value) => `<option value="${escapeHtml(value)}">${escapeHtml(value)}</option>`).join("");
  const pointsEnabled = !session.points || session.points.enabled !== false;
  const passesEnabled = Boolean(session.digital_passes && session.digital_passes.enabled);
  const auditRows = Array.isArray(audit.logs) ? audit.logs : [];
  const visibleAuditRows = filterAndSortAuditRows(auditRows, auditCategoryFilter, auditSortOrder);
  app.innerHTML = `
    ${renderAdminHealth(health)}
    <p class="section-note">Les comptes apparaissent après leur première connexion LDAP.</p>
    <div class="admin-grid">
      <section class="card"><div class="card-header"><div><h3>Comptes autorisés</h3><p>Les administrateurs gèrent les rôles ; une classe PP peut compléter n’importe quel rôle</p></div></div><div class="data-table-wrapper"><table class="data-table"><thead><tr><th>Compte</th><th>Rôle et classe PP</th><th>Actif</th><th></th></tr></thead><tbody>${data.users.map((user) => adminUserRow(user, classOptions)).join("")}</tbody></table></div></section>
      <div class="admin-side-stack">
        <section class="card"><div class="card-header"><div><h3>Module permis à points</h3><p>Fonction facultative, indépendante du suivi des circulations</p></div></div><div class="card-body"><div class="settings-toggle-row"><div><strong>${pointsEnabled ? "Module activé" : "Module désactivé"}</strong><p id="points-module-description">${pointsEnabled ? "La vue est visible selon les droits CPE, direction et PP." : "La vue est masquée pour tous. Les données déjà enregistrées sont conservées."}</p></div><button id="points-enabled-toggle" class="settings-switch" type="button" role="switch" aria-checked="${pointsEnabled}" aria-describedby="points-module-description"><span class="settings-switch-track" aria-hidden="true"><span class="settings-switch-thumb"></span></span><span class="settings-switch-label">${pointsEnabled ? "Désactiver" : "Activer"}</span></button></div><p id="points-module-feedback" class="field-error" role="alert"></p></div></section>
        <section class="card"><div class="card-header"><div><h3>Module billets numériques</h3><p>Autorisation temporaire de déplacement, sans QR code ni appareil élève</p></div></div><div class="card-body"><div class="settings-toggle-row"><div><strong>${passesEnabled ? "Module activé" : "Module désactivé"}</strong><p id="passes-module-description">${passesEnabled ? "Les personnels autorisés peuvent émettre et consulter les billets actifs." : "La vue et l’émission sont masquées. Les anciens billets restent dans le journal."}</p></div><button id="passes-enabled-toggle" class="settings-switch" type="button" role="switch" aria-checked="${passesEnabled}" aria-describedby="passes-module-description"><span class="settings-switch-track" aria-hidden="true"><span class="settings-switch-thumb"></span></span><span class="settings-switch-label">${passesEnabled ? "Désactiver" : "Activer"}</span></button></div><p id="passes-module-feedback" class="field-error" role="alert"></p></div></section>
        ${renderYearRolloverAssistant(data.active_school_year, health)}
        <section class="card"><div class="card-header"><div><h3>Accès hors groupes LDAP</h3><p>Préautoriser un compte avec son rôle, sa classe PP et une éventuelle date de fin</p></div></div><div class="card-body"><form id="authorized-user-form" class="access-form access-form-detailed"><input id="authorized-uid" class="input" placeholder="Identifiant Kwartz" required maxlength="64"><input id="authorized-label" class="input" placeholder="Fonction ou nom (facultatif)" maxlength="128"><select id="authorized-role" class="select" aria-label="Rôle attribué"><option value="teacher">Enseignant</option><option value="aed">AED</option><option value="cpe">CPE</option><option value="direction">Direction</option><option value="pp">Professeur principal</option><option value="service">Service médico-social</option></select><select id="authorized-pp-class" class="select" aria-label="Classe de professeur principal"><option value="">Aucune classe PP</option>${classOptions}</select><label class="access-expiry"><span>Fin d’accès (facultatif)</span><input id="authorized-expires" class="input" type="date"></label><button class="button primary" type="submit">Autoriser</button></form><div class="authorized-list">${renderAuthorizedUsers(data.authorized_users)}</div></div></section>
        <section class="card"><div class="card-header"><div><h3>Synchroniser les élèves depuis Kwartz</h3><p>Lecture directe des groupes-classes LDAP, avec aperçu obligatoire</p></div></div><div class="card-body"><div id="sync-preview" class="sync-preview muted" aria-live="polite">L’analyse ne modifie aucune donnée. Vous confirmerez seulement après avoir vérifié les effectifs par classe.</div><div class="form-actions sync-actions"><button id="sync-analyze" class="button secondary" type="button">Analyser l’annuaire</button><button id="sync-apply" class="button primary" type="button" hidden>Appliquer cette liste</button></div></div></section>
        <section class="card"><div class="card-header"><div><h3>Importer les élèves par CSV</h3><p>Solution de secours avec un export préparé depuis SIECLE, avec aperçu obligatoire</p></div></div><div class="card-body"><form id="import-form" class="upload-zone"><span class="empty-icon">⇧</span><h3>Fichier CSV</h3><p>Colonnes obligatoires : ID, NOM, PRENOM, CLASSE. Séparateur virgule ou point-virgule.</p><input id="students-file" name="students" type="file" accept=".csv,text/csv" required><label class="button secondary" for="students-file">Choisir un fichier</label><span id="file-name" class="muted">Aucun fichier</span><button id="csv-analyze" class="button primary" type="submit">Analyser le fichier</button></form><div id="csv-preview" class="sync-preview muted" aria-live="polite">L’analyse ne modifie aucune donnée. Vous vérifierez l’effectif et les classes avant d’appliquer le fichier.</div><div class="form-actions sync-actions"><button id="csv-apply" class="button primary" type="button" hidden>Appliquer pour ${escapeHtml(session.school_year)}</button></div></div></section>
      </div>
    </div>
    ${renderYearClosurePanel(data.school_years || [], data.active_school_year, data.closed_years || [])}
    <div id="recovery-admin-root">
      ${renderRecoverySection(recovery)}
      ${renderRecoveryDialogs(recovery)}
    </div>
    <section class="card audit-card">
      <div class="card-header"><div><h3>Journal des actions</h3><p>250 dernières opérations, sans mot de passe ni contenu détaillé des observations</p></div></div>
      <div class="audit-toolbar" role="group" aria-label="Filtrer et trier le journal des actions">
        <div class="audit-filter-field"><label for="audit-category-filter">Type d’action</label><select id="audit-category-filter" class="compact-select">${renderAuditCategoryOptions(auditRows)}</select></div>
        <div class="audit-filter-field"><label for="audit-sort-order">Ordre</label><select id="audit-sort-order" class="compact-select"><option value="newest" ${auditSortOrder === "newest" ? "selected" : ""}>Plus récentes d’abord</option><option value="oldest" ${auditSortOrder === "oldest" ? "selected" : ""}>Plus anciennes d’abord</option></select></div>
        <span id="audit-filter-count" class="audit-filter-count" aria-live="polite">${auditCountLabel(visibleAuditRows.length, auditRows.length)}</span>
      </div>
      <div id="audit-log-results">${renderAuditLogs(visibleAuditRows, "Aucune opération ne correspond à ce filtre.")}</div>
    </section>`;

  app.querySelectorAll("[data-save-user]").forEach((button) => {
    button.addEventListener("click", () => saveUser(Number(button.dataset.saveUser)));
  });
  document.querySelector("#points-enabled-toggle").addEventListener("click", (event) => togglePointsModule(event.currentTarget, pointsEnabled));
  document.querySelector("#passes-enabled-toggle").addEventListener("click", (event) => toggleDigitalPassModule(event.currentTarget, passesEnabled));
  const fileInput = document.querySelector("#students-file");
  const importForm = document.querySelector("#import-form");
  const csvPreview = document.querySelector("#csv-preview");
  const csvAnalyzeButton = document.querySelector("#csv-analyze");
  const csvApplyButton = document.querySelector("#csv-apply");
  let csvPreviewToken = "";
  fileInput.addEventListener("change", () => {
    document.querySelector("#file-name").textContent = fileInput.files[0] ? fileInput.files[0].name : "Aucun fichier";
    csvPreviewToken = "";
    csvApplyButton.hidden = true;
    csvPreview.classList.remove("sync-warning");
    csvPreview.textContent = "Analyse requise après chaque changement de fichier.";
  });
  importForm.addEventListener("submit", async (event) => {
    event.preventDefault();
    const file = fileInput.files[0];
    if (!file) return;
    csvPreviewToken = "";
    csvApplyButton.hidden = true;
    csvAnalyzeButton.disabled = true;
    csvAnalyzeButton.textContent = "Analyse en cours…";
    csvPreview.classList.remove("sync-warning");
    csvPreview.textContent = "Lecture et contrôle du fichier CSV…";
    try {
      const result = await requestStudentsImport(file, false, "");
      const classList = (result.classes || []).map((row) => `${escapeHtml(row.class_name)} (${Number(row.total)})`).join(" · ");
      const warningHtml = result.warning
        ? `<div class="sync-detail sync-alert"><strong>Import bloqué</strong><span>${escapeHtml(result.warning)}</span></div>`
        : "";
      csvPreview.innerHTML = `<div class="sync-summary"><strong>${Number(result.student_count)} élèves</strong><span>${Number(result.class_count)} classes · liste actuelle : ${Number(result.active_before)} élèves</span></div><p>${classList}</p>${warningHtml}`;
      csvPreview.classList.toggle("sync-warning", !result.safe_to_apply);
      if (result.safe_to_apply) {
        csvPreviewToken = String(result.preview_token || "");
        csvApplyButton.hidden = csvPreviewToken === "";
      }
    } catch (error) {
      csvPreview.classList.add("sync-warning");
      csvPreview.textContent = error.message;
      showToast(error.message);
    } finally {
      csvAnalyzeButton.disabled = false;
      csvAnalyzeButton.textContent = "Analyser à nouveau";
    }
  });
  csvApplyButton.addEventListener("click", async () => {
    const file = fileInput.files[0];
    if (!file || !csvPreviewToken || !window.confirm(`Remplacer la liste active de ${session.school_year} par cet aperçu CSV ? Une sauvegarde sera créée avant l’import lorsqu’elle est disponible.`)) return;
    csvApplyButton.disabled = true;
    csvApplyButton.textContent = "Import en cours…";
    try {
      const result = await requestStudentsImport(file, true, csvPreviewToken);
      const recoveryMessage = result.snapshot_id ? " Un point de récupération a été créé." : "";
      showToast(`${Number(result.row_count)} élèves importés dans ${Number(result.class_count)} classes.${recoveryMessage}`);
      await renderAdmin();
    } catch (error) {
      csvPreviewToken = "";
      csvApplyButton.hidden = true;
      csvPreview.classList.add("sync-warning");
      csvPreview.textContent = error.message;
      showToast(error.message);
    } finally {
      csvApplyButton.disabled = false;
      csvApplyButton.textContent = `Appliquer pour ${session.school_year}`;
    }
  });
  const analyzeButton = document.querySelector("#sync-analyze");
  const applyButton = document.querySelector("#sync-apply");
  const preview = document.querySelector("#sync-preview");
  let ldapPreviewToken = "";
  analyzeButton.addEventListener("click", async () => {
    ldapPreviewToken = "";
    applyButton.hidden = true;
    analyzeButton.disabled = true;
    analyzeButton.textContent = "Analyse en cours…";
    preview.classList.remove("sync-warning");
    preview.textContent = "Lecture des groupes-classes et des comptes élèves…";
    try {
      const result = await api("admin_sync_students", { method: "POST", body: {} });
      const classList = result.classes.map((row) => `${escapeHtml(row.class_name)} (${Number(row.total)})`).join(" · ");
      const conflictsHtml = (result.conflicts || []).length
        ? `<div class="sync-detail sync-alert"><strong>Appartenances multiples à vérifier dans Kwartz</strong>${result.conflicts.map((item) => `<span>${escapeHtml(item)}</span>`).join("")}</div>`
        : "";
      const suspiciousHtml = (result.suspicious || []).length
        ? `<div class="sync-detail"><strong>Très petits effectifs à vérifier</strong>${result.suspicious.map((row) => `<span>${escapeHtml(row.class_name)} : ${row.members.map(escapeHtml).join(", ")}</span>`).join("")}</div>`
        : "";
      const warningHtml = result.warning
        ? `<div class="sync-detail sync-alert"><strong>Synchronisation bloquée</strong><span>${escapeHtml(result.warning)}</span></div>`
        : "";
      preview.innerHTML = `<div class="sync-summary"><strong>${Number(result.student_count)} élèves</strong><span>${Number(result.class_count)} classes · liste actuelle : ${Number(result.active_before)} élèves${Number(result.skipped) ? ` · ${Number(result.skipped)} compte(s) ignoré(s)` : ""}</span></div><p>${classList}</p>${conflictsHtml}${suspiciousHtml}${warningHtml}`;
      preview.classList.toggle("sync-warning", !result.safe_to_apply);
      if (result.safe_to_apply) {
        ldapPreviewToken = String(result.preview_token || "");
        applyButton.hidden = ldapPreviewToken === "";
      }
    } catch (error) {
      preview.classList.add("sync-warning");
      preview.textContent = error.message;
      showToast(error.message);
    } finally {
      analyzeButton.disabled = false;
      analyzeButton.textContent = "Analyser à nouveau";
    }
  });
  applyButton.addEventListener("click", async () => {
    if (!ldapPreviewToken || !window.confirm(`Remplacer la liste active de ${session.school_year} par cet aperçu LDAP ? Les anciennes observations resteront archivées.`)) return;
    applyButton.disabled = true;
    applyButton.textContent = "Synchronisation…";
    try {
      const result = await api("admin_sync_students", { method: "POST", body: { apply: true, preview_token: ldapPreviewToken } });
      showToast(`${Number(result.row_count)} élèves synchronisés dans ${Number(result.class_count)} classes.`);
      await renderAdmin();
    } catch (error) {
      ldapPreviewToken = "";
      applyButton.hidden = true;
      preview.classList.add("sync-warning");
      preview.textContent = error.message;
      showToast(error.message);
    } finally {
      applyButton.disabled = false;
      applyButton.textContent = "Appliquer cette liste";
    }
  });
  const authorizedRole = document.querySelector("#authorized-role");
  const authorizedClass = document.querySelector("#authorized-pp-class");
  const syncAuthorizedClass = () => {
    const isPp = authorizedRole.value === "pp";
    authorizedClass.disabled = !isPp;
    if (!isPp) authorizedClass.value = "";
  };
  authorizedRole.addEventListener("change", syncAuthorizedClass);
  syncAuthorizedClass();
  document.querySelector("#authorized-user-form").addEventListener("submit", addAuthorizedUser);
  document.querySelectorAll("[data-remove-authorized]").forEach((button) => {
    button.addEventListener("click", () => removeAuthorizedUser(Number(button.dataset.removeAuthorized)));
  });
  document.querySelector("#school-year-form").addEventListener("submit", setSchoolYear);
  bindYearClosureControls();
  bindAuditLogControls(auditRows);
  bindRecoveryControls(recovery);
  startRecoveryRefresh(recovery);
}

function renderRecoverySection(status = {}) {
  if (status.unavailable) {
    return `<section class="card recovery-card" aria-labelledby="recovery-title"><div class="card-header recovery-heading"><div><h3 id="recovery-title">Points de récupération</h3><p>Protection locale des données élèves</p></div><span class="danger-label">Indisponible</span></div><div class="card-body"><div class="error-card"><strong>La récupération locale n’est pas disponible.</strong><p>${escapeHtml(status.error || "Réessayez dans quelques instants.")} Aucun bouton de purge ou de restauration n’est proposé tant que ce contrôle échoue.</p></div></div></section>`;
  }
  const environment = status.environment === "production" ? "production" : "test";
  const environmentLabel = environment === "production" ? "Production" : "Test";
  const retentionDays = Number(status.retention_days) || 7;
  const intervalMinutes = Number(status.interval_minutes) || 30;
  const storageBytes = Math.max(0, Number(status.storage_bytes) || 0);
  const storageLimitBytes = Math.max(1, Number(status.storage_limit_bytes) || (512 * 1024 * 1024));
  const snapshotCount = Math.max(0, Number(status.snapshot_count) || 0);
  const snapshots = Array.isArray(status.snapshots)
    ? [...status.snapshots].sort((left, right) => String(right.created_at || "").localeCompare(String(left.created_at || "")))
    : [];
  const latest = snapshots[0] || null;
  const purgePhrase = String(status.purge_confirmation || `VIDER ${environmentLabel.toUpperCase()} ${session.school_year || ""}`).trim();

  return `
    <section class="card recovery-card" aria-labelledby="recovery-title">
      <div class="card-header recovery-heading">
        <div><h3 id="recovery-title">Points de récupération</h3><p>Sauvegardes temporaires des données élèves de cette installation</p></div>
        <span class="recovery-environment ${environment}">${escapeHtml(environmentLabel)}</span>
      </div>
      <div class="card-body recovery-body">
        <div class="recovery-overview">
          <div class="recovery-latest">
            <span class="recovery-state-icon ${latest ? "ready" : "waiting"}" aria-hidden="true">${latest ? "✓" : "○"}</span>
            <div><strong>${latest ? `Dernier point créé le ${escapeHtml(formatDate(latest.created_at))}` : "Aucun point de récupération disponible"}</strong><span>${latest ? `${escapeHtml(recoverySnapshotKind(latest.kind))} · ${escapeHtml(formatRecoveryCounts(latest.counts))}` : "Créez un premier point avant toute opération importante."}</span></div>
          </div>
          <button id="recovery-create" class="button secondary" type="button">Créer maintenant</button>
        </div>
        <div class="recovery-facts" aria-label="Politique de récupération">
          <div><strong>${retentionDays} jours</strong><span>de conservation glissante</span></div>
          <div><strong>${intervalMinutes} minutes</strong><span>entre deux points automatiques</span></div>
          <div><strong>${escapeHtml(formatRecoveryCounts(status.counts))}</strong><span>données élèves actuelles</span></div>
          <div><strong>${escapeHtml(formatRecoverySize(storageBytes))} / ${escapeHtml(formatRecoverySize(storageLimitBytes))}</strong><span>${snapshotCount} point${snapshotCount > 1 ? "s" : ""} stocké${snapshotCount > 1 ? "s" : ""} dans MySQL</span></div>
        </div>
        <p class="recovery-explanation"><strong>Récupération locale :</strong> ces points restent dans cette même base MySQL ; ils ne remplacent pas une sauvegarde du serveur. Les points automatiques sont déclenchés par une session WebUI active, au maximum toutes les ${intervalMinutes} minutes. Si personne n’utilise l’application, aucun point n’est créé pendant cette période.</p>
        <div class="recovery-list-heading"><div><h4>Points récents</h4><p>La restauration remplace les élèves, observations, billets, points, actions, imports et clôtures annuelles. Elle conserve les utilisateurs, rôles, réglages et le journal d’audit.</p></div><span>${snapshots.length} disponible${snapshots.length > 1 ? "s" : ""}</span></div>
        ${snapshots.length ? `<div class="recovery-snapshot-list" role="list">${snapshots.slice(0, 30).map(renderRecoverySnapshot).join("")}</div>` : `<div class="recovery-empty"><span aria-hidden="true">↺</span><div><strong>Pas encore de sauvegarde</strong><p>Un point sera proposé avec l’activité de l’application, ou vous pouvez le créer maintenant.</p></div></div>`}
      </div>
    </section>
    <section class="card recovery-danger-zone" aria-labelledby="purge-zone-title">
      <div class="card-header"><div><h3 id="purge-zone-title">Vider les données élèves</h3><p>Opération exceptionnelle et réversible pendant ${retentionDays} jours</p></div><span class="danger-label">Zone dangereuse</span></div>
      <div class="card-body recovery-danger-body">
        <div><strong>Supprimer toutes les données élèves de cette installation</strong><p>Les élèves, observations, points, actions et imports seront retirés. Les comptes, rôles, réglages et journaux d’audit resteront intacts. Un point de récupération est créé juste avant la purge.</p></div>
        <button id="recovery-purge-open" class="button danger" type="button">Vider les données élèves</button>
      </div>
      <p class="recovery-danger-phrase">Confirmation demandée : <code>${escapeHtml(purgePhrase)}</code></p>
    </section>`;
}

function renderRecoverySnapshot(snapshot) {
  const id = String(snapshot.id || "");
  const schoolYear = snapshot.school_year ? ` · ${escapeHtml(snapshot.school_year)}` : "";
  const size = Number(snapshot.size_bytes) > 0 ? ` · ${escapeHtml(formatRecoverySize(snapshot.size_bytes))}` : "";
  return `<div class="recovery-snapshot" role="listitem"><div class="recovery-snapshot-main"><span class="recovery-snapshot-icon" aria-hidden="true">↺</span><div><strong>${escapeHtml(formatDate(snapshot.created_at))}</strong><span>${escapeHtml(recoverySnapshotKind(snapshot.kind))}${schoolYear}${size}</span><small>${escapeHtml(formatRecoveryCounts(snapshot.counts))} · identifiant ${escapeHtml(shortRecoveryId(id))}</small></div></div><button class="button secondary small" type="button" data-restore-snapshot="${escapeHtml(id)}">Restaurer</button></div>`;
}

function renderRecoveryDialogs(status = {}) {
  if (status.unavailable) return "";
  const environment = status.environment === "production" ? "production" : "test";
  const environmentLabel = environment === "production" ? "PRODUCTION" : "TEST";
  const purgePhrase = String(status.purge_confirmation || `VIDER ${environmentLabel} ${session.school_year || ""}`).trim();
  return `
    <dialog id="recovery-purge-dialog" class="recovery-dialog danger-dialog" aria-labelledby="recovery-purge-title" aria-describedby="recovery-purge-description">
      <form id="recovery-purge-form" novalidate>
        <header><div><span class="recovery-dialog-context ${environment}">${escapeHtml(environmentLabel)}</span><h2 id="recovery-purge-title">Vider les données élèves ?</h2></div><button class="icon-button" type="button" data-recovery-dialog-close aria-label="Fermer">×</button></header>
        <div class="recovery-dialog-content">
          <p id="recovery-purge-description">Cette opération supprime les élèves et toutes leurs données liées. Un point de récupération sera créé avant la suppression et restera restaurable pendant ${Number(status.retention_days) || 7} jours.</p>
          <div class="recovery-restore-target"><strong>Volumes actuellement concernés</strong><span>${escapeHtml(formatRecoveryCounts(status.counts))}</span></div>
          <div class="recovery-dialog-warning"><strong>Les nouvelles saisies effectuées après cette purge ne feront pas partie du point créé avant l’opération.</strong></div>
          <label for="recovery-purge-password">Votre mot de passe LDAP</label>
          <input id="recovery-purge-password" class="input" type="password" autocomplete="current-password" required maxlength="1024">
          <label for="recovery-purge-confirmation">Recopiez exactement la phrase suivante</label>
          <code class="recovery-confirmation-phrase" data-recovery-confirmation-display>${escapeHtml(purgePhrase)}</code>
          <input id="recovery-purge-confirmation" class="input confirmation-input" autocomplete="off" autocapitalize="characters" spellcheck="false" required aria-describedby="recovery-purge-feedback">
          <p id="recovery-purge-feedback" class="field-error recovery-dialog-feedback" role="alert" aria-live="assertive"></p>
        </div>
        <footer><button class="button secondary" type="button" data-recovery-dialog-close>Annuler</button><button class="button danger" type="submit" data-recovery-submit data-default-label="Vider définitivement" disabled>Vider définitivement</button></footer>
      </form>
    </dialog>
    <dialog id="recovery-restore-dialog" class="recovery-dialog" aria-labelledby="recovery-restore-title" aria-describedby="recovery-restore-description">
      <form id="recovery-restore-form" novalidate>
        <header><div><span class="recovery-dialog-context ${environment}">${escapeHtml(environmentLabel)}</span><h2 id="recovery-restore-title">Restaurer ce point ?</h2></div><button class="icon-button" type="button" data-recovery-dialog-close aria-label="Fermer">×</button></header>
        <div class="recovery-dialog-content">
          <p id="recovery-restore-description">La restauration remplace les élèves, observations, billets, points, actions, imports et clôtures annuelles. Les utilisateurs, rôles, réglages et journaux d’audit sont conservés.</p>
          <div class="recovery-restore-target" id="recovery-restore-target"></div>
          <div class="recovery-dialog-warning safe"><strong>Un nouveau point de récupération est créé avant la restauration.</strong> Vous pourrez ainsi revenir à l’état actuel si nécessaire.</div>
          <label for="recovery-restore-password">Votre mot de passe LDAP</label>
          <input id="recovery-restore-password" class="input" type="password" autocomplete="current-password" required maxlength="1024">
          <label for="recovery-restore-confirmation">Recopiez exactement la phrase suivante</label>
          <code class="recovery-confirmation-phrase" data-recovery-confirmation-display></code>
          <input id="recovery-restore-confirmation" class="input confirmation-input" autocomplete="off" autocapitalize="characters" spellcheck="false" required aria-describedby="recovery-restore-feedback">
          <p id="recovery-restore-feedback" class="field-error recovery-dialog-feedback" role="alert" aria-live="assertive"></p>
        </div>
        <footer><button class="button secondary" type="button" data-recovery-dialog-close>Annuler</button><button class="button danger" type="submit" data-recovery-submit data-default-label="Restaurer ce point" disabled>Restaurer ce point</button></footer>
      </form>
    </dialog>`;
}

function bindRecoveryControls(status = {}) {
  const createButton = document.querySelector("#recovery-create");
  const purgeDialog = document.querySelector("#recovery-purge-dialog");
  const restoreDialog = document.querySelector("#recovery-restore-dialog");
  if (!createButton || !purgeDialog || !restoreDialog) return;

  createButton.addEventListener("click", () => createRecoverySnapshot(createButton));
  document.querySelector("#recovery-purge-open").addEventListener("click", () => {
    openRecoveryDialog(purgeDialog, String(status.purge_confirmation || ""));
  });
  document.querySelectorAll("[data-restore-snapshot]").forEach((button) => {
    button.addEventListener("click", () => {
      const snapshotId = String(button.dataset.restoreSnapshot || "");
      const snapshot = (status.snapshots || []).find((item) => String(item.id) === snapshotId);
      const prefix = String(status.restore_confirmation_prefix || "RESTAURER").trim();
      const exactPhrase = `${prefix} ${snapshotId}`;
      restoreDialog.dataset.snapshotId = snapshotId;
      const target = restoreDialog.querySelector("#recovery-restore-target");
      target.innerHTML = snapshot
        ? `<strong>État du ${escapeHtml(formatDate(snapshot.created_at))}</strong><span>${escapeHtml(recoverySnapshotKind(snapshot.kind))} · ${escapeHtml(formatRecoveryCounts(snapshot.counts))}</span>`
        : `<strong>Point ${escapeHtml(shortRecoveryId(snapshotId))}</strong>`;
      openRecoveryDialog(restoreDialog, exactPhrase);
    });
  });

  [purgeDialog, restoreDialog].forEach((dialog) => {
    dialog.querySelectorAll("[data-recovery-dialog-close]").forEach((button) => button.addEventListener("click", () => {
      if (dialog.getAttribute("aria-busy") !== "true") dialog.close();
    }));
    dialog.querySelectorAll("input").forEach((input) => input.addEventListener("input", () => updateRecoveryDialogState(dialog)));
    dialog.addEventListener("cancel", (event) => {
      if (dialog.getAttribute("aria-busy") === "true") event.preventDefault();
    });
    dialog.addEventListener("close", () => resetRecoveryDialog(dialog));
  });
  document.querySelector("#recovery-purge-form").addEventListener("submit", submitStudentPurge);
  document.querySelector("#recovery-restore-form").addEventListener("submit", submitRecoveryRestore);
}

function openRecoveryDialog(dialog, exactPhrase) {
  resetRecoveryDialog(dialog);
  dialog.dataset.confirmation = exactPhrase;
  dialog.querySelector("[data-recovery-confirmation-display]").textContent = exactPhrase;
  updateRecoveryDialogState(dialog);
  dialog.showModal();
  window.requestAnimationFrame(() => dialog.querySelector('input[type="password"]').focus());
}

function resetRecoveryDialog(dialog) {
  const form = dialog.querySelector("form");
  if (form) form.reset();
  dialog.removeAttribute("aria-busy");
  dialog.querySelectorAll("[data-recovery-dialog-close]").forEach((button) => { button.disabled = false; });
  const feedback = dialog.querySelector(".recovery-dialog-feedback");
  if (feedback) feedback.textContent = "";
  dialog.querySelectorAll('[aria-invalid="true"]').forEach((input) => input.removeAttribute("aria-invalid"));
  const submit = dialog.querySelector("[data-recovery-submit]");
  if (submit) {
    submit.disabled = true;
    submit.textContent = submit.dataset.defaultLabel || submit.textContent;
  }
}

function updateRecoveryDialogState(dialog) {
  const password = dialog.querySelector('input[type="password"]');
  const confirmation = dialog.querySelector(".confirmation-input");
  const submit = dialog.querySelector("[data-recovery-submit]");
  if (!password || !confirmation || !submit) return;
  const confirmationMatches = confirmation.value === String(dialog.dataset.confirmation || "");
  submit.disabled = password.value.length === 0 || !confirmationMatches || dialog.getAttribute("aria-busy") === "true";
  if (password.value.length > 0) password.removeAttribute("aria-invalid");
  confirmation.setAttribute("aria-invalid", String(confirmation.value.length > 0 && !confirmationMatches));
}

async function createRecoverySnapshot(button) {
  const label = button.textContent;
  button.disabled = true;
  button.textContent = "Création…";
  try {
    await api("admin_create_snapshot", { method: "POST", body: {} });
    showToast("Point de récupération créé.");
    try {
      await renderAdmin();
    } catch (_) {
      showToast("Le point a bien été créé. Rechargez l’administration pour actualiser la liste.");
    }
  } catch (error) {
    showToast(error.message);
    if (button.isConnected) {
      button.disabled = false;
      button.textContent = label;
    }
  }
}

async function submitStudentPurge(event) {
  event.preventDefault();
  const dialog = event.currentTarget.closest("dialog");
  const password = dialog.querySelector('input[type="password"]');
  const confirmation = dialog.querySelector(".confirmation-input");
  const feedback = dialog.querySelector(".recovery-dialog-feedback");
  const submit = dialog.querySelector("[data-recovery-submit]");
  if (submit.disabled) return;
  const label = submit.textContent;
  dialog.setAttribute("aria-busy", "true");
  dialog.querySelectorAll("[data-recovery-dialog-close]").forEach((button) => { button.disabled = true; });
  submit.disabled = true;
  submit.textContent = "Suppression…";
  feedback.textContent = "";
  try {
    await api("admin_purge_students", { method: "POST", body: { password: password.value, confirmation: confirmation.value } });
    dialog.close();
    showToast("Données élèves vidées. Le point de récupération est conservé 7 jours.");
    try {
      await renderAdmin();
    } catch (_) {
      showToast("La purge est terminée. Rechargez l’administration pour actualiser l’écran.");
    }
  } catch (error) {
    feedback.textContent = error.message;
    password.value = "";
    if (error.status === 401) password.setAttribute("aria-invalid", "true");
    else password.removeAttribute("aria-invalid");
    dialog.removeAttribute("aria-busy");
    dialog.querySelectorAll("[data-recovery-dialog-close]").forEach((button) => { button.disabled = false; });
    submit.textContent = label;
    updateRecoveryDialogState(dialog);
    password.focus();
  }
}

async function submitRecoveryRestore(event) {
  event.preventDefault();
  const dialog = event.currentTarget.closest("dialog");
  const password = dialog.querySelector('input[type="password"]');
  const confirmation = dialog.querySelector(".confirmation-input");
  const feedback = dialog.querySelector(".recovery-dialog-feedback");
  const submit = dialog.querySelector("[data-recovery-submit]");
  if (submit.disabled) return;
  const label = submit.textContent;
  dialog.setAttribute("aria-busy", "true");
  dialog.querySelectorAll("[data-recovery-dialog-close]").forEach((button) => { button.disabled = true; });
  submit.disabled = true;
  submit.textContent = "Restauration…";
  feedback.textContent = "";
  try {
    await api("admin_restore_snapshot", { method: "POST", body: { snapshot_id: String(dialog.dataset.snapshotId || ""), password: password.value, confirmation: confirmation.value } });
    dialog.close();
    showToast("Point restauré. Un état de sécurité a été créé avant l’opération.");
    try {
      await renderAdmin();
    } catch (_) {
      showToast("La restauration est terminée. Rechargez l’administration pour actualiser l’écran.");
    }
  } catch (error) {
    feedback.textContent = error.message;
    password.value = "";
    if (error.status === 401) password.setAttribute("aria-invalid", "true");
    else password.removeAttribute("aria-invalid");
    dialog.removeAttribute("aria-busy");
    dialog.querySelectorAll("[data-recovery-dialog-close]").forEach((button) => { button.disabled = false; });
    submit.textContent = label;
    updateRecoveryDialogState(dialog);
    password.focus();
  }
}

function startRecoveryRefresh(status = {}) {
  clearInterval(recoveryRefreshTimer);
  const intervalMinutes = Math.min(1440, Math.max(1, Number(status.interval_minutes) || 30));
  recoveryRefreshTimer = window.setInterval(async () => {
    if (currentView !== "admin" || document.visibilityState !== "visible") return;
    try {
      const latest = await api("recovery_status");
      if (currentView !== "admin") return;
      const root = document.querySelector("#recovery-admin-root");
      if (!root) return;
      root.innerHTML = `${renderRecoverySection(latest)}${renderRecoveryDialogs(latest)}`;
      bindRecoveryControls(latest);
    } catch (_) {
      /* L’état déjà affiché reste disponible ; nouvel essai au prochain cycle. */
    }
  }, intervalMinutes * 60 * 1000);
}

function recoverySnapshotKind(kind) {
  const labels = {
    automatic: "Point automatique",
    manual: "Point manuel",
    before_purge: "Avant une purge",
    pre_purge: "Avant une purge",
    before_restore: "Avant une restauration",
    pre_restore: "Avant une restauration",
  };
  return labels[String(kind || "")] || "Point de récupération";
}

function formatRecoveryCounts(counts) {
  if (!counts || typeof counts !== "object") return "aucune donnée";
  const labels = {
    students: "élèves",
    observations: "observations",
    point_adjustments: "ajustements de points",
    action_records: "actions éducatives",
    points: "points",
    actions: "actions",
    student_imports: "imports",
    imports: "imports",
  };
  const values = Object.entries(counts)
    .filter(([, value]) => Number.isFinite(Number(value)))
    .map(([key, value]) => `${new Intl.NumberFormat("fr-FR").format(Number(value))} ${labels[key] || key}`);
  return values.join(" · ") || "aucune donnée";
}

function formatRecoverySize(bytes) {
  const value = Math.max(0, Number(bytes) || 0);
  if (value < 1024) return `${value} o`;
  if (value < 1024 * 1024) return `${new Intl.NumberFormat("fr-FR", { maximumFractionDigits: 1 }).format(value / 1024)} Ko`;
  return `${new Intl.NumberFormat("fr-FR", { maximumFractionDigits: 1 }).format(value / (1024 * 1024))} Mo`;
}

function shortRecoveryId(id) {
  const value = String(id || "");
  return value.length > 12 ? `…${value.slice(-10)}` : value;
}

async function togglePointsModule(button, currentlyEnabled) {
  const enabled = !currentlyEnabled;
  const confirmation = enabled
    ? "Activer le permis à points ? La vue redeviendra visible pour les personnels qui disposent des droits correspondants."
    : "Désactiver le permis à points ? La vue sera masquée pour tous, mais les observations et les données de points resteront conservées.";
  if (!window.confirm(confirmation)) return;
  const feedback = document.querySelector("#points-module-feedback");
  button.disabled = true;
  feedback.textContent = "";
  try {
    await api("admin_set_points_enabled", { method: "POST", body: { enabled } });
    session = await api("session");
    csrfToken = session.csrf_token;
    synchroniseServerClock(session.server_now_utc);
    updateAppVersion(session.app_version);
    updateEnvironmentBanner();
    renderNavigation();
    showToast(enabled ? "Permis à points activé." : "Permis à points désactivé. Les données sont conservées.");
    await renderAdmin();
  } catch (error) {
    feedback.textContent = error.message;
    button.disabled = false;
  }
}

async function toggleDigitalPassModule(button, currentlyEnabled) {
  const enabled = !currentlyEnabled;
  const confirmation = enabled
    ? "Activer les billets numériques ? Les personnels autorisés pourront créer des autorisations temporaires de déplacement."
    : "Désactiver les billets numériques ? La vue sera masquée et aucun nouveau billet ne pourra être créé.";
  if (!window.confirm(confirmation)) return;
  const feedback = document.querySelector("#passes-module-feedback");
  button.disabled = true;
  feedback.textContent = "";
  try {
    await api("admin_set_digital_passes_enabled", { method: "POST", body: { enabled } });
    session = await api("session");
    csrfToken = session.csrf_token;
    synchroniseServerClock(session.server_now_utc);
    updateAppVersion(session.app_version);
    updateEnvironmentBanner();
    renderNavigation();
    showToast(enabled ? "Billets numériques activés." : "Billets numériques désactivés.");
    await renderAdmin();
  } catch (error) {
    feedback.textContent = error.message;
    button.disabled = false;
  }
}

function renderAdminHealth(health) {
  if (!health || health.unavailable) return `<section class="card admin-health"><div class="card-header"><div><h3>Santé de l’application</h3><p>Indicateurs de fonctionnement</p></div><span class="badge cancelled">Indisponible</span></div><div class="card-body"><p class="muted">${escapeHtml(health?.error || "Impossible de charger les indicateurs.")}</p></div></section>`;
  const lastImport = health.last_import?.created_at ? formatDate(health.last_import.created_at) : "Jamais";
  const lastSync = health.last_ldap_sync?.created_at ? formatDate(health.last_ldap_sync.created_at) : "Jamais";
  const lastBackup = health.last_backup?.created_at ? formatDate(health.last_backup.created_at) : "Aucun";
  const lastConnection = health.last_connection?.last_login_at ? formatDate(health.last_connection.last_login_at) : "Aucune";
  const pendingOld = Number(health.pending_over_24h || 0);
  const inactive = Number(health.inactive_accounts_count || 0);
  const installedVersion = health.app_version || session?.app_version || "Indisponible";
  const services = health.services || {};
  const serviceRows = [
    ["MySQL", services.mysql],
    ["Annuaire LDAP", services.ldap],
    ["Dossier var", services.storage],
    ["Récupération", services.recovery],
  ];
  const serviceWarning = serviceRows.some(([, service]) => !service || service.ok !== true);
  const needsAttention = serviceWarning || pendingOld > 0 || inactive > 0;
  return `<section class="card admin-health">
    <div class="card-header"><div><h3>État du système</h3><p>Disponibilité des services et repères d’administration</p></div><span class="badge ${needsAttention ? "pending" : "confirmed"}">${needsAttention ? "À examiner" : "Opérationnel"}</span></div>
    <div class="service-health-list">${serviceRows.map(([label, service]) => renderServiceHealth(label, service)).join("")}</div>
    <div class="admin-health-grid"><div><strong>v${escapeHtml(installedVersion)}</strong><span>version installée</span></div><div><strong>${Number(health.active_students || 0)}</strong><span>élèves actifs</span></div><div><strong>${Number(health.active_classes || 0)}</strong><span>classes actives</span></div><div class="health-date"><strong>${escapeHtml(lastImport)}</strong><span>dernier import CSV</span></div><div class="health-date"><strong>${escapeHtml(lastSync)}</strong><span>dernière synchro LDAP</span></div><div class="health-date"><strong>${escapeHtml(lastBackup)}</strong><span>dernier point de récupération</span></div><div class="health-date"><strong>${escapeHtml(lastConnection)}</strong><span>dernière connexion</span></div><div class="${pendingOld ? "health-warning" : ""}"><strong>${pendingOld}</strong><span>signalements de plus de 24 h</span></div><div class="${inactive ? "health-warning" : ""}"><strong>${inactive}</strong><span>comptes inactifs depuis 90 jours ou jamais utilisés</span></div></div>
    ${inactive && Array.isArray(health.inactive_accounts) ? `<details class="health-accounts"><summary>Voir les comptes à examiner</summary><div>${health.inactive_accounts.slice(0, 30).map((account) => `<span><strong>${escapeHtml(displayName(account.first_name, account.last_name) || account.uid || account.ldap_uid)}</strong> · ${escapeHtml(roleLabels[account.role] || account.role || "")}</span>`).join("")}</div></details>` : ""}
  </section>`;
}

function renderServiceHealth(label, service = {}) {
  const ok = service && service.ok === true;
  const latency = Number.isFinite(Number(service?.latency_ms)) && service.latency_ms !== null
    ? ` · ${Number(service.latency_ms)} ms`
    : "";
  return `<div class="service-health-row ${ok ? "ok" : "warning"}"><span class="service-health-icon" aria-hidden="true">${ok ? "✓" : "!"}</span><div><strong>${escapeHtml(label)}</strong><span>${escapeHtml(service?.message || "Contrôle indisponible")}${escapeHtml(latency)}</span></div><span class="badge ${ok ? "confirmed" : "pending"}">${ok ? "OK" : "À vérifier"}</span></div>`;
}

function renderYearClosurePanel(schoolYears, activeSchoolYear, closedYears = []) {
  const closed = new Set(closedYears.map((value) => String(value.school_year || value)));
  const previousYears = normaliseFilterValues(schoolYears.map((value) => value.school_year || value)).filter((year) => year !== activeSchoolYear && !closed.has(year));
  return `<section class="card year-closure-card"><div class="card-header"><div><h3>Clôture d’une ancienne année</h3><p>Conserve uniquement des totaux anonymisés puis supprime les données élèves de l’année choisie</p></div><span class="danger-label">Action critique</span></div><div class="card-body">${previousYears.length ? `<div class="closure-selector"><label for="closure-year"><span>Année à clôturer</span><select id="closure-year" class="select"><option value="">Choisir une ancienne année…</option>${previousYears.map(optionHtml).join("")}</select></label><button id="closure-preview-button" class="button secondary" type="button">Afficher l’aperçu</button></div><div id="closure-preview" class="closure-preview muted" aria-live="polite">Aucune donnée ne sera modifiée avant la confirmation finale.</div>` : `<p class="muted">Aucune ancienne année contenant des données n’est disponible. Activez d’abord la nouvelle année scolaire.</p>`}</div></section>`;
}

function bindYearClosureControls() {
  const previewButton = document.querySelector("#closure-preview-button");
  if (!previewButton) return;
  document.querySelector("#closure-year").addEventListener("change", () => {
    const target = document.querySelector("#closure-preview");
    target.classList.add("muted");
    target.textContent = "Aucune donnée ne sera modifiée avant la confirmation finale.";
    previewButton.textContent = "Afficher l’aperçu";
  });
  previewButton.addEventListener("click", async () => {
    const schoolYear = document.querySelector("#closure-year").value;
    const target = document.querySelector("#closure-preview");
    if (!schoolYear) {
      target.textContent = "Choisissez une ancienne année scolaire.";
      return;
    }
    previewButton.disabled = true;
    previewButton.textContent = "Analyse…";
    try {
      const response = await api("admin_year_closure_preview", { query: { school_year: schoolYear } });
      const preview = response.preview || response;
      target.classList.remove("muted");
      target.innerHTML = renderYearClosurePreview(preview);
      document.querySelector("#year-closure-form").addEventListener("submit", closeSchoolYear);
    } catch (error) {
      target.textContent = error.message;
    } finally {
      previewButton.disabled = false;
      previewButton.textContent = "Actualiser l’aperçu";
    }
  });
}

function renderYearClosurePreview(preview) {
  const counts = preview.counts || preview;
  const schoolYear = preview.school_year || document.querySelector("#closure-year")?.value || "";
  const phrase = `CLOTURER ${schoolYear}`;
  return `<div class="closure-counts"><span><strong>${Number(counts.students || 0)}</strong> élèves</span><span><strong>${Number(counts.observations || 0)}</strong> observations</span><span><strong>${Number(counts.point_adjustments || 0)}</strong> ajustements de points</span><span><strong>${Number(counts.digital_passes || 0)}</strong> billets</span></div><p>Un point de récupération sera créé avant la clôture et conservé selon la durée configurée.</p><form id="year-closure-form" class="closure-confirm-form"><input type="hidden" name="school_year" value="${escapeHtml(schoolYear)}"><label><span>Mot de passe Kwartz</span><input class="input" type="password" name="password" autocomplete="current-password" required></label><label><span>Recopiez <strong>${escapeHtml(phrase)}</strong></span><input class="input" name="confirmation" autocomplete="off" required data-expected="${escapeHtml(phrase)}"></label><button class="button danger" type="submit">Clôturer définitivement ${escapeHtml(schoolYear)}</button><p class="field-error" data-closure-error role="alert"></p></form>`;
}

async function closeSchoolYear(event) {
  event.preventDefault();
  const form = event.currentTarget;
  const data = new FormData(form);
  const confirmation = String(data.get("confirmation") || "").trim();
  const expected = form.querySelector("[data-expected]").dataset.expected;
  const errorTarget = form.querySelector("[data-closure-error]");
  if (confirmation !== expected) {
    errorTarget.textContent = `Recopiez exactement « ${expected} ».`;
    return;
  }
  if (!window.confirm("Cette action supprimera définitivement les données nominatives de cette année. Continuer ?")) return;
  const button = form.querySelector("button[type=submit]");
  button.disabled = true;
  button.textContent = "Clôture en cours…";
  try {
    await api("admin_close_year", { method: "POST", body: { school_year: data.get("school_year"), password: data.get("password"), confirmation } });
    showToast("Année clôturée. Les agrégats anonymisés sont conservés.");
    await renderAdmin();
  } catch (error) {
    errorTarget.textContent = error.message;
    button.disabled = false;
    button.textContent = `Clôturer définitivement ${data.get("school_year")}`;
  }
}

function renderAuthorizedUsers(rows) {
  if (!rows.length) return `<p class="muted">Aucun accès individuel supplémentaire.</p>`;
  return rows.map((row) => {
    const role = row.preassigned_role || row.role || "teacher";
    const ppClass = row.preassigned_pp_class || row.pp_class || "";
    const expiry = row.access_expires_at || row.expires_at || "";
    return `<div class="authorized-row ${Number(row.active) ? "" : "inactive"}"><div><strong>${escapeHtml(row.ldap_uid)}</strong><span>${escapeHtml(row.label || "Sans libellé")} · ${escapeHtml(roleLabels[role] || role)}${ppClass ? ` · PP ${escapeHtml(ppClass)}` : ""}${expiry ? ` · jusqu’au ${escapeHtml(formatDateOnly(expiry))}` : ""}</span></div>${Number(row.active) ? `<button class="button danger small" type="button" data-remove-authorized="${row.id}">Retirer</button>` : `<span class="badge cancelled">Retiré</span>`}</div>`;
  }).join("");
}

async function addAuthorizedUser(event) {
  event.preventDefault();
  try {
    await api("admin_add_authorized_user", { method: "POST", body: {
      uid: document.querySelector("#authorized-uid").value,
      label: document.querySelector("#authorized-label").value,
      role: document.querySelector("#authorized-role").value,
      pp_class: document.querySelector("#authorized-pp-class").value,
      access_expires_at: document.querySelector("#authorized-expires").value,
    } });
    showToast("Identifiant autorisé. Il peut maintenant se connecter.");
    await renderAdmin();
  } catch (error) {
    showToast(error.message);
  }
}

async function removeAuthorizedUser(id) {
  if (!window.confirm("Retirer cette autorisation individuelle ?")) return;
  try {
    await api("admin_remove_authorized_user", { method: "POST", body: { id } });
    showToast("Autorisation retirée.");
    await renderAdmin();
  } catch (error) {
    showToast(error.message);
  }
}

async function setSchoolYear(event) {
  event.preventDefault();
  const schoolYear = document.querySelector("#school-year-input").value.trim();
  if (!window.confirm(`Activer l’année scolaire ${schoolYear} ? Les anciennes données resteront conservées.`)) return;
  try {
    await api("admin_set_school_year", { method: "POST", body: { school_year: schoolYear } });
    session = await api("session");
    csrfToken = session.csrf_token;
    synchroniseServerClock(session.server_now_utc);
    updateAppVersion(session.app_version);
    document.querySelector("#school-year").textContent = session.school_year;
    showToast(`Année ${schoolYear} activée. Importez maintenant son annuaire élèves.`);
    await renderAdmin();
  } catch (error) {
    showToast(error.message);
  }
}

function auditCategoryForAction(action) {
  const value = String(action || "");
  if (value.startsWith("auth.")) return "auth";
  if (value.startsWith("observation.")) return "observations";
  if (value.startsWith("students.")) return "students";
  if (value.startsWith("user.") || value.startsWith("access.")) return "accounts";
  if (value.startsWith("points.")) return "points";
  if (value.startsWith("digital_pass.")) return "passes";
  if (value.startsWith("recovery.")) return "recovery";
  if (value.startsWith("school_year.")) return "settings";
  return "other";
}

function renderAuditCategoryOptions(rows) {
  const counts = rows.reduce((result, row) => {
    const category = auditCategoryForAction(row.action);
    result[category] = (result[category] || 0) + 1;
    return result;
  }, {});
  return auditCategoryDefinitions.map((category) => {
    const count = category.value === "all" ? rows.length : Number(counts[category.value] || 0);
    const selected = category.value === auditCategoryFilter ? "selected" : "";
    return `<option value="${category.value}" ${selected}>${escapeHtml(category.label)} (${count})</option>`;
  }).join("");
}

function filterAndSortAuditRows(rows, category, order) {
  const filtered = category === "all" ? [...rows] : rows.filter((row) => auditCategoryForAction(row.action) === category);
  const direction = order === "oldest" ? 1 : -1;
  return filtered.sort((left, right) => {
    const dateComparison = String(left.created_at || "").localeCompare(String(right.created_at || ""));
    if (dateComparison !== 0) return dateComparison * direction;
    return ((Number(left.id) || 0) - (Number(right.id) || 0)) * direction;
  });
}

function auditCountLabel(visibleCount, totalCount) {
  return `${visibleCount} sur ${totalCount} opération${totalCount === 1 ? "" : "s"}`;
}

function bindAuditLogControls(rows) {
  const categorySelect = document.querySelector("#audit-category-filter");
  const orderSelect = document.querySelector("#audit-sort-order");
  const results = document.querySelector("#audit-log-results");
  const count = document.querySelector("#audit-filter-count");
  if (!categorySelect || !orderSelect || !results || !count) return;

  const update = () => {
    auditCategoryFilter = categorySelect.value;
    auditSortOrder = orderSelect.value;
    const visibleRows = filterAndSortAuditRows(rows, auditCategoryFilter, auditSortOrder);
    results.innerHTML = renderAuditLogs(visibleRows, "Aucune opération ne correspond à ce filtre.");
    count.textContent = auditCountLabel(visibleRows.length, rows.length);
  };

  categorySelect.addEventListener("change", update);
  orderSelect.addEventListener("change", update);
}

function renderAuditLogs(rows, emptyMessage = "Aucune action journalisée.") {
  if (!rows.length) return `<div class="card-body"><p class="muted">${escapeHtml(emptyMessage)}</p></div>`;
  const labels = {
    "auth.login": "Connexion", "auth.logout": "Déconnexion", "observation.create": "Signalement créé",
    "observation.update": "Signalement modifié", "observation.withdraw": "Signalement retiré",
    "observation.confirmed": "Signalement confirmé", "observation.cancelled": "Signalement annulé",
    "observation.claim": "Signalement pris en charge", "observation.release": "Prise en charge libérée",
    "observation.sequence_link": "Observations liées", "observation.sequence_unlink": "Séquence dissociée", "observation.sequence_confirm": "Parcours confirmé",
    "user.update": "Droits modifiés", "students.import": "Élèves importés", "students.ldap_sync": "Élèves synchronisés depuis LDAP",
    "access.authorize": "Accès autorisé", "access.revoke": "Accès retiré", "school_year.change": "Année scolaire changée", "school_year.close": "Année scolaire clôturée",
    "points.restore": "Point rendu", "points.action": "Action éducative enregistrée", "points.export": "Permis exporté", "points.module_toggle": "Module permis à points modifié",
    "digital_pass.issue": "Billet numérique créé", "digital_pass.revoke": "Billet numérique révoqué", "digital_pass.module_toggle": "Module billets numériques modifié",
    "recovery.snapshot_manual": "Point de récupération créé", "recovery.purge": "Données élèves vidées", "recovery.restore": "Point de récupération restauré",
  };
  return `<div class="data-table-wrapper"><table class="data-table"><thead><tr><th>Date</th><th>Utilisateur</th><th>Action</th><th>Informations</th></tr></thead><tbody>${rows.map((row) => `<tr><td>${formatDate(row.created_at)}</td><td>${escapeHtml(displayName(row.first_name, row.last_name) || row.ldap_uid || "Système")}</td><td>${escapeHtml(labels[row.action] || row.action)}</td><td class="audit-metadata">${escapeHtml(formatAuditMetadata(row.metadata))}</td></tr>`).join("")}</tbody></table></div>`;
}

function formatAuditMetadata(metadata) {
  if (!metadata || typeof metadata !== "object") return "—";
  return Object.entries(metadata).filter(([, value]) => value !== null && value !== "").map(([key, value]) => `${key}: ${String(value)}`).join(" · ") || "—";
}

function adminUserRow(user, classOptions) {
  const fixedAdmin = user.role === "admin";
  const roleEntries = fixedAdmin
    ? [["admin", roleLabels.admin]]
    : Object.entries(roleLabels).filter(([value]) => value !== "admin");
  const roles = roleEntries.map(([value, label]) => `<option value="${value}" ${user.role === value ? "selected" : ""}>${escapeHtml(label)}</option>`).join("");
  const selectedClassOptions = user.pp_class
    ? classOptions.replace(`value="${escapeHtml(user.pp_class)}"`, `value="${escapeHtml(user.pp_class)}" selected`)
    : classOptions;
  return `<tr data-user-row="${user.id}"><td class="student-cell"><strong>${escapeHtml(displayName(user.first_name, user.last_name) || user.ldap_uid)}</strong><span>${escapeHtml(user.ldap_uid)}${user.email ? ` · ${escapeHtml(user.email)}` : ""}${fixedAdmin ? " · compte administrateur initial" : ""}</span></td><td><div class="inline-controls"><select class="compact-select user-role-select" ${fixedAdmin ? "disabled" : ""}>${roles}</select><select class="compact-select user-class-select" ${fixedAdmin ? "disabled" : ""}><option value="">Classe PP…</option>${selectedClassOptions}</select></div></td><td><input class="user-active" type="checkbox" ${Number(user.active) ? "checked" : ""} ${fixedAdmin ? "disabled" : ""} aria-label="Compte actif"></td><td><button class="button secondary small" type="button" data-save-user="${user.id}" ${fixedAdmin ? "disabled" : ""}>Enregistrer</button></td></tr>`;
}

async function saveUser(id) {
  const row = document.querySelector(`[data-user-row="${id}"]`);
  try {
    await api("admin_update_user", {
      method: "POST",
      body: {
        id,
        role: row.querySelector(".user-role-select").value,
        pp_class: row.querySelector(".user-class-select").value,
        active: row.querySelector(".user-active").checked,
      },
    });
    showToast("Droits enregistrés.");
    await renderAdmin();
  } catch (error) {
    showToast(error.message);
  }
}

async function requestStudentsImport(file, apply, previewToken) {
  const formData = new FormData();
  formData.append("students", file);
  formData.append("apply", apply ? "1" : "0");
  if (apply) formData.append("preview_token", previewToken);
  return api("import_students", { method: "POST", formData });
}

function renderAbout() {
  const pointsEnabled = !session.points || session.points.enabled !== false;
  const passesEnabled = Boolean(session.digital_passes && session.digital_passes.enabled);
  app.innerHTML = `
    <section class="card form-card form-card-plain pilot-summary"><div class="card-body"><dl class="admin-detail-list"><div><dt>Finalité</dt><dd>Repérer les circulations à vérifier et mieux organiser la présence adulte</dd></div><div><dt>Validation</dt><dd>Chaque signalement est confirmé ou annulé par la vie scolaire</dd></div><div><dt>Accès</dt><dd>Authentification Kwartz et droits attribués selon le rôle</dd></div><div><dt>Permis à points</dt><dd>${pointsEnabled ? "Module activé, avec décision humaine" : "Module désactivé"}</dd></div><div><dt>Billets numériques</dt><dd>${passesEnabled ? "Module activé, autorisations temporaires" : "Module désactivé"}</dd></div><div><dt>Données</dt><dd>Aucune donnée élève n’est conservée hors ligne</dd></div><div><dt>Conservation</dt><dd>Année scolaire en cours</dd></div></dl></div></section>`;
}

function renderRecent(rows) {
  if (!rows.length) return `<p class="muted">Aucun signalement enregistré.</p>`;
  return rows.map((item) => `<div class="recent-row"><div><strong>${escapeHtml(item.first_name)} ${escapeHtml(item.last_name)} · ${escapeHtml(item.class_name)}</strong><span>${formatDate(item.occurred_at)} · ${escapeHtml(item.location)} · ${escapeHtml(item.reason)}${item.cancellation_reason ? ` · ${escapeHtml(item.cancellation_reason)}` : ""}</span></div><div class="recent-actions">${statusBadge(item.status)}${item.status === "pending" ? `<button class="button secondary small" type="button" data-edit-observation="${item.id}">Modifier</button><button class="button danger small" type="button" data-withdraw-observation="${item.id}">Retirer</button>` : ""}</div></div>`).join("");
}

function renderObservationTable(rows) {
  if (!rows.length) return `<div class="card-body"><p class="muted">Aucune observation confirmée sur cette période.</p></div>`;
  return `<div class="data-table-wrapper"><table class="data-table"><thead><tr><th>Date</th><th>Élève</th><th>Lieu</th><th>Motif</th><th>Précision</th></tr></thead><tbody>${rows.map((item) => `<tr><td>${formatDate(item.occurred_at)}</td><td class="student-cell"><strong>${escapeHtml(item.first_name)} ${escapeHtml(item.last_name)}</strong><span>${escapeHtml(item.class_name)}</span></td><td>${escapeHtml(item.location)}</td><td>${escapeHtml(item.reason)}</td><td>${escapeHtml(item.details || "—")}</td></tr>`).join("")}</tbody></table></div>`;
}

function renderRepetitions(rows) {
  if (!rows.length) return `<div class="card-body"><p class="muted">Aucun parcours ni aucune situation répétée sur cette période.</p></div>`;
  return `<div class="repetition-list">${rows.map((item) => {
    const situationCount = Number(item.total || 0);
    const observationCount = Number(item.observation_total || 0);
    const situations = Array.isArray(item.situations) ? item.situations : [];
    return `<details class="repetition-item">
      <summary>
        <span class="repetition-student"><strong>${escapeHtml(item.first_name)} ${escapeHtml(item.last_name)}</strong><small>${escapeHtml(item.class_name)}</small></span>
        <span class="repetition-counts"><b>${situationCount}</b> situation${situationCount > 1 ? "s" : ""}<small>${observationCount} observation${observationCount > 1 ? "s" : ""}</small></span>
        <span class="repetition-toggle">Voir le parcours</span>
      </summary>
      <div class="repetition-detail">${situations.map(renderRepetitionSituation).join("")}</div>
    </details>`;
  }).join("")}</div>`;
}

function renderRepetitionSituation(situation, index) {
  const observations = Array.isArray(situation.observations) ? situation.observations : [];
  const isPath = observations.length > 1;
  const heading = isPath ? `Parcours · ${observations.length} observations` : `Situation ${index + 1}`;
  return `<section class="repetition-situation">
    <header><strong>${heading}</strong><span>${formatDate(situation.started_at)}</span></header>
    <ol class="sequence-timeline">${observations.map(repetitionTimelineItem).join("")}</ol>
  </section>`;
}

function repetitionTimelineItem(observation) {
  const reporter = displayName(observation.reporter_first_name, observation.reporter_last_name);
  return `<li class="sequence-event repetition-event">
    <time datetime="${escapeHtml(String(observation.occurred_at).replace(" ", "T") + "Z")}">${formatDate(observation.occurred_at)}</time>
    <div class="sequence-event-body">
      <div class="sequence-event-heading"><strong>${escapeHtml(observation.location)}</strong></div>
      <span>${escapeHtml(observation.reason)}</span>
      <small>${reporter ? `Signalé par ${escapeHtml(reporter)}` : ""}${reporter && observation.details ? " · " : ""}${observation.details ? escapeHtml(observation.details) : ""}</small>
    </div>
  </li>`;
}

function statCard(label, value, detail, color) {
  return `<article class="stat-card"><div class="stat-label"><span>${escapeHtml(label)}</span><span class="status-dot ${color}"></span></div><div class="stat-value">${Number(value)}</div><div class="stat-detail">${escapeHtml(detail)}</div></article>`;
}

function statusBadge(status) {
  const labels = { pending: "À vérifier", confirmed: "Confirmé", cancelled: "Annulé", withdrawn: "Retiré" };
  return `<span class="badge ${escapeHtml(status)}">${labels[status] || escapeHtml(status)}</span>`;
}

function emptyState(icon, title, text) {
  return `<div class="empty-state"><div><span class="empty-icon">${icon}</span><h3>${escapeHtml(title)}</h3>${text ? `<p>${escapeHtml(text)}</p>` : ""}</div></div>`;
}

function widthPercentClass(value, minimum = 0) {
  const normalized = Math.min(100, Math.max(minimum, Number(value) || 0));
  return `width-${Math.ceil(normalized / 5) * 5}`;
}

function optionHtml(value) {
  return `<option value="${escapeHtml(value)}">${escapeHtml(value)}</option>`;
}

function displayUser(user) {
  return displayName(user.first_name, user.last_name) || user.uid;
}

function displayName(firstName, lastName) {
  return `${firstName || ""} ${lastName || ""}`.trim();
}

function initials(student) {
  return `${(student.first_name || "")[0] || ""}${(student.last_name || "")[0] || ""}`.toUpperCase();
}

function formatDate(value) {
  const date = parseUtcDate(value);
  if (Number.isNaN(date.getTime())) return value;
  return new Intl.DateTimeFormat("fr-FR", {
    day: "2-digit",
    month: "short",
    hour: "2-digit",
    minute: "2-digit",
    timeZone: "Europe/Paris",
  }).format(date);
}

function formatTime(value) {
  const date = parseUtcDate(value);
  if (Number.isNaN(date.getTime())) return String(value || "");
  return new Intl.DateTimeFormat("fr-FR", {
    hour: "2-digit",
    minute: "2-digit",
    timeZone: "Europe/Paris",
  }).format(date);
}

function formatDateOnly(value) {
  const date = parseUtcDate(value);
  if (Number.isNaN(date.getTime())) return String(value || "");
  return new Intl.DateTimeFormat("fr-FR", {
    day: "2-digit",
    month: "long",
    year: "numeric",
    timeZone: "Europe/Paris",
  }).format(date);
}

function parseUtcDate(value) {
  const source = String(value || "").trim();
  if (!source) return new Date(NaN);
  if (/^\d{4}-\d{2}-\d{2}$/.test(source)) return new Date(`${source}T00:00:00Z`);
  const normalized = source.includes("T") ? source : source.replace(" ", "T");
  const hasTimezone = /(?:Z|[+-]\d{2}:?\d{2})$/i.test(normalized);
  return new Date(hasTimezone ? normalized : `${normalized}Z`);
}

function escapeHtml(value = "") {
  return String(value)
    .replaceAll("&", "&amp;")
    .replaceAll("<", "&lt;")
    .replaceAll(">", "&gt;")
    .replaceAll('"', "&quot;")
    .replaceAll("'", "&#039;");
}

function showToast(message) {
  clearTimeout(toastTimer);
  toast.textContent = message;
  toast.classList.add("show");
  toastTimer = setTimeout(() => toast.classList.remove("show"), 3200);
}

let pointsTrimester = 0;
let pointsSearchFilter = "";
let pointsLevelFilter = "";
let pointsClassFilter = "";

async function renderPoints() {
  const query = pointsTrimester ? { t: pointsTrimester } : {};
  const data = await api("points", { query });
  pointsTrimester = data.trimester;
  session.alert_count = Number(data.totals.alert) + Number(data.totals.zero);
  renderNavigation();
  const bareme = session.points || { capital: data.capital, alert_threshold: data.alert_threshold, trimesters: [] };
  const trimesterOptions = (bareme.trimesters || []).map((item, index) => `<option value="${index + 1}" ${data.trimester === index + 1 ? "selected" : ""}>${escapeHtml(item.label)} (${item.start.slice(8, 10)}/${item.start.slice(5, 7)} → ${item.end.slice(8, 10)}/${item.end.slice(5, 7)})</option>`).join("");
  const classes = [...new Set(data.students.map((row) => row.class_name))].sort();
  const levels = [...new Set(classes.map(classLevel).filter(Boolean))].sort().reverse();
  if (data.scope_class) {
    pointsLevelFilter = "";
    pointsClassFilter = "";
  } else {
    if (!levels.includes(pointsLevelFilter)) pointsLevelFilter = "";
    if (!classes.includes(pointsClassFilter)
        || (pointsLevelFilter && classLevel(pointsClassFilter) !== pointsLevelFilter)) {
      pointsClassFilter = "";
    }
  }
  const filteredClassOptions = pointsLevelFilter
    ? classes.filter((className) => classLevel(className) === pointsLevelFilter)
    : classes;
  app.innerHTML = `
    <div class="page-intro"><div><h2>${data.scope_class ? `Permis à points — classe ${escapeHtml(data.scope_class)}` : "Permis à points de l’établissement"}</h2><p>Seules les situations <strong>confirmées</strong> retirent un point. Plusieurs observations d’un même parcours ne comptent qu’une fois.</p></div>
      <button id="points-export" class="button secondary" type="button">Exporter toute la période</button></div>
    <div class="points-bareme">Capital <b>${Number(data.capital)} points</b> par trimestre <span class="sep">·</span> <b>−1 point</b> par situation confirmée <span class="sep">·</span> <b>+1 point</b> possible sur décision CPE <span class="sep">·</span> alerte à <b>≤ ${Number(data.alert_threshold)}</b><span class="bareme-note">Barème et seuils configurables</span></div>
    <div class="stats-grid">
      ${statCard("Situations confirmées", data.totals.confirmed, `trimestre ${data.trimester} (${data.window_start.slice(8, 10)}/${data.window_start.slice(5, 7)} → ${data.window_end.slice(8, 10)}/${data.window_end.slice(5, 7)})`, "green")}
      ${statCard("Points rendus", data.totals.restored, "évolutions positives valorisées", "green")}
      ${statCard("Élèves en alerte", Number(data.totals.alert) + Number(data.totals.zero), `capital ≤ ${Number(data.alert_threshold)} ou épuisé`, "amber")}
      ${statCard("Actions à suivre", data.totals.actions, "seuils franchis non traités", "red")}
    </div>
    <section class="card table-card">
      <div class="card-header points-table-header"><div class="points-table-heading"><h3>Capital par élève</h3><p>Tri : points restants croissants — les situations prioritaires en premier</p></div>
      <div class="points-filter-toolbar" role="search" aria-label="Filtrer les élèves">
        <label class="points-filter-control points-filter-search" for="points-filter"><span>Rechercher</span><input id="points-filter" class="input compact-input" type="search" value="${escapeHtml(pointsSearchFilter)}" placeholder="Nom, prénom ou classe…" autocomplete="off"></label>
        ${data.scope_class ? "" : `<label class="points-filter-control" for="points-level"><span>Niveau</span><select id="points-level" class="compact-select"><option value="">Tous les niveaux</option>${levels.map((value) => `<option value="${escapeHtml(value)}" ${pointsLevelFilter === value ? "selected" : ""}>Niveau ${escapeHtml(value)}e</option>`).join("")}</select></label><label class="points-filter-control" for="points-class"><span>Classe</span><select id="points-class" class="compact-select"><option value="">${pointsLevelFilter ? `Toutes les classes de ${escapeHtml(pointsLevelFilter)}e` : "Toutes les classes"}</option>${filteredClassOptions.map((value) => `<option value="${escapeHtml(value)}" ${pointsClassFilter === value ? "selected" : ""}>${escapeHtml(value)}</option>`).join("")}</select></label>`}
        <label class="points-filter-control points-filter-period" for="points-trimester"><span>Période</span><select id="points-trimester" class="compact-select">${trimesterOptions}</select></label>
      </div></div>
      <div class="points-filter-status"><span id="points-result-count" aria-live="polite"></span><button id="points-filter-reset" class="filter-reset" type="button" hidden>Effacer les filtres</button></div>
      <div class="data-table-wrapper"><table class="data-table"><thead><tr><th>Élève</th><th>Capital restant</th><th>Points</th><th>Situations confirmées</th><th>En attente</th><th>Rendus</th><th>Actions</th><th>Dernière confirmée</th></tr></thead><tbody id="points-body"></tbody></table></div>
      <div class="points-legende"><span class="lg-green">Situation normale</span><span class="lg-amber">Alerte (≤ ${Number(data.alert_threshold)})</span><span class="lg-red">Capital épuisé</span><span>Cliquer sur un élève pour le détail et les actions éducatives</span></div>
    </section>
    <dialog id="points-dialog" class="points-modal" aria-labelledby="points-modal-title"><header><h3 id="points-modal-title"></h3><button id="points-modal-close" class="icon-button" type="button" aria-label="Fermer">×</button></header><p id="points-modal-subtitle" class="muted"></p><div id="points-modal-body"></div></dialog>
    <dialog id="letter-dialog" class="letter-preview-dialog" aria-labelledby="letter-dialog-title"><header><div><h3 id="letter-dialog-title">Aperçu du courrier famille</h3><p>À faire valider par la direction avant utilisation réelle.</p></div><button id="letter-dialog-close" class="icon-button" type="button" aria-label="Fermer">×</button></header><article id="letter-preview" class="letter-preview"></article><footer><button id="letter-cancel" class="button secondary" type="button">Retour</button><button id="letter-print" class="button primary" type="button">Imprimer le courrier</button></footer></dialog>`;

  const body = document.querySelector("#points-body");
  const filterInput = document.querySelector("#points-filter");
  const levelSelect = document.querySelector("#points-level");
  const classSelect = document.querySelector("#points-class");
  const trimesterSelect = document.querySelector("#points-trimester");
  const resultCount = document.querySelector("#points-result-count");
  const resetFilters = document.querySelector("#points-filter-reset");

  const badgeClass = (points) => points === 0 ? "points-red" : (points <= Number(data.alert_threshold) ? "points-amber" : "points-green");
  const syncClassOptions = () => {
    if (!levelSelect || !classSelect) return;
    const level = levelSelect.value;
    const availableClasses = level
      ? classes.filter((className) => classLevel(className) === level)
      : classes;
    if (pointsClassFilter && !availableClasses.includes(pointsClassFilter)) {
      pointsClassFilter = "";
    }
    const allClassesLabel = level ? `Toutes les classes de ${level}e` : "Toutes les classes";
    classSelect.innerHTML = `<option value="">${escapeHtml(allClassesLabel)}</option>${availableClasses.map((className) => `<option value="${escapeHtml(className)}">${escapeHtml(className)}</option>`).join("")}`;
    classSelect.value = pointsClassFilter;
  };
  const renderRows = () => {
    const needle = filterInput.value.trim().toLowerCase();
    const levelFilter = levelSelect ? levelSelect.value : "";
    const classFilter = classSelect ? classSelect.value : "";
    pointsSearchFilter = filterInput.value;
    pointsLevelFilter = levelFilter;
    pointsClassFilter = classFilter;
    const rows = data.students.filter((row) =>
      (!levelFilter || classLevel(row.class_name) === levelFilter) &&
      (!classFilter || row.class_name === classFilter) &&
      (!needle || `${row.last_name} ${row.first_name} ${row.class_name}`.toLowerCase().includes(needle)));
    const hasActiveFilters = Boolean(needle || levelFilter || classFilter);
    resultCount.textContent = hasActiveFilters
      ? `${rows.length} élève${rows.length > 1 ? "s" : ""} affiché${rows.length > 1 ? "s" : ""} sur ${data.students.length}`
      : `${data.students.length} élève${data.students.length > 1 ? "s" : ""}`;
    resetFilters.hidden = !hasActiveFilters;
    body.innerHTML = rows.length ? rows.map((row) => `
      <tr class="points-row" data-student="${row.id}" tabindex="0" role="button" aria-haspopup="dialog" aria-label="Ouvrir le détail de ${escapeHtml(row.first_name)} ${escapeHtml(row.last_name)}, ${escapeHtml(row.class_name)}, ${Number(row.points)} point(s) restant(s)">
        <td class="student-cell"><strong>${escapeHtml(row.last_name)} ${escapeHtml(row.first_name)}</strong><span>${escapeHtml(row.class_name)}</span></td>
        <td><span class="points-gauge"><i class="${badgeClass(row.points)} ${widthPercentClass(row.points / Number(data.capital) * 100)}"></i></span></td>
        <td><span class="points-badge ${badgeClass(row.points)}">${row.points}</span></td>
        <td>${row.confirmed || "—"}</td>
        <td>${row.pending ? `<span class="points-pending">+${row.pending} à vérifier</span>` : "—"}</td>
        <td>${row.restored ? `<span class="points-restored">+${row.restored}</span>` : "—"}</td>
        <td>${row.pending_actions ? `<span class="points-actions-due">${row.pending_actions} à faire</span>` : `<span class="muted">à jour</span>`}</td>
        <td>${row.last_confirmed_at ? formatDate(row.last_confirmed_at) : "—"}</td>
      </tr>`).join("") : `<tr><td colspan="8" class="muted">Aucun élève ne correspond.</td></tr>`;
    body.querySelectorAll("[data-student]").forEach((tableRow) => {
      tableRow.addEventListener("click", () => openPointsDetail(Number(tableRow.dataset.student)));
      tableRow.addEventListener("keydown", (event) => {
        if (event.key !== "Enter" && event.key !== " ") return;
        event.preventDefault();
        openPointsDetail(Number(tableRow.dataset.student));
      });
    });
  };
  renderRows();
  filterInput.addEventListener("input", renderRows);
  if (levelSelect) {
    levelSelect.addEventListener("change", () => {
      pointsLevelFilter = levelSelect.value;
      if (pointsClassFilter && classLevel(pointsClassFilter) !== pointsLevelFilter) {
        pointsClassFilter = "";
      }
      syncClassOptions();
      renderRows();
    });
  }
  if (classSelect) {
    classSelect.addEventListener("change", () => {
      pointsClassFilter = classSelect.value;
      const selectedClassLevel = classLevel(pointsClassFilter);
      if (pointsClassFilter && selectedClassLevel && levelSelect && levelSelect.value !== selectedClassLevel) {
        pointsLevelFilter = selectedClassLevel;
        levelSelect.value = selectedClassLevel;
        syncClassOptions();
      }
      renderRows();
    });
  }
  resetFilters.addEventListener("click", () => {
    pointsSearchFilter = "";
    pointsLevelFilter = "";
    pointsClassFilter = "";
    filterInput.value = "";
    if (levelSelect) levelSelect.value = "";
    syncClassOptions();
    renderRows();
    filterInput.focus();
  });
  trimesterSelect.addEventListener("change", () => {
    pointsTrimester = Number(trimesterSelect.value);
    renderPoints();
  });
  document.querySelector("#points-export").addEventListener("click", (event) => downloadPointsExport(event.currentTarget));
  const pointsDialog = document.querySelector("#points-dialog");
  document.querySelector("#points-modal-close").addEventListener("click", () => pointsDialog.close());
  const letterDialog = document.querySelector("#letter-dialog");
  document.querySelector("#letter-dialog-close").addEventListener("click", () => letterDialog.close());
  document.querySelector("#letter-cancel").addEventListener("click", () => letterDialog.close());
}

function classLevel(className) {
  const match = String(className || "").trim().match(/^([3-6])(?=\D|$)/);
  return match ? match[1] : "";
}

async function openPointsDetail(studentId) {
  try {
    const data = await api("points_detail", { query: { student_id: studentId, t: pointsTrimester } });
    const dialog = document.querySelector("#points-dialog");
    document.querySelector("#points-modal-title").textContent = `${data.student.last_name} ${data.student.first_name} — ${data.student.class_name}`;
    const confirmedCount = Number(data.confirmed_situations ?? data.observations.filter((item) => item.status === "confirmed").length);
    const pendingCount = Number(data.pending_situations ?? data.observations.filter((item) => item.status === "pending").length);
    document.querySelector("#points-modal-subtitle").textContent =
      `${data.points} point(s) restant(s) sur ${data.capital} · ${confirmedCount} situation(s) confirmée(s)`
      + (data.restored ? ` · ${data.restored} rendu(s)` : "")
      + (pendingCount ? ` · ${pendingCount} en attente` : "");

    const timeline = [
      ...data.observations.map((item) => ({ kind: "observation", date: item.occurred_at, item })),
      ...data.adjustments.map((item) => ({ kind: "adjustment", date: item.created_at, item })),
    ].sort((a, b) => String(b.date).localeCompare(String(a.date)));
    const timelineHtml = timeline.length ? timeline.map((entry) => entry.kind === "observation" ? `
      <div class="points-obs"><div class="points-obs-date">${formatDate(entry.item.occurred_at)}</div>
        <div class="points-obs-main">${escapeHtml(entry.item.reason)}<span>${escapeHtml(entry.item.location)}${entry.item.reporter ? ` — signalé par ${escapeHtml(entry.item.reporter)}` : ""}${entry.item.details ? ` — ${escapeHtml(entry.item.details)}` : ""}</span></div>
        ${statusBadge(entry.item.status)}</div>` : `
      <div class="points-obs points-obs-restored"><div class="points-obs-date">${formatDate(entry.item.created_at)}</div>
        <div class="points-obs-main">Point rendu : ${escapeHtml(entry.item.reason)}<span>par ${escapeHtml(entry.item.granted_by)}</span></div>
        <span class="badge confirmed">+${Number(entry.item.points)} point</span></div>`).join("")
      : `<p class="muted">Aucun mouvement sur ce trimestre.</p>`;

    const actionsHtml = data.actions.filter((action) => action.crossed || action.done).map((action) => {
      if (action.done) {
        return `<div class="points-action done"><span class="points-action-badge">✓</span><div><strong>${escapeHtml(action.action)}</strong> <span class="muted">(seuil ${Number(action.threshold_points)})</span><span class="points-action-meta">Fait le ${formatDate(action.done.done_at)} par ${escapeHtml(action.done.done_by)}${action.done.note ? ` — ${escapeHtml(action.done.note)}` : ""}</span></div></div>`;
      }
      return `<div class="points-action due"><span class="points-action-badge">!</span><div><strong>${escapeHtml(action.action)}</strong> <span class="muted">(seuil ${Number(action.threshold_points)} franchi)</span>
        ${data.can_manage ? `<div class="points-action-form"><input class="input compact-input" data-action-note="${Number(action.threshold_points)}" maxlength="160" placeholder="Note facultative"><button class="button secondary small" type="button" data-action-done="${Number(action.threshold_points)}">Marquer comme fait</button></div><span class="points-action-warning">Cette action sera journalisée et ne pourra pas être enregistrée deux fois.</span>` : `<span class="points-action-meta">À traiter par la vie scolaire</span>`}</div></div>`;
    }).join("");

    document.querySelector("#points-modal-body").innerHTML = `
      ${actionsHtml ? `<section class="points-actions-block"><h4>Actions éducatives</h4>${actionsHtml}</section>` : ""}
      ${data.can_manage ? `<section class="points-restore-block"><h4>Valoriser une évolution positive</h4><p>Un point peut être rendu après décision de la vie scolaire. Le motif est obligatoire et conservé dans le journal.</p><div class="points-action-form"><input id="restore-reason" class="input" maxlength="160" placeholder="Ex. engagement tenu pendant une semaine"><button id="restore-button" class="button success" type="button">Rendre 1 point</button></div></section>` : ""}
      <h4 class="points-timeline-title">Historique du trimestre</h4>${timelineHtml}
      ${data.can_manage ? `<div class="points-letter-block"><button id="letter-button" class="button secondary" type="button">Préparer le courrier famille</button></div>` : ""}
      <p class="points-modal-note">Chaque situation confirmée retire un point. Les passages d’un même parcours restent visibles mais ne comptent qu’une fois.</p>`;
    dialog.showModal();

    const restoreButton = document.querySelector("#restore-button");
    if (restoreButton) {
      restoreButton.addEventListener("click", async () => {
        const reason = document.querySelector("#restore-reason").value.trim();
        if (reason.length < 3) {
          showToast("Indiquez le motif du point rendu.");
          return;
        }
        const studentName = `${data.student.first_name} ${data.student.last_name}`;
        if (!window.confirm(`Rendre un point à ${studentName} pour le motif suivant ?\n\n${reason}`)) return;
        restoreButton.disabled = true;
        restoreButton.textContent = "Enregistrement…";
        try {
          await api("points_restore", { method: "POST", body: { student_id: studentId, reason } });
          showToast("Point rendu et journalisé.");
          dialog.close();
          await renderPoints();
          await openPointsDetail(studentId);
        } catch (error) {
          showToast(error.message);
          restoreButton.disabled = false;
          restoreButton.textContent = "Rendre 1 point";
        }
      });
    }

    document.querySelectorAll("[data-action-done]").forEach((button) => {
      button.addEventListener("click", async () => {
        const threshold = Number(button.dataset.actionDone);
        const noteInput = document.querySelector(`[data-action-note="${threshold}"]`);
        if (!window.confirm("Confirmer que cette action éducative a bien été réalisée ?")) return;
        button.disabled = true;
        button.textContent = "Enregistrement…";
        try {
          await api("points_action_done", { method: "POST", body: { student_id: studentId, threshold_points: threshold, note: noteInput ? noteInput.value.trim() : "" } });
          showToast("Action éducative enregistrée.");
          dialog.close();
          await renderPoints();
          await openPointsDetail(studentId);
        } catch (error) {
          showToast(error.message);
          button.disabled = false;
          button.textContent = "Marquer comme fait";
        }
      });
    });

    const letterButton = document.querySelector("#letter-button");
    if (letterButton) {
      letterButton.addEventListener("click", () => {
        dialog.close();
        openFamilyLetter(data);
      });
    }
  } catch (error) {
    showToast(error.message);
  }
}

async function downloadPointsExport(button) {
  const exportSession = session;
  const originalLabel = button.textContent;
  button.disabled = true;
  button.textContent = "Préparation…";
  try {
    const response = await fetch(`api.php?action=points_export&t=${pointsTrimester}`, {
      method: "POST",
      headers: { "X-CSRF-Token": csrfToken, Accept: "text/csv" },
      body: "{}",
      credentials: "same-origin",
    });
    if (!response.ok) {
      let message = "Export impossible.";
      try { message = (await response.json()).error || message; } catch (_) {}
      if (response.status === 401 && session === exportSession) showLogin();
      const error = new Error(message);
      error.status = response.status;
      throw error;
    }
    if (!exportSession || session !== exportSession) throw new Error("La session a été fermée.");
    const blob = await response.blob();
    if (session !== exportSession) throw new Error("La session a été fermée.");
    const disposition = response.headers.get("Content-Disposition") || "";
    const match = disposition.match(/filename="([^"]+)"/i);
    const url = URL.createObjectURL(blob);
    const link = document.createElement("a");
    link.href = url;
    link.download = match ? match[1] : `permis-points-T${pointsTrimester}.csv`;
    document.body.appendChild(link);
    link.click();
    link.remove();
    window.setTimeout(() => URL.revokeObjectURL(url), 1000);
    showToast("Export CSV préparé.");
  } catch (error) {
    showToast(error.message);
  } finally {
    button.disabled = false;
    button.textContent = originalLabel;
  }
}

function openFamilyLetter(data) {
  const config = session.points || {};
  const template = config.letter_template || "";
  const situations = new Map();
  data.observations.filter((item) => item.status === "confirmed").forEach((item) => {
    const situationId = item.situation_id || `observation:${item.id}`;
    if (!situations.has(situationId)) situations.set(situationId, []);
    situations.get(situationId).push(item);
  });
  const facts = [...situations.values()].map((items) => {
    const chronology = [...items].sort((left, right) => String(left.occurred_at).localeCompare(String(right.occurred_at)));
    if (chronology.length === 1) {
      const item = chronology[0];
      return `<li>${escapeHtml(formatDate(item.occurred_at))} — ${escapeHtml(item.reason)} (${escapeHtml(item.location)})</li>`;
    }
    const places = chronology.map((item) => item.location).filter((value, index, list) => index === 0 || value !== list[index - 1]);
    const reasons = [...new Set(chronology.map((item) => item.reason))];
    return `<li>${escapeHtml(formatDate(chronology[0].occurred_at))} — Parcours observé : ${places.map(escapeHtml).join(" → ")} (${reasons.map(escapeHtml).join(" ; ")})</li>`;
  }).join("");
  const factsHtml = facts ? `<ul>${facts}</ul>` : "<p>—</p>";
  const filled = escapeHtml(template)
    .replaceAll("{ELEVE}", escapeHtml(`${data.student.first_name} ${data.student.last_name}`))
    .replaceAll("{CLASSE}", escapeHtml(data.student.class_name))
    .replaceAll("{POINTS}", String(data.points))
    .replaceAll("{CAPITAL}", String(data.capital))
    .replaceAll("{TRIMESTRE}", escapeHtml(data.trimester_label || `trimestre ${data.trimester}`))
    .replaceAll("{COLLEGE}", escapeHtml(config.college_name || "Le collège"))
    .replaceAll("{DATE}", new Intl.DateTimeFormat("fr-FR", { dateStyle: "long" }).format(new Date()))
    .replace("{FAITS}", "@@FAITS@@")
    .replaceAll("\n", "<br>")
    .replace("@@FAITS@@", factsHtml);
  const dialog = document.querySelector("#letter-dialog");
  const preview = document.querySelector("#letter-preview");
  preview.innerHTML = filled;
  document.querySelector("#letter-print").onclick = () => {
    let sheet = document.querySelector("#letter-sheet");
    if (!sheet) {
      sheet = document.createElement("div");
      sheet.id = "letter-sheet";
      sheet.className = "letter-sheet";
      document.body.appendChild(sheet);
    }
    sheet.innerHTML = filled;
    window.print();
  };
  dialog.showModal();
}
