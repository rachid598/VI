# Nouveautés intégrées depuis `suivi-impecable-fusion.zip`

## Ajouts retenus

- signalement groupé de 1 à 8 élèves, sans fusionner leurs dossiers ;
- création atomique : soit tous les signalements du groupe sont enregistrés,
  soit aucun ne l’est ;
- anti-doublon sur les cinq dernières minutes, quel que soit le lieu ou le motif ;
- synchronisation des élèves depuis les groupes-classes LDAP Kwartz ;
- aperçu obligatoire des classes, petits effectifs et appartenances multiples ;
- aperçu signé et revérifié avant application ;
- garde-fou si l’effectif trouvé chute de plus de 20 % ;
- actualisation des badges d’alerte et de signalements à vérifier toutes les
  60 secondes ;
- pastille ambre « À vérifier » avec le nombre exact de signalements en attente ;
- filtres du permis dépendants : le niveau limite immédiatement les classes et
  le choix direct d’une classe sélectionne son niveau ;
- compteur de résultats et remise à zéro rapide des filtres.

## Éléments volontairement non recopiés

La fusion conserve les versions plus sûres déjà présentes pour l’export CSV,
les transactions du permis à points, les dialogues accessibles, l’impression du
courrier, la purge et le cache PWA isolé. Elle conserve également :

- un seul ZIP utilisable dans les deux dossiers web ;
- la base et l’utilisateur MySQL propres à chaque installation (`suivi_test`
  pour le test, `suivi` pour la production) ;
- une session et un cookie limités automatiquement au chemin de chaque dossier ;
- la migration de schéma version 5 ;
- le dossier `var/` local et son `settings.php`, distincts dans chaque copie.

## Renforts de cette livraison

- choix explicite du mode test ou production lors de l’installation ;
- bandeau permanent sur la version test ;
- module permis à points désactivable par un administrateur sans effacer les
  données ;
- session PWA conservée pendant huit heures au maximum, avec rotation de
  l’identifiant de session ;
- autocomplétion protégée contre les réponses obsolètes et utilisable au clavier ;
- purge serveur en simulation par défaut, transactionnelle et séparée pour les
  deux bases ;
- migrations MySQL protégées par verrou et audits enregistrés dans les mêmes
  transactions que les actions métier ;
- état de la dernière purge visible dans l’administration.
- formulaire de connexion explicitement limité à `POST`, avec bouton bloqué
  jusqu’au chargement du jeton de sécurité ;
- nettoyage immédiat d’une ancienne URL contenant `username` ou `password`,
  sans mise en cache de ces paramètres par la PWA.
- filtres du journal des actions par grande catégorie, avec compteur de
  résultats et tri des opérations de la plus récente à la plus ancienne ou
  dans l’ordre inverse.

Aucune réinstallation n’est nécessaire pour une installation de fusion déjà en
place : sauvegarder MySQL, conserver `var/`, remplacer les fichiers de l’application
et recharger deux fois la page.
