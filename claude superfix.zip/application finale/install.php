<?php

declare(strict_types=1);

ini_set('display_errors', '0');
ini_set('log_errors', '1');
ini_set('zend.exception_ignore_args', '1');

require_once __DIR__ . '/src/SchemaMigrator.php';
require_once __DIR__ . '/src/LdapAuthenticator.php';

/** Erreur de validation dont le message peut être affiché tel quel. */
final class InstallValidationException extends RuntimeException
{
}

$appVersionPath = __DIR__ . '/VERSION';
$appVersion = is_readable($appVersionPath)
    ? trim((string) file_get_contents($appVersionPath))
    : '';
if (!preg_match('/^\d+\.\d+\.\d+(?:-[0-9A-Za-z.-]+)?$/', $appVersion)) {
    $appVersion = '0.0.0-dev';
}

header('X-Content-Type-Options: nosniff');
header('X-Frame-Options: DENY');
header('Referrer-Policy: no-referrer');
header("Permissions-Policy: camera=(), microphone=(), geolocation=()");
header('X-Suivi-Version: ' . $appVersion);
header("Content-Security-Policy: default-src 'self'; script-src 'none'; style-src 'self'; img-src 'self' data:; form-action 'self'; frame-ancestors 'none'; base-uri 'none'");
header('Cache-Control: no-store');

$settingsPath = __DIR__ . '/var/settings.php';
$schemaPath = __DIR__ . '/database/schema.sql';
$installed = is_file($settingsPath);
$errors = [];
$success = false;
$isHttps = !empty($_SERVER['HTTPS']) && strtolower((string) $_SERVER['HTTPS']) !== 'off';
$checks = [
    'HTTPS actif' => $isHttps,
    'PHP 7.4 ou supérieur' => PHP_VERSION_ID >= 70400,
    'Extension LDAP' => extension_loaded('ldap'),
    'Extension MySQL' => extension_loaded('pdo_mysql'),
    'Dossier var accessible en écriture' => is_dir(__DIR__ . '/var') && is_writable(__DIR__ . '/var'),
    'Schéma de base présent' => is_file($schemaPath) && is_readable($schemaPath),
];
$ready = !in_array(false, $checks, true);

$installDirectory = str_replace('\\', '/', dirname(isset($_SERVER['SCRIPT_NAME']) ? (string) $_SERVER['SCRIPT_NAME'] : '/'));
$installCookiePath = rtrim($installDirectory, '/') . '/';
if ($installCookiePath === '//') {
    $installCookiePath = '/';
}
session_name('PAP_FUSION_INSTALL_' . strtoupper(substr(hash('sha256', __DIR__), 0, 8)));
session_set_cookie_params([
    'lifetime' => 1800,
    'path' => $installCookiePath,
    // L'installation est exclusivement HTTPS. Le cookie reste donc Secure,
    // même si quelqu'un tente d'ouvrir directement cette page en HTTP.
    'secure' => true,
    'httponly' => true,
    'samesite' => 'Strict',
]);
ini_set('session.use_strict_mode', '1');
ini_set('session.use_only_cookies', '1');
session_start();
if (empty($_SESSION['install_csrf'])) {
    $_SESSION['install_csrf'] = bin2hex(random_bytes(32));
}

$baseDn = isset($_POST['base_dn']) ? trim((string) $_POST['base_dn']) : 'dc=0594412a,dc=clg,dc=ac-lille,dc=fr';
$groupsInput = isset($_POST['groups']) ? trim((string) $_POST['groups']) : 'profs';
$allowedUsersInput = isset($_POST['allowed_users']) ? trim((string) $_POST['allowed_users']) : '';
$adminUid = isset($_POST['admin_uid']) ? strtolower(trim((string) $_POST['admin_uid'])) : 'r.elguimar';
$adminUid2 = isset($_POST['admin_uid_2']) ? strtolower(trim((string) $_POST['admin_uid_2'])) : '';
$schoolYear = isset($_POST['school_year']) ? trim((string) $_POST['school_year']) : '2026-2027';
$environment = isset($_POST['environment']) ? strtolower(trim((string) $_POST['environment'])) : 'test';
$databaseHost = isset($_POST['database_host']) ? trim((string) $_POST['database_host']) : 'localhost';
$databaseName = isset($_POST['database_name']) ? trim((string) $_POST['database_name']) : 'suivi_test';
$databaseUser = isset($_POST['database_user']) ? trim((string) $_POST['database_user']) : 'suivi_test';
$isolatedDatabaseConfirmed = isset($_POST['isolated_database']) && (string) $_POST['isolated_database'] === '1';

if ($_SERVER['REQUEST_METHOD'] === 'POST' && !$installed) {
    $postedToken = isset($_POST['csrf']) ? (string) $_POST['csrf'] : '';
    $databasePassword = isset($_POST['database_password']) ? (string) $_POST['database_password'] : '';
    $adminPassword = isset($_POST['admin_password']) ? (string) $_POST['admin_password'] : '';
    $pdo = null;
    $installationId = '';
    $bindingClaimed = false;
    $settingsCreated = false;
    if (!$isHttps) {
        $errors[] = 'L’installation doit être ouverte avec une adresse HTTPS.';
    }
    if (!hash_equals((string) $_SESSION['install_csrf'], $postedToken)) {
        $errors[] = 'La page a expiré. Rechargez-la puis recommencez.';
    }
    if (!$ready) {
        $errors[] = 'Un prérequis technique manque sur le serveur.';
    }
    if ($baseDn === '' || strlen($baseDn) > 255 || stripos($baseDn, 'dc=') === false || preg_match('/[\r\n]/', $baseDn)) {
        $errors[] = 'Le Base DN LDAP est invalide.';
    }
    if (!preg_match('/^[a-z0-9._-]{1,64}$/i', $adminUid)) {
        $errors[] = 'L’identifiant administrateur est invalide.';
    }
    if ($adminUid2 !== '' && !preg_match('/^[a-z0-9._-]{1,64}$/i', $adminUid2)) {
        $errors[] = 'L’identifiant de l’administrateur de secours est invalide.';
    }
    if ($adminUid2 !== '' && $adminUid2 === $adminUid) {
        $errors[] = 'L’administrateur de secours doit être un compte différent de l’administrateur initial.';
    }
    if (!preg_match('/^\d{4}-\d{4}$/', $schoolYear)) {
        $errors[] = 'L’année scolaire doit être écrite comme 2026-2027.';
    }
    if (!in_array($environment, ['test', 'production'], true)) {
        $errors[] = 'Le mode d’installation est invalide.';
    }
    if (!in_array($databaseHost, ['127.0.0.1', 'localhost'], true)) {
        $errors[] = 'Le serveur MySQL doit rester local à Kwartz.';
    }
    if (!preg_match('/^[a-zA-Z0-9_-]{1,64}$/', $databaseName) || !preg_match('/^[a-zA-Z0-9._-]{1,64}$/', $databaseUser)) {
        $errors[] = 'Le nom de base ou l’utilisateur MySQL est invalide.';
    }
    if (!$isolatedDatabaseConfirmed) {
        $errors[] = 'Confirmez que cette base MySQL est réservée à cet environnement.';
    }
    if ($databasePassword === '' || strlen($databasePassword) > 255) {
        $errors[] = 'Saisissez le mot de passe MySQL.';
    }
    if ($adminPassword === '' || strlen($adminPassword) > 255) {
        $errors[] = 'Saisissez le mot de passe Kwartz de l’administrateur initial.';
    }

    $groups = splitList($groupsInput);
    $allowedUsers = splitList($allowedUsersInput);
    if (count($groups) === 0) {
        $errors[] = 'Indiquez au moins un groupe LDAP autorisé.';
    }
    foreach (array_merge($groups, $allowedUsers) as $value) {
        if (!preg_match('/^[a-z0-9._ -]{1,64}$/i', $value)) {
            $errors[] = 'Un groupe ou identifiant contient des caractères invalides.';
            break;
        }
    }

    $bootstrapAdmins = $adminUid2 !== '' ? [$adminUid, $adminUid2] : [$adminUid];

    if (count($errors) === 0) {
        try {
            testLdap($baseDn, $groups);
            if ($adminUid2 !== '') {
                // Un compte de secours mal orthographié serait inutilisable le
                // jour où on en a besoin : on vérifie qu'il existe dans
                // l'annuaire, sans demander son mot de passe.
                assertLdapUserExists($baseDn, $adminUid2);
            }
            $installerLdap = new LdapAuthenticator([
                'uri' => 'ldap://127.0.0.1:389',
                'base_dn' => $baseDn,
                'user_filter' => '(&(uid={username})(objectClass=*))',
                'group_filter' => '(&(cn={group})(objectClass=*))',
                'uid_attribute' => 'uid',
                'first_name_attribute' => 'givenname',
                'last_name_attribute' => 'sn',
                'email_attribute' => 'mail',
                'allowed_groups' => $groups,
                'allowed_users' => $allowedUsers,
                'bootstrap_admins' => $bootstrapAdmins,
                'use_starttls' => false,
                'network_timeout' => 5,
            ]);
            $installerIdentity = $installerLdap->authenticate($adminUid, $adminPassword);
            $adminPassword = '';
            if (strtolower((string) $installerIdentity['uid']) !== $adminUid) {
                throw new LdapAuthenticationException('Identifiant ou mot de passe incorrect.');
            }

            $dsn = 'mysql:host=' . $databaseHost . ';dbname=' . $databaseName . ';charset=utf8mb4';
            $pdo = new PDO($dsn, $databaseUser, $databasePassword, [
                PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
                PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
                PDO::ATTR_EMULATE_PREPARES => false,
            ]);
            $installationId = bin2hex(random_bytes(32));
            $installationScopeHash = SchemaMigrator::installationScopeHash(
                __DIR__,
                $installationId
            );
            // Cette vérification précède toute création de table applicative :
            // une base déjà revendiquée par un autre dossier est refusée.
            $bindingClaimed = SchemaMigrator::bindInstallation(
                $pdo,
                $installationId,
                $environment,
                $installationScopeHash
            );
            installSchema($pdo, $schemaPath);

            $config = [
                'app' => [
                    'name' => 'Suivi des circulations',
                    'installation_id' => $installationId,
                    'installation_scope_hash' => $installationScopeHash,
                    'environment' => $environment,
                    'school_year' => $schoolYear,
                    'session_name' => 'PAP_FUSION_' . ($environment === 'production' ? 'PROD' : 'TEST') . '_' . strtoupper(substr(hash('sha256', __DIR__), 0, 8)),
                    'session_lifetime' => 28800,
                    'session_rotation_interval' => 1800,
                    'key' => bin2hex(random_bytes(32)),
                ],
                'database' => [
                    'dsn' => $dsn,
                    'user' => $databaseUser,
                    'password' => $databasePassword,
                ],
                'ldap' => [
                    'uri' => 'ldap://127.0.0.1:389',
                    'base_dn' => $baseDn,
                    'user_filter' => '(&(uid={username})(objectClass=*))',
                    'group_filter' => '(&(cn={group})(objectClass=*))',
                    'uid_attribute' => 'uid',
                    'first_name_attribute' => 'givenname',
                    'last_name_attribute' => 'sn',
                    'email_attribute' => 'mail',
                    'allowed_groups' => $groups,
                    'allowed_users' => $allowedUsers,
                    'bootstrap_admins' => $bootstrapAdmins,
                    'use_starttls' => false,
                    'network_timeout' => 5,
                    'class_group_pattern' => '^c([3-6])g([0-9]{1,2})$',
                    'class_label_format' => '{n}G{g}',
                ],
                'security' => [
                    'force_https' => true,
                    'login_max_attempts' => 5,
                    'login_ip_max_attempts' => 30,
                    'login_window_seconds' => 900,
                    'details_max_length' => 160,
                ],
                'privacy' => [
                    'observation_retention_days' => 120,
                    'inactive_school_year_retention_days' => 120,
                    'audit_retention_days' => 365,
                    'login_attempt_retention_days' => 30,
                ],
                'recovery' => [
                    'enabled' => true,
                    'interval_seconds' => 1800,
                    'retention_days' => 7,
                    'list_limit' => 30,
                ],
                'points' => [
                    'enabled' => false,
                    'capital' => 10,
                    'alert_threshold' => 5,
                    'trimesters' => [
                        ['label' => 'Trimestre 1', 'start' => '2026-07-01', 'end' => '2026-11-30'],
                        ['label' => 'Trimestre 2', 'start' => '2026-12-01', 'end' => '2027-02-28'],
                        ['label' => 'Trimestre 3', 'start' => '2027-03-01', 'end' => '2027-07-04'],
                    ],
                    'action_thresholds' => [
                        ['points' => 5, 'action' => 'Entretien CPE'],
                        ['points' => 2, 'action' => 'Information de la famille'],
                        ['points' => 0, 'action' => 'Commission éducative'],
                    ],
                    'college_name' => 'Collège Jean-Jaurès',
                    'letter_template' => "Objet : dispositif « permis à points » — information\n\nMadame, Monsieur,\n\nDans le cadre du dispositif « permis à points » prévu au règlement intérieur, nous vous informons que {ELEVE}, élève de {CLASSE}, dispose ce jour de {POINTS} point(s) sur un capital de {CAPITAL} pour le {TRIMESTRE}.\n\nLes faits suivants, vérifiés par la vie scolaire, ont conduit à ce décompte :\n{FAITS}\n\nNous vous invitons à évoquer cette situation avec votre enfant. La vie scolaire se tient à votre disposition pour tout échange.\n\n{COLLEGE}, le {DATE}\nLa vie scolaire",
                ],
                'digital_passes' => [
                    'enabled' => false,
                ],
            ];
            $content = "<?php\n\ndeclare(strict_types=1);\n\nreturn " . var_export($config, true) . ";\n";
            writeSettingsFile($settingsPath, $content);
            $settingsCreated = true;
            $databasePassword = '';
            $success = true;
            $installed = true;
            unset($_SESSION['install_csrf']);
        } catch (Throwable $error) {
            $adminPassword = '';
            $databasePassword = '';
            if ($settingsCreated && is_file($settingsPath)) {
                @unlink($settingsPath);
            }
            if ($bindingClaimed && $pdo instanceof PDO && $installationId !== '') {
                try {
                    SchemaMigrator::releaseInstallationBinding($pdo, $installationId);
                } catch (Throwable $cleanupError) {
                    // L'erreur principale reste prioritaire. Une liaison
                    // incomplète sera refusée explicitement au prochain essai.
                }
            }

            $reference = bin2hex(random_bytes(6));
            error_log(sprintf(
                '[suivi-install:%s] %s code=%d source=%s:%d',
                $reference,
                get_class($error),
                (int) $error->getCode(),
                basename($error->getFile()),
                $error->getLine()
            ));
            if ($error instanceof InstallationBindingException) {
                $errors[] = 'Cette base MySQL est déjà utilisée par une autre installation ou un autre environnement.';
            } elseif ($error instanceof InstallValidationException) {
                $errors[] = $error->getMessage();
            } elseif ($error instanceof LdapAuthenticationException) {
                $errors[] = 'L’identifiant administrateur ou son mot de passe Kwartz est incorrect.';
            } else {
                $errors[] = 'L’installation a échoué. Référence technique : ' . $reference . '.';
            }
        }
    }
}

/**
 * Écrit settings.php atomiquement avec des droits strictement privés.
 *
 * Le fichier temporaire porte un nom aléatoire, est créé en mode exclusif et
 * reste dans var/ afin que le renommage final soit atomique sur le même volume.
 */
function writeSettingsFile(string $settingsPath, string $content): void
{
    if (file_exists($settingsPath) || is_link($settingsPath)) {
        throw new RuntimeException('La configuration existe déjà.');
    }

    $directory = dirname($settingsPath);
    $temporaryPath = $directory . '/.settings-' . bin2hex(random_bytes(12)) . '.tmp.php';
    $previousUmask = umask(0077);
    $handle = false;
    $renamed = false;
    try {
        $handle = @fopen($temporaryPath, 'x+b');
        if ($handle === false) {
            throw new RuntimeException('Création de la configuration impossible.');
        }
        if (!flock($handle, LOCK_EX)) {
            throw new RuntimeException('Verrouillage de la configuration impossible.');
        }
        $offset = 0;
        $length = strlen($content);
        while ($offset < $length) {
            $written = fwrite($handle, substr($content, $offset));
            if ($written === false || $written === 0) {
                throw new RuntimeException('Écriture de la configuration impossible.');
            }
            $offset += $written;
        }
        if (!fflush($handle)) {
            throw new RuntimeException('Synchronisation de la configuration impossible.');
        }
        @chmod($temporaryPath, 0600);
        clearstatcache(true, $temporaryPath);
        $temporaryPermissions = @fileperms($temporaryPath);
        if ($temporaryPermissions === false || ($temporaryPermissions & 0077) !== 0) {
            throw new RuntimeException('Les permissions du fichier de configuration sont insuffisantes.');
        }
        flock($handle, LOCK_UN);
        fclose($handle);
        $handle = null;

        if (!@rename($temporaryPath, $settingsPath)) {
            throw new RuntimeException('Activation de la configuration impossible.');
        }
        $renamed = true;
        @chmod($settingsPath, 0600);
        clearstatcache(true, $settingsPath);
        $finalPermissions = @fileperms($settingsPath);
        if ($finalPermissions === false || ($finalPermissions & 0077) !== 0) {
            @unlink($settingsPath);
            $renamed = false;
            throw new RuntimeException('Les permissions finales de la configuration sont insuffisantes.');
        }
    } finally {
        umask($previousUmask);
        if (is_resource($handle)) {
            @flock($handle, LOCK_UN);
            @fclose($handle);
        }
        if (!$renamed && is_file($temporaryPath)) {
            @unlink($temporaryPath);
        }
    }
}

function splitList(string $value): array
{
    $items = preg_split('/[,;\r\n]+/', strtolower($value));
    if (!is_array($items)) {
        return [];
    }
    $items = array_map('trim', $items);
    return array_values(array_unique(array_filter($items, static function (string $item): bool {
        return $item !== '';
    })));
}

function ldapFilterEscape(string $value): string
{
    if (function_exists('ldap_escape')) {
        return ldap_escape($value, '', LDAP_ESCAPE_FILTER);
    }
    return strtr($value, ['\\' => '\\5c', '*' => '\\2a', '(' => '\\28', ')' => '\\29', "\0" => '\\00']);
}

function testLdap(string $baseDn, array $groups): void
{
    $connection = @ldap_connect('ldap://127.0.0.1:389');
    if ($connection === false) {
        throw new RuntimeException('Le serveur LDAP local est inaccessible.');
    }
    ldap_set_option($connection, LDAP_OPT_PROTOCOL_VERSION, 3);
    ldap_set_option($connection, LDAP_OPT_REFERRALS, 0);
    if (defined('LDAP_OPT_NETWORK_TIMEOUT')) {
        ldap_set_option($connection, LDAP_OPT_NETWORK_TIMEOUT, 5);
    }
    if (!@ldap_bind($connection)) {
        @ldap_unbind($connection);
        throw new RuntimeException('La connexion anonyme LDAP a échoué.');
    }
    $baseRead = @ldap_read($connection, $baseDn, '(objectClass=*)', ['objectClass'], 0, 1, 5);
    if ($baseRead === false) {
        @ldap_unbind($connection);
        throw new RuntimeException('Base DN introuvable dans LDAP.');
    }
    foreach ($groups as $group) {
        $filter = '(&(cn=' . ldapFilterEscape($group) . ')(objectClass=*))';
        $search = @ldap_search($connection, $baseDn, $filter, ['cn'], 0, 2, 5);
        $entries = $search !== false ? ldap_get_entries($connection, $search) : false;
        if (!is_array($entries) || (int) $entries['count'] < 1) {
            @ldap_unbind($connection);
            throw new RuntimeException('Le groupe LDAP « ' . $group . ' » est introuvable.');
        }
    }
    @ldap_unbind($connection);
}

function assertLdapUserExists(string $baseDn, string $uid): void
{
    $connection = @ldap_connect('ldap://127.0.0.1:389');
    if ($connection === false) {
        throw new RuntimeException('Le serveur LDAP local est inaccessible.');
    }
    ldap_set_option($connection, LDAP_OPT_PROTOCOL_VERSION, 3);
    ldap_set_option($connection, LDAP_OPT_REFERRALS, 0);
    if (defined('LDAP_OPT_NETWORK_TIMEOUT')) {
        ldap_set_option($connection, LDAP_OPT_NETWORK_TIMEOUT, 5);
    }
    if (!@ldap_bind($connection)) {
        @ldap_unbind($connection);
        throw new RuntimeException('La connexion anonyme LDAP a échoué.');
    }
    $filter = '(&(uid=' . ldapFilterEscape($uid) . ')(objectClass=*))';
    $search = @ldap_search($connection, $baseDn, $filter, ['uid'], 0, 2, 5);
    $entries = $search !== false ? ldap_get_entries($connection, $search) : false;
    @ldap_unbind($connection);
    if (!is_array($entries) || (int) $entries['count'] !== 1) {
        throw new InstallValidationException('L’administrateur de secours « ' . $uid . ' » est introuvable dans l’annuaire.');
    }
}

function installSchema(PDO $pdo, string $schemaPath): void
{
    $schema = file_get_contents($schemaPath);
    if ($schema === false) {
        throw new RuntimeException('Lecture du schéma MySQL impossible.');
    }
    $statements = preg_split('/;\s*(?:\r?\n|$)/', $schema);
    if (!is_array($statements)) {
        throw new RuntimeException('Schéma MySQL invalide.');
    }
    foreach ($statements as $statement) {
        $statement = trim($statement);
        if ($statement !== '') {
            $pdo->exec($statement);
        }
    }
}
?>
<!doctype html>
<html lang="fr">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>Installation — Suivi des circulations</title>
  <link rel="stylesheet" href="assets/app.css">
  <link rel="stylesheet" href="assets/impeccable.css?v=20">
</head>
<body>
  <main class="install-page">
    <section class="card install-card">
      <p class="eyebrow">Installation simplifiée Kwartz</p>
      <h1>Suivi des circulations</h1>
      <p class="app-version install-version">v<?= htmlspecialchars($appVersion, ENT_QUOTES, 'UTF-8') ?></p>
      <?php if ($installed): ?>
        <div class="install-success"><h2><?= $success ? 'Installation terminée' : 'Application déjà installée' ?></h2><p>MySQL et l’accès LDAP sont prêts.</p><a class="button primary" href="index.html">Ouvrir l’application</a></div>
      <?php elseif (!$isHttps): ?>
        <div class="install-errors" role="alert"><strong>Connexion sécurisée requise</strong><p>Rouvrez cette page avec son adresse HTTPS pour commencer l’installation.</p></div>
      <?php else: ?>
        <p>La connexion MySQL et la création des tables sont réalisées automatiquement.</p>
        <div class="check-list"><?php foreach ($checks as $label => $ok): ?><div class="check-row <?= $ok ? 'ok' : 'bad' ?>"><span><?= $ok ? '✓' : '×' ?></span><?= htmlspecialchars($label, ENT_QUOTES, 'UTF-8') ?></div><?php endforeach; ?></div>
        <?php if (count($errors) > 0): ?><div class="install-errors" role="alert"><strong>Installation impossible :</strong><ul><?php foreach ($errors as $error): ?><li><?= htmlspecialchars($error, ENT_QUOTES, 'UTF-8') ?></li><?php endforeach; ?></ul></div><?php endif; ?>
        <form method="post" class="install-form">
          <input type="hidden" name="csrf" value="<?= htmlspecialchars((string) $_SESSION['install_csrf'], ENT_QUOTES, 'UTF-8') ?>">
          <div class="install-section-title">Mode de cette installation</div>
          <label for="environment">Environnement <span>une installation correspond à une seule base MySQL</span></label>
          <select class="select" id="environment" name="environment" required>
            <option value="test" <?= $environment === 'test' ? 'selected' : '' ?>>Test / démonstration — données fictives uniquement</option>
            <option value="production" <?= $environment === 'production' ? 'selected' : '' ?>>Production — données réelles après validation</option>
          </select>
          <p class="muted">Pour disposer des deux environnements, envoyez le même ZIP dans deux dossiers puis utilisez deux bases et deux utilisateurs MySQL distincts.</p>

          <div class="install-section-title">Base MySQL dédiée</div>
          <div class="install-three-cols">
            <div><label for="database-host">Serveur</label><input class="input" id="database-host" name="database_host" required value="<?= htmlspecialchars($databaseHost, ENT_QUOTES, 'UTF-8') ?>"></div>
            <div><label for="database-name">Nom de la base</label><input class="input" id="database-name" name="database_name" required value="<?= htmlspecialchars($databaseName, ENT_QUOTES, 'UTF-8') ?>"></div>
            <div><label for="database-user">Utilisateur</label><input class="input" id="database-user" name="database_user" required value="<?= htmlspecialchars($databaseUser, ENT_QUOTES, 'UTF-8') ?>"></div>
          </div>
          <label for="database-password">Mot de passe MySQL <span>utilisé uniquement côté serveur</span></label>
          <input class="input" id="database-password" name="database_password" type="password" autocomplete="new-password" required>
          <label class="install-confirmation"><input type="checkbox" name="isolated_database" value="1" required <?= $isolatedDatabaseConfirmed ? 'checked' : '' ?>> <span>Je confirme que cette base et cet utilisateur MySQL ne sont pas utilisés par l’autre environnement.</span></label>

          <div class="install-section-title">Annuaire Kwartz</div>
          <label for="base-dn">Base DN LDAP</label><input class="input" id="base-dn" name="base_dn" required maxlength="255" value="<?= htmlspecialchars($baseDn, ENT_QUOTES, 'UTF-8') ?>">
          <label for="groups">Groupes autorisés <span>séparés par des virgules</span></label><input class="input" id="groups" name="groups" required value="<?= htmlspecialchars($groupsInput, ENT_QUOTES, 'UTF-8') ?>">
          <label for="allowed-users">Autres identifiants autorisés <span>facultatif : AED, CPE ou services hors groupe profs</span></label><textarea class="textarea" id="allowed-users" name="allowed_users" placeholder="identifiant1, identifiant2"><?= htmlspecialchars($allowedUsersInput, ENT_QUOTES, 'UTF-8') ?></textarea>
          <div class="install-two-cols"><div><label for="admin-uid">Administrateur initial</label><input class="input" id="admin-uid" name="admin_uid" required value="<?= htmlspecialchars($adminUid, ENT_QUOTES, 'UTF-8') ?>"></div><div><label for="school-year">Année scolaire</label><input class="input" id="school-year" name="school_year" required value="<?= htmlspecialchars($schoolYear, ENT_QUOTES, 'UTF-8') ?>"></div></div>
          <label for="admin-uid-2">Administrateur de secours <span>facultatif mais recommandé : second compte Kwartz gardant l’accès admin si le premier disparaît</span></label>
          <input class="input" id="admin-uid-2" name="admin_uid_2" value="<?= htmlspecialchars($adminUid2, ENT_QUOTES, 'UTF-8') ?>" placeholder="identifiant Kwartz (vérifié dans l’annuaire, sans mot de passe)">
          <label for="admin-password">Mot de passe Kwartz de l’administrateur <span>vérifié une fois, jamais enregistré</span></label>
          <input class="input" id="admin-password" name="admin_password" type="password" autocomplete="current-password" required>
          <button class="button primary" type="submit" <?= $ready ? '' : 'disabled' ?>>Tester et installer automatiquement</button>
        </form>
      <?php endif; ?>
    </section>
  </main>
</body>
</html>
