#!/bin/sh
# Purge RGPD planifiée — enveloppe cron de tools/cleanup.php.
#
# Ce script applique les durées de conservation de var/settings.php :
# - les années scolaires inactives sont purgées après le 31 août + délai ;
# - les journaux d'audit et tentatives de connexion suivent leurs propres délais ;
# - l'année scolaire active n'est jamais touchée (protection du script PHP).
#
# Programmation recommandée (crontab de l'utilisateur web, une ligne par
# installation) — tous les mois : chaque fin d'année scolaire est ainsi purgée
# automatiquement dès que son délai de conservation est écoulé, et les journaux
# sont entretenus en continu :
#
#   30 3 1 * * /bin/sh /chemin/vers/suivi/tools/purge-rgpd.sh
#
# Le compte rendu complet (années éligibles, volumes, résultat) est conservé
# dans var/purge-rgpd.log, hors d'atteinte du web grâce à var/.htaccess.

set -u

SCRIPT_DIR=$(CDPATH= cd -- "$(dirname -- "$0")" && pwd)
INSTALL_DIR=$(CDPATH= cd -- "$SCRIPT_DIR/.." && pwd)
LOG_FILE="$INSTALL_DIR/var/purge-rgpd.log"
PHP_BIN="${PHP_BIN:-php}"

cd -- "$INSTALL_DIR" || exit 1

# Rotation simple : au-delà d'environ 512 Kio, l'ancien journal est conservé
# une génération dans purge-rgpd.log.1 puis remplacé.
if [ -f "$LOG_FILE" ]; then
    LOG_SIZE=$(wc -c < "$LOG_FILE" 2>/dev/null || echo 0)
    if [ "$LOG_SIZE" -gt 524288 ]; then
        mv -f "$LOG_FILE" "$LOG_FILE.1"
    fi
fi

{
    echo "===================================================================="
    echo "Purge RGPD lancée le $(date -u '+%Y-%m-%d %H:%M:%S') UTC dans $INSTALL_DIR"
    "$PHP_BIN" "$INSTALL_DIR/tools/cleanup.php" --apply
    STATUS=$?
    echo "Code de sortie : $STATUS"
    echo ""
} >> "$LOG_FILE" 2>&1

# Codes de cleanup.php : 0 = succès, 3 = incohérence bloquante détectée
# (aucune donnée modifiée — à examiner manuellement), autre = erreur.
exit "${STATUS:-1}"
