<?php

declare(strict_types=1);

if (PHP_SAPI !== 'cli') {
    http_response_code(404);
    exit;
}

$arguments = isset($argv) && is_array($argv) ? array_slice($argv, 1) : [];
$mode = cleanupMode($arguments);
if ($mode === 'help') {
    cleanupUsage();
    exit(0);
}

require dirname(__DIR__) . '/src/bootstrap.php';

$privacy = isset($config['privacy']) && is_array($config['privacy']) ? $config['privacy'] : [];
$activeSchoolYear = trim((string) $config['app']['school_year']);
if (schoolYearEnd($activeSchoolYear) === null) {
    fwrite(STDERR, "Année scolaire active invalide : {$activeSchoolYear}. Nettoyage annulé.\n");
    exit(1);
}

$observationRetentionDays = retentionDays($privacy, 'observation_retention_days', 120);
$inactiveYearRetentionDays = retentionDays(
    $privacy,
    'inactive_school_year_retention_days',
    $observationRetentionDays
);
$auditRetentionDays = retentionDays($privacy, 'audit_retention_days', 365);
$loginRetentionDays = retentionDays($privacy, 'login_attempt_retention_days', 30);

$utc = new DateTimeZone('UTC');
$now = new DateTimeImmutable('now', $utc);
$auditCutoff = $now->sub(new DateInterval('P' . $auditRetentionDays . 'D'))->format('Y-m-d H:i:s');
$loginCutoff = $now->sub(new DateInterval('P' . $loginRetentionDays . 'D'))->format('Y-m-d H:i:s');
$pdo = $database->pdo();

$schoolYears = knownSchoolYears($pdo);
$eligibleSchoolYears = [];
$protectedSchoolYears = [];
$invalidSchoolYears = [];
foreach ($schoolYears as $schoolYear) {
    if ($schoolYear === $activeSchoolYear) {
        $protectedSchoolYears[$schoolYear] = 'année active';
        continue;
    }
    $schoolYearEnd = schoolYearEnd($schoolYear);
    if ($schoolYearEnd === null) {
        $invalidSchoolYears[] = $schoolYear;
        continue;
    }
    $purgeAfter = $schoolYearEnd->add(new DateInterval('P' . $inactiveYearRetentionDays . 'D'));
    if ($now->getTimestamp() >= $purgeAfter->getTimestamp()) {
        $eligibleSchoolYears[] = $schoolYear;
    } else {
        $protectedSchoolYears[$schoolYear] = 'protégée jusqu’au ' . $purgeAfter->format('Y-m-d H:i:s') . ' UTC';
    }
}

$inconsistentActions = countInconsistentActions($pdo);
$preview = cleanupCounts($pdo, $eligibleSchoolYears, $auditCutoff, $loginCutoff);

printCleanupHeader(
    $mode,
    $activeSchoolYear,
    $inactiveYearRetentionDays,
    $auditRetentionDays,
    $loginRetentionDays,
    $eligibleSchoolYears,
    $protectedSchoolYears,
    $invalidSchoolYears
);
printCleanupCounts($preview, 'Éléments concernés');

if ($inconsistentActions > 0) {
    fwrite(
        STDERR,
        "Blocage de sécurité : {$inconsistentActions} action(s) ont une année différente de celle de l’élève lié.\n"
        . "Corrigez cette incohérence avant d’appliquer la purge. Aucune donnée n’a été modifiée.\n"
    );
    exit($mode === 'apply' ? 3 : 0);
}

if ($mode !== 'apply') {
    echo "\nSIMULATION TERMINÉE — aucune écriture ni suppression effectuée.\n";
    echo "Relancez avec --apply uniquement après contrôle et sauvegarde MySQL.\n";
    exit(0);
}

try {
    $result = $database->transaction(function (PDO $transaction) use (
        $eligibleSchoolYears,
        $activeSchoolYear,
        $auditCutoff,
        $loginCutoff,
        $now
    ): array {
        $counts = emptyCleanupCounts();

        // Verrouille le choix d’année pendant toute la purge : un changement
        // concurrent dans l’administration ne peut pas rendre une année
        // nouvellement active éligible au milieu de la transaction.
        $activeYearLock = $transaction->prepare(
            'SELECT setting_value FROM app_settings
             WHERE setting_key = :setting_key FOR UPDATE'
        );
        $activeYearLock->execute(['setting_key' => 'active_school_year']);
        $lockedActiveSchoolYear = $activeYearLock->fetchColumn();
        if (!is_string($lockedActiveSchoolYear) || $lockedActiveSchoolYear !== $activeSchoolYear) {
            throw new RuntimeException(
                'L’année scolaire active a changé depuis la simulation. Relancez le nettoyage.'
            );
        }

        $deleteObservations = $transaction->prepare(
            'DELETE o FROM observations o
             INNER JOIN students s ON s.id = o.student_id
             WHERE s.school_year = :school_year AND s.school_year <> :active_school_year'
        );
        $deleteDigitalPasses = $transaction->prepare(
            'DELETE FROM digital_passes
             WHERE school_year = :school_year AND school_year <> :active_school_year'
        );
        $deleteAdjustments = $transaction->prepare(
            'DELETE a FROM point_adjustments a
             INNER JOIN students s ON s.id = a.student_id
             WHERE s.school_year = :school_year AND s.school_year <> :active_school_year'
        );
        $deleteActions = $transaction->prepare(
            'DELETE FROM action_records
             WHERE school_year = :school_year AND school_year <> :active_school_year'
        );
        $deleteImports = $transaction->prepare(
            'DELETE FROM student_imports
             WHERE school_year = :school_year AND school_year <> :active_school_year'
        );
        $deleteStudents = $transaction->prepare(
            'DELETE FROM students
             WHERE school_year = :school_year AND school_year <> :active_school_year'
        );

        foreach ($eligibleSchoolYears as $schoolYear) {
            $parameters = [
                'school_year' => $schoolYear,
                'active_school_year' => $activeSchoolYear,
            ];

            // Cet ordre laisse les clés étrangères des élèves intactes jusqu’à la fin.
            $deleteDigitalPasses->execute($parameters);
            $counts['digital_passes'] += $deleteDigitalPasses->rowCount();

            $deleteObservations->execute($parameters);
            $counts['observations'] += $deleteObservations->rowCount();

            $deleteAdjustments->execute($parameters);
            $counts['point_adjustments'] += $deleteAdjustments->rowCount();

            $deleteActions->execute($parameters);
            $counts['action_records'] += $deleteActions->rowCount();

            $deleteImports->execute($parameters);
            $counts['student_imports'] += $deleteImports->rowCount();

            $deleteStudents->execute($parameters);
            $counts['students'] += $deleteStudents->rowCount();
        }

        $deleteAudits = $transaction->prepare('DELETE FROM audit_logs WHERE created_at < :cutoff');
        $deleteAudits->execute(['cutoff' => $auditCutoff]);
        $counts['audit_logs'] = $deleteAudits->rowCount();

        $deleteAttempts = $transaction->prepare('DELETE FROM login_attempts WHERE attempted_at < :cutoff');
        $deleteAttempts->execute(['cutoff' => $loginCutoff]);
        $counts['login_attempts'] = $deleteAttempts->rowCount();
        $counts['school_years'] = count($eligibleSchoolYears);

        $resultJson = json_encode($counts, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
        if (!is_string($resultJson) || strlen($resultJson) > 255) {
            throw new RuntimeException('Le bilan de purge ne peut pas être enregistré dans app_settings.');
        }
        $saveSetting = $transaction->prepare(
            'INSERT INTO app_settings (setting_key, setting_value)
             VALUES (:setting_key, :setting_value)
             ON DUPLICATE KEY UPDATE setting_value = VALUES(setting_value)'
        );
        $settings = [
            'privacy_cleanup_last_applied_at' => $now->format('Y-m-d H:i:s'),
            'privacy_cleanup_last_status' => 'success',
            'privacy_cleanup_last_result' => $resultJson,
        ];
        foreach ($settings as $key => $value) {
            $saveSetting->execute(['setting_key' => $key, 'setting_value' => $value]);
        }

        return $counts;
    });
} catch (Throwable $error) {
    fwrite(STDERR, "ÉCHEC — transaction annulée, aucune purge partielle conservée.\n");
    fwrite(STDERR, $error->getMessage() . "\n");
    exit(1);
}

printCleanupCounts($result, 'Suppressions appliquées');
echo "\nNETTOYAGE APPLIQUÉ AVEC SUCCÈS — résultat et date enregistrés dans app_settings.\n";

function cleanupMode(array $arguments): string
{
    $mode = 'dry-run';
    $explicitModes = 0;
    foreach ($arguments as $argument) {
        if ($argument === '--help' || $argument === '-h') {
            return 'help';
        }
        if ($argument === '--dry-run') {
            $mode = 'dry-run';
            $explicitModes++;
            continue;
        }
        if ($argument === '--apply') {
            $mode = 'apply';
            $explicitModes++;
            continue;
        }
        fwrite(STDERR, "Option inconnue : {$argument}\n");
        cleanupUsage();
        exit(2);
    }
    if ($explicitModes > 1) {
        fwrite(STDERR, "Choisissez un seul mode : --dry-run ou --apply.\n");
        exit(2);
    }
    return $mode;
}

function cleanupUsage(): void
{
    echo "Usage : php tools/cleanup.php [--dry-run|--apply]\n";
    echo "  sans option / --dry-run : simule et affiche les volumes, sans écriture (défaut)\n";
    echo "  --apply                 : applique la purge dans une transaction\n";
}

function retentionDays(array $privacy, string $key, int $default): int
{
    $days = isset($privacy[$key]) ? (int) $privacy[$key] : $default;
    if ($days < 1 || $days > 3650) {
        throw new RuntimeException("Durée de conservation invalide pour {$key} (1 à 3650 jours attendus).");
    }
    return $days;
}

function schoolYearEnd(string $schoolYear): ?DateTimeImmutable
{
    if (!preg_match('/^(\d{4})-(\d{4})$/', $schoolYear, $matches)) {
        return null;
    }
    $startYear = (int) $matches[1];
    $endYear = (int) $matches[2];
    if ($endYear !== $startYear + 1) {
        return null;
    }
    return new DateTimeImmutable(sprintf('%04d-08-31 23:59:59', $endYear), new DateTimeZone('UTC'));
}

function knownSchoolYears(PDO $pdo): array
{
    $statement = $pdo->query(
        'SELECT school_year FROM students
         UNION SELECT school_year FROM student_imports
         UNION SELECT school_year FROM action_records
         UNION SELECT school_year FROM digital_passes
         ORDER BY school_year'
    );
    return array_values(array_unique(array_map('strval', array_column($statement->fetchAll(), 'school_year'))));
}

function countInconsistentActions(PDO $pdo): int
{
    $statement = $pdo->query(
        'SELECT COUNT(*) FROM action_records a
         INNER JOIN students s ON s.id = a.student_id
         WHERE a.school_year <> s.school_year'
    );
    return (int) $statement->fetchColumn();
}

function cleanupCounts(PDO $pdo, array $schoolYears, string $auditCutoff, string $loginCutoff): array
{
    $counts = emptyCleanupCounts();
    $countObservations = $pdo->prepare(
        'SELECT COUNT(*) FROM observations o
         INNER JOIN students s ON s.id = o.student_id WHERE s.school_year = :school_year'
    );
    $countDigitalPasses = $pdo->prepare(
        'SELECT COUNT(*) FROM digital_passes WHERE school_year = :school_year'
    );
    $countAdjustments = $pdo->prepare(
        'SELECT COUNT(*) FROM point_adjustments a
         INNER JOIN students s ON s.id = a.student_id WHERE s.school_year = :school_year'
    );
    $countActions = $pdo->prepare('SELECT COUNT(*) FROM action_records WHERE school_year = :school_year');
    $countImports = $pdo->prepare('SELECT COUNT(*) FROM student_imports WHERE school_year = :school_year');
    $countStudents = $pdo->prepare('SELECT COUNT(*) FROM students WHERE school_year = :school_year');
    foreach ($schoolYears as $schoolYear) {
        $parameters = ['school_year' => $schoolYear];
        foreach (
            [
                'observations' => $countObservations,
                'digital_passes' => $countDigitalPasses,
                'point_adjustments' => $countAdjustments,
                'action_records' => $countActions,
                'student_imports' => $countImports,
                'students' => $countStudents,
            ] as $key => $statement
        ) {
            $statement->execute($parameters);
            $counts[$key] += (int) $statement->fetchColumn();
        }
    }
    $counts['school_years'] = count($schoolYears);

    $countAudits = $pdo->prepare('SELECT COUNT(*) FROM audit_logs WHERE created_at < :cutoff');
    $countAudits->execute(['cutoff' => $auditCutoff]);
    $counts['audit_logs'] = (int) $countAudits->fetchColumn();

    $countAttempts = $pdo->prepare('SELECT COUNT(*) FROM login_attempts WHERE attempted_at < :cutoff');
    $countAttempts->execute(['cutoff' => $loginCutoff]);
    $counts['login_attempts'] = (int) $countAttempts->fetchColumn();

    return $counts;
}

function emptyCleanupCounts(): array
{
    return [
        'school_years' => 0,
        'observations' => 0,
        'digital_passes' => 0,
        'point_adjustments' => 0,
        'action_records' => 0,
        'student_imports' => 0,
        'students' => 0,
        'audit_logs' => 0,
        'login_attempts' => 0,
    ];
}

function printCleanupHeader(
    string $mode,
    string $activeSchoolYear,
    int $inactiveYearRetentionDays,
    int $auditRetentionDays,
    int $loginRetentionDays,
    array $eligibleSchoolYears,
    array $protectedSchoolYears,
    array $invalidSchoolYears
): void {
    echo 'Mode : ' . ($mode === 'apply' ? 'APPLICATION' : 'SIMULATION (aucune écriture)') . "\n";
    echo "Année active protégée : {$activeSchoolYear}\n";
    echo "Anciennes années : fin d’année scolaire + {$inactiveYearRetentionDays} jours\n";
    echo "Journaux d’audit : {$auditRetentionDays} jours ; tentatives de connexion : {$loginRetentionDays} jours\n";
    echo 'Années éligibles : ' . (count($eligibleSchoolYears) > 0 ? implode(', ', $eligibleSchoolYears) : 'aucune') . "\n";
    foreach ($protectedSchoolYears as $schoolYear => $reason) {
        echo "  - {$schoolYear} : {$reason}\n";
    }
    foreach ($invalidSchoolYears as $schoolYear) {
        echo "  - {$schoolYear} : format invalide, ignorée par sécurité\n";
    }
}

function printCleanupCounts(array $counts, string $title): void
{
    echo "\n{$title} :\n";
    echo "  années scolaires : {$counts['school_years']}\n";
    echo "  observations : {$counts['observations']}\n";
    echo "  points rendus : {$counts['point_adjustments']}\n";
    echo "  actions éducatives : {$counts['action_records']}\n";
    echo "  historiques d’import : {$counts['student_imports']}\n";
    echo "  élèves : {$counts['students']}\n";
    echo "  journaux d’audit : {$counts['audit_logs']}\n";
    echo "  tentatives de connexion : {$counts['login_attempts']}\n";
}
