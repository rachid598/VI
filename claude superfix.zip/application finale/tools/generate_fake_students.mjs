import { mkdirSync, writeFileSync } from "node:fs";
import { dirname, resolve } from "node:path";
import { fileURLToPath } from "node:url";

const firstNames = [
  "Adèle", "Adam", "Aïcha", "Alban", "Alexis", "Alice", "Amin", "Amira", "Anaïs", "Anis",
  "Assia", "Aya", "Baptiste", "Bilal", "Camille", "Célia", "Chloé", "Clara", "Clément", "Dalia",
  "Diane", "Eden", "Élias", "Élise", "Emma", "Enzo", "Eva", "Farah", "Gabriel", "Gaël",
  "Hana", "Hugo", "Ibrahim", "Imane", "Inès", "Isaac", "Jade", "Jasmine", "Jules", "Juliette",
  "Kamel", "Kenzo", "Lana", "Léa", "Léna", "Liam", "Lila", "Lina", "Lisa", "Louise",
  "Lucas", "Maël", "Maëlys", "Malo", "Mariam", "Mathis", "Maya", "Mehdi", "Mélina", "Mila",
  "Mohamed", "Naël", "Nassim", "Nathan", "Nina", "Noah", "Noémie", "Nour", "Océane", "Omar",
  "Paul", "Pauline", "Rania", "Raphaël", "Rayan", "Romane", "Sacha", "Salma", "Samir", "Sarah",
  "Sofia", "Sohan", "Soraya", "Théo", "Thomas", "Timéo", "Valentine", "Victor", "Yanis", "Yasmine",
  "Youssef", "Yuna", "Zacharie", "Zélie", "Amine", "Émile", "Louna", "Marius", "Naïm", "Zoé",
];

const lastNames = [
  "Albert", "Allard", "André", "Arnaud", "Aubert", "Barbier", "Baron", "Bensaïd", "Berger", "Bernard",
  "Bertrand", "Blanc", "Boulanger", "Bourgeois", "Brun", "Carlier", "Carpentier", "Chevalier", "Cohen", "Collet",
  "Da Silva", "David", "Delattre", "Denis", "Diallo", "Dumont", "Dupont", "Duval", "Faure", "Fernandes",
  "Fontaine", "Fournier", "Garcia", "Garnier", "Gauthier", "Girard", "Giraud", "Gomes", "Gonzalez", "Guérin",
  "Haddad", "Henry", "Hubert", "Jacob", "Jean", "Khelifi", "Lacroix", "Lambert", "Laurent", "Leclerc",
  "Legrand", "Lemaire", "Lemoine", "Leroy", "Lopez", "Marchal", "Marchand", "Marin", "Martinez", "Marty",
  "Masson", "Mercier", "Meyer", "Michel", "Moreau", "Moulin", "Muller", "Nguyen", "Nicolas", "Noël",
  "Olivier", "Paris", "Perrin", "Petit", "Picard", "Renaud", "Renard", "Richard", "Rivière", "Robert",
  "Robin", "Rodrigues", "Rossi", "Roux", "Roy", "Sanchez", "Simon", "Thomas", "Traoré", "Valentin",
  "Vidal", "Vincent", "Wagner", "Weber", "Ziani", "Benali", "Benkacem", "Camara", "Delaunay", "Lefèvre",
];

const levels = ["6", "5", "4", "3"];
const groupsPerLevel = 7;
const studentsPerLevel = 25;
const rows = ["ID;NOM;PRENOM;CLASSE"];
const identities = new Set();
let index = 0;

for (const level of levels) {
  for (let position = 0; position < studentsPerLevel; position += 1) {
      const firstName = firstNames[index % firstNames.length];
      const cycle = Math.floor(index / firstNames.length);
      const lastName = lastNames[(index * 37 + cycle * 11) % lastNames.length];
      const identityKey = `${lastName.toLocaleLowerCase("fr-FR")}|${firstName.toLocaleLowerCase("fr-FR")}`;
      if (identities.has(identityKey)) {
        throw new Error(`Identité dupliquée détectée : ${firstName} ${lastName}`);
      }
      identities.add(identityKey);
      const group = Math.floor((position * groupsPerLevel) / studentsPerLevel) + 1;
      rows.push(`FICTIF-${String(index + 1).padStart(4, "0")};${lastName};${firstName};${level}G${group}`);
      index += 1;
  }
}

const here = dirname(fileURLToPath(import.meta.url));
const destination = resolve(here, "../donnees/eleves-fictifs-100.csv");
mkdirSync(dirname(destination), { recursive: true });
writeFileSync(destination, `${rows.join("\n")}\n`, "utf8");
console.log(`${index} élèves fictifs uniques écrits dans ${destination}`);
