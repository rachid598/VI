# Récupération et purge depuis la WebUI

## Ce que protège ce dispositif

L’application conserve des **points de récupération** dans la base MySQL de
l’installation ouverte. Ils servent à revenir rapidement sur une erreur faite
depuis l’application, notamment une purge accidentelle ou une mauvaise
restauration.

Ce mécanisme n’est **pas une sauvegarde hors serveur** : les points de récupération
sont stockés dans la même base que les données courantes. Ils ne protègent donc
pas contre la perte du serveur Kwartz, la suppression ou la corruption de la base,
une panne du disque, un incident MySQL global ou la compromission du serveur. Une
copie MySQL externe reste la seule protection contre ces événements.

## Fonctionnement sans tâche planifiée

La création est déclenchée uniquement par l’activité de la WebUI : la session
ouverte interroge périodiquement le serveur et chaque action authentifiée normale
refait aussi le contrôle. Si le dernier point remonte à au moins 30 minutes, le
serveur crée le point suivant avant de poursuivre.

Par conséquent :

- il n’existe aucun processus qui se réveille seul toutes les 30 minutes ;
- aucun point n’est créé à une heure exacte si aucune WebUI n’est ouverte et
  active ; un onglet suspendu par le téléphone ou le navigateur n’est pas une
  garantie d’activité ;
- la première activité suivante déclenche le point manquant, sans tenter de
  fabriquer artificiellement les créneaux écoulés ;
- plusieurs personnes actives au même moment ne doivent créer qu’un seul point
  pour la même période de 30 minutes.

Sur sept jours, une activité continue représenterait environ 48 points
automatiques par jour, soit **336 points automatiques au maximum théorique par
environnement**. Les points manuels et les points de sécurité peuvent s’y ajouter,
mais un plafond physique conserve au plus **400 points par environnement**. En
usage réel, il y en aura souvent moins, car les nuits, week-ends et périodes sans
activité ne créent aucun état.

La WebUI d’administration doit aussi permettre de créer manuellement un point
immédiat. Cette action ne remplace pas une sauvegarde MySQL externe.

## Données enregistrées et restaurées

Un point de récupération couvre les données métier liées aux élèves :

- élèves et classes ;
- historiques d’import ou de synchronisation des élèves ;
- observations et leur état ;
- billets numériques et leur état ;
- points rendus ;
- actions éducatives suivies ;
- clôtures annuelles et agrégats anonymisés.

Une restauration remet **cet ensemble** dans l’état exact du point choisi. Les
données métier créées après ce point peuvent donc disparaître. La WebUI doit
l’annoncer clairement et afficher les volumes qui seront remplacés.

Les éléments suivants sont conservés et ne sont ni purgés ni restaurés :

- comptes utilisateurs, rôles et autorisations d’accès ;
- configuration de l’application et année scolaire active ;
- configuration LDAP/MySQL de `var/settings.php` ;
- tentatives de connexion ;
- journal d’audit ;
- points de récupération eux-mêmes.

Chaque point doit porter au minimum son environnement, sa date UTC, son année
scolaire de référence, sa version de schéma, sa provenance et une empreinte
d’intégrité. Une restauration doit être refusée si l’environnement ne correspond
pas ou si la version de schéma n’est pas compatible.

L’environnement provient de `app.environment` dans `var/settings.php`. Pour une
ancienne configuration sans cette clé, l’application peut déduire `test` si le
nom du dossier contient `test` ou `demo` ; dans tous les autres cas, elle doit
choisir le comportement prudent `production`. Il reste préférable d’ajouter
explicitement `environment => 'test'` ou `environment => 'production'` dans la
section `app` avant d’activer les opérations destructrices.

## Bouton « Purger tous les élèves »

Le bouton est disponible dans les administrations **test et production**, mais
reste réservé au rôle administrateur. Il supprime toutes les données métier
énumérées ci-dessus, pour toutes les années, sans supprimer les utilisateurs, les
réglages, l’audit ni les points de récupération.

Le parcours impose, dans cet ordre :

1. l’affichage des nombres actuels d’élèves, observations, points, actions et
   imports concernés ;
2. un rappel très visible de l’environnement concerné ;
3. une réauthentification LDAP ponctuelle du compte administrateur courant,
   exigée pour cette purge ;
4. la saisie exacte de `VIDER TEST {année_scolaire}` ou
   `VIDER PRODUCTION {année_scolaire}`, par exemple
   `VIDER PRODUCTION 2026-2027` ;
5. la création obligatoire d’un point marqué « avant purge » ;
6. la purge et son enregistrement dans l’audit, dans une opération atomique.

Le mot de passe LDAP ne doit jamais être stocké, renvoyé dans une réponse,
inscrit dans les journaux ni placé dans le point de récupération. Si LDAP est
indisponible ou si la création du point échoue, la purge doit être refusée sans
suppression partielle. Le point créé juste avant la purge contient les volumes
réellement présents au moment de l’opération.

L’autorisation doit être recalculée côté serveur pour chaque opération. La purge
et la restauration utilisent exclusivement des requêtes `POST`, un jeton CSRF,
une réauthentification LDAP ponctuelle demandée à chaque action, ainsi qu’une
limitation des échecs LDAP. Elles exigent HTTPS. Le journal d’audit conserve
l’administrateur, l’environnement, les compteurs et l’identifiant du point,
jamais le mot de passe ni le contenu nominatif du point.

## Restaurer un point

La restauration est également réservée à l’administrateur. La liste doit afficher
la date, la provenance, l’environnement, l’année scolaire et les volumes du point,
sans afficher le contenu nominatif dans la liste.

Avant de restaurer :

1. afficher ce qui sera remplacé et préciser que les données plus récentes peuvent
   disparaître ;
2. exiger une nouvelle authentification LDAP ponctuelle pour cette restauration ;
3. exiger la phrase exacte `RESTAURER TEST {snapshot_id}` ou
   `RESTAURER PRODUCTION {snapshot_id}`, avec l’identifiant affiché par la WebUI ;
4. créer obligatoirement un nouveau point marqué « avant restauration » ;
5. verrouiller les écritures métier concurrentes pendant l’opération ;
6. restaurer toutes les tables concernées dans une seule transaction ;
7. conserver et compléter le journal d’audit.

Le point créé avant la restauration permet d’annuler une restauration mal choisie.
Si sa création ou le contrôle d’intégrité du point cible échoue, aucune donnée ne
doit être modifiée.

## Conservation pendant sept jours

Les points de récupération sont supprimés après **sept jours glissants**. Sans
tâche planifiée, cette suppression se fait lors de la prochaine activité de la
WebUI, de l’ouverture de l’administration ou de la création d’un nouveau point.
Un point expiré peut donc rester physiquement présent un peu plus de sept jours si
l’application n’est pas utilisée, mais il ne doit plus être proposé comme
restaurable.

Les points « avant purge » et « avant restauration » suivent la même durée de
sept jours. Le stockage est borné au premier seuil atteint : 400 points ou
512 Mio par environnement. Les plus anciens points expirés ou excédentaires sont
supprimés en priorité.

Ces états dupliquent des données personnelles. Leur accès doit rester strictement
administratif, leur contenu ne doit pas être mis dans le cache PWA et aucune URL
publique ne doit permettre de les télécharger.

## Contraintes techniques à valider

- Les tables métier et la table de récupération doivent utiliser un moteur MySQL
  transactionnel. Les clés étrangères doivent être restaurées dans un ordre testé.
- Un verrou MySQL et un second contrôle transactionnel du dernier point empêchent
  les doublons lors de requêtes simultanées.
- Le format doit être versionné, authentifié par une empreinte liée à la clé de
  l’application et, si possible, compressé. Les limites PHP, MySQL
  `max_allowed_packet`, disque et temps de requête doivent être mesurées.
- Un état complet répété jusqu’à 400 fois peut devenir volumineux si les
  observations s’accumulent. La limite en nombre ne dispense pas d’une limite de
  taille et d’une alerte de capacité.
- Une restauration d’un ancien schéma doit être refusée tant qu’une stratégie de
  conversion n’a pas été testée ; elle ne doit jamais deviner une conversion.
- Les écritures concurrentes doivent être bloquées ou refusées pendant purge et
  restauration, avec un message clair pour les autres utilisateurs.
- La création automatique ne doit pas ralentir silencieusement une saisie : les
  durées doivent être mesurées sur le volume cible et tout échec doit être visible
  dans l’administration.

## Indications attendues dans l’administration

La section **Protection et récupération** doit montrer sans ambiguïté :

- le badge `TEST` ou `PRODUCTION` ;
- la date du dernier point réussi et son origine ;
- le nombre de points conservés et leur volume MySQL cumulé ;
- la mention « récupération locale dans la même base — pas une sauvegarde du
  serveur » ;
- un bouton secondaire « Créer un point maintenant » ;
- la liste des 30 points restaurables les plus récents ;
- un bouton de restauration par point ;
- le bouton de purge, visuellement séparé des actions ordinaires.

Les actions longues doivent désactiver les boutons concernés, annoncer leur
progression et présenter une réussite ou une erreur exploitable. Une fermeture de
l’onglet ne doit jamais laisser une demi-purge ou une demi-restauration : la
transaction serveur doit soit aboutir entièrement, soit être annulée.

## Vérifications avant utilisation réelle

1. Créer des données fictives dans `suivi-test` et forcer un point manuel.
2. Modifier ces données, restaurer le point et comparer tous les compteurs.
3. Vérifier qu’utilisateurs, réglages, audit et points de récupération sont restés
   intacts.
4. Tester un échec LDAP, une phrase incorrecte et une requête simultanée : aucune
   donnée ne doit être supprimée.
5. Purger le test, puis restaurer le point « avant purge ».
6. Vérifier que le test n’affiche jamais les points de production, et inversement.
7. Mesurer le temps et l’espace nécessaires avec un volume proche de 700 élèves et
   sept jours de points.
8. Conserver malgré tout une sauvegarde MySQL externe vérifiée avant d’activer la
   purge en production.
