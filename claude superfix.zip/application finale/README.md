# Suivi des circulations — v1.0.0-rc.4

Cette livraison est la première **version candidate** avant la mise en production
officielle. Le numéro de version est centralisé dans `VERSION` et affiché sur
l’écran de connexion, dans le menu et dans la santé de l’application.

Cette version indépendante réunit le socle complet de **Suivi impeccable** et les
idées utiles développées dans la branche Claude. **Un seul et même ZIP** est copié
dans deux dossiers web Kwartz distincts : `suivi-test` pour la démonstration et
`suivi` pour la production. L’installation de test utilise la base et l’utilisateur
MySQL `suivi_test` ; la production utilise la base et l’utilisateur `suivi`.

Chaque dossier crée et conserve son propre `var/settings.php`. Les deux fichiers
ne doivent jamais être copiés l’un sur l’autre. Le cookie de session est
automatiquement limité au chemin web de son installation (`/suivi-test/` ou
`/suivi/`) : aucune modification manuelle du nom de session ou du cookie n’est
nécessaire.

## Ce que la fusion conserve

- authentification LDAP Kwartz et liste d’accès administrable ;
- saisie, anti-doublon, modification et retrait d’un signalement en attente ;
- signalement groupé jusqu’à huit élèves, créé dans une seule transaction ;
- validation chronologique avec motif d’annulation ;
- historique élève, bilan PP, audit et gestion de l’année scolaire ;
- créneaux exacts du collège, PWA sécurisée et thèmes clair/sombre ;
- interface institutionnelle responsive avec le formulaire en priorité.

## Fonctions Claude intégrées

- un point peut être rendu par un CPE, la direction ou l’administrateur, avec motif ;
- seuils d’action éducative suivis et journalisés ;
- export CSV compatible Excel français, protégé contre les formules injectées ;
- badge d’élèves en alerte dans le menu ;
- filtres par niveau et par classe ;
- aperçu puis impression d’un courrier famille prérempli ;
- total des points rendus et des actions à suivre dans le tableau Permis.

## Nouveautés reprises du ZIP du 13 juillet 2026

- synchronisation des élèves depuis les groupes-classes LDAP Kwartz ;
- aperçu des effectifs par classe avant toute modification ;
- blocage si l’annuaire change entre l’aperçu et l’application ;
- blocage d’une baisse supérieure à 20 % de l’effectif actif pour éviter une
  désactivation massive après une réponse LDAP incomplète ;
- import CSV SIECLE toujours disponible comme solution de secours ;
- détection d’un signalement récent même si le lieu ou le motif diffère ;
- actualisation discrète du badge d’alerte pendant la session.

## Sécurité ajoutée pendant la fusion

- migration MySQL versionnée en base, sans marqueur fichier fragile ;
- verrou transactionnel pour empêcher deux points rendus simultanément ;
- vérification serveur qu’un seuil est réellement franchi ;
- export CSV en POST avec CSRF et journal d’audit ;
- cache PWA isolé pour ne pas supprimer celui des autres versions ;
- module permis à points activable ou désactivable par l’administrateur ;
- mode test/production choisi à l’installation et clairement identifiable ;
- purge contrôlée avec aperçu avant application ;
- purge complète des données élèves depuis la WebUI, protégée par
  réauthentification LDAP, phrase de confirmation et point préalable ;
- points de récupération à l’activité, au plus toutes les 30 minutes, conservés
  sept jours et restaurables par un administrateur, avec plafonds de 400 points
  et 512 Mio par environnement ;
- contrôle admin, CSRF, aperçu signé et journal d’audit pour la synchronisation LDAP.

Les points de récupération restent dans la base MySQL de l’environnement ouvert.
Ils protègent d’une erreur applicative, mais **ne constituent pas une sauvegarde
hors serveur**. Sans activité WebUI, aucun point n’est créé à heure fixe. Voir
`RECUPERATION_WEBUI.md` avant d’activer la purge en production.

Voir `INSTALLATION_3_ETAPES.md` pour un test parallèle et
`MISE_A_JOUR_v1.0.0-rc.3.md` avant toute mise à jour. Les changements de chaque
livraison sont consignés dans `CHANGELOG.md`.

## Fonctions de l’application finale

- heure réelle du constat réglable précisément entre maintenant et 20 minutes
  auparavant, calculée par le serveur ;
- onglets complets pour retrouver ses signalements en attente, confirmés ou annulés ;
- file CPE/AED filtrable, prise en charge temporaire et parcours à sélection explicite ;
- intensité fixe et comparable des créneaux chauds ;
- rapport anonymisé sur 7, 28 ou 90 jours, export CSV et impression PDF ;
- santé de l’application, rôle préattribué aux accès LDAP individuels et
  date d’expiration facultative ;
- rôle administrateur réservé aux comptes initiaux déclarés sur le serveur ;
- clôture contrôlée d’une ancienne année avec agrégats anonymisés ;
- billets numériques temporaires, désactivés par défaut et activables depuis
  l’administration ; leur liste globale est réservée à la vie scolaire,
  direction et administration.
- contexte minimal du billet valable à l’heure du constat, visible dans la file
  de vérification et les parcours rapprochés, sans décision automatique.

## Nouveautés de la version candidate 4

- saisie hors connexion : un constat envoyé pendant une coupure réseau attend
  sur l’appareil (10 constats et 12 heures maximum) puis part automatiquement à
  la reconnexion, sans doublon ;
- tests automatisés des calculs critiques : `php tests/run-tests.php`, sans
  base de données ni dépendance ;
- purge RGPD de fin d’année programmable par cron avec `tools/purge-rgpd.sh`
  (voir `CONSERVATION_ET_PURGE.md`) ;
- vérification du déploiement (en-têtes de sécurité, 403 sur `var/`, `src/`
  et les autres dossiers protégés, extensions PHP) :
  `php tools/verifier-deploiement.php https://serveur/suivi/` ;
- administrateur de secours facultatif proposé à l’installation et vérifié
  dans l’annuaire ; les installations existantes peuvent l’ajouter dans
  `bootstrap_admins` de `var/settings.php` (voir `MISE_A_JOUR_v1.0.0-rc.4.md`).
