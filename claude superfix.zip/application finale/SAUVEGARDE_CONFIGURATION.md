# Sauvegarder `var/settings.php`

La base MySQL et `var/settings.php` sont deux sauvegardes différentes. La base
contient les données ; `settings.php` contient les paramètres LDAP/MySQL, la clé
de sécurité de l’application et le mode test ou production.

Avec les deux installations, il existe donc quatre éléments distincts à protéger :

- la base `suivi_test`, son utilisateur MySQL `suivi_test` et
  `suivi-test/var/settings.php` ;
- la base `suivi`, son utilisateur MySQL `suivi` et
  `suivi/var/settings.php`.

Ils proviennent du même ZIP applicatif, mais ne doivent jamais être regroupés ou
intervertis. Les cookies, eux, sont automatiquement isolés par les chemins web
`/suivi-test/` et `/suivi/` et ne nécessitent aucune sauvegarde.

## Avant une mise à jour

1. Dans le gestionnaire de fichiers Kwartz utilisé pour publier le site, ouvrir
   le dossier de l’installation, puis `var`.
2. Télécharger ou copier `settings.php` vers un emplacement administratif
   protégé et autorisé par l’établissement.
3. Le nommer clairement, par exemple
   `settings-suivi-production-2026-07-13.php`.
4. Conserver séparément la copie du test et celle de la production.

Ce fichier contient le mot de passe MySQL. Ne jamais l’ajouter au ZIP, l’envoyer
par courriel ou le déposer dans un espace personnel non validé. Si le gestionnaire
Kwartz ne permet pas de le télécharger, demander à l’administrateur réseau une
copie protégée hors du dossier HTML.

## Vérifier la protection web

Pour la production, ouvrir directement :

`https://votre-serveur:8443/suivi/var/settings.php`

Pour le test, ouvrir également :

`https://votre-serveur:8443/suivi-test/var/settings.php`

Les deux adresses doivent répondre **403 / accès interdit**. Le contenu PHP, un
écran blanc avec un code 200 ou un téléchargement du fichier ne sont pas
acceptables.

Faire le même contrôle pour `/database/`, `/src/` et `/tools/` sous chacun des
deux dossiers web.

## Restaurer

1. Restaurer la base correspondant exactement à l’environnement : `suivi_test`
   pour `suivi-test`, ou `suivi` pour `suivi`.
2. Remettre la copie de `settings.php` dans le dossier `var` de cette même
   installation, jamais dans l’autre dossier.
3. Si Kwartz expose les permissions, utiliser `0640` pour ce fichier.
4. Ne jamais restaurer la configuration de `suivi-test` dans `suivi`, ni
   l’inverse.

Le ZIP applicatif commun ne contient aucun `var/settings.php`. Une mise à jour par
copie ne doit donc pas écraser les deux configurations locales ; il faut néanmoins
conserver séparément leur copie avant toute intervention.
