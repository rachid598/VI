# Conservation et purge

Le nettoyage est un traitement de **fin d’année scolaire**. Il ne doit jamais
modifier le calcul du permis à points pendant l’année active.

Le même ZIP est installé dans `suivi-test` et `suivi`, mais chaque copie du script
charge uniquement le `var/settings.php` de son propre dossier. Elle agit donc sur
une seule base avec l’utilisateur associé : `suivi_test` côté test, `suivi` côté
production. Ce nettoyage de fin d’année reste une opération manuelle distincte
des points de récupération et de la purge totale disponibles dans la WebUI.
L’isolation automatique des cookies par chemin n’a aucune incidence sur ce
traitement en ligne de commande.

## Règles appliquées

- L’année définie comme active dans `app_settings` est toujours protégée.
- Ses observations, points rendus et actions éducatives ne sont jamais supprimés
  par une simple ancienneté en jours.
- Une année inactive devient éligible seulement après le 31 août de son année de
  fin, augmenté du délai de conservation configuré.
- Une purge d’année supprime, dans une seule transaction : observations, points
  rendus, actions éducatives, historiques d’import, puis fiches élèves.
- Les journaux d’audit et tentatives de connexion suivent leurs propres délais.
- Une incohérence entre l’année d’une action éducative et celle de l’élève bloque
  l’application de la purge. Elle doit être examinée manuellement.

Les comptes utilisateurs ne sont ni supprimés ni anonymisés automatiquement.
Ils sont référencés par les observations, imports et journaux d’audit ; une
suppression automatique serait risquée. Leur politique de fin de compte doit être
validée séparément avec le DPD et mise en œuvre après étude des références.

## Configuration

La section `privacy` du `var/settings.php` de chaque installation accepte :

```php
'privacy' => [
    'observation_retention_days' => 120,
    'inactive_school_year_retention_days' => 120,
    'audit_retention_days' => 365,
    'login_attempt_retention_days' => 30,
],
```

`inactive_school_year_retention_days` est facultatif. S’il manque, la valeur de
`observation_retention_days` est réutilisée. Le délai commence après le 31 août,
et non à la date de chaque observation. `login_attempt_retention_days` vaut
30 jours par défaut.

Les durées acceptées vont de 1 à 3650 jours. Elles doivent être validées avant
l’utilisation de données réelles.

## Exécution sûre

Depuis le dossier de l’installation concernée (`suivi-test` ou `suivi`) :

```sh
php tools/cleanup.php
```

Sans option, le script est en mode `--dry-run` : il affiche les années et volumes
concernés sans aucune écriture en base. `--dry-run` peut aussi être indiqué
explicitement.

Après lecture du bilan et sauvegarde de la base et du `var/settings.php`
correspondants :

```sh
php tools/cleanup.php --apply
```

`--apply` est la seule option qui supprime des données. Toutes les suppressions et
l’enregistrement du bilan sont atomiques : en cas d’erreur, la transaction est
annulée.

Après un nettoyage appliqué, les clés suivantes sont enregistrées dans
`app_settings` :

- `privacy_cleanup_last_applied_at` : date UTC du dernier succès ;
- `privacy_cleanup_last_status` : `success` ;
- `privacy_cleanup_last_result` : compteurs JSON des suppressions.

Une simulation ne modifie jamais ces clés.

## Exploitation Kwartz

1. Pour `suivi-test`, sauvegarder `suivi_test` et
   `suivi-test/var/settings.php`, puis vérifier la restauration de cette paire.
2. Pour `suivi`, sauvegarder `suivi` et `suivi/var/settings.php`, puis vérifier la
   restauration de cette autre paire.
3. Exécuter une simulation dans chaque dossier et conserver les deux sorties.
4. Contrôler séparément l’année active et les années éligibles.
5. Exécuter `--apply` manuellement une première fois dans le dossier voulu.
6. Répéter manuellement l’opération dans l’autre environnement seulement si sa
   propre politique de conservation l’exige.
7. Vérifier les trois clés `privacy_cleanup_last_*` dans chacune des deux bases.

## Purge automatique à chaque fin d’année scolaire (cron)

Une fois les durées de conservation validées avec le DPD et une première purge
appliquée manuellement avec succès, la purge peut être programmée pour que
**chaque fin d’année scolaire soit traitée automatiquement**, sans intervention.

L’enveloppe `tools/purge-rgpd.sh` exécute `cleanup.php --apply` depuis le bon
dossier et conserve le compte rendu complet dans `var/purge-rgpd.log` (protégé
du web par `var/.htaccess`, avec rotation automatique).

Ligne crontab recommandée, une par installation, le 1ᵉʳ de chaque mois à 3 h 30 :

```cron
30 3 1 * * /bin/sh /chemin/vers/suivi/tools/purge-rgpd.sh
```

Fonctionnement avec les valeurs par défaut (120 jours après le 31 août) :

- l’année scolaire terminée devient éligible fin décembre ; l’exécution de
  janvier la purge automatiquement — chaque fin d’année est donc couverte ;
- les passages mensuels intermédiaires entretiennent en continu les journaux
  d’audit (365 jours) et les tentatives de connexion (30 jours) ;
- l’année active reste toujours protégée, et une incohérence de données bloque
  la purge (code de sortie 3) sans rien supprimer : consultez alors le journal.

Vérifications périodiques conseillées : lire `var/purge-rgpd.log` après le
passage de janvier, et contrôler les clés `privacy_cleanup_last_*` dans
`app_settings`. La sauvegarde préalable de la base et du `var/settings.php`
reste de la responsabilité de l’exploitation Kwartz.

Les points de récupération toutes les 30 minutes, la purge totale et la
restauration restent gérés depuis la WebUI : ils sont indépendants de ce
nettoyage de fin d’année.

Ne stockez jamais les sauvegardes dans le dossier HTML publié.
