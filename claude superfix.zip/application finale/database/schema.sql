SET NAMES utf8mb4;
SET time_zone = '+00:00';

CREATE TABLE IF NOT EXISTS users (
    id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
    ldap_uid VARCHAR(64) NOT NULL,
    first_name VARCHAR(128) NOT NULL DEFAULT '',
    last_name VARCHAR(128) NOT NULL DEFAULT '',
    email VARCHAR(255) NOT NULL DEFAULT '',
    role ENUM('teacher','aed','cpe','direction','pp','service','admin') NOT NULL DEFAULT 'teacher',
    pp_class VARCHAR(32) NULL,
    active TINYINT(1) NOT NULL DEFAULT 1,
    last_login_at DATETIME NULL,
    created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    PRIMARY KEY (id),
    UNIQUE KEY uq_users_ldap_uid (ldap_uid),
    KEY idx_users_role_active (role, active)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS students (
    id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
    external_ref VARCHAR(128) NOT NULL,
    school_year VARCHAR(16) NOT NULL,
    first_name VARCHAR(128) NOT NULL,
    last_name VARCHAR(128) NOT NULL,
    class_name VARCHAR(32) NOT NULL,
    active TINYINT(1) NOT NULL DEFAULT 1,
    created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    PRIMARY KEY (id),
    UNIQUE KEY uq_students_year_ref (school_year, external_ref),
    KEY idx_students_search (school_year, active, last_name, first_name),
    KEY idx_students_class (school_year, active, class_name)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS observations (
    id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
    student_id BIGINT UNSIGNED NOT NULL,
    reporter_user_id BIGINT UNSIGNED NOT NULL,
    occurred_at DATETIME NOT NULL,
    location VARCHAR(64) NOT NULL,
    reason VARCHAR(96) NOT NULL,
    details VARCHAR(160) NOT NULL DEFAULT '',
    submission_key CHAR(36) NULL,
    digital_pass_destination VARCHAR(96) NULL,
    digital_pass_issued_at DATETIME NULL,
    digital_pass_expires_at DATETIME NULL,
    sequence_key CHAR(32) NULL,
    status ENUM('pending','confirmed','cancelled','withdrawn') NOT NULL DEFAULT 'pending',
    claimed_by_user_id BIGINT UNSIGNED NULL,
    claimed_at DATETIME NULL,
    claim_expires_at DATETIME NULL,
    cancellation_reason VARCHAR(96) NULL,
    validator_user_id BIGINT UNSIGNED NULL,
    validated_at DATETIME NULL,
    withdrawn_at DATETIME NULL,
    created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    PRIMARY KEY (id),
    CONSTRAINT fk_observation_student FOREIGN KEY (student_id) REFERENCES students(id),
    CONSTRAINT fk_observation_reporter FOREIGN KEY (reporter_user_id) REFERENCES users(id),
    CONSTRAINT fk_observation_validator FOREIGN KEY (validator_user_id) REFERENCES users(id),
    CONSTRAINT fk_observation_claimed_by FOREIGN KEY (claimed_by_user_id) REFERENCES users(id),
    KEY idx_observations_status_date (status, occurred_at),
    KEY idx_observations_student_date (student_id, occurred_at),
    KEY idx_observations_sequence (sequence_key),
    KEY idx_observations_claim (status, claim_expires_at, claimed_by_user_id),
    KEY idx_observations_reporter_date (reporter_user_id, occurred_at),
    UNIQUE KEY uq_observations_submission
        (reporter_user_id, student_id, submission_key)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS user_notifications (
    id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
    user_id BIGINT UNSIGNED NOT NULL,
    observation_id BIGINT UNSIGNED NOT NULL,
    event_type ENUM('confirmed','cancelled') NOT NULL,
    created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    read_at DATETIME NULL,
    PRIMARY KEY (id),
    UNIQUE KEY uq_user_notification_event (user_id, observation_id, event_type),
    CONSTRAINT fk_notification_user
        FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
    CONSTRAINT fk_notification_observation
        FOREIGN KEY (observation_id) REFERENCES observations(id) ON DELETE CASCADE,
    KEY idx_notifications_user_read (user_id, read_at, created_at)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS authorized_users (
    id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
    ldap_uid VARCHAR(64) NOT NULL,
    label VARCHAR(128) NOT NULL DEFAULT '',
    preassigned_role ENUM('teacher','aed','cpe','direction','pp','service','admin') NULL,
    preassigned_pp_class VARCHAR(32) NULL,
    active TINYINT(1) NOT NULL DEFAULT 1,
    access_expires_at DATETIME NULL,
    created_by BIGINT UNSIGNED NULL,
    created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    PRIMARY KEY (id),
    UNIQUE KEY uq_authorized_users_uid (ldap_uid),
    CONSTRAINT fk_authorized_user_creator FOREIGN KEY (created_by) REFERENCES users(id),
    KEY idx_authorized_users_active (active),
    KEY idx_authorized_users_expiry (active, access_expires_at)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS app_settings (
    setting_key VARCHAR(64) NOT NULL,
    setting_value VARCHAR(255) NOT NULL,
    updated_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    PRIMARY KEY (setting_key)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS audit_logs (
    id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
    user_id BIGINT UNSIGNED NULL,
    action VARCHAR(64) NOT NULL,
    entity_type VARCHAR(64) NOT NULL,
    entity_id BIGINT UNSIGNED NULL,
    metadata JSON NULL,
    created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY (id),
    CONSTRAINT fk_audit_user FOREIGN KEY (user_id) REFERENCES users(id),
    KEY idx_audit_date (created_at),
    KEY idx_audit_entity (entity_type, entity_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS login_attempts (
    id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
    identifier_hash CHAR(64) NOT NULL,
    success TINYINT(1) NOT NULL DEFAULT 0,
    attempted_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY (id),
    KEY idx_login_attempts_identifier_date (identifier_hash, attempted_at),
    KEY idx_login_attempts_date (attempted_at, id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS student_imports (
    id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
    imported_by BIGINT UNSIGNED NOT NULL,
    school_year VARCHAR(16) NOT NULL,
    row_count INT UNSIGNED NOT NULL,
    source_hash CHAR(64) NOT NULL,
    created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY (id),
    CONSTRAINT fk_import_user FOREIGN KEY (imported_by) REFERENCES users(id),
    KEY idx_import_date (created_at)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS point_adjustments (
    id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
    student_id BIGINT UNSIGNED NOT NULL,
    granted_by BIGINT UNSIGNED NOT NULL,
    points TINYINT UNSIGNED NOT NULL DEFAULT 1,
    reason VARCHAR(160) NOT NULL,
    created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY (id),
    CONSTRAINT fk_adjustment_student FOREIGN KEY (student_id) REFERENCES students(id),
    CONSTRAINT fk_adjustment_user FOREIGN KEY (granted_by) REFERENCES users(id),
    KEY idx_adjustments_student_date (student_id, created_at)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS action_records (
    id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
    student_id BIGINT UNSIGNED NOT NULL,
    school_year VARCHAR(16) NOT NULL,
    trimester TINYINT UNSIGNED NOT NULL,
    threshold_points INT NOT NULL,
    action_label VARCHAR(96) NOT NULL,
    note VARCHAR(160) NOT NULL DEFAULT '',
    done_by BIGINT UNSIGNED NOT NULL,
    done_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY (id),
    UNIQUE KEY uq_action (student_id, school_year, trimester, threshold_points),
    CONSTRAINT fk_action_student FOREIGN KEY (student_id) REFERENCES students(id),
    CONSTRAINT fk_action_user FOREIGN KEY (done_by) REFERENCES users(id),
    KEY idx_actions_period (school_year, trimester, threshold_points)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS digital_passes (
    id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
    student_id BIGINT UNSIGNED NOT NULL,
    school_year VARCHAR(16) NOT NULL,
    issuer_user_id BIGINT UNSIGNED NOT NULL,
    destination VARCHAR(96) NOT NULL,
    issued_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    expires_at DATETIME NOT NULL,
    revoked_at DATETIME NULL,
    revoked_by_user_id BIGINT UNSIGNED NULL,
    PRIMARY KEY (id),
    CONSTRAINT fk_digital_pass_student FOREIGN KEY (student_id) REFERENCES students(id),
    CONSTRAINT fk_digital_pass_issuer FOREIGN KEY (issuer_user_id) REFERENCES users(id),
    CONSTRAINT fk_digital_pass_revoker FOREIGN KEY (revoked_by_user_id) REFERENCES users(id),
    KEY idx_digital_pass_student_active (student_id, school_year, revoked_at, expires_at),
    KEY idx_digital_pass_student_period (student_id, school_year, issued_at, expires_at),
    KEY idx_digital_pass_year_issued (school_year, issued_at),
    KEY idx_digital_pass_issuer_issued (issuer_user_id, issued_at)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS year_closures (
    id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
    school_year VARCHAR(16) NOT NULL,
    closed_by_user_id BIGINT UNSIGNED NOT NULL,
    closed_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    student_count INT UNSIGNED NOT NULL DEFAULT 0,
    observation_count INT UNSIGNED NOT NULL DEFAULT 0,
    aggregate_sha256 CHAR(64) NOT NULL,
    PRIMARY KEY (id),
    UNIQUE KEY uq_year_closures_school_year (school_year),
    CONSTRAINT fk_year_closure_user FOREIGN KEY (closed_by_user_id) REFERENCES users(id),
    KEY idx_year_closures_closed_at (closed_at)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS annual_aggregates (
    id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
    closure_id BIGINT UNSIGNED NOT NULL,
    school_year VARCHAR(16) NOT NULL,
    metric_key VARCHAR(64) NOT NULL,
    dimension_key VARCHAR(64) NOT NULL DEFAULT '',
    dimension_value VARCHAR(128) NOT NULL DEFAULT '',
    metric_value BIGINT UNSIGNED NOT NULL DEFAULT 0,
    created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY (id),
    UNIQUE KEY uq_annual_aggregate_dimension
        (school_year, metric_key, dimension_key, dimension_value),
    CONSTRAINT fk_annual_aggregate_closure
        FOREIGN KEY (closure_id) REFERENCES year_closures(id) ON DELETE CASCADE,
    KEY idx_annual_aggregates_closure (closure_id),
    KEY idx_annual_aggregates_metric (school_year, metric_key)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS recovery_snapshots (
    id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
    kind ENUM('automatic','manual','before_purge','before_restore') NOT NULL,
    environment VARCHAR(16) NOT NULL,
    school_year VARCHAR(16) NULL,
    format_version SMALLINT UNSIGNED NOT NULL,
    schema_version INT UNSIGNED NOT NULL,
    payload_encoding VARCHAR(16) NOT NULL,
    payload LONGBLOB NOT NULL,
    payload_sha256 CHAR(64) NOT NULL,
    payload_hmac CHAR(64) NOT NULL,
    payload_bytes BIGINT UNSIGNED NOT NULL,
    uncompressed_bytes BIGINT UNSIGNED NOT NULL,
    counts JSON NOT NULL,
    created_by BIGINT UNSIGNED NULL,
    created_at DATETIME NOT NULL,
    expires_at DATETIME NOT NULL,
    PRIMARY KEY (id),
    KEY idx_recovery_created (created_at),
    KEY idx_recovery_kind_created (kind, created_at),
    KEY idx_recovery_expires (expires_at),
    KEY idx_recovery_environment_created (environment, created_at),
    KEY idx_recovery_environment_kind_created (environment, kind, created_at),
    KEY idx_recovery_environment_school_year (environment, school_year)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO app_settings (setting_key, setting_value)
VALUES ('digital_passes_enabled', 'false')
ON DUPLICATE KEY UPDATE setting_key = VALUES(setting_key);
