# Système visuel — institution contemporaine

## Principes

1. La saisie avant tout : le formulaire est la première destination et reçoit la
   composition la plus affirmée de l’application.
2. Une surface, une fonction : bordure nette ou élévation, jamais les deux sans
   raison de superposition.
3. La couleur porte du sens : vert pour le confirmé, ambre pour l’attention, rouge
   uniquement pour l’erreur ou le retrait.
4. Les tableaux assument leur densité et restent horizontalement défilables sur
   mobile plutôt que de masquer des informations.
5. Les états de focus restent visibles au clavier.

## Palette

- Bleu institution : `#102f3a`
- Vert d’action : `#147a50`
- Or de repère : `#c9972d`
- Fond clair : `#f2f5f3`
- Surface claire : `#ffffff`
- Fond sombre : `#0b1519`
- Surface sombre : `#121e22`
- Danger : `#b04444`

## Typographie

- Titres : SF Pro Display / Avenir Next / Segoe UI, gras et compacts.
- Interface : SF Pro Text / Avenir Next / Segoe UI, dense et lisible.
- Capitales et espacement de lettres réservés aux libellés très courts.

## Formes et élévation

- Rayon des surfaces : 9 à 14 px.
- Boutons et champs : 7 à 9 px.
- Ombre très légère sur les cartes ordinaires, avec bordure franche.
- Ombre uniquement pour les menus, modales et navigation mobile superposée.

## Composants

- Navigation bleu institution avec sélection franche et repère or réservé à la
  page active.
- Connexion en composition bicolonne : identité du collège à gauche, formulaire
  sobre à droite ; empilement naturel sur téléphone.
- Sélecteur clair/sombre disponible avant et après connexion, préférence conservée
  uniquement dans le navigateur.
- Cartes statistiques sobres, valeurs dominantes et détails courts.
- Champs blancs, bordure définie, focus turquoise avec anneau discret.
- Élèves sélectionnés sous forme de pastilles compactes, avec compteur sur huit et
  retrait individuel explicite.
- Aperçu LDAP dans une surface calme ; les conflits et blocages utilisent le rouge
  uniquement lorsqu’une intervention de l’administrateur est nécessaire.
- En-têtes de tableaux gris clair, casse naturelle.
- Récréations et pause méridienne en ambre pâle dans les grilles.
- Détail du permis présenté dans un dialogue natif accessible, avec actions dues,
  points rendus et historique dans une même chronologie.
- Courrier famille toujours prévisualisé avant impression ; aucun envoi automatique.
- Interrupteur d’administration explicite pour le module points, accompagné de son
  état et de ses conséquences, sans supprimer les données lors de la désactivation.
- Action d’installation PWA visible : invite native lorsqu’elle existe, consigne
  adaptée sinon, et confirmation claire lorsque l’application est déjà installée.
- Bandeau de démonstration réservé au mode test ; aucune confusion possible avec
  l’environnement de production.
- Section d’administration « Protection et récupération » : badge d’environnement,
  dernier point, nombre conservé, volume MySQL cumulé et avertissement permanent
  « même base — pas une sauvegarde du serveur ».
- Liste des 30 points de récupération les plus récents avec date, origine, année
  et volumes ; aucune donnée nominative dans la liste.
- Parcours de purge et restauration en plusieurs étapes : aperçu des volumes,
  réauthentification LDAP ponctuelle à chaque action, phrase exacte liée à
  l’environnement et à l’année ou à l’identifiant du point, puis état de progression.
  Les actions dangereuses restent séparées des actions courantes.
- Avant toute purge ou restauration, la création du point préalable est visible et
  bloquante : un échec laisse les données intactes.
- Le bouton de purge en production nomme explicitement la production et ne partage
  ni apparence ni emplacement avec « Créer un point maintenant ».
- État d'envoi placé dans le formulaire, au même niveau que l'action principale :
  en cours, enregistré ou réessayer, sans bloquer silencieusement le bouton.
- Notifications personnelles regroupées dans un dialogue accessible depuis la
  barre supérieure, avec compteur non lu et action explicite « tout marquer comme lu ».
- Guide initial limité à trois ou quatre repères selon le rôle, affiché une fois et
  rouvert à la demande par le bouton d'aide.
- État du système présenté comme une liste de services lisibles (MySQL, LDAP,
  dossier `var`, récupération), suivi des indicateurs administratifs existants.
- Changement d'année présenté comme une séquence réelle en trois étapes : activer,
  importer, puis contrôler et clôturer.
