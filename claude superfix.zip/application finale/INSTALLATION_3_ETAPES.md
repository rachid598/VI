# Installer test et production sur Kwartz

Le même ZIP sert aux deux installations. Il ne faut ni fabriquer deux variantes
du code, ni enregistrer deux mots de passe MySQL dans la même configuration.

À la fin, l’architecture doit être exactement séparée ainsi :

| Environnement | Dossier web | Base MySQL | Utilisateur MySQL | Configuration |
| --- | --- | --- | --- | --- |
| Test | `suivi-test` | `suivi_test` | `suivi_test` | `suivi-test/var/settings.php` |
| Production | `suivi` | `suivi` | `suivi` | `suivi/var/settings.php` |

Chaque installation crée automatiquement un cookie limité à son propre chemin
web. Les sessions de `/suivi-test/` et `/suivi/` sont donc isolées sans modifier
manuellement le nom du cookie ou `var/settings.php`.

## 1. Installer la démonstration

1. Créer le dossier HTML `suivi-test` et y envoyer le contenu du ZIP.
2. Créer une base et un utilisateur MySQL réservés au test, par exemple :
   - base : `suivi_test` ;
   - utilisateur : `suivi_test`.
3. Ouvrir `https://votre-serveur:8443/suivi-test/install.php`.
4. Choisir **Test / démonstration**, saisir les identifiants de la base de test,
   puis confirmer l'installation avec le mot de passe Kwartz de
   l'administrateur initial. Ce mot de passe est seulement vérifié par LDAP et
   n'est pas enregistré.
5. Utiliser exclusivement des élèves et signalements fictifs.

Le bandeau de démonstration reste visible. Le permis à points est désactivé à
l’installation et peut être activé par l’administrateur pour le tester.

## 2. Installer la production

Après validation de la direction et du DPD :

1. Créer un dossier HTML séparé, par exemple `suivi`.
2. Envoyer exactement le même ZIP dans ce dossier.
3. Utiliser une autre base et un autre utilisateur MySQL, par exemple :
   - base : `suivi` ;
   - utilisateur : `suivi`.
4. Ouvrir `https://votre-serveur:8443/suivi/install.php`.
5. Choisir **Production**, saisir les identifiants de la base de production,
   puis confirmer avec le mot de passe Kwartz de l'administrateur initial.

Ne copiez jamais le `var/settings.php` du test vers la production : il contient
le mode, la clé de sécurité et les identifiants de sa propre base.

Les deux dossiers contiennent le même code applicatif, mais il doit bien rester
deux fichiers `var/settings.php`, deux bases et deux utilisateurs MySQL distincts.

## 3. Contrôler avant les données réelles

Dans l’installation de test :

1. créer, modifier puis retirer un signalement en attente ;
2. sélectionner plusieurs élèves et vérifier la création groupée ;
3. confirmer un signalement avec un compte CPE/AED ;
4. analyser le LDAP sans l’appliquer et contrôler les effectifs ;
5. activer puis désactiver le permis à points dans **Administration** ;
6. vérifier qu’il disparaît du menu lorsqu’il est désactivé ;
7. tester un point rendu, une action éducative, l’export et le courrier fictif ;
8. vérifier les rôles, l’historique, l’audit et les créneaux chauds ;
9. installer la PWA depuis le bouton proposé par l’application ;
10. exécuter la purge en aperçu avant tout nettoyage réel.

Avant l’ouverture de la production : sauvegarder séparément les deux couples
« base + `var/settings.php` », tester depuis la WebUI un point de récupération,
une purge puis une restauration, et contrôler que `/var`, `/database`, `/src` et
`/tools` répondent avec un refus d’accès HTTP dans les deux dossiers web. Aucune
tâche planifiée n’est nécessaire pour les points de récupération.
