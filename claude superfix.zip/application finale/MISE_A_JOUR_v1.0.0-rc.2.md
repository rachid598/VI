# Mise à jour vers Suivi des circulations v1.0.0-rc.2

## Avant de commencer

1. Tester d’abord dans le dossier et la base MySQL de test.
2. Créer un point de récupération manuel depuis **Administration**.
3. Conserver une copie de `var/settings.php` hors du dossier Web.

## Mise à jour de l’installation existante

Copier le contenu du ZIP par-dessus le dossier Web existant (`suivi` ou
`suivi-test`), sans supprimer ce dossier et sans remplacer le dossier `var` du
serveur. Le fichier `var/settings.php` conserve la connexion à la base MySQL.

À la première ouverture, la migration automatique passe le schéma MySQL en
version 8. Elle ajoute le contexte minimal du billet numérique aux observations
et tente de compléter les signalements déjà présents lorsque leur billet existe
encore. Les autres données et réglages sont conservés.

## Contrôles après la copie

1. Recharger l’application et accepter l’actualisation proposée par la PWA.
2. Vérifier que `v1.0.0-rc.2` apparaît sur la connexion ou dans le menu.
3. Vérifier que le curseur accepte toutes les valeurs de 0 à 20 minutes.
4. Créer un billet de test, puis un signalement pendant sa validité.
5. Ouvrir **À vérifier** avec un compte CPE/AED : la destination et le créneau
   du billet doivent apparaître, sans décision automatique.

Ne pas utiliser le même `var/settings.php` dans deux dossiers différents : la
liaison de sécurité entre le dossier et la base le refuse.
