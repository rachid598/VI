<?php

declare(strict_types=1);

/**
 * Tests automatisés des calculs critiques, sans aucune dépendance externe.
 *
 * Exécution (PHP 7.4 minimum, aucune base de données requise) :
 *     php tests/run-tests.php
 *
 * Le code de sortie vaut 0 si tous les tests passent, 1 sinon. Ce lanceur
 * n'ouvre aucune connexion MySQL ni LDAP : il teste uniquement les fonctions
 * de calcul pur via la réflexion, sans toucher aux données.
 */

if (PHP_SAPI !== 'cli') {
    http_response_code(404);
    exit;
}

error_reporting(E_ALL);
ini_set('display_errors', '1');

// Les classes sous test référencent HttpException, définie normalement par
// src/bootstrap.php (qui exige settings.php et MySQL). On fournit ici la même
// classe minimale pour tester sans installation.
if (!class_exists('HttpException')) {
    final class HttpException extends RuntimeException
    {
        /** @var int */
        private $status;

        public function __construct(int $status, string $message)
        {
            parent::__construct($message);
            $this->status = $status;
        }

        public function status(): int
        {
            return $this->status;
        }
    }
}

require_once dirname(__DIR__) . '/src/ApiController.php';
require_once dirname(__DIR__) . '/src/LdapAuthenticator.php';
require_once dirname(__DIR__) . '/src/RecoveryService.php';

final class TestRunner
{
    /** @var int */
    private $passed = 0;
    /** @var array<int,string> */
    private $failures = [];
    /** @var string */
    private $currentTest = '';

    public function run(string $name, callable $test): void
    {
        $this->currentTest = $name;
        try {
            $test($this);
            echo "  ✓ {$name}\n";
            $this->passed++;
        } catch (Throwable $error) {
            $this->failures[] = $name . ' — ' . $error->getMessage();
            echo "  ✗ {$name}\n      " . $error->getMessage() . "\n";
        }
    }

    public function assertSame($expected, $actual, string $detail = ''): void
    {
        if ($expected !== $actual) {
            throw new RuntimeException(sprintf(
                '%sattendu %s, obtenu %s',
                $detail !== '' ? $detail . ' : ' : '',
                var_export($expected, true),
                var_export($actual, true)
            ));
        }
    }

    public function assertTrue(bool $condition, string $detail): void
    {
        if (!$condition) {
            throw new RuntimeException($detail);
        }
    }

    public function assertThrowsHttp(int $expectedStatus, callable $callback, string $detail): void
    {
        try {
            $callback();
        } catch (HttpException $error) {
            $this->assertSame($expectedStatus, $error->status(), $detail . ' (code HTTP)');
            return;
        }
        throw new RuntimeException($detail . ' : aucune HttpException levée.');
    }

    public function summary(): int
    {
        $total = $this->passed + count($this->failures);
        echo "\n";
        if (count($this->failures) === 0) {
            echo "RÉSULTAT : {$this->passed}/{$total} tests réussis.\n";
            return 0;
        }
        echo "RÉSULTAT : {$this->passed}/{$total} tests réussis, " . count($this->failures) . " échec(s) :\n";
        foreach ($this->failures as $failure) {
            echo "  - {$failure}\n";
        }
        return 1;
    }
}

/**
 * Appelle une méthode privée sans exécuter le constructeur de la classe :
 * seules les fonctions de calcul pur, sans état, sont testées ainsi.
 * @param mixed $instance
 * @return mixed
 */
function callPrivate($instance, string $method, array $arguments)
{
    $reflection = new ReflectionMethod(get_class($instance), $method);
    $reflection->setAccessible(true);
    return $reflection->invokeArgs($instance, $arguments);
}

/** @return mixed */
function bareInstance(string $class)
{
    return (new ReflectionClass($class))->newInstanceWithoutConstructor();
}

$runner = new TestRunner();
$controller = bareInstance('ApiController');
$ldap = bareInstance('LdapAuthenticator');

echo "Tests de « Suivi des circulations » — PHP " . PHP_VERSION . "\n\n";
echo "Protection CSV (safeCsvCell)\n";

$runner->run('neutralise les formules commençant par =, +, - et @', function (TestRunner $t) use ($controller): void {
    $t->assertSame("'=SUM(A1:A9)", callPrivate($controller, 'safeCsvCell', ['=SUM(A1:A9)']));
    $t->assertSame("'+331234", callPrivate($controller, 'safeCsvCell', ['+331234']));
    $t->assertSame("'-2+3", callPrivate($controller, 'safeCsvCell', ['-2+3']));
    $t->assertSame("'@commande", callPrivate($controller, 'safeCsvCell', ['@commande']));
});

$runner->run('laisse intactes les valeurs ordinaires et accentuées', function (TestRunner $t) use ($controller): void {
    $t->assertSame('Durand', callPrivate($controller, 'safeCsvCell', ['Durand']));
    $t->assertSame('Élise', callPrivate($controller, 'safeCsvCell', ['Élise']));
    $t->assertSame('6G2', callPrivate($controller, 'safeCsvCell', ['6G2']));
    $t->assertSame('', callPrivate($controller, 'safeCsvCell', ['']));
});

echo "\nAnalyse CSV SIECLE (normalizeHeader / cleanCell)\n";

$runner->run('normalise les en-têtes : BOM, accents, espaces, casse', function (TestRunner $t) use ($controller): void {
    $t->assertSame('nomdefamille', callPrivate($controller, 'normalizeHeader', ["\xEF\xBB\xBFNom de famille"]));
    $t->assertSame('prenom', callPrivate($controller, 'normalizeHeader', ['Prénom']));
    $t->assertSame('classe', callPrivate($controller, 'normalizeHeader', ['  CLASSE  ']));
});

$runner->run('nettoie les cellules : octets nuls et caractères de contrôle', function (TestRunner $t) use ($controller): void {
    $t->assertSame('Martin', callPrivate($controller, 'cleanCell', ["Mar\0tin"]));
    $t->assertSame('Nadia', callPrivate($controller, 'cleanCell', ["\x01Nadia\x1F"]));
    $t->assertSame('Lou Anne', callPrivate($controller, 'cleanCell', ['  Lou Anne  ']));
});

echo "\nLongueurs et casse UTF-8 (length / lower)\n";

$runner->run('compte les caractères, pas les octets', function (TestRunner $t) use ($controller): void {
    $t->assertSame(4, callPrivate($controller, 'length', ['aéîo']));
    $t->assertSame(0, callPrivate($controller, 'length', ['']));
    $t->assertSame(160, callPrivate($controller, 'length', [str_repeat('é', 160)]));
});

$runner->run('met en minuscules y compris les capitales accentuées', function (TestRunner $t) use ($controller): void {
    $t->assertSame('élise', callPrivate($controller, 'lower', ['ÉLISE']));
    $t->assertSame('r.elguimar', callPrivate($controller, 'lower', ['R.ELGUIMAR']));
});

echo "\nCréneaux du collège (schoolTimeSlot)\n";

$slotAt = static function (string $time) use ($controller): ?string {
    $date = new DateTimeImmutable('2026-09-15 ' . $time, new DateTimeZone('Europe/Paris'));
    return callPrivate($controller, 'schoolTimeSlot', [$date]);
};

$runner->run('borne chaque créneau du matin à la minute près', function (TestRunner $t) use ($slotAt): void {
    $t->assertSame('Accueil', $slotAt('07:30'), '07:30');
    $t->assertSame('Accueil', $slotAt('08:04'), '08:04');
    $t->assertSame('M1', $slotAt('08:05'), '08:05');
    $t->assertSame('M1', $slotAt('09:02'), '09:02');
    $t->assertSame('M2', $slotAt('09:03'), '09:03');
    $t->assertSame('M2', $slotAt('09:57'), '09:57');
    $t->assertSame('Récréation matin', $slotAt('09:58'), '09:58');
    $t->assertSame('Récréation matin', $slotAt('10:16'), '10:16');
    $t->assertSame('M3', $slotAt('10:17'), '10:17');
    $t->assertSame('M4', $slotAt('11:15'), '11:15');
});

$runner->run("borne l'après-midi et retourne null hors ouverture", function (TestRunner $t) use ($slotAt): void {
    $t->assertSame('Pause méridienne', $slotAt('12:10'), '12:10');
    $t->assertSame('S1', $slotAt('13:35'), '13:35');
    $t->assertSame('S2', $slotAt('14:33'), '14:33');
    $t->assertSame('Récréation après-midi', $slotAt('15:28'), '15:28');
    $t->assertSame('S3', $slotAt('15:47'), '15:47');
    $t->assertSame('S4', $slotAt('16:42'), '16:42');
    $t->assertSame('S4', $slotAt('17:29'), '17:29');
    $t->assertSame(null, $slotAt('17:30'), '17:30');
    $t->assertSame(null, $slotAt('22:00'), '22:00');
});

echo "\nDates locales Paris → UTC (parseOptionalLocalDateTime)\n";

$runner->run('convertit une date seule en fin de journée locale', function (TestRunner $t) use ($controller): void {
    // Le 15 mars, Paris est en heure d'hiver (UTC+1).
    $t->assertSame('2026-03-15 22:59:59', callPrivate($controller, 'parseOptionalLocalDateTime', ['2026-03-15']));
    // Le 15 juillet, Paris est en heure d'été (UTC+2).
    $t->assertSame('2026-07-15 21:59:59', callPrivate($controller, 'parseOptionalLocalDateTime', ['2026-07-15']));
});

$runner->run('convertit une date-heure locale précise', function (TestRunner $t) use ($controller): void {
    $t->assertSame('2026-07-15 08:30:00', callPrivate($controller, 'parseOptionalLocalDateTime', ['2026-07-15T10:30']));
    $t->assertSame('2026-01-15 09:30:00', callPrivate($controller, 'parseOptionalLocalDateTime', ['2026-01-15T10:30']));
});

$runner->run('vide → null, formats invalides → erreur 422', function (TestRunner $t) use ($controller): void {
    $t->assertSame(null, callPrivate($controller, 'parseOptionalLocalDateTime', ['']));
    $t->assertThrowsHttp(422, static function () use ($controller): void {
        callPrivate($controller, 'parseOptionalLocalDateTime', ['15/07/2026']);
    }, 'format français rejeté');
    $t->assertThrowsHttp(422, static function () use ($controller): void {
        callPrivate($controller, 'parseOptionalLocalDateTime', ['2026-02-30']);
    }, 'date inexistante rejetée');
});

echo "\nFenêtres de trimestre (trimesterWindow / shiftPointsDate)\n";

$pointsConfig = [
    'trimesters' => [
        ['label' => 'Trimestre 1', 'start' => '2020-07-01', 'end' => '2020-11-30'],
        ['label' => 'Trimestre 2', 'start' => '2020-12-01', 'end' => '2021-02-28'],
        ['label' => 'Trimestre 3', 'start' => '2021-03-01', 'end' => '2021-07-04'],
    ],
];

$runner->run('retourne la fenêtre exacte du trimestre demandé', function (TestRunner $t) use ($controller, $pointsConfig): void {
    $t->assertSame(
        [1, '2020-07-01 00:00:00', '2020-11-30 23:59:59'],
        callPrivate($controller, 'trimesterWindow', [$pointsConfig, 1])
    );
    $t->assertSame(
        [2, '2020-12-01 00:00:00', '2021-02-28 23:59:59'],
        callPrivate($controller, 'trimesterWindow', [$pointsConfig, 2])
    );
    $t->assertSame(
        [3, '2021-03-01 00:00:00', '2021-07-04 23:59:59'],
        callPrivate($controller, 'trimesterWindow', [$pointsConfig, 3])
    );
});

$runner->run('replie un numéro hors limites sur le premier trimestre (dates passées)', function (TestRunner $t) use ($controller, $pointsConfig): void {
    // Les dates de ce jeu d'essai sont passées : aucun trimestre ne contient
    // la date du jour, le calcul doit donc retomber sur le premier.
    $window = callPrivate($controller, 'trimesterWindow', [$pointsConfig, 99]);
    $t->assertSame(1, $window[0]);
});

$runner->run('décale une date de configuration d’une année exacte', function (TestRunner $t) use ($controller): void {
    $t->assertSame('2027-07-01', callPrivate($controller, 'shiftPointsDate', ['2026-07-01', 1]));
    $t->assertSame('2025-12-01', callPrivate($controller, 'shiftPointsDate', ['2026-12-01', -1]));
    $t->assertSame('pas-une-date', callPrivate($controller, 'shiftPointsDate', ['pas-une-date', 1]));
});

echo "\nAnnuaire LDAP (échappement et lecture des entrées)\n";

$runner->run('échappe les caractères spéciaux des filtres LDAP', function (TestRunner $t) use ($ldap): void {
    $escaped = callPrivate($ldap, 'escapeFilterValue', ['a*(b)\\c']);
    $t->assertTrue(strpos($escaped, '*') === false, 'l’astérisque doit être échappé : ' . $escaped);
    $t->assertTrue(strpos($escaped, '(') === false, 'la parenthèse ouvrante doit être échappée : ' . $escaped);
    $t->assertTrue(strpos($escaped, ')') === false, 'la parenthèse fermante doit être échappée : ' . $escaped);
    $t->assertSame('durand', callPrivate($ldap, 'escapeFilterValue', ['durand']), 'valeur ordinaire inchangée');
});

$runner->run('lit les entrées LDAP au format count/index', function (TestRunner $t) use ($ldap): void {
    $entry = [
        'memberuid' => ['count' => 2, 0 => 'eleve1', 1 => 'eleve2'],
        'givenname' => ['count' => 1, 0 => 'Nadia'],
    ];
    $t->assertSame(['eleve1', 'eleve2'], callPrivate($ldap, 'values', [$entry, 'memberUid']));
    $t->assertSame('Nadia', callPrivate($ldap, 'firstValue', [$entry, 'givenName']));
    $t->assertSame([], callPrivate($ldap, 'values', [$entry, 'absent']));
    $t->assertSame('', callPrivate($ldap, 'firstValue', [$entry, 'absent']));
});

echo "\nInstantanés de récupération (signature HMAC)\n";

$runner->run('la signature dépend de la clé, du contexte et du contenu', function (TestRunner $t): void {
    $service = bareInstance('RecoveryService');
    $keyProperty = new ReflectionProperty('RecoveryService', 'appKey');
    $keyProperty->setAccessible(true);
    $keyProperty->setValue($service, str_repeat('k', 64));
    $context = ['kind' => 'manual', 'environment' => 'test', 'payload_sha256' => hash('sha256', 'données')];

    $first = callPrivate($service, 'payloadHmac', [$context, 'données']);
    $second = callPrivate($service, 'payloadHmac', [$context, 'données']);
    $t->assertSame($first, $second, 'signature déterministe');
    $t->assertTrue(preg_match('/^[a-f0-9]{64}$/', $first) === 1, 'format SHA-256 hexadécimal');

    $otherPayload = callPrivate($service, 'payloadHmac', [$context, 'données modifiées']);
    $t->assertTrue($first !== $otherPayload, 'un contenu modifié change la signature');

    $otherContext = callPrivate($service, 'payloadHmac', [array_merge($context, ['kind' => 'automatic']), 'données']);
    $t->assertTrue($first !== $otherContext, 'un contexte modifié change la signature');

    $keyProperty->setValue($service, str_repeat('x', 64));
    $otherKey = callPrivate($service, 'payloadHmac', [$context, 'données']);
    $t->assertTrue($first !== $otherKey, 'une autre clé change la signature');
});

exit($runner->summary());
