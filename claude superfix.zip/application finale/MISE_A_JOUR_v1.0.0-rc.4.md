# Mise à jour vers 1.0.0-rc.4

Cette mise à jour conserve la base MySQL et la configuration existantes.
Aucune migration de schéma : la base reste en version 9.

## Avant la mise à jour

1. Créer un point de récupération depuis l’administration.
2. Conserver une copie du fichier `var/settings.php` présent sur le serveur.

## Fichiers à téléverser

- `index.html`
- `service-worker.js`
- `VERSION`
- `CHANGELOG.md`
- `CONSERVATION_ET_PURGE.md`
- `assets/app.js`
- `assets/app.css`
- `install.php` (utile seulement pour de futures installations)
- `tests/` (nouveau dossier complet, avec son `.htaccess`)
- `tools/purge-rgpd.sh` (nouveau)
- `tools/verifier-deploiement.php` (nouveau)

Il est également possible de remplacer tout le dossier par le contenu du ZIP,
à condition de conserver le fichier `var/settings.php` déjà installé.

## Après le téléversement

1. Ouvrir l’application : si le bandeau « nouvelle version » apparaît,
   choisir **Actualiser**.
2. Vérifier le déploiement une fois :
   `php tools/verifier-deploiement.php https://serveur/suivi/`
   (ajouter `--insecure` si le certificat Kwartz est auto-signé).
3. Lancer les tests automatisés une fois : `php tests/run-tests.php`.
4. Programmer la purge RGPD de fin d’année (voir `CONSERVATION_ET_PURGE.md`) :
   `30 3 1 * * /bin/sh /chemin/vers/suivi/tools/purge-rgpd.sh`

## Administrateur de secours pour les installations existantes

Le formulaire d’installation propose désormais un second administrateur.
Pour une installation déjà en place, il s’ajoute sans réinstaller : éditer
`var/settings.php` et compléter la liste `bootstrap_admins`, par exemple :

```php
'bootstrap_admins' => ['premier.admin', 'second.admin'],
```

L’identifiant doit exister dans l’annuaire Kwartz. Conserver les droits du
fichier (0600) après modification.

## Saisie hors connexion

Un constat envoyé pendant une coupure réseau est désormais conservé sur
l’appareil (12 heures maximum, 10 constats maximum, par utilisateur) puis
transmis automatiquement dès la reconnexion, sans doublon grâce à la clé
d’envoi. L’heure du constat reste calculée par le serveur : si le délai de
reconnexion dépasse les 20 minutes de recul autorisées, l’heure est plafonnée
et l’utilisateur en est informé.
