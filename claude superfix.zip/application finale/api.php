<?php

declare(strict_types=1);

// Ne jamais afficher les erreurs PHP dans une réponse HTTP et empêcher les
// traces d'exception d'inclure les arguments des fonctions (un mot de passe
// LDAP peut notamment transiter par ces arguments).
ini_set('display_errors', '0');
ini_set('log_errors', '1');
ini_set('zend.exception_ignore_args', '1');

if (!is_file(__DIR__ . '/var/settings.php')) {
    http_response_code(503);
    header('Content-Type: application/json; charset=utf-8');
    header('Cache-Control: no-store');
    echo json_encode([
        'error' => 'Installation requise.',
        'installation_required' => true,
    ], JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
    exit;
}

try {
    require __DIR__ . '/src/bootstrap.php';
    require_once __DIR__ . '/src/ApiController.php';
    $action = isset($_GET['action']) ? (string) $_GET['action'] : 'session';
    $controller = new ApiController(
        $database,
        $auth,
        $config,
        $ldapAuthenticator,
        $recoveryService,
        $digitalPassService,
        $finalAdminService
    );
    $controller->dispatch($action);
} catch (HttpException $error) {
    emitApiError($error->getMessage(), $error->status());
} catch (InstallationBindingException $error) {
    emitApiError(
        'Cette installation n’est pas liée à ce dossier ou à cette base MySQL. Contactez l’administrateur Kwartz.',
        503
    );
} catch (LdapAuthenticationException $error) {
    emitApiError($error->getMessage(), 401);
} catch (RecoveryBusyException $error) {
    emitApiError('Une sauvegarde ou restauration est déjà en cours. Réessayez dans quelques secondes.', 423);
} catch (RecoveryValidationException $error) {
    emitApiError($error->getMessage(), 409);
} catch (Throwable $error) {
    $reference = bin2hex(random_bytes(6));
    // Conserver assez d'informations pour retrouver l'incident sans écrire le
    // message ni la trace complète, qui peuvent contenir des données saisies.
    error_log(sprintf(
        '[Suivi circulations %s] %s code=%d source=%s:%d',
        $reference,
        get_class($error),
        (int) $error->getCode(),
        basename($error->getFile()),
        $error->getLine()
    ));
    emitApiError('Une erreur technique est survenue. Référence : ' . $reference, 500);
}

function emitApiError(string $message, int $status): void
{
    if (function_exists('jsonResponse')) {
        jsonResponse(['error' => $message], $status);
    }
    http_response_code($status);
    header('Content-Type: application/json; charset=utf-8');
    header('Cache-Control: no-store');
    echo json_encode(['error' => $message], JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
    exit;
}
