# Mise à jour vers Suivi des circulations v1.0.0-rc.1

## Avant de commencer

1. Tester d’abord dans le dossier et la base MySQL de test.
2. Créer un point de récupération manuel depuis **Administration**.
3. Conserver une copie de `var/settings.php` hors du dossier Web.

## Mise à jour d’une installation existante

Copier le contenu de ce dossier par-dessus le dossier Web existant (`suivi` ou
`suivi-test`), mais **ne pas remplacer le dossier `var` du serveur**. Le fichier
`var/settings.php` existant garde la connexion à la même base MySQL.

À la première ouverture, l’application applique automatiquement la migration
de schéma v7. Les observations, comptes, rôles, réglages et points existants sont
conservés. Le module **Billets numériques** reste désactivé jusqu’à son activation
explicite dans **Administration**.

## Fichiers à copier

- `index.html`, `api.php`, `install.php`, `.htaccess` ;
- `assets/`, `src/`, `database/`, `tools/` ;
- `manifest.json`, `manifest.webmanifest`, `service-worker.js`.

Les fichiers Markdown et le dossier `donnees/` sont de la documentation et des
données fictives : ils ne sont pas nécessaires au fonctionnement en production.

## Contrôle après copie

1. Recharger l’application et accepter l’actualisation PWA si elle est proposée.
2. Vérifier la connexion LDAP, la recherche d’un élève et un signalement fictif.
3. Vérifier la file **À vérifier**, puis le rapport anonymisé.
4. Dans **Administration**, contrôler la santé, les effectifs et le dernier point
   de récupération.

Ne pas installer une seconde copie dans un autre chemin avec le même
`var/settings.php` : la liaison de sécurité entre le dossier et la base le refuse.
