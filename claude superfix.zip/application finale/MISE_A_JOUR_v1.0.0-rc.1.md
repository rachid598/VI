# Mise à jour vers Suivi des circulations v1.0.0-rc.1

## Avant de commencer

1. Tester d’abord dans le dossier et la base MySQL de test.
2. Créer un point de récupération manuel depuis **Administration**.
3. Conserver une copie de `var/settings.php` hors du dossier Web.

## Mise à jour de l’installation existante

Copier le contenu du ZIP par-dessus le dossier Web existant (`suivi` ou
`suivi-test`), sans supprimer ce dossier et sans remplacer le dossier `var` du
serveur. Le fichier `var/settings.php` conserve la connexion à la base MySQL
existante.

À la première ouverture, la migration du schéma MySQL est automatique. Les
observations, comptes, rôles, réglages et points sont conservés. Le module
**Billets numériques** reste désactivé jusqu’à son activation dans
**Administration**.

## Contrôles après la copie

1. Recharger l’application et accepter l’actualisation proposée par la PWA.
2. Vérifier que `v1.0.0-rc.1` apparaît sur la connexion ou dans le menu.
3. Tester la connexion LDAP, la recherche d’un élève et un signalement fictif.
4. Vérifier la file **À vérifier**, le tableau de bord et la santé de l’application.

Ne pas utiliser le même `var/settings.php` dans deux dossiers différents : la
liaison de sécurité entre le dossier et la base le refuse.
