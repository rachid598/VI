# Mise à jour vers la fusion

## Deux installations, une seule archive

Le même ZIP sert à mettre à jour `suivi-test` et `suivi`. Il est copié séparément
dans chacun des deux dossiers web. Cela ne fusionne pas les environnements :

- `suivi-test` conserve sa base et son utilisateur MySQL `suivi_test`, ainsi que
  `suivi-test/var/settings.php` ;
- `suivi` conserve sa base et son utilisateur MySQL `suivi`, ainsi que
  `suivi/var/settings.php`.

Les cookies restent automatiquement isolés par les chemins `/suivi-test/` et
`/suivi/`. Il n’y a aucun nom de session à modifier lors d’une mise à jour.

## Sauvegarde préalable

Avant de mettre à jour un dossier, faire un dump de **sa** base MySQL :
`suivi_test` pour le test, `suivi` pour la production. La migration est additive
et idempotente, mais la sauvegarde reste obligatoire pour chaque environnement.

Sauvegarder également le `var/settings.php` du dossier concerné dans un
emplacement protégé hors du dossier HTML. Il contient le mot de passe MySQL et la
clé de sécurité : ne pas l’ajouter au ZIP, l’envoyer par courriel ou le remplacer
par celui de l’autre environnement. La procédure complète se trouve dans
`SAUVEGARDE_CONFIGURATION.md`.

## Mise à jour d’un dossier de fusion existant

Mettre à jour un dossier à la fois. Copier les fichiers du même ZIP par-dessus
l’installation en conservant son propre `var/settings.php`. Le ZIP livré n’inclut
jamais ce fichier. Au premier chargement de cet environnement, le migrateur passe
sa base au schéma version 6 et crée :

- `point_adjustments` ;
- `action_records`.

Il ne supprime ni ne transforme les signalements, comptes, élèves ou journaux.

### Liaison de sécurité entre le dossier et sa base

Au premier chargement de cette version, la base est automatiquement liée à
l'identifiant de son `settings.php`, à son environnement et à une empreinte du
chemin réel du dossier. Copier par erreur `settings.php` dans un autre dossier ne
permet donc plus aux deux copies d'utiliser la même base.

Ne renommez et ne déplacez pas un dossier `suivi` ou `suivi-test` sans préparer
la reliaison. Un déplacement volontaire ne demande **pas** de réinstaller
l'application ni de recréer la base, mais il doit être réalisé en maintenance :

1. sauvegarder la base et `var/settings.php` ;
2. fermer temporairement l'accès à l'application ;
3. retirer la clé `installation_scope_hash` de la section `app` de
   `var/settings.php` ;
4. supprimer uniquement la ligne `installation_scope_hash` de `app_settings` ;
5. ouvrir une fois l'application depuis son nouveau dossier, puis contrôler
   l'environnement et la base affichés.

Cette procédure doit rester encadrée par l'administrateur Kwartz ; il ne faut
jamais supprimer `installation_id` pour contourner un conflit de base.

## Configuration facultative

La section `points` de `var/settings.php` peut contenir :

- `capital` et `alert_threshold` ;
- `trimesters` ;
- `action_thresholds` ;
- `college_name` ;
- `letter_template`.

Des valeurs sûres par défaut sont utilisées si ces nouvelles clés sont absentes.

La section `ldap` peut aussi préciser :

- `class_group_pattern` (défaut : `^c([3-6])g([0-9]{1,2})$`) ;
- `class_label_format` (défaut : `{n}G{g}`).

Ces deux clés sont facultatives : une installation existante fonctionne sans
modifier `var/settings.php`.

Pour une configuration ancienne, il est recommandé d’ajouter explicitement dans
la section `app` :

```php
'environment' => 'test', // dans suivi-test
```

ou :

```php
'environment' => 'production', // dans suivi
```

Si cette clé manque, un dossier dont le nom contient `test` ou `demo` est traité
comme un environnement de test ; tous les autres noms sont traités prudemment
comme la production. Cette déduction évite de présenter une installation inconnue
comme un test, mais une valeur explicite reste plus sûre avant d’activer la purge.

## Synchronisation LDAP des élèves

Dans **Administration**, lancer d’abord **Analyser l’annuaire**. Le bouton
d’application n’apparaît qu’après un aperçu valide. L’application refait la
lecture LDAP et refuse la mise à jour si le résultat a changé ou s’il représente
moins de 80 % de l’effectif actif existant. Le CSV reste disponible en secours.

La synchronisation réutilise les tables `students` et `student_imports` de
l’installation ouverte. Elle n’ajoute aucune table et ne change jamais de base ni
d’utilisateur MySQL : le test reste sur `suivi_test`, la production sur `suivi`.

## Cache

Le cache PWA intègre automatiquement l’adresse complète du dossier dans son nom.
`suivi-test` et `suivi` ne partagent donc pas leur cache. Après envoi des fichiers,
recharger deux fois chaque installation pour activer la nouvelle version ; le
cache de l'autre dossier n'est pas supprimé.

## Correctif de connexion du 13 juillet 2026

Cette livraison empêche une soumission native du formulaire en `GET` lorsque le
JavaScript est indisponible ou n'a pas encore fini de charger. Le bouton reste
désactivé jusqu'à la récupération du jeton de sécurité, et le formulaire de
secours utilise explicitement `POST`.

Le fichier `assets/url-sanitizer.js` retire aussi `username` et `password` de
l'adresse visible si une ancienne URL contaminée est rouverte. Ce nettoyage ne
peut pas effacer les journaux serveur déjà écrits : si un vrai mot de passe est
apparu dans une URL, le changer puis faire traiter les journaux par
l'administrateur Kwartz selon la procédure de l'établissement.

Après la mise à jour, ouvrir l'URL propre et recharger deux fois. Pour contrôler
le correctif sans exposer de secret, tenter une connexion avec un identifiant
inexistant et un mot de passe entièrement fictif : l'adresse doit rester sur
`index.html`, sans `?username=` ni `?password=`.

## Récupération et purge WebUI

La mise à jour ajoute une récupération locale pilotée par l’activité de la WebUI.
Chaque installation conserve uniquement les points présents dans sa propre base :
`suivi-test` ne peut ni afficher ni restaurer ceux de `suivi`, et inversement.

Avant la première utilisation en production :

1. conserver le dump MySQL externe et le `var/settings.php` décrits plus haut ;
2. ouvrir l’administration et vérifier que l’environnement affiché est correct ;
3. créer un point manuel avec des données fictives dans le test ;
4. tester une restauration puis une purge et la restauration « avant purge » ;
5. contrôler que comptes, accès, réglages et audit n’ont pas été remplacés ;
6. mesurer le volume de stockage après plusieurs points.

La cadence de 30 minutes n’est pas une horloge serveur : un point est créé par la
première activité authentifiée admissible après ce délai. Aucune WebUI active
signifie aucun nouveau point. La rétention de sept jours, le plafond de 400 points
et la limite cumulée de 512 Mio par environnement sont également appliqués lors
de l’activité suivante.

Ces points sont dans la même base que l’application. Ils permettent un retour
rapide après une erreur, mais ne remplacent pas le dump MySQL externe préalable à
une mise à jour ou à une opération sensible. La procédure et les limites complètes
sont détaillées dans `RECUPERATION_WEBUI.md`.
