# Historique des versions

## 1.0.0-rc.4 — 19 juillet 2026

### Saisie hors connexion

- un constat envoyé pendant une coupure réseau est conservé sur l’appareil puis
  transmis automatiquement à la reconnexion, sans doublon grâce à la clé d’envoi ;
- file locale strictement bornée : 10 constats et 12 heures maximum, propre à
  chaque utilisateur, effacée dès l’envoi ou l’abandon explicite ;
- bannière dédiée sur l’écran de saisie : liste des constats en attente, envoi
  manuel et abandon possible ; un refus du serveur n’est jamais forcé ;
- l’heure du constat reste calculée par le serveur ; au-delà du recul autorisé
  de 20 minutes, elle est plafonnée et l’auteur en est informé ;
- le formulaire de saisie reste utilisable hors connexion même si la liste
  « Mes signalements » est momentanément indisponible.

### Exploitation et conformité

- tests automatisés des calculs critiques sans dépendance ni base de données :
  `php tests/run-tests.php` (protection CSV, créneaux, dates Paris/UTC,
  trimestres, LDAP, signature des instantanés) ;
- purge RGPD de fin d’année programmable : nouvelle enveloppe cron
  `tools/purge-rgpd.sh` avec journal dans `var/purge-rgpd.log`, documentée dans
  `CONSERVATION_ET_PURGE.md` — chaque année scolaire terminée est purgée
  automatiquement à l’issue de son délai de conservation ;
- vérification du déploiement en une commande :
  `php tools/verifier-deploiement.php https://serveur/suivi/` contrôle les
  en-têtes de sécurité, le refus (403) des dossiers sensibles et les
  extensions PHP ;
- l’installateur accepte un administrateur de secours facultatif, vérifié dans
  l’annuaire, pour conserver un accès admin si le compte initial disparaît.

### Versions techniques

- schéma MySQL : `9` (inchangé) ;
- format des données de récupération : `10` (inchangé).

## 1.0.0-rc.3 — 17 juillet 2026

### Fiabilité et accompagnement

- prévention précise d’un même constat renvoyé par le même auteur dans un délai de deux minutes ;
- clé d’envoi conservée lors d’une coupure réseau afin qu’un nouvel essai ne crée pas de doublon ;
- états visibles « envoi », « enregistré » et « réessayer » dans le formulaire ;
- notifications internes lorsqu’un constat personnel est confirmé ou annulé ;
- guide de première connexion affiché une fois, puis accessible depuis le bouton d’aide ;
- page d’état enrichie pour MySQL, LDAP, le dossier `var` et la fraîcheur de la récupération ;
- parcours guidé pour activer une nouvelle année, importer les élèves et clôturer l’ancienne ;
- bilan hebdomadaire anonymisé proposé par défaut, avec périodes étendues toujours disponibles.

### Versions techniques

- schéma MySQL : `9` ;
- format des données de récupération : `10`, avec restauration compatible des instantanés antérieurs.

## 1.0.0-rc.2 — 16 juillet 2026

### Améliorations

- remplacement des quatre choix horaires par un curseur précis de 0 à 20 minutes ;
- affichage immédiat de l’heure du constat calculée depuis l’horloge du serveur ;
- conservation du contexte minimal du billet numérique valable au moment du constat ;
- affichage de ce billet dans la file CPE/AED et dans les parcours rapprochés ;
- reprise automatique du contexte pour les signalements déjà présents lors de
  la migration, lorsque le billet correspondant existe encore ;
- aucune confirmation ou annulation automatique liée au billet.

### Versions techniques

- schéma MySQL : `8` ;
- format des données de récupération : `9`, avec restauration compatible des
  instantanés antérieurs.

## 1.0.0-rc.1 — 16 juillet 2026

Première version candidate complète de **Suivi des circulations**.

### Principales fonctions

- signalements horodatés, modifiables et vérifiés par la vie scolaire ;
- suivi explicite des parcours rapprochés ;
- tableau de bord, créneaux chauds et rapport anonymisé ;
- rôles LDAP, bilan professeur principal et journal des actions ;
- permis à points facultatif ;
- billets numériques facultatifs, désactivés par défaut ;
- sauvegardes de récupération, purge contrôlée et clôture annuelle ;
- PWA installable avec thèmes clair et sombre.

### Statut

Version candidate destinée aux essais sur l’installation de test. Elle deviendra
`1.0.0` après validation sur Kwartz avec LDAP et MySQL.
